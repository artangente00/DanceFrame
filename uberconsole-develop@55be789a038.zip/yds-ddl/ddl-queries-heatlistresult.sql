
-- Create SQL Queries to return data for each of the following:

-- List of Events
SELECT * FROM uberconsole.tbl_event

-- List of Events that have Results information
SELECT * FROM uberconsole.tbl_hrresult where event_id=$1;
-- ($1 is the eventid)

SELECT 
    a.result_id,
    a.judgepanel,
    a.scoreheaders,
    b.event_id,
    b.event_name,
    b.date_start,
    b.date_stop
FROM uberconsole.tbl_hrresult a
JOIN uberconsole.tbl_event b
ON	b.event_id = a.event_id
WHERE b.even_id=$1


-- For a specific event (where by event name & year), List Heats IDs 

SELECT 
    a.heat_id,
    a.heat_name,
    a.heat_time,
    a.heat_date,
    a.description,
    b.event_id,
    b.event_name,
    b.date_start,
    b.date_stop,
    b.event_year
FROM uberconsole.tbl_hrheats a
JOIN uberconsole.tbl_event b
ON	b.event_id = a.event_id
WHERE b.event_year=2018


--  list all events where they have results, For a specific person,
-- use person key or name
SELECT 
	*
FROM uberconsole.tbl_event
WHERE event_id IN (
    SELECT DISTINCT
        event_id
    FROM (
        SELECT
            x.result_id,
            x.event_id,
            x.judgepanel,
            x.scoreheaders,
            x.subheat_id,
            x.couple_id,
            x.couple_value,
            x.couple_key,
            x.person_key,
            z.person_id,
            z.competitor_num,
            z.masterperson_id,
            y.firstname,
            y.lastname,
            y.gender,
            y.persontype,
            y.nickname,
            y.ndcaus_num
        FROM (
            SELECT 
                a.result_id,
                a.event_id,
                a.judgepanel,
                a.scoreheaders,
                a.subheat_id,
                b.couple_id,
                b.couple_value,
                c.couple_key,
                c.person1_key as person_key
            FROM uberconsole.tbl_hrresult a
            JOIN uberconsole.tbl_hrmarks b
            ON 	b.result_id = a.result_id
            AND b.event_id = a.event_id
            JOIN uberconsole.tbl_hrcouples c
            ON 	c.couple_id=b.couple_id
            AND c.event_id =b.event_id
            UNION
            SELECT 
                a.result_id,
                a.event_id,
                a.judgepanel,
                a.scoreheaders,
                a.subheat_id,
                b.couple_id,
                b.couple_value,
                c.couple_key,
                c.person2_key
            FROM uberconsole.tbl_hrresult a
            JOIN uberconsole.tbl_hrmarks b
            ON b.result_id = a.result_id
            AND b.event_id = a.event_id
            JOIN uberconsole.tbl_hrcouples c
            ON c.couple_id=b.couple_id
            AND c.event_id =b.event_id
        ) as x
        JOIN uberconsole.tbl_hrpersons z
        ON 	z.person_key=x.person_key
        AND z.event_id=x.event_id
        JOIN uberconsole.tbl_masterpersons y
        ON y.masterperson_id = z.masterperson_id
    ) as w
    -- WHERE w.person_key='13717'
    WHERE w.lastname= 'Rybczynski'
	AND w.firstname='Erwin'
)

-- List Heat IDs For a specific person, and specific event,
-- use person key or name
-- (1)
SELECT
	heat_id,
    heat_name,
    heat_session,
    heat_time,
    heat_date,
    heat_type
    description,
    event_id,
    xml_id
FROM uberconsole.tbl_hrheats
WHERE heat_id IN (
	SELECT
    	heat_id
    FROM (
        SELECT
            x.event_id,
            x.subheat_id,
            x.person_key,
            j.heat_id,
            j.subheat_key,
            j.subheat_type,
            j.subheat_dance,
            j.subheat_level,
            j.subheat_age,
            z.person_id,
            z.competitor_num,
            z.masterperson_id,
            y.firstname,
            y.lastname,
            y.gender,
            y.persontype,
            y.nickname,
            y.ndcaus_num
        FROM (
            SELECT 
                f.event_id,
                f.subheat_id,
                f.person_key
            FROM (
                SELECT 
                    a.event_id,
                    a.subheat_id,
                    b.person1_key as person_key
                FROM uberconsole.tbl_hrmarks a
                JOIN uberconsole.tbl_hrcouples b
                ON 	b.couple_id=a.couple_id
                AND b.event_id =a.event_id
                UNION
                SELECT 
                    a.event_id,
                    a.subheat_id,
                    b.person2_key as person_key
                FROM uberconsole.tbl_hrmarks a
                JOIN uberconsole.tbl_hrcouples b
                ON 	b.couple_id=a.couple_id
                AND b.event_id =a.event_id
                UNION
                SELECT 
                    a.event_id,
                    a.subheat_id,
                    b.person1_key as person_key
                FROM uberconsole.tbl_hrcoupleentries a
                JOIN uberconsole.tbl_hrcouples b
                ON 	b.couple_id=a.couple_id
                AND b.event_id =a.event_id
                UNION
                SELECT 
                    a.event_id,
                    a.subheat_id,
                    b.person2_key as person_key
                FROM uberconsole.tbl_hrcoupleentries a
                JOIN uberconsole.tbl_hrcouples b
                ON 	b.couple_id=a.couple_id
                AND b.event_id =a.event_id
                UNION
                SELECT
                    a.event_id,
                    a.subheat_id,
                    a.person_key
                FROM uberconsole.tbl_hrsoloentries a
            ) as f ORDER BY event_id, subheat_id, person_key
        ) x
        JOIN uberconsole.tbl_hrsubheats j
        ON j.subheat_id=x.subheat_id
        AND j.event_id=x.event_id
        JOIN uberconsole.tbl_hrpersons z
        ON 	z.person_key=x.person_key
        AND z.event_id=x.event_id
        JOIN uberconsole.tbl_masterpersons y
        ON y.masterperson_id = z.masterperson_id
    ) w
     -- WHERE w.person_key='13717'
    WHERE w.lastname= 'Rybczynski'
    AND w.firstname='Erwin'
   	AND w.event_id=99
    ---AND w.event_name='dev7 Go'
)

-- (2)
SELECT
	w.heat_id,
    w.heat_name,
    w.heat_session,
    w.heat_time,
    w.heat_date,
    w.heat_type,
    w.description,
    w.xml_id,
    w.event_id
FROM (
    SELECT
        x.event_id,
        x.subheat_id,
        x.person_key,
        j.heat_id,
        j.subheat_key,
        j.subheat_type,
        j.subheat_dance,
        j.subheat_level,
        j.subheat_age,
        m.heat_name,
        m.heat_session,
        m.heat_time,
        m.heat_date,
        m.heat_type,
        m.description,
        m.xml_id,
        z.person_id,
        z.competitor_num,
        z.masterperson_id,
        y.firstname,
        y.lastname,
        y.gender,
        y.persontype,
        y.nickname,
        y.ndcaus_num
    FROM (
        SELECT 
            f.event_id,
            f.subheat_id,
            f.person_key
        FROM (
            SELECT 
                a.event_id,
                a.subheat_id,
                b.person1_key as person_key
            FROM uberconsole.tbl_hrmarks a
            JOIN uberconsole.tbl_hrcouples b
            ON 	b.couple_id=a.couple_id
            AND b.event_id =a.event_id
            UNION
            SELECT 
                a.event_id,
                a.subheat_id,
                b.person2_key as person_key
            FROM uberconsole.tbl_hrmarks a
            JOIN uberconsole.tbl_hrcouples b
            ON 	b.couple_id=a.couple_id
            AND b.event_id =a.event_id
            UNION
            SELECT 
                a.event_id,
                a.subheat_id,
                b.person1_key as person_key
            FROM uberconsole.tbl_hrcoupleentries a
            JOIN uberconsole.tbl_hrcouples b
            ON 	b.couple_id=a.couple_id
            AND b.event_id =a.event_id
            UNION
            SELECT 
                a.event_id,
                a.subheat_id,
                b.person2_key as person_key
            FROM uberconsole.tbl_hrcoupleentries a
            JOIN uberconsole.tbl_hrcouples b
            ON 	b.couple_id=a.couple_id
            AND b.event_id =a.event_id
            UNION
            SELECT
                a.event_id,
                a.subheat_id,
                a.person_key
            FROM uberconsole.tbl_hrsoloentries a
        ) as f ORDER BY event_id, subheat_id, person_key
    ) x
    JOIN uberconsole.tbl_hrsubheats j
    ON 	j.subheat_id=x.subheat_id
    AND j.event_id=x.event_id
    JOIN uberconsole.tbl_hrheats m
    ON 	m.heat_id=j.heat_id
    AND m.event_id=j.event_id
    JOIN uberconsole.tbl_hrpersons z
    ON 	z.person_key=x.person_key
    AND z.event_id=x.event_id
    JOIN uberconsole.tbl_masterpersons y
    ON y.masterperson_id = z.masterperson_id
) w
 -- WHERE w.person_key='13717'
WHERE w.lastname= 'Rybczynski'
AND w.firstname='Erwin'
AND w.event_id=99
---AND w.event_name='dev7 Go'




-- List couple IDs for a specific event For a specific person, 
--- use person key or name
SELECT
	w.couple_id,
    w.couple_key,
    w.event_id
FROM (
    SELECT
        -- x.event_id,
        x.couple_id,
        x.couple_key,
        x.person_key,
        z.person_id,
        z.competitor_num,
        z.masterperson_id,
        y.firstname,
        y.lastname,
        y.gender,
        y.persontype,
        y.nickname,
        y.ndcaus_num,
    	k.*
    FROM (
        SELECT 
            * 
        FROM (
            SELECT 
                a.event_id,
                a.couple_id,
                a.couple_key,
                b.person1_key as person_key
            FROM uberconsole.tbl_hrmarks a
            JOIN uberconsole.tbl_hrcouples b
            ON 	b.couple_id=a.couple_id
            AND b.event_id =a.event_id
            UNION
            SELECT 
                a.event_id,
                a.couple_id,
                a.couple_key,
                b.person2_key as person_key
            FROM uberconsole.tbl_hrmarks a
            JOIN uberconsole.tbl_hrcouples b
            ON 	b.couple_id=a.couple_id
            AND b.event_id =a.event_id
            UNION
            SELECT 
                a.event_id,
                a.couple_id,
                a.couple_key,
                b.person1_key as person_key
            FROM uberconsole.tbl_hrcoupleentries a
            JOIN uberconsole.tbl_hrcouples b
            ON 	b.couple_id=a.couple_id
            AND b.event_id =a.event_id
            UNION
            SELECT 
                a.event_id,
                a.couple_id,
                a.couple_key,
                b.person2_key as person_key
            FROM uberconsole.tbl_hrcoupleentries a
            JOIN uberconsole.tbl_hrcouples b
            ON 	b.couple_id=a.couple_id
            AND b.event_id =a.event_id
        ) as f ORDER BY event_id, couple_key
    ) as x
    JOIN uberconsole.tbl_hrpersons z
    ON 	z.person_key=x.person_key
    AND z.event_id=x.event_id
    JOIN uberconsole.tbl_masterpersons y
    ON y.masterperson_id = z.masterperson_id
    JOIN uberconsole.tbl_event k
    ON k.event_id=x.event_id
) as w
 -- WHERE w.person_key='13717'
WHERE w.lastname= 'Rybczynski'
AND w.firstname='Erwin'
-- AND w.event_id=99
AND w.event_name='dev7 Go'


-- List Heat IDs, For a specific couple, and specific event,
--- use couple key
SELECT
	* 
FROM uberconsole.tbl_hrheats 
WHERE heat_id IN (
    SELECT
    	heat_id
    FROM (
        SELECT
            x.entry_id,
            x.couple_id,
            x.couple_key,
            x.subheat_id,
            -- x.event_id,
            x.src_type,
            y.heat_id,
            z.*
        FROM (
            SELECT 
                    a.mark_id as entry_id,
                    a.couple_id,
                    a.couple_key,
                    a.subheat_id,
                    a.event_id,
                    'M' as src_type
            FROM uberconsole.tbl_hrmarks a
            UNION
            SELECT
                b.entry_id,
                b.couple_id,
                b.couple_key,
                b.subheat_id,
                b.event_id,
                 'C'
            FROM uberconsole.tbl_hrcoupleentries b
        ) as x
        JOIN uberconsole.tbl_hrsubheats y
        ON 	y.subheat_id = x.subheat_id
        AND y.event_id = x.event_id
        JOIN uberconsole.tbl_event z
        ON z.event_id=x.event_id
    ) as W
    WHERE couple_key = '44-01'
    -- AND event_id = 99
    AND event_name='asdfsdfa new 12 3'
)
ORDER BY heat_name, heat_id

--List judges from master table
SELECT * FROM uberconsole.tbl_masterjudeges


--List persons from master table
SELECT * FROM uberconsole.tbl_masterpersons

--List couples from master table
- No master couple is being matained

-- Query to list all the results with marks couple with complete person info
SELECT
    x.result_id,
    x.event_id,
    x.judgepanel,
    x.scoreheaders,
    x.subheat_id,
    x.couple_id,
    x.couple_value,
    x.couple_key,
    x.person_key,
    z.person_id,
    z.competitor_num,
    z.masterperson_id,
    y.firstname,
    y.lastname,
    y.gender,
    y.persontype,
    y.nickname,
    y.ndcaus_num
FROM (
    SELECT 
        a.result_id,
        a.event_id,
        a.judgepanel,
        a.scoreheaders,
        a.subheat_id,
        b.couple_id,
        b.couple_value,
        c.couple_key,
        c.person1_key as person_key
    FROM uberconsole.tbl_hrresult a
    JOIN uberconsole.tbl_hrmarks b
    ON 	b.result_id = a.result_id
    AND b.event_id = a.event_id
    JOIN uberconsole.tbl_hrcouples c
    ON 	c.couple_id=b.couple_id
    AND c.event_id =b.event_id
    UNION
    SELECT 
        a.result_id,
        a.event_id,
        a.judgepanel,
        a.scoreheaders,
        a.subheat_id,
        b.couple_id,
        b.couple_value,
        c.couple_key,
        c.person2_key
    FROM uberconsole.tbl_hrresult a
    JOIN uberconsole.tbl_hrmarks b
    ON b.result_id = a.result_id
    AND b.event_id = a.event_id
    JOIN uberconsole.tbl_hrcouples c
    ON c.couple_id=b.couple_id
    AND c.event_id =b.event_id
) as x
JOIN uberconsole.tbl_hrpersons z
ON 	z.person_key=x.person_key
AND z.event_id=x.event_id
JOIN uberconsole.tbl_masterpersons y
ON y.masterperson_id = z.masterperson_id

