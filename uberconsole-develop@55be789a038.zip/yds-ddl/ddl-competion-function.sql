/* 
===============================================================
* File:		ddl-competition-function.sql
* Desc: 	Competion module function definition
* Auth:		lmorallos
* Date:		2017/11/15
===============================================================
*/

/* [*] =competition */
CREATE OR REPLACE FUNCTION uberconsole.FN_COMPETITION_INSERT(
	vname		text	
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(competition_id) into cnt FROM uberconsole.tbl_competition WHERE UPPER(name) = UPPER($1);
	IF (cnt = 0) THEN
		SELECT nextval('uberconsole.seq_competition') INTO id;
		INSERT INTO uberconsole.tbl_competition (
			competition_id,
			name			
        )
		VALUES (id,$1);
		rtr := id;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


CREATE OR REPLACE FUNCTION uberconsole.FN_COMPETITION_UPDATE_BYID(
	vcomp_id 	int,
	vname		text	
) RETURNS INTEGER AS
$BODY$DECLARE	
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN			
	/* check new name first */
	SELECT count(competition_id) into cnt FROM uberconsole.tbl_competition WHERE UPPER(name) = UPPER($2);
	IF (cnt = 0) THEN
		UPDATE uberconsole.tbl_competition SET
			name = $2		
		WHERE competition_id = $1;
		rtr := 100;
	ELSE		
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


CREATE OR REPLACE FUNCTION uberconsole.FN_COMPETITION_DELETEBYID(
	vcomp_id		int	
) RETURNS INTEGER AS
$BODY$DECLARE	
	ecnt 	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(competition_id) into ecnt FROM uberconsole.tbl_event WHERE competition_id = $1;
	IF (ecnt = 0) THEN
		SELECT count(competition_id) into cnt FROM uberconsole.tbl_competition WHERE competition_id = $1;
		IF (cnt = 1) THEN
			DELETE FROM uberconsole.tbl_competition
			WHERE competition_id = $1;
			rtr := 100;
		ELSE
			rtr := -98;
		END IF;	
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_COMPETITION_DELETEBYNAME(
	vname		text	
) RETURNS INTEGER AS
$BODY$DECLARE
	id		INTEGER;
	ecnt 	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT competition_id into id FROM uberconsole.tbl_competition WHERE UPPER(name) = UPPER($1);
	SELECT count(competition_id) into ecnt FROM uberconsole.tbl_event WHERE competition_id = id;
	IF (ecnt = 0) THEN
		SELECT count(competition_id) into cnt FROM uberconsole.tbl_competition WHERE competition_id = id;
		IF (cnt = 1) THEN
			DELETE FROM uberconsole.tbl_competition
			WHERE competition_id = id;
			rtr := 100;
		ELSE
			rtr := -98;
		END IF;	
	ELSE
		rtr := -99;
	END IF;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_COMPETITION_SEARCHBYNAME(
	vname		text	
) RETURNS INTEGER AS
$BODY$DECLARE
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(competition_id) into cnt FROM uberconsole.tbl_competition WHERE UPPER(name) = UPPER($1);
	IF (cnt = 1) THEN		
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_COMPETITION_SEARCHBYID(
	vcomp_id		int
) RETURNS INTEGER AS
$BODY$DECLARE
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(competition_id) into cnt FROM uberconsole.tbl_competition WHERE competition_id = $1;
	IF (cnt = 1) THEN		
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


/* [*] =events */
CREATE OR REPLACE FUNCTION uberconsole.FN_EVENT_INSERT_BYCOMPID(	
	vcomp_id	int,
	vdstart		date,
	vdstop		date,
	vdline		timestamp,
	vevent_year	int,
	vwebsite	text,
	vstatus		int,
	vpubstatus	int,
	vname		text,
	vuregister	boolean
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(event_id) into cnt FROM uberconsole.tbl_event WHERE 
				(competition_id = $1) AND (date_start = $2) AND (date_stop = $3);
	IF (cnt = 0) THEN
		SELECT nextval('uberconsole.seq_event') INTO id;
		INSERT INTO uberconsole.tbl_event (
			event_id,
			competition_id,
			date_start,
			date_stop,
			deadline,
			event_year,
			website,			
			status,
			pubstatus,
			event_name,
			uregister,
			lastupdate
        )
		VALUES (id,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,now());
		rtr := id;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_EVENT_IMAGEUPDATE_BYEVENTID(
	vevent_id 		int,	
	vimgid			int
) RETURNS INTEGER AS
$BODY$DECLARE
	cnt 	INTEGER;
	rtr		INTEGER;
BEGIN
	SELECT count(event_id) into cnt FROM uberconsole.tbl_event WHERE event_id = $1;
	IF (cnt = 1) THEN
		UPDATE uberconsole.tbl_event SET
			image_id = $2
		WHERE event_id = $1;
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


CREATE OR REPLACE FUNCTION uberconsole.FN_EVENT_UPDATE_BYEVENTID(
	vevent_id 		int,	
	vdstart			date,
	vdstop			date,
	vdline			timestamp,
	vevent_year		int,
	vwebsite		text,
	vstatus			int,
	vname			text,
	vpubstatus		int,
	vimgid			int,
	vuregister		boolean
) RETURNS INTEGER AS
$BODY$DECLARE
	cnt 	INTEGER;
	vcnt 	INTEGER;
	rtr		INTEGER;
BEGIN
	SELECT count(event_id) into cnt FROM uberconsole.tbl_event WHERE event_id = $1;
	IF (cnt = 1) THEN
		UPDATE uberconsole.tbl_event SET
			date_start = $2,
			date_stop = $3,
			deadline = $4,
			event_year = $5,
			website = $6,
			status = $7,
			event_name = $8,
			pubstatus = $9,
			image_id = $10,
			uregister = $11,
			lastupdate = now()
		WHERE event_id = $1;
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


CREATE OR REPLACE FUNCTION uberconsole.FN_EVENT_SETSTATUS(
	vevent_id 	int,	
	status		int
) RETURNS INTEGER AS
$BODY$DECLARE	
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(event_id) into cnt FROM uberconsole.tbl_event WHERE event_id = $1;
	IF (cnt = 1) THEN
		UPDATE uberconsole.tbl_event SET 
			status = $2,
			lastupdate = now()
		WHERE event_id = $1;
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


CREATE OR REPLACE FUNCTION uberconsole.FN_EVENT_PUBSTATUS(
	vevent_id 	int,	
	vpstatus	int,
	vptime		bigint
) RETURNS INTEGER AS
$BODY$DECLARE	
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(event_id) into cnt FROM uberconsole.tbl_event WHERE event_id = $1;
	IF (cnt = 1) THEN
		IF ((vpstatus = 2) OR (vpstatus = 3) OR (vpstatus = 7)) THEN
			UPDATE uberconsole.tbl_event SET pubstatus = $2, timecommit=$3, lastupdate = now()	
			WHERE event_id = $1;
		ELSE 
			UPDATE uberconsole.tbl_event SET pubstatus = $2, timecommit=0, lastupdate = now()	
			WHERE event_id = $1;
			IF ((vpstatus = 0) OR (vpstatus = 5)) THEN 
				UPDATE uberconsole.tbl_event SET lastpublish = now()	
				WHERE event_id = $1;
			END IF;
		END IF;
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


CREATE OR REPLACE FUNCTION uberconsole.FN_EVENT_SETPUSHID(
	vevent_id 	int,	
	vpushid		text
) RETURNS INTEGER AS
$BODY$DECLARE	
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(event_id) into cnt FROM uberconsole.tbl_event WHERE event_id = $1;
	IF (cnt = 1) THEN
		UPDATE uberconsole.tbl_event SET 
			push_id = $2
		WHERE event_id = $1;
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_EVENT_GET_EVENTSTATUS_REPORT ()
RETURNS TABLE (
	futurepubcnt 	INTEGER,
	futureunpubcnt 	INTEGER,
	remlastyrcnt 	INTEGER,
	uniqeventcnt 	INTEGER
)
AS
$BODY$DECLARE	
	vfuturepubcnt 	INTEGER;
	vfutureunpubcnt INTEGER;
	vremlastyrcnt 	INTEGER;
	vuniqeventcnt 	INTEGER;			
BEGIN
	SELECT count(event_id) INTO vfuturepubcnt FROM uberConsole.VW_EVENT_WITHCOMPETITION WHERE date_stop >= now() AND pubstatus = 5;
	SELECT count(event_id) INTO vfutureunpubcnt FROM uberConsole.VW_EVENT_WITHCOMPETITION WHERE date_stop >= now() AND pubstatus <> 5;
	SELECT count(competition_id) INTO vuniqeventcnt FROM (SELECT DISTINCT competition_id FROM  uberConsole.VW_EVENT_WITHCOMPETITION) as a;
	SELECT count(competition_id) INTO vremlastyrcnt FROM 
	(
		SELECT distinct on (competition_id) competition_id, date_stop, pubstatus, event_id
		FROM uberConsole.VW_EVENT_WITHCOMPETITION 
		ORDER BY competition_id, date_stop desc
	) a
	WHERE (a.date_stop > NOW() - INTERVAL '1 year')
	AND NOT a.date_stop >= now();	
	RETURN QUERY SELECT vfuturepubcnt, vfutureunpubcnt, vremlastyrcnt, vuniqeventcnt;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;



DROP FUNCTION uberconsole.FN_EVENT_GET_PUBSTATUS_REPORT ()
RETURNS TABLE (
	items INTEGER,
	pubpending   INTEGER,
	pubcommit    INTEGER,
	unpubpending INTEGER,
	unpubcommit  INTEGER,
	allpending   INTEGER,
	allcommit    INTEGER
);


CREATE OR REPLACE FUNCTION uberconsole.FN_EVENT_GET_PUBSTATUS_REPORT ()
RETURNS TABLE (
	items INTEGER,
	pubpending   INTEGER,
	pubcommit    INTEGER,
	unpubpending INTEGER,
	unpubcommit  INTEGER,
	repubpending INTEGER,
	repubcommit  INTEGER,
	allpending   INTEGER,
	allcommit    INTEGER
)
AS
$BODY$DECLARE	
	ppcnt 	INTEGER;
	pccnt 	INTEGER;
	upcnt 	INTEGER;
	uccnt 	INTEGER;
	rpcnt 	INTEGER;
	rccnt 	INTEGER;
	apcnt   INTEGER;
	accnt   INTEGER;
BEGIN
	SELECT count(pubstatus) INTO ppcnt FROM uberconsole.tbl_event WHERE pubstatus = 1;
	SELECT count(pubstatus) INTO pccnt FROM uberconsole.tbl_event WHERE pubstatus = 2;
	SELECT count(pubstatus) INTO uccnt FROM uberconsole.tbl_event WHERE pubstatus = 3;
	SELECT count(pubstatus) INTO upcnt FROM uberconsole.tbl_event WHERE pubstatus = 4;
	SELECT count(pubstatus) INTO rpcnt FROM uberconsole.tbl_event WHERE pubstatus = 6;
	SELECT count(pubstatus) INTO rccnt FROM uberconsole.tbl_event WHERE pubstatus = 7;
	apcnt := ppcnt + upcnt + rpcnt;
	accnt := pccnt + uccnt + rccnt;
	RETURN QUERY SELECT 
		CAST(count(event_id) as INTEGER) as items,
		ppcnt,pccnt,upcnt,uccnt,rpcnt,rccnt,apcnt,accnt
	FROM uberconsole.tbl_event 
	WHERE pubstatus IN (1,2,3,4,6,7);
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_EVENT_DELETE( 
	vevent_id 	int	
) RETURNS INTEGER AS
$BODY$DECLARE	
	cnt 	INTEGER;
	vcnt 	INTEGER;
	ocnt 	INTEGER;
	ccnt 	INTEGER;
	xcnt 	INTEGER;
	icnt	INTEGER;
	rtr		INTEGER;
	slist	RECORD;
BEGIN
	SELECT count(event_id) into cnt FROM uberconsole.tbl_event WHERE event_id = $1;
	IF (cnt = 1) THEN
		/* allow delete of there are no connection with other tabes */
		SELECT count(event_id) into ocnt FROM uberconsole.tbl_organizer WHERE event_id = $1;
		IF (ocnt > 0) THEN
			DELETE FROM uberconsole.tbl_organizer WHERE event_id = $1;
		END IF;
		SELECT count(event_id) into vcnt FROM uberconsole.tbl_venue WHERE event_id = $1;
		IF (vcnt > 0) THEN
			DELETE FROM uberconsole.tbl_venue WHERE event_id = $1;
		END IF;
		SELECT count(event_id) into ccnt FROM uberconsole.tbl_contact WHERE event_id = $1;
		IF (ccnt > 0) THEN
			DELETE FROM uberconsole.tbl_contact WHERE event_id = $1;
		END IF;
		SELECT count(event_id) into ocnt FROM uberconsole.tbl_finance WHERE event_id = $1;
		IF (ocnt > 0) THEN
			DELETE FROM uberconsole.tbl_finance WHERE event_id = $1;
		END IF;
		SELECT count(code_id) into icnt FROM uberconsole.tbl_imgdata WHERE code='EVENT' AND code_id = $1;
		IF (icnt > 0) THEN
			DELETE FROM uberconsole.tbl_imgdata  WHERE code='EVENT' AND code_id = $1;
		END IF;
		SELECT count(event_id) into xcnt FROM uberconsole.tbl_eventform_xml WHERE event_id = $1;
		IF (xcnt > 0) THEN
			DELETE FROM uberconsole.tbl_eventform_xml WHERE event_id = $1;
		END IF;
		
		SELECT count(event_id) into xcnt FROM uberconsole.tbl_schedlist WHERE event_id = $1;
		IF (xcnt > 0) THEN
			DELETE FROM uberconsole.tbl_schedlist WHERE event_id = $1;
		END IF;
		SELECT count(event_id) into xcnt FROM uberconsole.tbl_schedule WHERE event_id = $1;
		IF (xcnt > 0) THEN
			DELETE FROM uberconsole.tbl_schedule WHERE event_id = $1;
		END IF;
		
		SELECT count(event_id) into xcnt FROM uberconsole.tbl_enablement WHERE event_id = $1;
		IF (xcnt > 0) THEN
			DELETE FROM uberconsole.tbl_enablement WHERE event_id = $1;
		END IF;
		
		SELECT count(event_id) into xcnt FROM uberconsole.tbl_hotel WHERE event_id = $1;
		IF (xcnt > 0) THEN
			FOR slist IN SELECT image_id, event_id FROM uberconsole.tbl_hotel WHERE event_id = $1 
			LOOP				
				DELETE FROM uberconsole.tbl_imgdata WHERE image_id = slist.image_id;
			END LOOP;		
			DELETE FROM uberconsole.tbl_hotel WHERE event_id = $1;
		END IF;
		
		SELECT count(event_id) into xcnt FROM uberconsole.tbl_sponsor WHERE event_id = $1;
		IF (xcnt > 0) THEN
			FOR slist IN SELECT image_id, event_id FROM uberconsole.tbl_sponsor WHERE event_id = $1 
			LOOP				
				DELETE FROM uberconsole.tbl_imgdata WHERE image_id = slist.image_id;
			END LOOP;		
			DELETE FROM uberconsole.tbl_sponsor WHERE event_id = $1;
		END IF;
		
		SELECT count(event_id) into xcnt FROM uberconsole.tbl_information WHERE event_id = $1;
		IF (xcnt > 0) THEN
			FOR slist IN SELECT image_id, event_id FROM uberconsole.tbl_information WHERE event_id = $1 
			LOOP				
				DELETE FROM uberconsole.tbl_imgdata WHERE image_id = slist.image_id;
			END LOOP;
			DELETE FROM uberconsole.tbl_information WHERE event_id = $1;
		END IF;
		
		DELETE FROM uberconsole.tbl_event WHERE event_id = $1;
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_EVENT_COPY( 
	vevent_id 	int,	
	vname 		text
) RETURNS INTEGER AS
$BODY$DECLARE	
	id		INTEGER;
	cnt 	INTEGER;
	vcnt 	INTEGER;
	ocnt 	INTEGER;
	ccnt 	INTEGER;
	icnt	INTEGER;
	scnt	INTEGER;
	dcnt	INTEGER;
	rtr		INTEGER;
	vid 	INTEGER;
	xcnt	INTEGER;
	slist	RECORD;
	imgid   INTEGER;
BEGIN
	SELECT count(event_id) into cnt FROM uberconsole.tbl_event WHERE event_id = $1;
	IF (cnt = 1) THEN
		/* generate id first */
		/* copy event*/
		SELECT nextval('uberconsole.seq_event') INTO id;
		INSERT INTO uberconsole.tbl_event 
		(event_id, date_start, date_stop, deadline,website, event_year, competition_id, status, image_id, pubstatus,event_name, usemanual, uregister, lastupdate) 
		SELECT 
		id, date_start, date_stop, deadline,website, event_year, competition_id, 5, image_id, 0, $2, usemanual, uregister, now() 
		FROM uberconsole.tbl_event
		WHERE event_id = $1;
		
		/* copy venue */
		SELECT count(event_id) into vcnt FROM uberconsole.tbl_venue WHERE event_id = $1;
		IF (vcnt > 0) THEN
			SELECT nextval('uberconsole.seq_venue') INTO vid;
			INSERT INTO uberconsole.tbl_venue 
			(venue_id, name, address, address2, city, province, country, zipcode, phone, fax, resvphone, website, longtitude, latitude, event_id)
			SELECT 
			vid, name, address, address2, city, province, country, zipcode, phone, fax, resvphone, website, longtitude, latitude, id  
			FROM uberconsole.tbl_venue WHERE event_id = $1;		
		END IF;
		
		/* copy contact */
		SELECT count(event_id) into ccnt FROM uberconsole.tbl_contact WHERE event_id = $1;
		IF (ccnt > 0) THEN
			SELECT nextval('uberconsole.seq_contact') INTO vid;
			INSERT INTO uberconsole.tbl_contact 
			(contact_id, name, address, address2, city,	province, country, zipcode, phone, fax, email, event_id)
			SELECT 
			vid, name, address, address2, city,  province,country, zipcode, phone, fax, email, id 
			FROM uberconsole.tbl_contact WHERE event_id = $1;	
		END IF;
		
		/* copy finance */
		SELECT count(event_id) into ccnt FROM uberconsole.tbl_finance WHERE event_id = $1;
		IF (ccnt > 0) THEN
			SELECT nextval('uberconsole.seq_finance') INTO vid;
			INSERT INTO uberconsole.tbl_finance (finance_id, surcharge, description, event_id)
			SELECT 
			vid, surcharge, description, id 
			FROM uberconsole.tbl_finance WHERE event_id = $1;	
		END IF;
		
		/* copy organizer */
		FOR slist IN SELECT organizer_id, name, event_id FROM uberconsole.tbl_organizer WHERE event_id = $1 
		LOOP	
			INSERT INTO uberconsole.tbl_organizer (organizer_id, name, event_id )
			VALUES (nextval('uberconsole.seq_organizer'), slist.name, id);
		END LOOP;
			
		/* copy event image*/
		SELECT count(code_id) into icnt FROM uberconsole.tbl_imgdata WHERE code_id = $1 AND code = 'EVENT';
		IF (icnt > 0) THEN
			SELECT nextval('uberconsole.seq_imgdata') INTO vid;
			INSERT INTO uberconsole.tbl_imgdata 
			(image_id, filename, mimetype, code, code_id, image)
			SELECT 
			vid, filename, mimetype, code, id, image
			FROM uberconsole.tbl_imgdata WHERE code_id = $1 AND code = 'EVENT';
		END IF;
	
		/* copy eventform xml */
		SELECT count(event_id) into xcnt FROM uberconsole.tbl_eventform_xml WHERE event_id = $1;
		IF (xcnt > 0) THEN
			SELECT nextval('uberconsole.seq_eventform_xml') INTO vid;
			INSERT INTO uberconsole.tbl_eventform_xml 
			(eventxml_id, xmlgenerated, jsongenerated, xmlmanual, jsonmanual, event_id)
			SELECT 
			vid, xmlgenerated, jsongenerated, xmlmanual, jsonmanual, id 
			FROM uberconsole.tbl_eventform_xml WHERE event_id = $1;	
		END IF;
		
		/* copy schedule and schedule data */
		SELECT count(event_id) into dcnt FROM uberconsole.tbl_schedlist WHERE event_id = $1;
		IF (dcnt > 0) THEN
			FOR slist IN SELECT header_name, hdrorder, timevalue, tvalorder, description FROM uberconsole.tbl_schedlist WHERE event_id = $1 
			LOOP	
				INSERT INTO uberconsole.tbl_schedlist (schedlist_id, header_name, hdrorder, timevalue, tvalorder,description, event_id)
				VALUES (nextval('uberconsole.seq_schedlist'), slist.header_name, slist.hdrorder, slist.timevalue, slist.tvalorder, slist.description, id);
			END LOOP;
		END IF;
		SELECT count(event_id) into scnt FROM uberconsole.tbl_schedule WHERE event_id = $1;
		IF (scnt > 0) THEN
			SELECT nextval('uberconsole.seq_schedule') INTO vid;
			INSERT INTO uberconsole.tbl_schedule 
			(schedule_id, sched_name, event_id)
			SELECT 
			vid, sched_name, id 
			FROM uberconsole.tbl_schedule WHERE event_id = $1;	
		END IF;	

		/* copy enablement */
		SELECT count(event_id) into xcnt FROM uberconsole.tbl_enablement WHERE event_id = $1;
		IF (xcnt > 0) THEN
			SELECT nextval('uberconsole.seq_enablement') INTO vid;
			INSERT INTO uberconsole.tbl_enablement 
			(enable_id,venue_enable,contact_enable,organizer_enable,schedule_enable,hotel_enable,sponsor_enable,information_enable,finance_enable, event_id)
			SELECT 
			vid, false, false, false, false, false, false, false, false, id
			FROM uberconsole.tbl_enablement WHERE event_id = $1;	
		END IF;
		
		/* copy hotel */
		SELECT count(event_id) into ccnt FROM uberconsole.tbl_hotel WHERE event_id = $1;
		IF (ccnt > 0) THEN
			FOR slist IN SELECT url,description,ordervalue,image_id FROM uberconsole.tbl_hotel WHERE event_id = $1 
			LOOP	
				INSERT INTO uberconsole.tbl_hotel (hotel_id,url,description,ordervalue,image_id,event_id)
				VALUES (nextval('uberconsole.seq_codeall'), slist.url, slist.description, slist.ordervalue, slist.image_id, id);
			END LOOP;
			
			FOR slist IN SELECT hotel_id,image_id FROM uberconsole.tbl_hotel WHERE event_id = id 
			LOOP
				imgid :=  slist.image_id;
				IF (imgid > 0) THEN 
					SELECT nextval('uberconsole.seq_imgdata') INTO vid;
					INSERT INTO uberconsole.tbl_imgdata (image_id,filename,mimetype,code,code_id,image)
					SELECT vid, filename,mimetype,code,slist.hotel_id,image
					FROM uberconsole.tbl_imgdata WHERE image_id = slist.image_id;
					UPDATE uberconsole.tbl_hotel SET image_id = vid WHERE hotel_id = slist.hotel_id;
				END IF;
			END LOOP;
		END IF;
		
		/* copy sponsor */
		SELECT count(event_id) into ccnt FROM uberconsole.tbl_sponsor WHERE event_id = $1;
		IF (ccnt > 0) THEN
			FOR slist IN SELECT url,description,ordervalue,image_id FROM uberconsole.tbl_sponsor WHERE event_id = $1 
			LOOP	
				INSERT INTO uberconsole.tbl_sponsor (sponsor_id,url,description,ordervalue,image_id,event_id)
				VALUES (nextval('uberconsole.seq_codeall'), slist.url, slist.description, slist.ordervalue, slist.image_id, id);
			END LOOP;
			
			FOR slist IN SELECT sponsor_id,image_id FROM uberconsole.tbl_sponsor WHERE event_id = id 
			LOOP
				imgid :=  slist.image_id;
				IF (imgid > 0) THEN 
					SELECT nextval('uberconsole.seq_imgdata') INTO vid;
					INSERT INTO uberconsole.tbl_imgdata (image_id,filename,mimetype,code,code_id,image)
					SELECT vid, filename,mimetype,code,slist.sponsor_id,image
					FROM uberconsole.tbl_imgdata WHERE image_id = slist.image_id;
					UPDATE uberconsole.tbl_sponsor SET image_id = vid WHERE sponsor_id = slist.sponsor_id;
				END IF;
			END LOOP;
		END IF;
		
		/* copy information */
		SELECT count(event_id) into ccnt FROM uberconsole.tbl_information WHERE event_id = $1;
		IF (ccnt > 0) THEN
			FOR slist IN SELECT url,description,ordervalue,image_id FROM uberconsole.tbl_information WHERE event_id = $1 
			LOOP	
				INSERT INTO uberconsole.tbl_information (information_id, url,description,ordervalue,image_id,event_id)
				VALUES (nextval('uberconsole.seq_codeall'), slist.url, slist.description, slist.ordervalue, slist.image_id, id);
			END LOOP;
			
			FOR slist IN SELECT information_id,image_id FROM uberconsole.tbl_information WHERE event_id = id 
			LOOP
				imgid :=  slist.image_id;
				IF (imgid > 0) THEN 
					SELECT nextval('uberconsole.seq_imgdata') INTO vid;
					INSERT INTO uberconsole.tbl_imgdata (image_id,filename,mimetype,code,code_id,image)
					SELECT vid, filename,mimetype,code,slist.information_id,image
					FROM uberconsole.tbl_imgdata WHERE image_id = slist.image_id;
					UPDATE uberconsole.tbl_information SET image_id = vid WHERE information_id = slist.information_id;
				END IF;
			END LOOP;
		END IF;
		rtr := id;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_EVENT_SEARCH_BYEVENTANDDATE(	
	vevent_id	int,
	vdstart		date,
	vdstop		date
) RETURNS INTEGER AS
$BODY$DECLARE
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(event_id) into cnt FROM uberconsole.tbl_event WHERE 
				(event_id = $1) AND (date_start = $2) AND (date_stop = $3);
	IF (cnt = 1) THEN		
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


CREATE OR REPLACE FUNCTION uberconsole.FN_EVENT_SEARCH_BYCOMPIDANDDATE(	
	vcompetition_id	int,
	vdstart		date,
	vdstop		date
) RETURNS INTEGER AS
$BODY$DECLARE
	cnt INTEGER;
	cid INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(event_id) into cnt FROM uberconsole.tbl_event WHERE 
				(competition_id = $1) AND (date_start = $2) AND (date_stop = $3);
	IF (cnt = 1) THEN	
		SELECT event_id into cid FROM uberconsole.tbl_event WHERE 
				(competition_id = $1) AND (date_start = $2) AND (date_stop = $3);
		rtr := cid;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


/* [*] =venue */
CREATE OR REPLACE FUNCTION uberconsole.FN_VENUE_INSERT_WITH_EVENTID(
	vevent_id	int,
	vname		text,
	vaddress	text,
	vaddress2	text,
	vcity 		text,
	vprovince 	text,	
	vcountry 	text,
	vzipcode 	text,	
	vphone 		text,
	vresvphone	text,
	vfax 		text,
	website		text,
	vlon 		text,
	vlat 		text	
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN	
	SELECT count(event_id) into cnt FROM uberconsole.tbl_venue WHERE event_id = $1 and UPPER(name) = UPPER($2);
	IF (cnt = 0) THEN
		SELECT nextval('uberconsole.seq_venue') INTO id;
		INSERT INTO uberconsole.tbl_venue (		
			venue_id,
			event_id,
			name,
			address,
			address2,
			city,
			province,
			country,
			zipcode,			
			phone,
			resvphone,
			fax,
			website,
			longtitude,
			latitude
        )
		VALUES (id,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14);
		rtr := id;	
	ELSE
		rtr := -99;
	END IF;	
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_VENUE_UPDATEBY_EVENTID(
	vevent_id	int,
	vname		text,
	vaddress	text,
	vaddress2	text,
	vcity 		text,
	vprovince 	text,	
	vcountry 	text,
	vzipcode 	text,	
	vphone 		text,
	vresvphone	text,
	vfax 		text,
	website		text,
	vlon 		text,
	vlat 		text	
) RETURNS INTEGER AS
$BODY$DECLARE
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(venue_id) into cnt FROM uberconsole.tbl_venue WHERE event_id = $1 and UPPER(name) = UPPER($2);
	IF (cnt = 0) THEN
		UPDATE uberconsole.tbl_venue SET	
			name = $2,
			address = $3,
			address2 = $4,
			city = $5,
			province = $6,
			country = $7,
			zipcode = $8,			
			phone = $9,
			resvphone = $10,	
			fax = $11,
			website = $12,	
			longtitude = $13,
			latitude = $14
		WHERE event_id = $1;
		rtr := 100;
	ELSE
		UPDATE uberconsole.tbl_venue SET				
			address = $3,
			address2 = $4,
			city = $5,
			province = $6,
			country = $7,
			zipcode = $8,			
			phone = $9,
			resvphone = $10,	
			fax = $11,
			website = $12,	
			longtitude = $13,
			latitude = $14
		WHERE event_id = $1 and UPPER(name) = UPPER($2);
		rtr := 100;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


CREATE OR REPLACE FUNCTION uberconsole.FN_VENUE_DELETEBYID(
	vvenue_id	int
) RETURNS INTEGER AS
$BODY$DECLARE
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(venue_id) into cnt FROM uberconsole.tbl_venue WHERE venue_id = $1;
	IF (cnt = 1) THEN
		DELETE FROM uberconsole.tbl_venue 
		WHERE venue_id = $1;
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


CREATE OR REPLACE FUNCTION uberconsole.FN_VENUE_SEARCHBYID(		
	vvenue_id 	int
) RETURNS INTEGER AS
$BODY$DECLARE
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(venue_id) into cnt FROM uberconsole.tbl_venue WHERE vvenue_id = $1;
	IF (cnt = 1) THEN
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_VENUE_SEARCHBYNAME(
	vname 	text
) RETURNS INTEGER AS
$BODY$DECLARE
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(venue_id) into cnt FROM uberconsole.tbl_venue WHERE UPPER(name) = UPPER($1);
	IF (cnt = 1) THEN
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


/* [*] =contact */
CREATE OR REPLACE FUNCTION uberconsole.FN_CONTACT_INSERT_WITH_EVENTID(
	vevent_id	int,
	vname		text,
	vaddress	text,
	vaddress2	text,
	vcity 		text,
	vprovince 	text,	
	vcountry 	text,
	vzipcode 	text,	
	vphone 		text,	
	vfax 		text,	
	vemail		text	
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN	
	SELECT count(event_id) into cnt FROM uberconsole.tbl_contact WHERE event_id = $1 and UPPER(name) = UPPER($2);
	IF (cnt = 0) THEN
		SELECT nextval('uberconsole.seq_contact') INTO id;
		INSERT INTO uberconsole.tbl_contact (		
			contact_id,
			event_id,
			name,
			address,
			address2,
			city,
			province,
			country,
			zipcode,			
			phone,
			fax,
			email
        )
		VALUES (id,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11);
		rtr := id;	
	ELSE
		rtr := -99;
	END IF;	
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_CONTACT_UPDATEBY_EVENTID(
	vevent_id	int,
	vname		text,
	vaddress	text,
	vaddress2	text,
	vcity 		text,
	vprovince 	text,	
	vcountry 	text,
	vzipcode 	text,	
	vphone 		text,	
	vfax 		text,
	vemail		text	
) RETURNS INTEGER AS
$BODY$DECLARE
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(contact_id) into cnt FROM uberconsole.tbl_contact WHERE event_id = $1 and UPPER(name) = UPPER($2);
	IF (cnt = 0) THEN
		UPDATE uberconsole.tbl_contact SET	
			name = $2,
			address = $3,
			address2 = $4,
			city = $5,
			province = $6,
			country = $7,
			zipcode = $8,			
			phone = $9,			
			fax = $10,
			email = $11			
		WHERE event_id = $1;
		rtr := 100;
	ELSE
		UPDATE uberconsole.tbl_contact SET				
			address = $3,
			address2 = $4,
			city = $5,
			province = $6,
			country = $7,
			zipcode = $8,			
			phone = $9,			
			fax = $10,
			email = $11				
		WHERE event_id = $1 and UPPER(name) = UPPER($2);
		rtr := 100;		
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_CONTACT_DELETEBYID(
	vcontact_id	int
) RETURNS INTEGER AS
$BODY$DECLARE
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(contact_id) into cnt FROM uberconsole.tbl_contact WHERE contact_id = $1;
	IF (cnt = 1) THEN
		DELETE FROM uberconsole.tbl_contact 
		WHERE contact_id = $1;
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


CREATE OR REPLACE FUNCTION uberconsole.FN_CONTACT_SEARCHBYID(		
	vcontact_id 	int
) RETURNS INTEGER AS
$BODY$DECLARE
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(contact_id) into cnt FROM uberconsole.tbl_contact WHERE contact_id = $1;
	IF (cnt = 1) THEN
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_CONTACT_SEARCHBYNAME(
	vname 	text
) RETURNS INTEGER AS
$BODY$DECLARE
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(contact_id) into cnt FROM uberconsole.tbl_contact WHERE UPPER(name) = UPPER($1);
	IF (cnt = 1) THEN
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

/* [*] =organizer */
CREATE OR REPLACE FUNCTION uberconsole.FN_ORGANIZER_INSERT_WITH_EVENTID(
	vevent_id	int,
	vname		text	
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN	
	SELECT count(organizer_id) into cnt FROM uberconsole.tbl_organizer WHERE event_id = $1 and UPPER(name) = UPPER($2);
	IF (cnt = 0) THEN
		SELECT nextval('uberconsole.seq_organizer') INTO id;
		INSERT INTO uberconsole.tbl_organizer (
			organizer_id,
			event_id,
			name	
		)
		VALUES (id,$1,$2);
		rtr := id;	
	ELSE
		rtr := -99;
	END IF;	
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_ORGANIZER_UPDATEBY_EVENTID(	
	vorganizer_id	int,	
	vname			text	
) RETURNS INTEGER AS
$BODY$DECLARE
	cnt INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(organizer_id) into cnt FROM uberconsole.tbl_organizer WHERE organizer_id = $1;
	IF (cnt = 1) THEN
		UPDATE uberconsole.tbl_organizer SET	
			name = $2		 
		WHERE organizer_id = $1;
		rtr := 100;
	ELSE		
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


CREATE OR REPLACE FUNCTION uberconsole.FN_ORGANIZER_DELETEBYID(
	vorg_id	int
) RETURNS INTEGER AS
$BODY$DECLARE
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(organizer_id) into cnt FROM uberconsole.tbl_organizer WHERE organizer_id = $1;
	IF (cnt = 1) THEN
		DELETE FROM uberconsole.tbl_organizer 
		WHERE organizer_id = $1;
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


CREATE OR REPLACE FUNCTION uberconsole.FN_ORGANIZER_SEARCHBYID(		
	vorg_id 	int
) RETURNS INTEGER AS
$BODY$DECLARE
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(organizer_id) into cnt FROM uberconsole.tbl_organizer WHERE organizer_id = $1;
	IF (cnt = 1) THEN
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


CREATE OR REPLACE FUNCTION uberconsole.FN_ORGANIZER_SEARCHBYNAME(
	vname 	text
) RETURNS INTEGER AS
$BODY$DECLARE
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(organizer_id) into cnt FROM uberconsole.tbl_organizer WHERE UPPER(name) = UPPER($1);
	IF (cnt = 1) THEN
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

/* -- schedule -- */
CREATE OR REPLACE FUNCTION uberconsole.FN_SCHEDULE_INSERT_WITH_EVENTID(
	vevent_id		int,
	vsched_name		text,
	voldevent_id	int
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN	
	SELECT count(schedule_id) into cnt FROM uberconsole.tbl_schedule WHERE event_id = $1;
	IF (cnt = 0) THEN
		SELECT nextval('uberconsole.seq_schedule') INTO id;
		INSERT INTO uberconsole.tbl_schedule (
			schedule_id,
			event_id,
			sched_name
		)
		VALUES (id,$1,$2);
		-- insert all data from tmp to schedlist_id
		INSERT INTO uberconsole.tbl_schedlist (schedlist_id, header_name, hdrorder, timevalue, tvalorder, description, event_id)
		SELECT schedlist_id,header_name,hdrorder,timevalue,tvalorder,description, $1
		FROM uberconsole.tbl_tmpschedlist WHERE event_id = $3;
		-- delete data 
		DELETE FROM uberconsole.tbl_tmpschedlist 
		WHERE event_id = $3;
		rtr := id;
	ELSE
		rtr := -99;
	END IF;	
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


CREATE OR REPLACE FUNCTION uberconsole.FN_SCHEDULE_UPDATE_BYEVENTID(
	vevent_id		int,
	vsched_name		text
) RETURNS INTEGER AS
$BODY$DECLARE
	cnt 	INTEGER;
	rtr		INTEGER;
BEGIN
	SELECT count(schedule_id) into cnt FROM uberconsole.tbl_schedule WHERE event_id = $1;
	IF (cnt = 1) THEN
		UPDATE uberconsole.tbl_schedule SET
			sched_name = $2
		WHERE event_id = $1;
		-- delete current schedlist
		DELETE FROM uberconsole.tbl_schedlist 
		WHERE event_id = $1;
		-- replace data
		INSERT INTO uberconsole.tbl_schedlist (schedlist_id,header_name,hdrorder,timevalue,tvalorder,description, event_id) 
		SELECT schedlist_id,header_name,hdrorder,timevalue,tvalorder,description, event_id
		FROM uberconsole.tbl_tmpschedlist WHERE event_id = $1;
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


DROP FUNCTION uberconsole.FN_SCHEDULE_LIST_INSERT_WITH_EVENTID(
	vevent_id		int,
	vheader_name	text,
	vtimevalue	  	text,
	vdescription	text
);


CREATE OR REPLACE FUNCTION uberconsole.FN_SCHEDULE_LIST_INSERT_WITH_EVENTID(
	vevent_id		int,
	vheader_name	text,
	vhdrorder		int,
	vtimevalue	  	text,
	vtvalorder		int,
	vdescription	text
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN	
	--SELECT count(schedlist_id) into cnt FROM uberconsole.tbl_schedlist WHERE event_id = $1 
	--		and UPPER(header_name) = UPPER($2) and UPPER(timevalue) = UPPER($3);
	--IF (cnt = 0) THEN
	SELECT nextval('uberconsole.seq_schedlist') INTO id;
	INSERT INTO uberconsole.tbl_tmpschedlist (
		schedlist_id,
		event_id,
		header_name,
		hdrorder,
		timevalue,
		tvalorder,
		description
	)
	VALUES (id,$1,$2,$3,$4,$5,$6);
	SELECT count(schedlist_id) into cnt FROM uberconsole.tbl_tmpschedlist WHERE event_id = $1 and UPPER(header_name) = UPPER($2);
	IF (cnt > 0) THEN
		UPDATE uberconsole.tbl_tmpschedlist SET
			hdrorder = $3
		 WHERE event_id = $1 and UPPER(header_name) = UPPER($2);
	END IF;
	rtr := id;	
	--ELSE
	--	rtr := -99;
	-- END IF;	
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

DROP FUNCTION uberconsole.FN_SCHEDULE_LIST_UPDATE_WITH_EVENTID(
	vschedlist_id	int,
	vheader_name	text,
	vtimevalue	  	text,
	vdescription	text
);


CREATE OR REPLACE FUNCTION uberconsole.FN_SCHEDULE_LIST_UPDATE_WITH_EVENTID(
	vschedlist_id	int,
	vheader_name	text,
	vhdrorder		int,
	vtimevalue	  	text,
	vtvalorder		int,
	vdescription	text,
	vevent_id		int
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	xcnt 	INTEGER;
	rtr	INTEGER;
BEGIN	
	SELECT count(schedlist_id) into cnt FROM uberconsole.tbl_tmpschedlist WHERE schedlist_id = $1;
	IF (cnt = 1) THEN
		UPDATE uberconsole.tbl_tmpschedlist SET
			header_name = $2,
			hdrorder = $3,
			timevalue = $4,
			tvalorder = $5,
			description = $6
		WHERE schedlist_id = $1;
		SELECT count(schedlist_id) into xcnt FROM uberconsole.tbl_tmpschedlist WHERE event_id = $7 and UPPER(header_name) = UPPER($2);
		IF (xcnt > 0) THEN
			UPDATE uberconsole.tbl_tmpschedlist SET
				hdrorder = $3
			 WHERE event_id = $7 and UPPER(header_name) = UPPER($2);
		END IF;
		rtr := 100;	
	ELSE
		rtr := -99;	
	END IF;	
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_SCHEDULE_LIST_CLEANTMPBYID(
	vevent_id	int
) RETURNS INTEGER AS
$BODY$DECLARE
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(event_id) into cnt FROM uberconsole.tbl_tmpschedlist WHERE event_id = $1;
	IF (cnt > 0) THEN
		DELETE FROM uberconsole.tbl_tmpschedlist 
		WHERE event_id = $1;
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


DROP FUNCTION uberconsole.FN_SCHEDULE_LIST__DELETEBYID(
	vschedlist_id	int
);


CREATE OR REPLACE FUNCTION uberconsole.FN_SCHEDULE_LIST_DELETEBYID(
	vschedlist_id	int
) RETURNS INTEGER AS
$BODY$DECLARE
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(schedlist_id) into cnt FROM uberconsole.tbl_tmpschedlist WHERE schedlist_id = $1;
	IF (cnt = 1) THEN
		DELETE FROM uberconsole.tbl_tmpschedlist
		WHERE schedlist_id = $1;
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_SCHEDULE_LIST_MOVETO_TMP(
	vevent_id		int
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN	
	SELECT count(schedlist_id) into cnt FROM uberconsole.tbl_schedlist WHERE event_id = $1;
	IF (cnt > 0) THEN
		-- delete data 
		DELETE FROM uberconsole.tbl_tmpschedlist 
		WHERE event_id = $1;
		-- insert all data from tmp to schedlist_id
		INSERT INTO uberconsole.tbl_tmpschedlist (schedlist_id,header_name,hdrorder,timevalue,tvalorder,description, event_id)
		SELECT schedlist_id,header_name,hdrorder,timevalue,tvalorder,description, event_id
		FROM uberconsole.tbl_schedlist WHERE event_id = $1;
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;	
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_SCHEDULE_LIST_HEARORDER_LASTVALUE(
	vevent_id	int
) RETURNS INTEGER AS
$BODY$DECLARE
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(event_id) into cnt FROM uberconsole.tbl_schedlist WHERE event_id = $1 AND tempdata=true;
	IF (cnt > 0) THEN
		UPDATE uberconsole.tbl_schedlist SET
			deleted = false
		WHERE event_id = $1;
		DELETE FROM uberconsole.tbl_schedlist 
		WHERE event_id = $1 AND tempdata=true;
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

/* finance */
CREATE OR REPLACE FUNCTION uberconsole.FN_FINANCE_INSERT(
	vevent_id		int,
	vsurcharge		float,
	vdescription	text
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(event_id) into cnt FROM uberconsole.tbl_finance WHERE event_id = $1;
	IF (cnt = 0) THEN
		SELECT nextval('uberconsole.seq_finance') INTO id;
		INSERT INTO uberconsole.tbl_finance (
			finance_id,
			event_id,
			surcharge,
			description
        )
		VALUES (id, $1, $2, $3);
		rtr := id;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_FINANCE_UPDATE_BYID(
	vfinance_id		int,
	vsurcharge		float,
	vdescription	text
) RETURNS INTEGER AS
$BODY$DECLARE	
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN			
	SELECT count(finance_id) into cnt FROM uberconsole.tbl_finance WHERE finance_id = $1;
	IF (cnt = 1) THEN
		UPDATE uberconsole.tbl_finance SET
			surcharge = $2,
			description	= $3
		WHERE finance_id = $1;
		rtr := 100;
	ELSE		
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


/* enablement */
CREATE OR REPLACE FUNCTION uberconsole.FN_EVENT_ENABLEMENT(
) RETURNS INTEGER AS
$BODY$DECLARE
	cnt 	INTEGER;
	rtr		INTEGER;
	slist RECORD;
BEGIN
	SELECT count(event_id) into cnt FROM uberconsole.tbl_event;
	IF (cnt > 0) THEN
		FOR slist IN SELECT event_id FROM uberconsole.tbl_event 
		LOOP	
			INSERT INTO uberconsole.tbl_enablement (enable_id, event_id)
			VALUES (nextval('uberconsole.seq_enablement'), slist.event_id);
		END LOOP;
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_EVENT_ENABLEMENT_INSERT(
	vevent_id	int,
	vvenue_enable boolean,
	vcontact_enable boolean,
	vorganizer_enable boolean,
	vschedule_enable boolean,
	vhotel_enable boolean,
	vsponsor_enable boolean,
	vinformation_enable boolean,
	vfinance_enable boolean
) RETURNS INTEGER AS
$BODY$DECLARE
	cnt 	INTEGER;
	id 	INTEGER;
	rtr		INTEGER;
BEGIN
	SELECT count(event_id) into cnt FROM uberconsole.tbl_enablement WHERE event_id = $1; 
	IF (cnt = 0) THEN
		SELECT nextval('uberconsole.seq_enablement') INTO id;
		INSERT INTO uberconsole.tbl_enablement (
			enable_id,
			event_id,
			venue_enable,
			contact_enable,
			organizer_enable,
			schedule_enable,
			hotel_enable,
			sponsor_enable,
			information_enable,
			finance_enable
		)
		VALUES (id, $1, $2, $3, $4, $5, $6, $7, $8, $9);
		rtr := id;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_EVENT_ENABLEMENT_UPDATE(
	vevent_id	int,
	vvenue_enable boolean,
	vcontact_enable boolean,
	vorganizer_enable boolean,
	vschedule_enable boolean,
	vhotel_enable boolean,
	vsponsor_enable boolean,
	vinformation_enable boolean,
	vfinance_enable boolean
) RETURNS INTEGER AS
$BODY$DECLARE
	cnt 	INTEGER;
	rtr		INTEGER;
BEGIN
	SELECT count(event_id) into cnt FROM uberconsole.tbl_enablement WHERE event_id = $1; 
	IF (cnt = 1) THEN
		UPDATE uberconsole.tbl_enablement SET
			venue_enable = $2,
			contact_enable = $3,
			organizer_enable = $4,
			schedule_enable = $5,
			hotel_enable = $6,
			sponsor_enable = $7,
			information_enable = $8,
			finance_enable = $9
		WHERE event_id = $1; 
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

/* generic form */

CREATE OR REPLACE FUNCTION uberconsole.FN_EVENT_GENERICFORM_INSERT_WITH_EVENTID(
	vevent_id		int,
	vcodecon		int,
	voldevent_id	int
	
) RETURNS INTEGER AS
$BODY$DECLARE
	rtr	INTEGER;
	slist	RECORD;
BEGIN	
	-- hotel
	IF (vcodecon = 1) THEN
		-- insert all data from tmp to hotel
		INSERT INTO uberconsole.tbl_hotel (hotel_id,url,description,ordervalue,image_id,event_id)
		SELECT code_id,url,description,ordervalue,image_id, $1
		FROM uberconsole.tbl_tmpformdata WHERE code='HOTEL' AND event_id = $3;
		-- delete data 
		DELETE FROM uberconsole.tbl_tmpformdata 
		WHERE code='HOTEL' AND event_id = $3;
		-- transfer tmp images to table images
		FOR slist IN SELECT image_id, event_id FROM uberconsole.tbl_hotel WHERE event_id = $1 
		LOOP	
			INSERT INTO uberconsole.tbl_imgdata (image_id,filename,mimetype,code,code_id,image)
			SELECT image_id,filename,mimetype,code,code_id,image
			FROM uberconsole.tbl_tmpimgdata WHERE image_id = slist.image_id;
			-- clear data
			DELETE FROM uberconsole.tbl_tmpimgdata WHERE image_id = slist.image_id;
		END LOOP;		
		rtr := 100;
	END IF;
	-- sponsor
	IF (vcodecon = 2) THEN
		-- insert all data from tmp to sponsor
		INSERT INTO uberconsole.tbl_sponsor (sponsor_id,url,description,ordervalue,image_id,event_id)
		SELECT code_id,url,description,ordervalue,image_id, $1
		FROM uberconsole.tbl_tmpformdata WHERE code='SPONSOR' AND event_id = $3;
		-- delete data 
		DELETE FROM uberconsole.tbl_tmpformdata 
		WHERE code='SPONSOR' AND event_id = $3;
		FOR slist IN SELECT image_id, event_id FROM uberconsole.tbl_sponsor WHERE event_id = $1 
		LOOP	
			INSERT INTO uberconsole.tbl_imgdata (image_id,filename,mimetype,code,code_id,image)
			SELECT image_id,filename,mimetype,code,code_id,image
			FROM uberconsole.tbl_tmpimgdata WHERE image_id = slist.image_id;
			-- clear data
			DELETE FROM uberconsole.tbl_tmpimgdata WHERE image_id = slist.image_id;
		END LOOP;		
		rtr := 100;
	END IF;
	-- information
	IF (vcodecon = 3) THEN
		-- insert all data from tmp to information
		INSERT INTO uberconsole.tbl_information (information_id,url,description,ordervalue,image_id,event_id)
		SELECT code_id,url,description,ordervalue,image_id, $1
		FROM uberconsole.tbl_tmpformdata WHERE code='INFO' AND event_id = $3;
		-- delete data 
		DELETE FROM uberconsole.tbl_tmpformdata 
		WHERE code='INFO' AND event_id = $3;
		-- transfer tmp images to table images
		FOR slist IN SELECT image_id, event_id FROM uberconsole.tbl_information WHERE event_id = $1 
		LOOP	
			INSERT INTO uberconsole.tbl_imgdata (image_id,filename,mimetype,code,code_id,image)
			SELECT image_id,filename,mimetype,code,code_id,image
			FROM uberconsole.tbl_tmpimgdata WHERE image_id = slist.image_id;
			-- clear data
			DELETE FROM uberconsole.tbl_tmpimgdata WHERE image_id = slist.image_id;
		END LOOP;		
		rtr := 100;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

	
CREATE OR REPLACE FUNCTION uberconsole.FN_EVENT_GENERICFORM_UPDATE_BYEVENTID(
	vevent_id		int,
	vcodecon		int
) RETURNS INTEGER AS
$BODY$DECLARE
	rtr		INTEGER;
	slist	RECORD;
BEGIN
	-- hotel
	IF (vcodecon = 1) THEN
		DELETE FROM uberconsole.tbl_hotel 
		WHERE event_id = $1;
		-- insert all data from tmp to hotel
		INSERT INTO uberconsole.tbl_hotel (hotel_id,url,description,ordervalue,image_id,event_id)
		SELECT code_id,url,description,ordervalue,image_id,event_id
		FROM uberconsole.tbl_tmpformdata WHERE code='HOTEL' AND event_id = $1;
		-- delete image data 				
		DELETE FROM uberconsole.tbl_tmpformdata 
		WHERE code='HOTEL' AND event_id = $1;
		FOR slist IN SELECT image_id, event_id FROM uberconsole.tbl_hotel WHERE event_id = $1 
		LOOP	
			INSERT INTO uberconsole.tbl_imgdata (image_id,filename,mimetype,code,code_id,image)
			SELECT image_id,filename,mimetype,code,code_id,image
			FROM uberconsole.tbl_tmpimgdata WHERE image_id = slist.image_id;
			-- clear data
			DELETE FROM uberconsole.tbl_tmpimgdata WHERE image_id = slist.image_id;
		END LOOP;				
		rtr := 100;
	END IF;
	-- sponsor
	IF (vcodecon = 2) THEN
		DELETE FROM uberconsole.tbl_sponsor 
		WHERE event_id = $1;
		-- insert all data from tmp to sponsor
		INSERT INTO uberconsole.tbl_sponsor (sponsor_id,url,description,ordervalue,image_id,event_id)
		SELECT code_id,url,description,ordervalue,image_id,event_id
		FROM uberconsole.tbl_tmpformdata WHERE code='SPONSOR' AND event_id = $1;
		-- delete data 
		DELETE FROM uberconsole.tbl_tmpformdata 
		WHERE code='SPONSOR' AND event_id = $1;
		-- delete data from table images
		FOR slist IN SELECT image_id, event_id FROM uberconsole.tbl_sponsor WHERE event_id = $1 
		LOOP	
			INSERT INTO uberconsole.tbl_imgdata (image_id,filename,mimetype,code,code_id,image)
			SELECT image_id,filename,mimetype,code,code_id,image
			FROM uberconsole.tbl_tmpimgdata WHERE image_id = slist.image_id;
			-- clear data
			DELETE FROM uberconsole.tbl_tmpimgdata WHERE image_id = slist.image_id;
		END LOOP;			
		rtr := 100;
	END IF;
	-- information
	IF (vcodecon = 3) THEN
		DELETE FROM uberconsole.tbl_information 
		WHERE event_id = $1;
		-- insert all data from tmp to information
		INSERT INTO uberconsole.tbl_information (information_id,url,description,ordervalue,image_id,event_id)
		SELECT code_id,url,description,ordervalue,image_id,event_id
		FROM uberconsole.tbl_tmpformdata WHERE code='INFO' AND event_id = $1;
		-- delete data 
		DELETE FROM uberconsole.tbl_tmpformdata 
		WHERE code='INFO' AND event_id = $1;
		-- delete data from table images
		FOR slist IN SELECT image_id, event_id FROM uberconsole.tbl_information WHERE event_id = $1 
		LOOP	
			INSERT INTO uberconsole.tbl_imgdata (image_id,filename,mimetype,code,code_id,image)
			SELECT image_id,filename,mimetype,code,code_id,image
			FROM uberconsole.tbl_tmpimgdata WHERE image_id = slist.image_id;
			-- clear data
			DELETE FROM uberconsole.tbl_tmpimgdata WHERE image_id = slist.image_id;
		END LOOP;			
		rtr := 100;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_EVENT_GENERICFORM_MOVETO_TMP(
	vevent_id		int,
	vcodecon		int
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr		INTEGER;
	slist	RECORD;
BEGIN	
	-- hotel
	IF (vcodecon = 1) THEN
		SELECT count(event_id) into cnt FROM uberconsole.tbl_hotel WHERE event_id = $1;
		IF (cnt > 0) THEN
			DELETE FROM uberconsole.tbl_tmpformdata 
			WHERE code='HOTEL' AND event_id = $1;			
			-- insert all data from tmp to hotel
			INSERT INTO uberconsole.tbl_tmpformdata (code_id,url,description,ordervalue,image_id,event_id,code)
			SELECT hotel_id,url,description,ordervalue,image_id,event_id,'HOTEL'
			FROM uberconsole.tbl_hotel WHERE event_id = $1;
			
			-- delete image from tmp table image
			FOR slist IN SELECT image_id, event_id FROM uberconsole.tbl_tmpformdata WHERE code='HOTEL' AND event_id = $1
			LOOP	
				DELETE FROM uberconsole.tbl_tmpimgdata WHERE image_id = slist.image_id;
				INSERT INTO uberconsole.tbl_tmpimgdata  (image_id,filename,mimetype,code,code_id,image)
				SELECT image_id,filename,mimetype,code,code_id,image
				FROM uberconsole.tbl_imgdata WHERE image_id = slist.image_id;
			END LOOP;									
			rtr := 100;
		ELSE
			rtr := -99;
		END IF;	
	END IF;
	-- sponsor
	IF (vcodecon = 2) THEN
		SELECT count(event_id) into cnt FROM uberconsole.tbl_sponsor WHERE event_id = $1;
		IF (cnt > 0) THEN
			DELETE FROM uberconsole.tbl_tmpformdata 
			WHERE code='SPONSOR' AND event_id = $1;
			-- insert all data from tmp to sponsor
			INSERT INTO uberconsole.tbl_tmpformdata (code_id,url,description,ordervalue,image_id,event_id,code)
			SELECT sponsor_id,url,description,ordervalue,image_id,event_id,'SPONSOR'
			FROM uberconsole.tbl_sponsor WHERE event_id = $1;
			-- delete image from tmp table image
			-- delete image from tmp table image
			FOR slist IN SELECT image_id, event_id FROM uberconsole.tbl_tmpformdata WHERE code='SPONSOR' AND event_id = $1
			LOOP	
				DELETE FROM uberconsole.tbl_tmpimgdata WHERE image_id = slist.image_id;
				INSERT INTO uberconsole.tbl_tmpimgdata  (image_id,filename,mimetype,code,code_id,image)
				SELECT image_id,filename,mimetype,code,code_id,image
				FROM uberconsole.tbl_imgdata WHERE image_id = slist.image_id;
			END LOOP;		
			rtr := 100;
		ELSE
			rtr := -99;
		END IF;	
	END IF;
	-- information
	IF (vcodecon = 3) THEN
		SELECT count(event_id) into cnt FROM uberconsole.tbl_information WHERE event_id = $1;
		IF (cnt > 0) THEN
			DELETE FROM uberconsole.tbl_tmpformdata 
			WHERE code='INFO' AND event_id = $1;
			-- insert all data from tmp to info
			INSERT INTO uberconsole.tbl_tmpformdata (code_id,url,description,ordervalue,image_id,event_id,code)
			SELECT information_id_id,url,description,ordervalue,image_id,event_id,'INFO'
			FROM uberconsole.tbl_information WHERE event_id = $1;
			-- delete image from tmp table image
			FOR slist IN SELECT image_id, event_id FROM uberconsole.tbl_tmpformdata WHERE code='SPONSOR' AND event_id = $1
			LOOP	
				DELETE FROM uberconsole.tbl_tmpimgdata WHERE image_id = slist.image_id;
				INSERT INTO uberconsole.tbl_tmpimgdata  (image_id,filename,mimetype,code,code_id,image)
				SELECT image_id,filename,mimetype,code,code_id,image
				FROM uberconsole.tbl_imgdata WHERE image_id = slist.image_id;
			END LOOP;	
			rtr := 100;
		ELSE
			rtr := -99;
		END IF;	
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_EVENT_GENERICFORM_LIST_INSERT(
	vevent_id		int,
	vurl			text,
	vdescription	text,
	vordervalue		int,
	vimage_id		int,
	vcodecon		int
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	codestr	text;
	rtr		INTEGER;
BEGIN	
	-- hotel
	IF (vcodecon = 1) THEN
		codestr = 'HOTEL';
	END IF;
	-- sponsor
	IF (vcodecon = 2) THEN
		codestr = 'SPONSOR';
	END IF;
	-- information
	IF (vcodecon = 3) THEN
		codestr = 'INFO';
	END IF;
	SELECT count(event_id) into cnt FROM uberconsole.tbl_tmpformdata WHERE event_id = $1 AND code=codestr 
		AND UPPER(url) = UPPER($3) AND UPPER(description) = UPPER($4);
	IF (cnt = 0) THEN
		SELECT nextval('uberconsole.seq_codeall') INTO id;
		INSERT INTO uberconsole.tbl_tmpformdata (
			code_id,
			event_id,
			code,
			url,
			description,
			ordervalue,
			image_id
		)
		VALUES (id,$1,codestr,$2,$3,$4,$5);
		rtr := id;	
	ELSE
		rtr := -99;
	END IF;	
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_EVENT_GENERICFORM_LIST_UPDATE (
	vcode_id		int,
	vevent_id		int,
	vurl			text,
	vdescription	text,
	vordervalue		int,
	vcodecon		int
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	xcnt 	INTEGER;
	rtr	INTEGER;
BEGIN	
	-- hotel
	IF (vcodecon = 1) THEN
		codestr = 'HOTEL';
	END IF;
	-- sponsor
	IF (vcodecon = 2) THEN
		codestr = 'SPONSOR';
	END IF;
	-- information
	IF (vcodecon = 3) THEN
		codestr = 'INFO';
	END IF;

	SELECT count(code_id) into cnt FROM uberconsole.tbl_tmpformdata WHERE code_id = $1;
	IF (cnt = 1) THEN
		SELECT count(event_id) into xcnt FROM uberconsole.tbl_tmpformdata WHERE event_id = $2 AND code=codestr 
			AND UPPER(url) = UPPER($3) AND UPPER(description) = UPPER($4);
		IF (xcnt = 0) THEN
			UPDATE uberconsole.tbl_tmpformdata SET
				url = $3,
				description = $4,
				ordervalue = $5
			WHERE code_id = $1;
		ELSE
			UPDATE uberconsole.tbl_tmpformdata SET
				ordervalue
			WHERE event_id = $2 AND code=codestr 
			AND UPPER(url) = UPPER($3) AND UPPER(description) = UPPER($4);
		END IF;
		rtr := 100;	
	ELSE
		rtr := -99;	
	END IF;	
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_EVENT_GENERICFORM_LIST_DELETEBYID(
	vcode_id	int
) RETURNS INTEGER AS
$BODY$DECLARE
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(code_id) into cnt FROM uberconsole.tbl_tmpformdata WHERE code_id = $1;
	IF (cnt = 1) THEN
		DELETE FROM uberconsole.tbl_tmpformdata
		WHERE code_id = $1;
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_EVENT_GENERICFORM_LIST_CLEANTMPBYID(
	vevent_id	int
) RETURNS INTEGER AS
$BODY$DECLARE
	cnt 	INTEGER;
	rtr		INTEGER;
	slist	RECORD;
BEGIN
	SELECT count(event_id) into cnt FROM uberconsole.tbl_tmpformdata WHERE event_id = $1;
	IF (cnt > 0) THEN
		FOR slist IN SELECT image_id, event_id FROM uberconsole.tbl_tmpformdata WHERE event_id = $1 
		LOOP				
			DELETE FROM uberconsole.tbl_tmpimgdata WHERE image_id = slist.image_id;
		END LOOP;					
		DELETE FROM uberconsole.tbl_tmpformdata WHERE event_id = $1;		
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


CREATE OR REPLACE FUNCTION uberconsole.FN_EVENT_GENERICFORM_IMAGEUPDATE_BYID(
	vcode_id 		int,	
	vimgid			int
) RETURNS INTEGER AS
$BODY$DECLARE
	cnt 	INTEGER;
	rtr		INTEGER;
BEGIN
	SELECT count(event_id) into cnt FROM uberconsole.tbl_tmpformdata WHERE code_id = $1;
	IF (cnt = 1) THEN
		UPDATE uberconsole.tbl_tmpformdata SET
			image_id = $2
		WHERE code_id = $1;
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;



/* --image data -- */
CREATE OR REPLACE FUNCTION uberconsole.FN_IMAGE_INSERT_WITH_EVENTID(
	vevent_id	int,
	vfilename	text,	
	vmimetype	text,	
	vimg	bytea	
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN	
	SELECT count(organizer_id) into cnt FROM uberconsole.tbl_imgdata WHERE code_id = $1 AND code='EVENT';
	IF (cnt = 0) THEN
		SELECT nextval('uberconsole.seq_imgdata') INTO id;
		INSERT INTO uberconsole.tbl_imgdata (
			image_id, 
			code, 
			code_id, 
			filename, 
			mimetype, 
			image
		)
		VALUES (id,'EVENT',$1,$2,$3,$4);
		rtr := id;	
	ELSE
		rtr := -99;
	END IF;	
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_EVENT_GETALL_IMAGEID (
	vevent_id 	int
)
RETURNS TABLE (
	imageid INTEGER
)
AS
$BODY$DECLARE	
	icnt 	INTEGER;
	slist 	RECORD;
BEGIN
	-- create a temp table
	DROP TABLE IF EXISTS tmp_imageidlist;
	CREATE TEMPORARY TABLE tmp_imageidlist AS
	SELECT image_id FROM uberconsole.tbl_event WHERE event_id = $1;
    -- hotel
    INSERT INTO tmp_imageidlist (image_id) 
    SELECT image_id FROM uberconsole.tbl_hotel WHERE event_id = $1;
    -- sponsor
    INSERT INTO tmp_imageidlist (image_id) 
    SELECT image_id FROM uberconsole.tbl_sponsor WHERE event_id = $1;
    -- information
    INSERT INTO tmp_imageidlist (image_id) 
    SELECT image_id FROM uberconsole.tbl_information WHERE event_id = $1;
    
	RETURN QUERY SELECT DISTINCT
		image_id
	FROM tmp_imageidlist ORDER BY image_id;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

/* -- user ----- */
DROP FUNCTION CREATE OR REPLACE FUNCTION uberconsole.FN_USER_INSERT(
	vusername		text,
	vfirstname		text,	
	vlastname		text,
	vactive			boolean,
	vdatecreated	timestamp
);

CREATE OR REPLACE FUNCTION uberconsole.FN_USER_INSERT(
	vusername		text,
	vfirstname		text,	
	vlastname		text,
	vactive			boolean,
	vsysuid			int
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	tid  	BIGINT;
	cnt 	INTEGER;
	nvar 	TIMESTAMP;
	rtr	INTEGER;
BEGIN
	SELECT count(user_id) into cnt FROM uberconsole.tbl_user WHERE UPPER(username) = UPPER($1);
	IF (cnt = 0) THEN
		SELECT nextval('uberconsole.seq_user') INTO id;
		IF (id = 9999) THEN 
			id := id + 1;
		END IF;
		SELECT nextval('uberconsole.seq_systransid') INTO tid;
		nvar := NOW();
		INSERT INTO uberconsole.tbl_user (
			user_id,
			username,
			firstname,
			lastname,
			active,
			sysuid,
			systransid,
			syscreated,
			sysdeleted,
			sysactive,
			sysaction
        )
		VALUES (id ,$1, $2, $3, $4, $5, tid, nvar, nvar, true, 1);
		rtr := id;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.xFN_USER_INSERT(
	vusername		text,
	vfirstname		text,	
	vlastname		text,
	vactive			boolean,
	vdatecreated	timestamp
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(user_id) into cnt FROM uberconsole.tbl_user WHERE UPPER(username) = UPPER($1);
	IF (cnt = 0) THEN
		SELECT nextval('uberconsole.seq_user') INTO id;
		IF (id = 9999) THEN 
			id := id + 1;
		END IF;
		INSERT INTO uberconsole.tbl_user (
			user_id,
			username,
			firstname,
			lastname,
			active,
			datecreated		
        )
		VALUES (id ,$1, $2, $3, $4, $5);
		rtr := id;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

DROP FUNCTION uberconsole.FN_USER_UPDATE(
	vuser_id		int,
	vusername		text,
	vfirstname		text,	
	vlastname		text,
	vactive			boolean
);

CREATE OR REPLACE FUNCTION uberconsole.FN_USER_UPDATE(
	vuser_id		int,
	vusername		text,
	vfirstname		text,	
	vlastname		text,
	vactive			boolean,
	vsysuid			int
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	tid		BIGINT;
	cnt 	INTEGER;
	vcnt 	INTEGER;
	chk		INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(user_id) into cnt FROM uberconsole.tbl_user WHERE user_id = $1 AND sysactive=true;
	IF (cnt = 1) THEN
		SELECT count(user_id) into chk FROM uberconsole.tbl_user WHERE user_id=$1 AND UPPER(username)=UPPER($2) 
					AND UPPER(firstname)=UPPER($3) AND UPPER(lastname)=UPPER($4) AND active=$5 AND sysactive=true;
		IF (chk = 1) THEN
			rtr := $1;
			RETURN rtr;
		END IF; 
		SELECT count(user_id) into vcnt FROM uberconsole.tbl_user WHERE UPPER(username) = UPPER($2) AND sysactive=true;
		IF (vcnt = 1) THEN
			SELECT nextval('uberconsole.seq_systransid') INTO tid;
			INSERT INTO uberconsole.tbl_user 
				(user_id,username,firstname,lastname,active,sysuid,systransid,syscreated,sysdeleted,sysactive,sysaction)
			SELECT 
				user_id,username,firstname,lastname,active,$6,tid,syscreated,now(),false,2
			FROM uberconsole.tbl_user
			WHERE user_id = $1 AND sysactive=true;
			
			UPDATE uberconsole.tbl_user SET
				firstname = $3,
				lastname = $4,
				active = $5,
				sysuid = $6,
				systransid = tid,
				sysdeleted = now(),
				sysaction = 2
			WHERE user_id = $1 AND sysactive=true;
			rtr := 100;
		ELSE
			rtr := -98;
		END IF;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

	
DROP FUNCTION UNCTION uberconsole.xFN_USER_UPDATE(
	vuser_id		int,
	vusername		text,
	vfirstname		text,	
	vlastname		text,
	vactive			boolean,
	vlastupdated 	timestamp
);

CREATE OR REPLACE FUNCTION uberconsole.xFN_USER_UPDATE(
	vuser_id		int,
	vusername		text,
	vfirstname		text,	
	vlastname		text,
	vactive			boolean
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	vcnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(user_id) into cnt FROM uberconsole.tbl_user WHERE user_id = $1;
	IF (cnt = 1) THEN
		SELECT count(user_id) into vcnt FROM uberconsole.tbl_user WHERE UPPER(username) = UPPER($2);
		IF (vcnt = 1) THEN
			UPDATE uberconsole.tbl_user SET
				firstname = $3,
				lastname = $4,
				active = $5
			WHERE user_id = $1;
		ELSE
			UPDATE uberconsole.tbl_user SET
				username = $2,
				firstname = $3,
				lastname = $4,
				active = $5
			WHERE user_id = $1;
		END IF;
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

DROP FUNCTION uberconsole.FN_USER_DELETE(
	vuser_id		int
);

CREATE OR REPLACE FUNCTION uberconsole.FN_USER_DELETE(
	vuser_id		int,
	vsysuid			int
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	tid		BIGINT;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(user_id) into cnt FROM uberconsole.tbl_user WHERE user_id = $1 AND sysactive=true;
	IF (cnt = 1) THEN
		SELECT nextval('uberconsole.seq_systransid') INTO tid;
		UPDATE uberconsole.tbl_user SET
			sysuid = $2,
			systransid = tid,
			sysdeleted = now(),
			sysaction = 3,
			sysactive=false;
		WHERE user_id = $1 AND sysactive=true;
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100


CREATE OR REPLACE FUNCTION uberconsole.xFN_USER_DELETE(
	vuser_id		int
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(user_id) into cnt FROM uberconsole.tbl_user WHERE user_id = $1;
	IF (cnt = 1) THEN
		DELETE FROM uberconsole.tbl_user WHERE user_id = $1;
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_USER_BYID(
	vuser_id		int
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(user_id) into cnt FROM uberconsole.tbl_user WHERE user_id = $1;
	IF (cnt = 1) THEN
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_USER_BYUSERNAME(
	vusername		text
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	vid		INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(user_id) into cnt FROM uberconsole.tbl_user WHERE UPPER(username) = UPPER($1);
	IF (cnt = 1) THEN
		SELECT user_id into vid FROM uberconsole.tbl_user WHERE UPPER(username) = UPPER($1);
		rtr := vid;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_USER_SETACTIVE(
	vuser_id		int,
	vactive			boolean
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(user_id) into cnt FROM uberconsole.tbl_user WHERE user_id = $1;
	IF (cnt = 1) THEN
		UPDATE uberconsole.tbl_user SET
			active = $2
		WHERE user_id = $1;
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_SYSLOG_INSERT(
	vaction		text,
	vmodname	text,	
	vclassname	text,
	vuser_id	int,
	vlogdate	timestamp
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	rtr	INTEGER;
BEGIN
		SELECT nextval('uberconsole.seq_syslog') INTO id;
		INSERT INTO uberconsole.tbl_syslog (
			syslog_id,
			action,
			modname,
			classname,
			user_id,
			logdate	
        )
		VALUES (id ,$1, $2, $3, $4, $5);
	RETURN id;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_SYSLOG_TBLUPDATE(
	vtblname	text,
	vsysid		int,
	vidvar		text,	
	vidval		int
) RETURNS INTEGER AS
$BODY$DECLARE
	msql text;
	rtr	INTEGER;
BEGIN
	msql := 'UPDATE uberconsole.' || $1 || ' SET syslog_id=' || $2 || ' WHERE ' || $3 || '=' || $4;

	EXECUTE msql;

	rtr := 100;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

-- config----

CREATE OR REPLACE FUNCTION uberconsole.FN_EVENTFORM_INSERT(
	vevent_id	int,
	vform_id	int,
	vformtype	int,
	vheadertype	int,
	ventrytype	int
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(eventform_id) into cnt FROM uberconsole.tbl_eventform WHERE event_id=$1 AND form_id = $2;
	IF (cnt = 0) THEN
		SELECT nextval('uberconsole.seq_eventform') INTO id;
		INSERT INTO uberconsole.tbl_eventform (
			eventform_id,
			event_id,
			form_id,
			formtype,
			headertype,
			entrytype
        )
		VALUES (id, $1, $2, $3, $4, $5);
		rtr := id;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_EVENTFORM_DELETE(
	veventform_id	int
) RETURNS INTEGER AS
$BODY$DECLARE
	id 	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(eventform_id) into cnt FROM uberconsole.tbl_eventform WHERE eventform_id=$1;
	IF (cnt = 1) THEN
		DELETE FROM uberconsole.tbl_eventform
		WHERE eventform_id = $1;
		rtr := 100;	
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_EVENTFORM_HCONTENT_INSERT(
	veventform_id	int,
	vheader			text
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(eventform_id) into cnt FROM uberconsole.tbl_eventform_hcontent WHERE eventform_id=$1 AND horizheader = $2;
	IF (cnt = 0) THEN
		SELECT nextval('uberconsole.seq_eventform_hcontent') INTO id;
		INSERT INTO uberconsole.tbl_eventform_hcontent (
			hcontent_id,
			eventform_id,
			horizheader
        )
		VALUES (id, $1, $2);
		rtr := id;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


CREATE OR REPLACE FUNCTION uberconsole.FN_EVENTFORM_HCONTENT_DELETEBYID(
	vhcontent_id	int
) RETURNS INTEGER AS
$BODY$DECLARE
	id 	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(eventform_id) into cnt FROM uberconsole.tbl_eventform_hcontent WHERE hcontent_id=$1;
	IF (cnt = 1) THEN
		DELETE FROM uberconsole.tbl_eventform_hcontent
		WHERE hcontent_id=$1;
		rtr := 100;	
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_EVENTFORM_HCONTENT_DELETE(
	veventform_id	int,
	vheader			text
) RETURNS INTEGER AS
$BODY$DECLARE
	id 	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(eventform_id) into cnt FROM uberconsole.tbl_eventform_hcontent WHERE eventform_id=$1 AND horizheader = $2;
	IF (cnt = 1) THEN
		DELETE FROM uberconsole.tbl_eventform_hcontent
		WHERE eventform_id=$1 AND horizheader = $2;
		rtr := 100;	
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


CREATE OR REPLACE FUNCTION uberconsole.FN_EVENTFORM_HCONTENT_CLEAR(
	veventform_id	int
) RETURNS INTEGER AS
$BODY$DECLARE
	id 	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(eventform_id) into cnt FROM uberconsole.tbl_eventform_hcontent WHERE eventform_id=$1;
	IF (cnt > 0) THEN
		DELETE FROM uberconsole.tbl_eventform_hcontent
		WHERE eventform_id = $1;
		rtr := 100;	
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_EVENTFORM_DANCE_INSERT(
	vhcontent_id   	int,
	veventform_id  	int,
	vcode	 	  	text,
	vdescription	text	
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(eventform_id) into cnt FROM uberconsole.tbl_eventform_dance WHERE hcontent_id=$1 AND eventform_id=$2 AND code = $3;
	IF (cnt = 0) THEN
		SELECT nextval('uberconsole.seq_eventform_dance') INTO id;
		INSERT INTO uberconsole.tbl_eventform_dance (
			eventdance_id,
			hcontent_id,
			eventform_id,
			code,
			description
        )
		VALUES (id, $1, $2, $3, $4);
		rtr := id;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_EVENTFORM_DANCE_DELETE(
	vhcontent_id   	int,
	veventform_id  	int,
	vcode			text
) RETURNS INTEGER AS
$BODY$DECLARE
	id 	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(eventform_id) into cnt FROM uberconsole.tbl_eventform_dance WHERE hcontent_id=$1 AND eventform_id=$2 AND code = $3;
	IF (cnt = 1) THEN
		DELETE FROM uberconsole.tbl_eventform_dance
		WHERE hcontent_id=$1 AND eventform_id=$2 AND code = $3;
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


CREATE OR REPLACE FUNCTION uberconsole.FN_EVENTFORM_DANCE_DELETEBYID(
	veventdance_id   	int
) RETURNS INTEGER AS
$BODY$DECLARE
	id 	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(eventform_id) into cnt FROM uberconsole.tbl_eventform_dance WHERE eventdance_id=$1;
	IF (cnt = 1) THEN
		DELETE FROM uberconsole.tbl_eventform_dance
		WHERE eventdance_id=$1;
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_EVENTFORM_FIELD_INSERT(
	veventform_id  	int,
	vfield_name	 	text,
	vlinkto			text	
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(eventform_id) into cnt FROM uberconsole.tbl_eventform_field WHERE eventform_id=$1 AND UPPER(field_name)= UPPER($2);
	IF (cnt = 0) THEN
		SELECT nextval('uberconsole.seq_eventform_field') INTO id;
		INSERT INTO uberconsole.tbl_eventform_field (
			eventfield_id,
			eventform_id,
			field_name,
			linkto
        )
		VALUES (id, $1, $2, $3);
		rtr := id;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


CREATE OR REPLACE FUNCTION uberconsole.FN_EVENTFORM_FIELD_SEARCHBYFORMID(
	veventform_id  	int	
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(eventform_id) into cnt FROM uberconsole.tbl_eventform_field WHERE eventform_id=$1;
	IF (cnt > 0) THEN
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;



CREATE OR REPLACE FUNCTION uberconsole.FN_EVENTFORM_VERTICAL_INSERT(
	veventfield_id	int,
	veventform_id  	int,
	vcode	 	  	text,
	vdescription	text,
	vallows			boolean
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(eventform_id) into cnt FROM uberconsole.tbl_eventform_vertical WHERE eventfield_id=$1 AND eventform_id=$2 AND UPPER(code) = UPPER($3);
	IF (cnt = 0) THEN
		SELECT nextval('uberconsole.seq_eventform_vertical') INTO id;
		INSERT INTO uberconsole.tbl_eventform_vertical (			
			eventvertical_id, 
			eventfield_id,
			eventform_id,
			code,
			description,
			allowall
        )
		VALUES (id, $1, $2, $3, $4, $5);
		rtr := id;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


CREATE OR REPLACE FUNCTION uberconsole.FN_EVENTFORM_VERTICAL_DELETEBYID(
	veventvertical_id   	int
) RETURNS INTEGER AS
$BODY$DECLARE
	id 	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(eventform_id) into cnt FROM uberconsole.tbl_eventform_vertical WHERE eventvertical_id=$1;
	IF (cnt = 1) THEN
		DELETE FROM uberconsole.tbl_eventform_vertical
		WHERE eventvertical_id=$1;
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_EVENTFORM_VERTICAL_ALLOW_INSERT(
	veventform_id  		int,
	veventvertical_id 	int,
	veventdance_id		int
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(eventform_id) into cnt FROM uberconsole.tbl_eventform_vertical_allow WHERE eventform_id=$1 
						AND eventvertical_id = $2 AND eventdance_id=$3;
	IF (cnt = 0) THEN
		SELECT nextval('uberconsole.seq_eventform_allow') INTO id;
		INSERT INTO uberconsole.tbl_eventform_vertical_allow (
			eventallow_id, 
			eventform_id,
			eventvertical_id,
			eventdance_id
        )
		VALUES (id, $1, $2, $3);
		rtr := id;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_EVENTFORM_VERTICAL_ALLOW_DELETEBYID(
	veventallow_id   	int
) RETURNS INTEGER AS
$BODY$DECLARE
	id 	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(eventform_id) into cnt FROM uberconsole.tbl_eventform_vertical_allow WHERE eventallow_id=$1;
	IF (cnt = 1) THEN
		DELETE FROM uberconsole.tbl_eventform_vertical_allow
		WHERE eventallow_id=$1;
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_EVENT_SETUSEMANUAL(
	vevent_id 	int,	
	vumanual	boolean
) RETURNS INTEGER AS
$BODY$DECLARE	
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(event_id) into cnt FROM uberconsole.tbl_event WHERE event_id = $1;
	IF (cnt = 1) THEN
		UPDATE uberconsole.tbl_event SET 
			usemanual = $2,
			lastupdate = now()
		WHERE event_id = $1;
		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_HEAT_LIST_INSERT(	
	vevent_id		int,
	vdescription	text,
	vfilename		text,
	vheatasof		timestamp
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(event_id) into cnt FROM uberconsole.tbl_heatlist WHERE event_id=$1;
	IF (cnt = 0) THEN
		SELECT nextval('uberconsole.seq_heatlist') INTO id;
		INSERT INTO uberconsole.tbl_heatlist (
			heatlist_id,
			event_id,
			description,
			filename,
			heatasof
        )
		VALUES (id,$1,$2,$3,$4);
		rtr := id;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_HEAT_STUDIO_INSERT(	
	vheatlist_id 	int,
	vstudiocpm_id	text,
	vname			text
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(heatlist_id) into cnt FROM uberconsole.tbl_heatstudio WHERE  heatlist_id = $1 AND studiocpm_id = $2;
	IF (cnt = 0) THEN
		SELECT nextval('uberconsole.seq_heatstudio') INTO id;
		INSERT INTO uberconsole.tbl_heatstudio (
			studio_id,
			heatlist_id,
			studiocpm_id,
			name
        )
		VALUES (id,$1,$2,$3);
		rtr := id;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_HEAT_PERSON_INSERT(	
	vheatlist_id 	int,
	vpersoncpm_id	text,
	vlastname		text,
	vfirstname		text,
	vsex			text,
	vprofile_type	text,
	vstudiocpm_id	text
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	sid		INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(heatlist_id) into cnt FROM uberconsole.tbl_heatperson WHERE heatlist_id  = $1 AND personcpm_id = $2;
	IF (cnt = 0) THEN
		SELECT studio_id into sid FROM uberconsole.tbl_heatstudio WHERE heatlist_id = $1 AND studiocpm_id = $7;
		SELECT nextval('uberconsole.seq_heatperson') INTO id;
		INSERT INTO uberconsole.tbl_heatperson (
			person_id,
			heatlist_id ,
			personcpm_id,
			lastname,
			firstname,
			sex,
			profile_type,
			studiocpm_id,
			studio_id
        )
		VALUES (id,$1,$2,$3,$4,$5,$6,$7, sid);
		rtr := id;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_HEAT_INFO_INSERT(	
	vheatlist_id int,
	vheat_val	text,
	vschedule	text,
	vdescription text
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(heatlist_id) into cnt FROM uberconsole.tbl_heatinfo WHERE heatlist_id = $1 AND heat_val = $2 AND schedule=$3;
	IF (cnt = 0) THEN
		SELECT nextval('uberconsole.seq_heatinfo') INTO id;
		INSERT INTO uberconsole.tbl_heatinfo (
			heat_id,
			heatlist_id,
			heat_val,
			schedule,
			description
        )
		VALUES (id,$1,$2,$3,$4);
		rtr := id;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_HEAT_COMP_INSERT(	
	vheatlist_id int,	
	vcompcpm_id	text,
	vheattype	text,
	vdance		text,
	vheatlevel	text,
	vage		text,	
	vheat_id	int
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	hid		INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(heatlist_id) into cnt FROM uberconsole.tbl_heatcomp WHERE heatlist_id = $1 AND compcpm_id = $2;
	IF (cnt = 0) THEN	
		SELECT nextval('uberconsole.seq_heatcomp') INTO id;
		INSERT INTO uberconsole.tbl_heatcomp (
			comp_id,
			heatlist_id,
			compcpm_id,
			heattype,
			dance,
			heatlevel,
			age,				
			heat_id
        )
		VALUES (id,$1,$2,$3,$4,$5, $6, $7);
		rtr := id;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_HEAT_ENTRY_INSERT(	
	vheatlist_id 	int,
	ventrycpm_id	text,	
	vpersoncpm_id	text,
	vseqno			text,	
	vpartnercpm_id	text,	
	vstudiocpm_id	text,
	votherinfo		text,
	vcompcpm_id		text	
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	pid		INTEGER;
	rid		INTEGER;
	cid		INTEGER;
	sid		INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(heatlist_id) into cnt FROM uberconsole.tbl_heatentry WHERE heatlist_id = $1 AND entrycpm_id = $2;
	IF (cnt = 0) THEN
		SELECT person_id into pid FROM uberconsole.tbl_heatperson WHERE heatlist_id = $1 AND personcpm_id = $3;
		SELECT person_id into rid FROM uberconsole.tbl_heatperson WHERE heatlist_id = $1 AND personcpm_id = $5;
		
		SELECT studio_id into sid FROM uberconsole.tbl_heatstudio WHERE heatlist_id = $1 AND studiocpm_id = $6;
		SELECT comp_id into cid FROM uberconsole.tbl_heatcomp WHERE heatlist_id = $1 AND compcpm_id	 = $8;

		SELECT nextval('uberconsole.seq_heatentry') INTO id;
		INSERT INTO uberconsole.tbl_heatentry (
			entry_id,
			heatlist_id,
			entrycpm_id,
			person_id,
			personcpm_id,
			seqno,
			partner_id,
			partnercpm_id,
			studio_id,
			studiocpm_id,
			otherinfo, 
			comp_id,
			compcpm_id
        )
		VALUES (id, $1,$2, pid, $3,$4, rid, $5, sid, $6, $7, cid, $8);
		rtr := id;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_HEAT_LIST_DELETE(	
	vheatlist_id 	int
) RETURNS INTEGER AS
$BODY$DECLARE
	rtr	INTEGER;
    cnt INTEGER;
BEGIN
	SELECT count(event_id) into cnt FROM uberconsole.tbl_heatlist WHERE heatlist_id = $1;
	IF (cnt > 0) THEN
	
		DELETE FROM uberconsole.tbl_heatentry WHERE heatlist_id = $1;
		
		DELETE FROM uberconsole.tbl_heatcomp WHERE heatlist_id = $1;
				
		DELETE FROM uberconsole.tbl_heatinfo WHERE heatlist_id = $1;
		
		DELETE FROM uberconsole.tbl_heatperson WHERE heatlist_id = $1;

		DELETE FROM uberconsole.tbl_heatstudio WHERE heatlist_id = $1;
		
		DELETE FROM uberconsole.tbl_heatlist WHERE heatlist_id = $1;	

		rtr := 100;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


/* ------- heatresult -------- */

CREATE OR REPLACE FUNCTION uberconsole.FN_HEATRESULT_EVENT_CLEAR(	
	vevent_id	int
) RETURNS INTEGER AS
$BODY$DECLARE
	rtr 	INTEGER;
	cnt 	INTEGER;
	scnt 	INTEGER;
	ccnt 	INTEGER;
	rcnt 	INTEGER;
	hlist	RECORD;
	slist	RECORD;
	clist	RECORD;
	mlist	RECORD;
BEGIN
	/* delete alll data using event_id */	
	SELECT count(event_id) into cnt FROM uberconsole.tbl_hrprogram WHERE event_id = $1;
	IF (cnt > 0) THEN
		/* delete heats first */
		FOR hlist IN SELECT heat_id, xml_id, event_id FROM uberconsole.tbl_hrheats WHERE event_id = $1 
		LOOP
			SELECT count(heat_id) into scnt FROM uberconsole.tbl_hrsubheats WHERE heat_id = hlist.heat_id;
			IF (scnt > 0) THEN
				FOR slist IN SELECT heat_id, subheat_id FROM uberconsole.tbl_hrsubheats WHERE heat_id = hlist.heat_id
				LOOP
					SELECT count(subheat_id) into ccnt FROM uberconsole.tbl_hrcoupleentries WHERE subheat_id = slist.subheat_id; 
					IF (ccnt > 0) THEN
						DELETE FROM uberconsole.tbl_hrcoupleentries WHERE subheat_id = slist.subheat_id;
					END IF;
					SELECT count(result_id) into rcnt FROM uberconsole.tbl_hrresult WHERE subheat_id = slist.subheat_id; 
					IF (rcnt > 0) THEN
						DELETE FROM uberconsole.tbl_hrmarks WHERE subheat_id=slist.subheat_id;
						DELETE FROM uberconsole.tbl_hrresult WHERE subheat_id=slist.subheat_id;
					END IF;
				END LOOP;
				DELETE FROM uberconsole.tbl_hrsubheats WHERE heat_id = hlist.heat_id;
			END IF;
		END LOOP;		
		DELETE FROM uberconsole.tbl_hrheats WHERE event_id=$1;
		DELETE FROM uberconsole.tbl_hrcouples WHERE event_id=$1;
		DELETE FROM uberconsole.tbl_hrpersons WHERE event_id=$1;
		DELETE FROM uberconsole.tbl_hrjudges WHERE event_id=$1;
		DELETE FROM uberconsole.tbl_hrstudios WHERE event_id=$1;
		DELETE FROM uberconsole.tbl_hrprogram WHERE event_id=$1;
		rtr := -99;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


CREATE OR REPLACE FUNCTION uberconsole.FN_HEATRESULT_PROGRAM_INSERT(		
	vistudio	boolean,
	vijudge		boolean,
	viperson	boolean,
	viheat		boolean,
	vevent_id 	int,
	vxml_id 	int
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT nextval('uberconsole.seq_hrprogram') INTO id;
	INSERT INTO uberconsole.tbl_hrprogram (
		program_id,
		istudio,
		ijudge,
		iperson,
		iheat,
		event_id,
		xml_id	
	)
	VALUES (id,$1,$2,$3,$4,$5,$6);
	rtr := id;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_HEATRESULT_STUDIO_INSERT(	
	vstudio_key	text,
	vname		text,
	vinvoice	text,
	vevent_id	int,
	vxml_id		int
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT nextval('uberconsole.seq_hrstudios') INTO id;
	INSERT INTO uberconsole.tbl_hrstudios (
		studio_id,
		studio_key,
		name,
		invoice,
		event_id,
		xml_id
	)
	VALUES (id,$1,$2,$3,$4,$5);
	rtr := id;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


CREATE OR REPLACE FUNCTION uberconsole.FN_HEATRESULT_JUDGE_INSERT(	
	vjudge_key	text,
	vfirstname	text,
	vlastnamey	text,
	vjudge_num	text,
	vevent_id	int,
	vxml_id		int
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT nextval('uberconsole.seq_hrjudges') INTO id;
	INSERT INTO uberconsole.tbl_hrjudges (
		judge_id,
		judge_key,
		firstname,
		lastname,
		judge_num,
		event_id,
		xml_id
	)
	VALUES (id,$1,$2,$3,$4,$5,$6);
	rtr := id;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


CREATE OR REPLACE FUNCTION uberconsole.FN_HEATRESULT_PERSON_INSERT(	
	vperson_key 	text,
	vfirstname		text,
	vlastname		text,
	vgender			text,
	vpersontype		text,
	vstudio_key 	text,
	vnickname		text,
	vndcaus_num		text,
	vcompetitor_num	text,
	vevent_id 		int,
	vxml_id 		int
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT nextval('uberconsole.seq_hrpersons') INTO id;
	INSERT INTO uberconsole.tbl_hrpersons (
		person_id,
		person_key,
		firstname,
		lastname,
		gender,
		persontype,
		studio_key,
		nickname,
		ndcaus_num,
		competitor_num,
		event_id,
		xml_id
	)
	VALUES (id,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11);
	rtr := id;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


CREATE OR REPLACE FUNCTION uberconsole.FN_HEATRESULT_COUPLES_SEARCH(	
	vcouple_key 	text,
	vevent_id		int
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT count(couple_id) into cnt FROM uberconsole.tbl_hrcouples WHERE 
				(couple_key  = $1) AND (event_id = $2);
	IF (cnt = 1) THEN
		SELECT couple_id into id FROM uberconsole.tbl_hrcouples WHERE 
				(couple_key  = $1) AND (event_id = $2);
		rtr := id;
	ELSE
		rtr := -99;
	END IF;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_HEATRESULT_COUPLES_INSERT(	
	vcouple_key 	text,
	vperson1_key	text,
	vperson2_key	text,
	vevent_id		int,
	vxml_id			int	
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT nextval('uberconsole.seq_hrcouples') INTO id;
	INSERT INTO uberconsole.tbl_hrcouples (
		couple_id,
		couple_key,
		person1_key,
		person2_key,
		event_id,
		xml_id
	)
	VALUES (id,$1,$2,$3,$4,$5);
	rtr := id;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_HEATRESULT_HEATS_INSERT(	
	vheat_name 		text,
	vheat_session 	text,
	vheat_time		text,
	vheat_date 		text,
	vdescription 	text,
	vevent_id 		int,
	vxml_id 		int	
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT nextval('uberconsole.seq_hrheats') INTO id;
	INSERT INTO uberconsole.tbl_hrheats (
		heat_id,
		heat_name,
		heat_session,
		heat_time,
		heat_date,
		description,
		event_id,
		xml_id
    )
	VALUES (id,$1,$2,$3,$4,$5,$6, $7);
	rtr := id;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

	
CREATE OR REPLACE FUNCTION uberconsole.FN_HEATRESULT_SUBHEATS_INSERT(	
	vsubheat_key	text,
	vsubheat_type 	text,
	vsubheat_dance	text,
	vsubheat_level 	text,
	vsubheat_age  	text,
	vheat_id 		int	
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT nextval('uberconsole.seq_hrsubheats') INTO id;
	INSERT INTO uberconsole.tbl_hrsubheats (
		subheat_id,
		subheat_key,
		subheat_type,
		subheat_dance,
		subheat_level,
		subheat_age,
		heat_id
	)
	VALUES (id,$1,$2,$3,$4,$5,$6);
	rtr := id;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;
 		

CREATE OR REPLACE FUNCTION uberconsole.FN_HEATRESULT_COUPLE_ENTRIES_INSERT(	
	vcouple_key 	text,
	vsubheat_id 	int,
	vevent_id 	int
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cid  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT couple_id into cid FROM uberconsole.tbl_hrcouples WHERE 
				(couple_key  = $1) AND (event_id = $3);
	SELECT nextval('uberconsole.seq_hrcoupleentries') INTO id;
	INSERT INTO uberconsole.tbl_hrcoupleentries (
		entry_id,
		couple_key,
		couple_id,
		subheat_id
	)
	VALUES (id,$1,cid,$2);
	rtr := id;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;

CREATE OR REPLACE FUNCTION uberconsole.FN_HEATRESULT_RESULT_INSERT(	
	judgepanel		text,
	scoreheaders	text,
	subheat_id		int
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT nextval('uberconsole.seq_hrresult') INTO id;
	INSERT INTO uberconsole.tbl_hrresult (
		result_id,
		judgepanel,
		scoreheaders,
		subheat_id
	)
	VALUES (id,$1,$2,$3);
	rtr := id;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;


CREATE OR REPLACE FUNCTION uberconsole.FN_HEATRESULT_MARKS_INSERT(	
	vcouple_key		text,
	vcouple_value	text,
	vresult_id		int,
	vsubheat_id		int,
	vevent_id 	int
) RETURNS INTEGER AS
$BODY$DECLARE
	id  	INTEGER;
	cid  	INTEGER;
	cnt 	INTEGER;
	rtr	INTEGER;
BEGIN
	SELECT couple_id into cid FROM uberconsole.tbl_hrcouples WHERE 
				(couple_key  = $1) AND (event_id = $5);
	SELECT nextval('uberconsole.seq_hrmarks') INTO id;
	INSERT INTO uberconsole.tbl_hrmarks (
		mark_id,
		couple_key,
		couple_value,
		couple_id,
		result_id,
		subheat_id
	)
	VALUES (id,$1,$2,cid,$3,$4);
	rtr := id;
	RETURN rtr;
END;$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;
