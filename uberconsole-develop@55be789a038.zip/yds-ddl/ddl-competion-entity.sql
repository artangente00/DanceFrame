/* 
===============================================================
* File:		ddl-competition-entity.sql
* Desc: 	Competion module table definition
* Auth:		lmorallos
* Date:		2017/11/15
===============================================================
*/

/* [*] =competition */
create sequence uberconsole.seq_competition
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;

DROP TABLE IF EXISTS uberconsole.tbl_competition;
CREATE TABLE uberconsole.tbl_competition (
	competition_id	int primary key,
	name		varchar(512)	
);

/* [*] =events */
create sequence uberconsole.seq_event
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;

DROP TABLE IF EXISTS uberconsole.tbl_event;
CREATE TABLE uberconsole.tbl_event (
	event_id		int primary key,	
	date_start		date,
	date_stop		date,
	deadline		timestamp,
	website			varchar(255),
	event_year		int,
	competition_id 	int,
	status		 	int
);

ALTER TABLE uberconsole.tbl_event ADD COLUMN event_name	varchar(512);
ALTER TABLE uberconsole.tbl_event ADD COLUMN image_id int;
ALTER TABLE uberconsole.tbl_event ADD COLUMN pubaction int;
ALTER TABLE uberconsole.tbl_event ADD COLUMN pubstatus int;
ALTER TABLE uberconsole.tbl_event ADD COLUMN timecommit bigint;

ALTER TABLE uberconsole.tbl_event DROP COLUMN pubaction;
ALTER TABLE uberconsole.tbl_event ADD COLUMN lastupdate timestamp;
ALTER TABLE uberconsole.tbl_event ADD COLUMN usemanual boolean;

ALTER TABLE uberconsole.tbl_event ADD COLUMN uregister boolean;
ALTER TABLE uberconsole.tbl_event ADD COLUMN push_id varchar(512);
ALTER TABLE uberconsole.tbl_event ADD COLUMN lastpublish timestamp;

/* [*] =venue */
create sequence uberconsole.seq_venue
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;

DROP TABLE IF EXISTS uberconsole.tbl_venue;
CREATE TABLE uberconsole.tbl_venue (
	venue_id	int primary key,
	name		varchar(512),
	address		varchar(255),
	address2	varchar(255),
	city		varchar(255),	
	province	varchar(255),
	country		varchar(255),
	zipcode		varchar(20),
	phone		varchar(20),
	fax			varchar(20),
	resvphone	varchar(20),
	website		varchar(255),
	longtitude	varchar(50),
	latitude	varchar(50),
	event_id	int
);

/* [*] =contact */
create sequence uberconsole.seq_contact
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;

DROP TABLE IF EXISTS uberconsole.tbl_contact;
CREATE TABLE uberconsole.tbl_contact (
	contact_id	int primary key,
	name		varchar(255),
	address		varchar(255),
	address2	varchar(255),
	city		varchar(255),	
	province	varchar(255),
	country		varchar(255),
	zipcode		varchar(20),
	phone		varchar(20),
	fax			varchar(20),
	email		varchar(255),
	event_id	int
);

/* [*] =organizer */
create sequence uberconsole.seq_organizer
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;
	
	
DROP TABLE IF EXISTS uberconsole.tbl_organizer;
CREATE TABLE uberconsole.tbl_organizer (
	organizer_id int primary key,
	name	  varchar(32),
	event_id	int
);
/* [*] = image table */
drop sequence uberconsole.seq_imgdata;
create sequence uberconsole.seq_imgdata
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;

DROP TABLE IF EXISTS uberconsole.tbl_imgdata;
CREATE TABLE uberconsole.tbl_imgdata 
(
	image_id int primary key,
	filename	varchar(255),
	mimetype	varchar(32),
	code		varchar(32),
	code_id		int,
	image 		bytea
);
	
/* [*] =schedule */
create sequence uberconsole.seqtmpevent
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;
	
create sequence uberconsole.seq_schedule
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;

DROP TABLE IF EXISTS uberconsole.tbl_schedule;
CREATE TABLE uberconsole.tbl_schedule (
	schedule_id int primary key,
	event_id	  	int
	sched_name 		varchar(512);
	sched_enable 	boolean;
);

create sequence uberconsole.seq_schedlist
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;
	
	
DROP TABLE IF EXISTS uberconsole.tbl_schedlist;
CREATE TABLE uberconsole.tbl_schedlist(
	schedlist_id int primary key,
	header_name	  varchar(256),
	timevalue	  varchar(32),
	description	  varchar(256),
	event_id	  int,
	tempdata	  boolean
);

CREATE TABLE uberconsole.tbl_tmpschedlist(
	schedlist_id int primary key,
	header_name	  varchar(256),
	hdrorder 	  int,
	timevalue	  varchar(32),
	tvalorder 	  int,
	description	  varchar(256),
	event_id	  int
);

ALTER TABLE uberconsole.tbl_schedlist DROP COLUMN tmpdata;
ALTER TABLE uberconsole.tbl_event ADD COLUMN deleted boolean;
ALTER TABLE uberconsole.tbl_event ADD COLUMN hdrorder int;
ALTER TABLE uberconsole.tbl_event ADD COLUMN tvalorder int;

/* event enable */
create sequence uberconsole.seq_senablement
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;
	
CREATE TABLE uberconsole.tbl_enablement(
	enable_id int primary key,
	venue_enable		boolean not null default false,
	contact_enable		boolean not null default false,
	organizer_enable	boolean not null default false,
	schedule_enable		boolean not null default false,
	hotel_enable		boolean not null default false,
	sponsor_enable		boolean not null default false,
	event_id 	int
);

ALTER TABLE uberconsole.tbl_enablement ADD COLUMN finance_enable boolean not null default false;

/* tempall */
create sequence uberconsole.seq_codeall
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;
	
CREATE TABLE uberconsole.tbl_tmpformdata(
	code_id int primary key,
	code		varchar(64),
	url	  		varchar(512),
	description	varchar(1024),
	ordervalue	int,
	image_id	int,
	event_id	int
);

CREATE TABLE uberconsole.tbl_tmpimgdata 
(
	image_id int primary key,
	filename	varchar(255),
	mimetype	varchar(32),
	code		varchar(32),
	code_id		int,
	image 		bytea
);

/* hotel */
CREATE TABLE uberconsole.tbl_hotel(
	hotel_id int primary key,
	url	  		varchar(512),
	description	varchar(1024),
	ordervalue	int,
	image_id	int,
	event_id	int
);

/* sponsor */
CREATE TABLE uberconsole.tbl_sponsor (
	sponsor_id int primary key,
	url	  		varchar(512),
	description	varchar(1024),
	ordervalue	int,
	image_id	int,
	event_id	int
);

/* information */
CREATE TABLE uberconsole.tbl_information(
	information_id int primary key,
	url	  		varchar(512),
	description	varchar(1024),
	ordervalue	int,
	image_id	int,
	event_id	int
);

/* finance */
create sequence uberconsole.seq_finance
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;
	
CREATE TABLE uberconsole.tbl_finance(
	finance_id int primary key,
	surcharge	double,
	description	varchar(1024),
	event_id	int
);


		
/* [*] =lookup  */
drop sequence uberconsole.seq_loookup;
create sequence uberconsole.seq_loookup
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;
	
DROP TABLE IF EXISTS uberconsole.tbl_lookup;
CREATE TABLE uberconsole.tbl_lookup 
(
	lookup_id int primary key,
	code		varchar(32),
	idx			int,
	description varchar(255)
);

INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'EVTSTAT',1, 'Stage 1 - Pre-Registration');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'EVTSTAT',2, 'Stage 2 - Registering');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'EVTSTAT',3, 'Stage 3 - Registration Closed');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'EVTSTAT',4, 'Stage 4 - In-Progress');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'EVTSTAT',5, 'Stage 5 - Closed');

INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'NOYES',0, 'NO');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'NOYES',1, 'YES');

INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'PUBSTAT',0, 'NOT PUBLISHED');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'PUBSTAT',1, 'PUBLISH PENDING');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'PUBSTAT',2, 'PUBLISH COMMIT IN PROGRESS');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'PUBSTAT',3, 'UNPUBLISH COMMIT IN PROGRESS');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'PUBSTAT',4, 'UNPUBLISH PENDING');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'PUBSTAT',5, 'PUBLISHED');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'PUBSTAT',6, 'RE-PUBLISH PENDING');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'PUBSTAT',7, 'RE-PUBLISH COMMIT IN PROGRESS');

--
-- INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-FORMTYPE',1, 'COUPLE');
-- INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-FORMTYPE',2, 'SOLO');
-- INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-FORMTYPE',3, 'COUPLE AND SOLO');
-- INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-FORMTYPE',4, 'GROUP');


INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-HEADTYPE',1, 'LEVEL');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-HEADTYPE',2, 'STYLE');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-HEADTYPE',3, 'COUPLE');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-HEADTYPE',4, 'GROUP');

INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-FORMTYPE',1, 'AGE ONLY');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-FORMTYPE',2, 'WITH AGE CHECK');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-FORMTYPE',3, 'GROUP');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-FORMTYPE',4, 'FREEFORM');

INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-ENTRYTYPE',1, 'SOLO');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-ENTRYTYPE',2, 'COUPLE');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-ENTRYTYPE',3, 'COUPLE+SOLO');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-ENTRYTYPE',4, 'GROUP');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-ENTRYTYPE',5, 'AMATEUR');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-ENTRYTYPE',6, 'PROFESSIONAL');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-ENTRYTYPE',7, 'AM-AM');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-ENTRYTYPE',8, 'AM-PRO');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-ENTRYTYPE',9, 'PRO-AM');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-ENTRYTYPE',10, 'PRO-PRO');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-ENTRYTYPE',11, 'MULTI-DANCES');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-ENTRYTYPE',12, 'OPEN-SCHOLARSHIP');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-ENTRYTYPE',13, 'SINGLE');

INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-FIELD',1, 'AGE');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-FIELD',2, 'LEVEL');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-FIELD',3, 'DANCE CATEGORY');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-FIELD',4, 'STUDENT NAME');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-FIELD',5, 'TEACHER NAME');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-FIELD',6, 'DANCE');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-FIELD',7, 'SESSION');


INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-DANCECAT',1, 'OPEN');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-DANCECAT',2, 'CLOSE');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-DANCECAT',3, 'DANCE');

INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-SESSION',1, 'DAY');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-SESSION',2, 'EVENING');

INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-COUPLE',1, 'AM-AM');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-COUPLE',2, 'AM-PRO');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-COUPLE',3, 'PRO-AM');
INSERT INTO  uberconsole.tbl_lookup(lookup_id, code, idx, description) VALUES (nextval('uberconsole.seq_loookup'),'CF-COUPLE',4, 'PRO-PRO');


/*---- user ----*/

drop sequence uberconsole.seq_user;
create sequence uberconsole.seq_user
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;
	
DROP TABLE IF EXISTS uberconsole.tbl_user;
CREATE TABLE uberconsole.tbl_user
(
	user_id int primary key,
	username	varchar(32),
	firstname	varchar(128),
	lastname	varchar(128),
	active		boolean,
	datecreated	timestamp,
	lastupdated	timestamp
);

INSERT INTO uberconsole.tbl_user (
	user_id,
	username,
	firstname,
	lastname,
	active,
	datecreated		
)
VALUES (9999 ,'admin', 'System', 'Adminsitrator', true, now());

create sequence uberconsole.seq_systransid
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;
	
ALTER TABLE uberconsole.tbl_user DROP COLUMN syslog_id;
ALTER TABLE uberconsole.tbl_user DROP COLUMN datecreated;
ALTER TABLE uberconsole.tbl_user DROP CONSTRAINT user_id;
ALTER TABLE uberconsole.tbl_user ADD COLUMN sysuid int;
ALTER TABLE uberconsole.tbl_user ADD COLUMN systransid bigint;
ALTER TABLE uberconsole.tbl_user ADD COLUMN syscreated timestamp;
ALTER TABLE uberconsole.tbl_user ADD COLUMN sysdeleted timestamp;
ALTER TABLE uberconsole.tbl_user ADD COLUMN sysactive boolean;
ALTER TABLE uberconsole.tbl_user ADD COLUMN sysaction int;

UPDATE uberconsole.tbl_user SET sysactive = true;

UPDATE uberconsole.tbl_user SET 
	systransid = 0,
	syscreated = now(),
	sysaction = 1,
	sysuid = 0
WHERE user_id=9999;

/* ---- configuration ---*/
create sequence uberconsole.seq_form
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;
	
CREATE TABLE uberconsole.tbl_form
(
	form_id int primary key,
	name	 varchar(128)
);

INSERT INTO  uberconsole.tbl_form(form_id, name) VALUES (nextval('uberconsole.seq_form'),'Future Celebrities Competition Kids');
INSERT INTO  uberconsole.tbl_form(form_id, name) VALUES (nextval('uberconsole.seq_form'),'Rising Start Challenge');
INSERT INTO  uberconsole.tbl_form(form_id, name) VALUES (nextval('uberconsole.seq_form'),'Group Dance Competition');
INSERT INTO  uberconsole.tbl_form(form_id, name) VALUES (nextval('uberconsole.seq_form'),'Adult Showcase Single Dance');
INSERT INTO  uberconsole.tbl_form(form_id, name) VALUES (nextval('uberconsole.seq_form'),'Showdown Solo');
INSERT INTO  uberconsole.tbl_form(form_id, name) VALUES (nextval('uberconsole.seq_form'),'Amateur Competition');
INSERT INTO  uberconsole.tbl_form(form_id, name) VALUES (nextval('uberconsole.seq_form'),'Adult Multi-Dance Competition(Multi-Dances)');
INSERT INTO  uberconsole.tbl_form(form_id, name) VALUES (nextval('uberconsole.seq_form'),'Adult Multi-Dance Competition (Open Scholarship)');

create sequence uberconsole.seq_age
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;

CREATE TABLE uberconsole.tbl_age
(
	age_id int primary key,
	name	 	 varchar(128),
	description	 varchar(128)
);

INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'Pre-Dance','3-7');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'JV0','4-7');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'JV1','8-9');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'JV2','10-11');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'JN1','12-13');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'JN2','14-15');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'YOUTH','16+');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'YT1','16-18');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'YT2','Und 21');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'A1','16+');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'A2','35+');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'A3','45+');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'A4','55+');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'B1','45+');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'B2','55+');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'C1','65+');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'C2','75+');

INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'LA-MD1','18+');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'LA-MD2','36+');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'LA-MD3','51+');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'LA-OS1','18+');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'LA-OS2','50+');

INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'Bronze 1','18+');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'Bronze 2','36+');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'Bronze 3','51+');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'Silver 1','18+');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'Silver 2','36+');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'Silver 3','50+');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'Gold 1','18+');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'Gold 2','36+');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'Gold 3','50+');


INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'Bronze/Silver 1','18+');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'Bronze/Silver 2','50+');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'Gold/Advance 1','18+');
INSERT INTO  uberconsole.tbl_age(age_id, name,description) VALUES (nextval('uberconsole.seq_age'),'Gold/Advance 2','50+');



create sequence uberconsole.seq_level
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;
	
CREATE TABLE uberconsole.tbl_level
(
	level_id int primary key,
	name	 	 varchar(128)
);
INSERT INTO  uberconsole.tbl_level(level_id, name) VALUES (nextval('uberconsole.seq_level'),'BASIC');
INSERT INTO  uberconsole.tbl_level(level_id, name) VALUES (nextval('uberconsole.seq_level'),'DEBUTANTE');
INSERT INTO  uberconsole.tbl_level(level_id, name) VALUES (nextval('uberconsole.seq_level'),'PRE-BRONZE');
INSERT INTO  uberconsole.tbl_level(level_id, name) VALUES (nextval('uberconsole.seq_level'),'BRONZE');
INSERT INTO  uberconsole.tbl_level(level_id, name) VALUES (nextval('uberconsole.seq_level'),'SILVER');
INSERT INTO  uberconsole.tbl_level(level_id, name) VALUES (nextval('uberconsole.seq_level'),'GOLD');
INSERT INTO  uberconsole.tbl_level(level_id, name) VALUES (nextval('uberconsole.seq_level'),'NEW COMER');
INSERT INTO  uberconsole.tbl_level(level_id, name) VALUES (nextval('uberconsole.seq_level'),'INTER BRONZE');
INSERT INTO  uberconsole.tbl_level(level_id, name) VALUES (nextval('uberconsole.seq_level'),'FULL BRONZE');
INSERT INTO  uberconsole.tbl_level(level_id, name) VALUES (nextval('uberconsole.seq_level'),'INTER SILVER');
INSERT INTO  uberconsole.tbl_level(level_id, name) VALUES (nextval('uberconsole.seq_level'),'FULL SILVER');
INSERT INTO  uberconsole.tbl_level(level_id, name) VALUES (nextval('uberconsole.seq_level'),'INTER GOLD');
INSERT INTO  uberconsole.tbl_level(level_id, name) VALUES (nextval('uberconsole.seq_level'),'FULL GOLD');

create sequence uberconsole.seq_style
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;
		
CREATE TABLE uberconsole.tbl_style
(
	style_id int primary key,
	name	 	 varchar(128)
);

INSERT INTO  uberconsole.tbl_style(style_id, name) VALUES (nextval('uberconsole.seq_style'),'SMOOTH');
INSERT INTO  uberconsole.tbl_style(style_id, name) VALUES (nextval('uberconsole.seq_style'),'RHYTHM');
INSERT INTO  uberconsole.tbl_style(style_id, name) VALUES (nextval('uberconsole.seq_style'),'STANDARD');
INSERT INTO  uberconsole.tbl_style(style_id, name) VALUES (nextval('uberconsole.seq_style'),'LATIN');
INSERT INTO  uberconsole.tbl_style(style_id, name) VALUES (nextval('uberconsole.seq_style'),'INTERNATIONAL STYLE SINGLE DANCE');
INSERT INTO  uberconsole.tbl_style(style_id, name) VALUES (nextval('uberconsole.seq_style'),'AMERICAN STYLE SINGLE DANCE');


create sequence uberconsole.seq_dance
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;
	
CREATE TABLE uberconsole.tbl_dance
(
	dance_id int primary key,
	name	 	 varchar(128),
	code	 	 varchar(64)
);

INSERT INTO  uberconsole.tbl_dance(dance_id, name, code) VALUES (nextval('uberconsole.seq_dance'),'WALTZ','W');
INSERT INTO  uberconsole.tbl_dance(dance_id, name, code) VALUES (nextval('uberconsole.seq_dance'),'TANGO','T');
INSERT INTO  uberconsole.tbl_dance(dance_id, name, code) VALUES (nextval('uberconsole.seq_dance'),'VIENESSE WALTZ','VW');
INSERT INTO  uberconsole.tbl_dance(dance_id, name, code) VALUES (nextval('uberconsole.seq_dance'),'FOXTROT','F');
INSERT INTO  uberconsole.tbl_dance(dance_id, name, code) VALUES (nextval('uberconsole.seq_dance'),'QUICKSTEP','QS');


create sequence uberconsole.seq_eventform
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;
	
CREATE TABLE uberconsole.tbl_eventform
(
	eventform_id int primary key,
	event_id	int,
	form_id	 	int,
	formtype	int,
	headertype	int,
	entrytype	int
)

create sequence uberconsole.seq_eventform_hcontent
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;
	
CREATE TABLE uberconsole.tbl_eventform_hcontent
(
	hcontent_id int primary key,
	eventform_id  	int,
	horizheader	 	varchar(255)
)

create sequence uberconsole.seq_eventform_dance
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;

CREATE TABLE uberconsole.tbl_eventform_dance
(
	eventdance_id int primary key,
	hcontent_id   	int,
	eventform_id  	int,
	code	 	  	varchar(64),
	description	  	varchar(512)
)

create sequence uberconsole.seq_eventform_field
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;
	
CREATE TABLE uberconsole.tbl_eventform_field
(
	eventfield_id int primary key,
	eventform_id  	int,
	field_name	  	varchar(255),
	linkto		  	varchar(255)
);

create sequence uberconsole.seq_eventform_vertical
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;
	
CREATE TABLE uberconsole.tbl_eventform_vertical
(
	eventvertical_id int primary key,
	eventform_id  	int,
	eventfield_id	int,
	code			varchar(255),
	description		varchar(255),
	allowall		boolean
);

create sequence uberconsole.seq_eventform_allow
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;
	
CREATE TABLE uberconsole.tbl_eventform_vertical_allow
(
	eventallow_id  	int primary key,
	eventform_id  		int,
	eventvertical_id 	int,
	eventdance_id		int
);

create sequence uberconsole.seq_eventform_xml
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;
	
CREATE TABLE uberconsole.tbl_eventform_xml
(
	eventxml_id  	int primary key,
	event_id  		int,
	xmlgenerated	bytea,
	jsongenerated 	bytea,
	xmlmanual		bytea,
	jsonmanual		bytea
);


/* heat list */
CREATE SEQUENCE uberconsole.seq_heatlist
    START 1
    INCREMENT 1
    NO MAXVALUE
    CACHE 1;

CREATE TABLE uberconsole.tbl_heatlist
(		
	heatlist_id		int,	
    event_id		int,
	description		varchar(255),
	filename		varchar(255),
    heatasof		timestamp
);


CREATE SEQUENCE uberconsole.seq_heatstudio
    START 1
    INCREMENT 1
    NO MAXVALUE
    CACHE 1;


CREATE TABLE uberconsole.tbl_heatstudio
(		
	studio_id		int,
	studiocpm_id	varchar(255),
	name			varchar(255),	
	heatlist_id		int
);


CREATE SEQUENCE uberconsole.seq_heatperson
    START 1
    INCREMENT 1
    NO MAXVALUE
    CACHE 1;


CREATE TABLE uberconsole.tbl_heatperson
(		
	person_id		int,
	personcpm_id	varchar(255),
	lastname		varchar(255),
	firstname		varchar(255),
	sex				varchar(8),
	profile_type	varchar(8),
	studio_id		int,
	studiocpm_id	varchar(255),	
	heatlist_id		int
);

CREATE SEQUENCE uberconsole.seq_heatinfo
    START 1
    INCREMENT 1
    NO MAXVALUE
    CACHE 1;


CREATE TABLE uberconsole.tbl_heatinfo
(	
	heat_id		int,
	heat_val	varchar(255),
	schedule	varchar(255),
	description varchar(255),	
	heatlist_id	int
);


CREATE SEQUENCE uberconsole.seq_heatcomp
    START 1
    INCREMENT 1
    NO MAXVALUE
    CACHE 1;


CREATE TABLE uberconsole.tbl_heatcomp
(		
	comp_id		int,
	compcpm_id	varchar(255),
	heattype	varchar(255),
	dance		varchar(255),
	heatlevel	varchar(255),
	age			varchar(255),	
	heat_id		int,
	heatlist_id	int
);


CREATE SEQUENCE uberconsole.seq_heatentry
    START 1
    INCREMENT 1
    NO MAXVALUE
    CACHE 1;

CREATE TABLE uberconsole.tbl_heatentry
(			
	entry_id		int,
	entrycpm_id		varchar(255),
	person_id		int,
	personcpm_id	varchar(255),
	seqno			varchar(255),
	partner_id		int,
	partnercpm_id	varchar(255),
	studio_id		int,
	studiocpm_id	varchar(255),	
	comp_id			int,
	compcpm_id		varchar(255),	
	otherinfo		varchar(255),
	heatlist_id		int
);




/*---- syslog ----*/

drop sequence uberconsole.seq_syslog;
create sequence uberconsole.seq_syslog
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;

DROP TABLE IF EXISTS uberconsole.tbl_syslog;
CREATE TABLE uberconsole.tbl_syslog
(
	syslog_id int primary key,
	action		varchar(32),
	modname		varchar(128),
	classname	varchar(128),
	user_id		int,
	logdate		timestamp
);

ALTER TABLE uberconsole.tbl_competition ADD COLUMN syslog_id int;
ALTER TABLE uberconsole.tbl_event ADD COLUMN syslog_id int;
ALTER TABLE uberconsole.tbl_venue ADD COLUMN syslog_id int;
ALTER TABLE uberconsole.tbl_contact ADD COLUMN syslog_id int;
ALTER TABLE uberconsole.tbl_organizer ADD COLUMN syslog_id int;
ALTER TABLE uberconsole.tbl_imgdata ADD COLUMN syslog_id int;
ALTER TABLE uberconsole.tbl_user ADD COLUMN syslog_id int;
ALTER TABLE uberconsole.tbl_user DROP COLUMN lastupdated;

UPDATE uberconsole.tbl_user SET lastname='Administrator' WHERE user_id=9999

ALTER TABLE uberconsole.tbl_competition DROP COLUMN syslog_id;
ALTER TABLE uberconsole.tbl_event DROP COLUMN syslog_id;
ALTER TABLE uberconsole.tbl_venue DROP COLUMN syslog_id;
ALTER TABLE uberconsole.tbl_contact DROP COLUMN syslog_id;
ALTER TABLE uberconsole.tbl_organizer DROP COLUMN syslog_id;
ALTER TABLE uberconsole.tbl_imgdata DROP COLUMN syslog_id;

/* -- views --- */
DROP VIEW IF EXISTS uberConsole.VW_EVENT_WITHCOMPETITION;
CREATE OR REPLACE VIEW uberConsole.VW_EVENT_WITHCOMPETITION AS
SELECT 
	a.event_id,
    a.event_name,
    a.date_start,
    a.date_stop,
    a.deadline,
    a.website,
    a.event_year,
	a.timecommit,
    a.status,
    a.competition_id,
	a.image_id,
	a.pubstatus,
	a.lastupdate,
	a.usemanual,
	a.uregister,
	a.push_id,
	a.lastpublish,
    b.name as competition_name,	
	c.filename,
	c.mimetype,
    d.description as status_name,
	f.description as publish_status
FROM uberconsole.tbl_event a
JOIN uberconsole.tbl_competition b
	ON b.competition_id = a.competition_id
LEFT JOIN uberconsole.tbl_imgdata c
	ON c.image_id = c.image_id
	AND c.code_id = a.event_id
	AND c.code = 'EVENT'
LEFT JOIN uberconsole.tbl_lookup d
	ON d.idx = a.status
	AND d.code = 'EVTSTAT'
LEFT JOIN uberconsole.tbl_lookup f
	ON f.idx = a.pubstatus
	AND f.code = 'PUBSTAT';
	
DROP VIEW IF EXISTS uberConsole.VW_EVENT_PUBLISH;
CREATE OR REPLACE VIEW uberConsole.VW_EVENT_PUBLISH AS
SELECT 
	a.event_id,
    a.event_name,
    a.date_start,
    a.event_year,
	a.timecommit,
    a.status,
    a.competition_id,
	a.pubstatus,
	a.lastpublish,
    b.name as competition_name,	
    d.description as status_name,
	f.description as publish_status
FROM uberconsole.tbl_event a
JOIN uberconsole.tbl_competition b
	ON b.competition_id = a.competition_id
LEFT JOIN uberconsole.tbl_lookup d
	ON d.idx = a.status
	AND d.code = 'EVTSTAT'
LEFT JOIN uberconsole.tbl_lookup f
	ON f.idx = a.pubstatus
	AND f.code = 'PUBSTAT';

DROP VIEW IF EXISTS uberConsole.VW_SYSLOG;
CREATE OR REPLACE VIEW uberConsole.VW_SYSLOG AS
SELECT
 	a.syslog_id,
	a.action,
	a.modname,
	a.classname,
	a.user_id,
	a.logdate,
    b.username
FROM uberconsole.tbl_syslog a
JOIN uberconsole.tbl_user b
ON b.user_id = a.user_id
    
DROP VIEW IF EXISTS uberconsole.VW_USERMANAGEMENT;
CREATE OR REPLACE VIEW uberconsole.VW_USERMANAGEMENT AS
SELECT 
  user_id,
  username,
  firstname,
  lastname,
  active,
  syscreated as datecreated,
  sysdeleted as lastupdated
FROM uberconsole.tbl_user
WHERE sysactive=true


DROP VIEW IF EXISTS uberConsole.VW_EVENT_CONFIGFORM;
CREATE OR REPLACE VIEW uberConsole.VW_EVENT_CONFIGFORM AS
SELECT
	a.eventform_id,
	a.event_id,
	a.form_id,
	a.formtype,
	a.headertype,
	a.entrytype,
    b.event_name,
	c.name as form_name,
	d.description as formtype_name,
	e.description as headertype_name,
	f.description as entrytype_name
FROM uberconsole.tbl_eventform a
JOIN uberconsole.tbl_event b
	ON b.event_id = a.event_id
JOIN uberconsole.tbl_form c
	ON 	c.form_id = a.form_id
LEFT JOIN uberconsole.tbl_lookup d
	ON d.idx = a.formtype
	AND d.code = 'CF-FORMTYPE'
LEFT JOIN uberconsole.tbl_lookup e
	ON e.idx = a.headertype
	AND e.code = 'CF-HEADTYPE'
LEFT JOIN uberconsole.tbl_lookup f
	ON f.idx = a.entrytype
	AND f.code = 'CF-ENTRYTYPE';


DROP VIEW IF EXISTS uberConsole.VW_EVENT_CONFIGDANCE;
CREATE OR REPLACE VIEW uberConsole.VW_EVENT_CONFIGDANCE AS
SELECT 
	a.eventdance_id,
    a.hcontent_id,
    a.eventform_id,
    a.code,
    a.description,
    b.horizheader
FROM uberconsole.tbl_eventform_dance a
JOIN uberconsole.tbl_eventform_hcontent b
	ON b.eventform_id = a.eventform_id
	AND b.hcontent_id = a.hcontent_id;
	

DROP VIEW IF EXISTS uberConsole.VW_EVENT_CONFIGALLOW;
CREATE OR REPLACE VIEW uberConsole.VW_EVENT_CONFIGALLOW AS
SELECT 
a.eventallow_id, 
a.eventform_id, 
a.eventvertical_id, 
a.eventdance_id,
b.code as verticalcode,
b.description as verticaldesc,
c.code as dancecode,
b.description as dancedesc
FROM uberconsole.tbl_eventform_vertical_allow a
JOIN uberconsole.tbl_eventform_vertical b
	ON b.eventvertical_id = a.eventvertical_id
LEFT JOIN uberconsole.tbl_eventform_dance c
	ON c.eventdance_id = a.eventdance_id;


	
DROP VIEW IF EXISTS uberConsole.VW_EVENT_CONFIGXML;
CREATE OR REPLACE VIEW uberConsole.VW_EVENT_CONFIGXML AS
SELECT
	a.event_id,
	a.event_name,
	a.usemanual,
	b.eventxml_id,
	b.xmlgenerated,
	b.jsongenerated,
	b.xmlmanual,
	b.jsonmanual
FROM uberconsole.tbl_event a
JOIN uberconsole.tbl_eventform_xml b
ON b.event_id = a.event_id;

CREATE OR REPLACE VIEW uberconsole.VW_EVENT_GENERICFORM_DATA AS
SELECT
	a.code_id,
	a.code,
	a.url,
	a.description,
	a.ordervalue,
	a.image_id,
	a.event_id
	b.filename,
	b.mimetype,
	b.code,
	b.code_id as imgevent_id,
	b.image
FROM uberconsole.tbl_tmpformdata a
JOIN uberconsole.tbl_tmpimgdata b
	ON b.image_id = a.image_id;


CREATE OR REPLACE VIEW uberconsole.VW_EVENT_FORM_HOTEL AS
SELECT
	a.hotel_id as code_id,
	a.url,
	a.description,
	a.ordervalue,
	a.image_id,
	a.event_id,
	b.filename,
	b.mimetype
FROM uberconsole.tbl_hotel a
LEFT JOIN uberconsole.tbl_imgdata b
	ON b.image_id = a.image_id;	
	

CREATE OR REPLACE VIEW uberconsole.VW_EVENT_FORM_SPONSOR AS
SELECT
	a.sponsor_id as code_id,
	a.url,
	a.description,
	a.ordervalue,
	a.image_id,
	a.event_id,
	b.filename,
	b.mimetype
FROM uberconsole.tbl_sponsor a
LEFT JOIN uberconsole.tbl_imgdata b
	ON b.image_id = a.image_id;	
	
	
CREATE OR REPLACE VIEW uberconsole.VW_EVENT_FORM_INFO AS
SELECT
	a.information_id as code_id,
	a.url,
	a.description,
	a.ordervalue,
	a.image_id,
	a.event_id,
	b.filename,
	b.mimetype
FROM uberconsole.tbl_information a
LEFT JOIN uberconsole.tbl_imgdata b
	ON b.image_id = a.image_id;	

CREATE OR REPLACE VIEW uberconsole.VW_HEATLIST_INFO AS
SELECT 
	a.heatlist_id,
	a.person_id,
    a.personcpm_id,
    (b.lastname || ',' || b.firstname) as mainname,
    b.sex as mainsex,
    a.partner_id,
    a.partnercpm_id,
    (c.lastname || ',' || c.firstname) as partname,
    c.sex as partsex,
    a.seqno,
    a.comp_id,
    a.compcpm_id,
	a.otherinfo,
    d.heattype,
    d.dance,
    d.heatlevel,
    d.age,
    d.heat_id,
    e.heat_val,
    e.schedule,
    e.description
FROM uberconsole.tbl_heatentry a
JOIN uberconsole.tbl_heatperson b
ON b.personcpm_id = a.personcpm_id
LEFT JOIN uberconsole.tbl_heatperson c
ON c.personcpm_id = a.partnercpm_id
LEFT JOIN uberconsole.tbl_heatcomp d
ON d.compcpm_id = a.compcpm_id
AND d.heatlist_id = a.heatlist_id
LEFT JOIN uberconsole.tbl_heatinfo e
ON e.heat_id = d.heat_id
AND e.heatlist_id = a.heatlist_id;




/* [*] = xml data table */
drop sequence uberconsole.seq_xmldata;
create sequence uberconsole.seq_xmldata
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;

DROP TABLE IF EXISTS uberconsole.tbl_xmldata;
CREATE TABLE uberconsole.tbl_xmldata 
(
	xml_id int primary key,
	filename	varchar(255),
	uploadtime	timestatmp,
	code		varchar(32),
	event_id	int,
	xmldata 	bytea
);

/* [*] = heatlist and result strucutre */
drop sequence uberconsole.seq_hrpogram;
create sequence uberconsole.seq_hrpogram
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;

DROP TABLE IF EXISTS uberconsole.tbl_hrpogram;
CREATE TABLE uberconsole.tbl_hrpogram
(
	program_id 	int primary key,
	istudio		boolean,
	ijudge		boolean,
	iperson		boolean,
	iheat		boolean,
	event_id 	int,
	xml_id 		int
);


drop sequence uberconsole.seq_hrstudios;
create sequence uberconsole.seq_hrstudios
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;
	
DROP TABLE IF EXISTS uberconsole.tbl_hrstudios;
CREATE TABLE uberconsole.tbl_hrstudios 
(
	studio_id 	int primary key,
	studio_key 	varchar(255),
	name		varchar(1024),
	invoice		varchar(255),
	event_id 	int,
	xml_id 		int
);

drop sequence uberconsole.seq_hrjudges;
create sequence uberconsole.seq_hrjudges
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;
	
DROP TABLE IF EXISTS uberconsole.tbl_hrjudges;
CREATE TABLE uberconsole.tbl_hrjudges
(
	judge_id 	int primary key,
	judge_key 	varchar(255),
	firstname	varchar(1024),
	lastname	varchar(1024),
	judge_num	varchar(255),
	event_id 	int,
	xml_id 		int
);


drop sequence uberconsole.seq_hrpersons;
create sequence uberconsole.seq_hrpersons
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;
	
DROP TABLE IF EXISTS uberconsole.tbl_hrpersons;
CREATE TABLE uberconsole.tbl_hrpersons
(
	person_id 	int primary key,
	person_key 	varchar(255),
	firstname	varchar(1024),
	lastname	varchar(1024),
	gender		varchar(255),
	persontype	varchar(255),
	studio_key 	varchar(255),
	nickname	varchar(255),
	ndcaus_num	varchar(255),
	competitor_num	varchar(255),
	event_id 	int,
	xml_id 		int
);

drop sequence uberconsole.seq_hrcouples;
create sequence uberconsole.seq_hrcouples
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;
	
DROP TABLE IF EXISTS uberconsole.tbl_hrcouples;
CREATE TABLE uberconsole.tbl_hrcouples
(
	couple_id 	int primary key,
	couple_key 	varchar(255),
	person1_key	varchar(255),
	person2_key varchar(255),
	event_id 	int,
	xml_id 		int
);

drop sequence uberconsole.seq_hrheats;
create sequence uberconsole.seq_hrheats
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;
	
DROP TABLE IF EXISTS uberconsole.tbl_hrheats;
CREATE TABLE uberconsole.tbl_hrheats
(
	heat_id 		int primary key,
	heat_name 		varchar(255),
	heat_session 	varchar(255),
	heat_time		varchar(255),
	heat_date 		varchar(255),
	description 	varchar(1024),
	event_id 		int,
	xml_id 			int
);

DROP sequence IF EXISTS uberconsole.seq_hrsubheats;	
create sequence uberconsole.seq_hrsubheats
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;
	
DROP TABLE IF EXISTS uberconsole.tbl_hrsubheats;
CREATE TABLE uberconsole.tbl_hrsubheats
(
	subheat_id 		int primary key,
	subheat_key 	varchar(255),
	subheat_type 	varchar(255),
	subheat_dance	varchar(255),
	subheat_level 	varchar(255),
	subheat_age  	varchar(255),
	heat_id 		int
); 	
	
DROP sequence IF EXISTS uberconsole.seq_hrcoupleentries;	
create sequence uberconsole.seq_hrcoupleentries
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;
	
DROP TABLE IF EXISTS uberconsole.tbl_hrcoupleentries;
CREATE TABLE uberconsole.tbl_hrcoupleentries
(
	entry_id 		int primary key,
	couple_key 		varchar(255),
	couple_id		int,
	subheat_id		int
); 		

DROP sequence IF EXISTS uberconsole.seq_hrresult;	
create sequence uberconsole.seq_hrresult
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;
	
DROP TABLE IF EXISTS uberconsole.tbl_hrresult;
CREATE TABLE uberconsole.tbl_hrresult
(
	result_id 		int primary key,
	judgepanel		varchar(1024),
	scoreheaders	varchar(1024),
	subheat_id		int
); 

DROP sequence IF EXISTS uberconsole.seq_hrmarks;	
create sequence uberconsole.seq_hrmarks
    start 1
    increment 1
    NO MAXVALUE
    CACHE 1;
	
DROP TABLE IF EXISTS uberconsole.tbl_hrmarks;
CREATE TABLE uberconsole.tbl_hrmarks
(
	mark_id 		int primary key,
	couple_key		varchar(255),
	couple_value	varchar(1024),
	couple_id		int,
	result_id		int,
	subheat_id		int
); 
