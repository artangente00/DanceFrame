/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.listener;

import com.danceframe.console.service.dataprovider.BasicDao;
import com.danceframe.console.web.service.util.SpringContextBean;
import java.io.File;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import liquibase.integration.spring.SpringLiquibase;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

/**
 *
 * @author lmorallos
 */
public class YdsWebStartupListener implements ServletContextListener {
        
        private static final Logger logger = LogManager.getLogger(YdsWebStartupListener.class);
        
        private BasicDao basicDao;
        private SpringLiquibase liquibase;
	
	@Override
	public void contextDestroyed(ServletContextEvent context) {
            logger.info("UserAdd Your Dance Sport Web Application stopped and destroyed.");
		
	}

	@Override
	public void contextInitialized(ServletContextEvent context) {
            logger.info("UserAdd Your Dance Sport Web Application started.");
            logger.info("==>OS Temporary Directory:" +  System.getProperty("java.io.tmpdir"));
            File file = new File(".");
            String currentDirectory = file.getAbsolutePath();
            logger.info("==>Website Current Directory:" + currentDirectory);
            basicDao = (BasicDao)SpringContextBean.getSpringBean("basicDao");
            // Utility.isNullDebug(basicDao, basicDao.getClass().getName());
            if (null != basicDao) {
                logger.info("==>Basic Dao properly initialized.");
            } 
            liquibase = (SpringLiquibase)SpringContextBean.getSpringBean("liquibase");
            if (null != liquibase) {
                logger.info("==>Liquibase automatically started.");
            }
            
	}

    
    /**
     * @return the basicDao
     */
    public BasicDao getBasicDao() {
        return basicDao;
    }

    /**
     * @param basicDao the basicDao to set
     */
    public void setBasicDao(BasicDao basicDao) {
        this.basicDao = basicDao;
    }
}
