/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.managebean;

import com.danceframe.console.common.model.uam.Syslog;
import com.danceframe.console.web.service.UserManagementService;
import com.danceframe.console.web.service.util.AppInfo;
import com.danceframe.console.web.service.util.CookieHelper;
import java.lang.reflect.Field;
import javax.faces.application.FacesMessage;
import javax.faces.application.FacesMessage.Severity;
import javax.faces.bean.ManagedProperty;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.context.RequestContext;

/**
 *
 * @author lmorallos
 */
public abstract class BaseBean {
    
    private static final Logger logger = LogManager.getLogger(BaseBean.class);
    private static final String HTTP_HEADER_AUTH = "Authorization";
    
    @ManagedProperty(value="#{appInfo}")
    private AppInfo appInfo;
    
    @ManagedProperty(value="#{userManagementService}")
    private UserManagementService userManagementService;  
    
    private String username;
    private int userid;
    private String fullname;
    
    
    public  RequestContext context;
    public  FacesContext faces;
    
    private int pageSize = 10;
    private int pageNumber = 1;
    
    public void  addMessage(String summary) {   
        faces = FacesContext.getCurrentInstance();
        FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO, summary, null );
        faces.addMessage(null, msg);
    }
    
    public void  addMessage(String summary, Severity severity ) {   
        faces = FacesContext.getCurrentInstance();
        FacesMessage msg = new FacesMessage(severity, summary, null );
        faces.addMessage(null, msg);
    }
    
    public int writeSysteLog(String action) {
        int iret = 0;
        if (username != null) {
            Syslog syslog = new Syslog();
            syslog.setAction(action);
            String className = super.getClass().getSimpleName();
            syslog.setClassName(className);
            syslog.setUsername(username);
            syslog.setUserid(userid);
            String modname = new String();
            try {
                String classFullName = super.getClass().getName();
                Class myClass = Class.forName(classFullName);
                Field myField = myClass.getDeclaredField("MODULE_NAME");
                modname = (String)myField.get(null);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            syslog.setModuleName(modname);
            logger.info("==>" + syslog.toString());
            iret = userManagementService.getSyslogProviderDao().insert(syslog);
        }
        return iret;
    }
    
    public void getHeaderUser() {
        if ((null == username) || (username.isEmpty())) {
            faces = FacesContext.getCurrentInstance();
            ExternalContext externalContext = faces.getExternalContext();
            username = (String)externalContext.getSessionMap().get(CookieHelper.COOKIE_USER);
            userid = (int)externalContext.getSessionMap().get(CookieHelper.COOKIE_USERID);
            fullname = (String)externalContext.getSessionMap().get(CookieHelper.COOKIE_FNAME) + " " +
                    (String)externalContext.getSessionMap().get(CookieHelper.COOKIE_LNAME);
            logger.info("get hdr username:" + username + " uid:" + userid);
        }
    }
   
    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }
    
    /**
     * @return the pageSize
     */
    public int getPageSize() {
        return pageSize;
    }

    /**
     * @param pageSize the pageSize to set
     */
    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    /**
     * @return the pageNumber
     */
    public int getPageNumber() {
        return pageNumber;
    }

    /**
     * @param pageNumber the pageNumber to set
     */
    public void setPageNumber(int pageNumber) {
        this.pageNumber = pageNumber;
    }

    /**
     * @return the appInfo
     */
    public AppInfo getAppInfo() {
        return appInfo;
    }

    /**
     * @param appInfo the appInfo to set
     */
    public void setAppInfo(AppInfo appInfo) {
        this.appInfo = appInfo;
    }

    /**
     * @return the userManagementService
     */
    public UserManagementService getUserManagementService() {
        return userManagementService;
    }

    /**
     * @param userManagementService the userManagementService to set
     */
    public void setUserManagementService(UserManagementService userManagementService) {
        this.userManagementService = userManagementService;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return the userid
     */
    public int getUserid() {
        return userid;
    }

    /**
     * @param userid the userid to set
     */
    public void setUserid(int userid) {
        this.userid = userid;
    }

    /**
     * @return the fullname
     */
    public String getFullname() {
        return fullname;
    }

    /**
     * @param fullname the fullname to set
     */
    public void setFullname(String fullname) {
        this.fullname = fullname;
    }
}
