/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.managebean.competition;

import com.danceframe.console.common.model.competition.Event;
import com.danceframe.console.common.model.competition.PublishSummary;
import com.danceframe.console.common.model.firebase.competition.ImageBlob;
import com.danceframe.console.service.constant.PublishStatus;
import com.danceframe.console.web.lazy.competition.PublishLazyList;
import com.danceframe.console.web.managebean.BaseBean;
import com.danceframe.console.web.service.CompetitionService;
import com.danceframe.console.web.service.RestProviderService;
import com.danceframe.console.web.service.util.HttpClientHelper;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.model.LazyDataModel;

/**
 *
 * @author lmorallos
 */
@ManagedBean (name="publishView")
@ViewScoped
public class PublishView extends BaseBean implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    public static final String MODULE_NAME = "PUBLISH";
    private static final Logger logger = LogManager.getLogger(PublishView.class);
    private static final String URL = "http://localhost:8080/uberSync/SyncEvents";
    
    @ManagedProperty(value="#{competitionService}")
    private CompetitionService      competitionService;   
    
     @ManagedProperty(value="#{restProviderService}")
    private RestProviderService     restProviderService;
    
    private LazyDataModel<Event>    eventList = null;
    private List<Event>             selectedEvents;
    private PublishSummary          publishSummary;
    
    private List<ImageBlob>         imageDeltaList;
    private int                     totImageSync;
    private int                     totMissingImage;
    
    @PostConstruct
    public void init() {
        if (eventList == null ) {
            eventList = new PublishLazyList(competitionService);
        }
        reloadStatus(); 
        // this.setModuleName(MODULE_NAME);
        this.getHeaderUser();
    }

    public void checkPublishedImages() {
         imageDeltaList = restProviderService.getImageListRestProvider().getDeltaList();
         if (imageDeltaList.size() > 0) {
             addMessage("Images Not Sync to Firebase" + imageDeltaList.size());
             totMissingImage = imageDeltaList.size();
         }
    }
    
    public void closeDialog() {
        // reset data
        totImageSync = 0;
        totMissingImage = 0;
        if (imageDeltaList != null) {
                imageDeltaList.clear();
        } 
    }
    
    public void syncImages() {
        totImageSync = 0;
        for (ImageBlob img:imageDeltaList) {
             logger.info("Syching Image:" + img.toString());
            int imgId = img.getImageId();
            if (restProviderService.getImageStoreRestProvider().addImageToFirebase(imgId)) {
                logger.info("Successfully added image:" + imgId + " filname" + img.getOnDBFilename());
                totImageSync++;
                totMissingImage--;
            }
        }
        if (totImageSync > 0) {
            addMessage("Total Published Images:" + totImageSync);
            imageDeltaList = restProviderService.getImageListRestProvider().getDeltaList();
        } else {
             addMessage("No More Published Images to sync.");
        }
    }
     
    public void refresh() {
        // refresh data table;
        eventList = null;
        eventList = new PublishLazyList(competitionService);
        reloadStatus();
    }
    public void publish() {
        if (!isEmptySelection()) {
            if (isCheckSelectionValue(PublishStatus.PUBLISH_PENDING)) {
               // to publish commited 
                for (Event varevent:selectedEvents) {
                    if (varevent.getPubstatus() == PublishStatus.PUBLISH_PENDING) {
                        long currTime = System.currentTimeMillis();
                        competitionService.getEventProviderDao().
                            setPublishStatus(varevent.getId(),PublishStatus.PUBLISH_IN_PROGRESS,currTime);
                    }
                }
                String urlStr = URL + "?commit=PUBLISHED";
                String result = HttpClientHelper.getURL(urlStr);
                logger.info("firebase helper:" + result);
                reloadStatus();
                addMessage("Selected Publish Pending Event Committed.");
            } else {
                addMessage("No Selected Event with Publish Pending "); 
            }
        }
    }
    
    public void unpublish() {
        if (!isEmptySelection()) {
           if (isCheckSelectionValue(PublishStatus.UNPUBLISH_PENDING)) {
                for (Event varevent:selectedEvents) {
                    if (varevent.getPubstatus() == PublishStatus.UNPUBLISH_PENDING) {
                       long currTime = System.currentTimeMillis();
                        competitionService.getEventProviderDao().
                            setPublishStatus(varevent.getId(),PublishStatus.UNPUBLISH_IN_PROGRESS, currTime);
                    }
                }
                String urlStr = URL + "?commit=UNPUBLISHED";
                String result = HttpClientHelper.getURL(urlStr);
                logger.info("firebase helpere:" + result);
                reloadStatus();
                addMessage("Selected Un-Publish Pending Event Committed.");
            } else {
                addMessage("No Selected Event with Un-Publish Pending "); 
            }
        }
    }
    
    public void republish() {
        if (!isEmptySelection()) {
           if (isCheckSelectionValue(PublishStatus.REPUBLISH_PENDING)) {
                for (Event varevent:selectedEvents) {
                    if (varevent.getPubstatus() == PublishStatus.REPUBLISH_PENDING) {
                       long currTime = System.currentTimeMillis();
                        competitionService.getEventProviderDao().
                            setPublishStatus(varevent.getId(),PublishStatus.REPUBLISH_IN_PROGRESS, currTime);
                    }
                }
                String urlStr = URL + "?commit=REPUBLISHED";
                String result = HttpClientHelper.getURL(urlStr);
                logger.info("firebase helpere:" + result);
                reloadStatus();
                addMessage("Selected Re-Publish Pending Event Committed.");
            } else {
                addMessage("No Selected Event with Re-Publish Pending "); 
            }
        }
    }
    public void allpending() {
        if (!isEmptySelection()) {
           if (isCheckSelectionValue(PublishStatus.PUBLISH_PENDING) || 
               isCheckSelectionValue(PublishStatus.UNPUBLISH_PENDING)) {
                // all to pending to committed
                for (Event varevent:selectedEvents) {
                    long currTime = System.currentTimeMillis();
                    if (varevent.getPubstatus() == PublishStatus.PUBLISH_PENDING) {
                        competitionService.getEventProviderDao().
                            setPublishStatus(varevent.getId(),PublishStatus.PUBLISH_IN_PROGRESS, currTime);
                    }
                    if (varevent.getPubstatus() == PublishStatus.UNPUBLISH_PENDING) {
                        competitionService.getEventProviderDao().
                            setPublishStatus(varevent.getId(),PublishStatus.UNPUBLISH_IN_PROGRESS, currTime);
                    }
                }
                String urlStr = URL + "?commit=ALL";
                String result = HttpClientHelper.getURL(urlStr);
                logger.info("firebase helpere:" + result);
                reloadStatus();
                addMessage("Selected Pending Event are all Committed.");
            } else {
                addMessage("No Selected Event with Publish/Un-Publish Pending "); 
            } 
        }
    }
    public void cancel() {
        if (!isEmptySelection()) {
            if (isCheckSelectionValue(PublishStatus.PUBLISH_PENDING) || 
               isCheckSelectionValue(PublishStatus.PUBLISH_PENDING) ||
               isCheckSelectionValue(PublishStatus.REPUBLISH_PENDING)) {
                // publish pending - to not publish , unpublish pending -> to publsihed
                for (Event varevent:selectedEvents) {
                    long currTime = System.currentTimeMillis();
                    if (varevent.getPubstatus() == PublishStatus.PUBLISH_PENDING) {
                        competitionService.getEventProviderDao().
                            setPublishStatus(varevent.getId(),PublishStatus.NOT_PUBLISHED, currTime);
                    }
                    if (varevent.getPubstatus() == PublishStatus.UNPUBLISH_PENDING) {
                        competitionService.getEventProviderDao().
                            setPublishStatus(varevent.getId(),PublishStatus.PUBLISHED, currTime);
                    }
                    if (varevent.getPubstatus() == PublishStatus.REPUBLISH_PENDING) {
                        competitionService.getEventProviderDao().
                            setPublishStatus(varevent.getId(),PublishStatus.PUBLISHED, currTime);
                    }
                }
                reloadStatus();
                addMessage("Selected All Pending Event Restored.");
            } else {
                addMessage("No Selected Event with Publish/Un-Publish Pending "); 
            } 
        }
    }
    
    private void reloadStatus() {
        selectedEvents = null;
        publishSummary = competitionService.getEventProviderDao().getPublishReport();
        logger.info(publishSummary.toString());
    }
    
    private boolean isCheckSelectionValue(int pubstatus) {
        boolean retbool = false;
        for (Event varevent:selectedEvents) {
            if (varevent.getPubstatus() == pubstatus) {
                retbool = true;
                break;
            }
        }
        return retbool;
    }
    private boolean isEmptySelection() {
        boolean retbool = true;
        if (null == selectedEvents) {
            addMessage("No event selected.");
        } else {
            if (selectedEvents.size() > 0) {
                retbool = false;
            } else {
                addMessage("No event selected.");
            }   
        }
        return retbool;
    }
    /**
     * @return the competitionService
     */
    public CompetitionService getCompetitionService() {
        return competitionService;
    }

    /**
     * @param competitionService the competitionService to set
     */
    public void setCompetitionService(CompetitionService competitionService) {
        this.competitionService = competitionService;
    }

    /**
     * @return the eventList
     */
    public LazyDataModel<Event> getEventList() {
        if (eventList == null ) {
            eventList = new PublishLazyList(competitionService);
        }
        return eventList;
    }

    /**
     * @param eventList the eventList to set
     */
    public void setEventList(LazyDataModel<Event> eventList) {
        this.eventList = eventList;
    }

    /**
     * @return the selectedEvents
     */
    public List<Event> getSelectedEvents() {
        return selectedEvents;
    }

    /**
     * @param selectedEvents the selectedEvents to set
     */
    public void setSelectedEvents(List<Event> selectedEvents) {
        this.selectedEvents = selectedEvents;
    }

    /**
     * @return the publishSummary
     */
    public PublishSummary getPublishSummary() {
        return publishSummary;
    }

    /**
     * @param publishSummary the publishSummary to set
     */
    public void setPublishSummary(PublishSummary publishSummary) {
        this.publishSummary = publishSummary;
    }

    /**
     * @return the imageDeltaList
     */
    public List<ImageBlob> getImageDeltaList() {
        return imageDeltaList;
    }

    /**
     * @param imageDeltaList the imageDeltaList to set
     */
    public void setImageDeltaList(List<ImageBlob> imageDeltaList) {
        this.imageDeltaList = imageDeltaList;
    }

    /**
     * @return the restProviderService
     */
    public RestProviderService getRestProviderService() {
        return restProviderService;
    }

    /**
     * @param restProviderService the restProviderService to set
     */
    public void setRestProviderService(RestProviderService restProviderService) {
        this.restProviderService = restProviderService;
    }

    /**
     * @return the totImageSync
     */
    public int getTotImageSync() {
        return totImageSync;
    }

    /**
     * @param totImageSync the totImageSync to set
     */
    public void setTotImageSync(int totImageSync) {
        this.totImageSync = totImageSync;
    }

    /**
     * @return the totMissingImage
     */
    public int getTotMissingImage() {
        return totMissingImage;
    }

    /**
     * @param totMissingImage the totMissingImage to set
     */
    public void setTotMissingImage(int totMissingImage) {
        this.totMissingImage = totMissingImage;
    }
}
