/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.lazy.participant;

import com.danceframe.console.common.model.participant.Participant;
import com.danceframe.console.web.service.ParticipantManagementService;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

/**
 *
 * @author nbonita
 */
public class ParticipantLazyList extends LazyDataModel<Participant> {
    
    private static final Logger logger = LogManager.getLogger(ParticipantLazyList.class);
    
    private ParticipantManagementService participantManagementService;
    
    private List<Participant> participants;
    private int rowCount;
    private String userPushID;
    
    public ParticipantLazyList(ParticipantManagementService pmsc, String uPushID) {
        participantManagementService = pmsc;
        userPushID = uPushID;
    }

    public List<Participant> load(int first, int pageSize, String sortField,
                             SortOrder sortOrder, Map<String, Object> filters) {
        // filters can be here
        String wherestr = " WHERE user_push_id = '" + userPushID + "'";
        String wherecnt = wherestr;

        // sorting
        String sortSql = " ORDER BY last_name ASC";
        wherestr += sortSql;
        
        participants = participantManagementService.getParticipantProviderDao().getAllWithPaging(wherestr, 
                       pageSize, first);
        
        Long rc = (Long)participantManagementService.getParticipantProviderDao().getAllCount(wherecnt);
        
        rowCount = rc.intValue();
        setPageSize(pageSize);
        return participants;           
       }
    
    
    @Override
    public Object getRowKey(Participant participant) {
        return participant.getId();
    }
    
    @Override
    public Participant getRowData(String participantId) {
        Integer id = Integer.valueOf(participantId);
        for (Participant participant : participants) {
            if(id.equals(participant.getId())){
                return participant;
            }
        }
        return null;
    }
    /**
     * @return the participants
     */
    public List<Participant> getParticipants() {
        return participants;
    }

    /**
     * @param participants the participants to set
     */
    public void setParticipants(List<Participant> participants) {
        this.participants = participants;
    }

    /**
     * @return the rowCount
     */
    public int getRowCount() {
        return rowCount;
    }

    /**
     * @param rowCount the rowCount to set
     */
    public void setRowCount(int rowCount) {
        this.rowCount = rowCount;
    }

    /**
     * @return the participantManagementService
     */
    public ParticipantManagementService getParticipantManagementService() {
        return participantManagementService;
    }

    /**
     * @param participantManagementService the participantManagementService to set
     */
    public void setParticipantManagementService(ParticipantManagementService participantManagementService) {
        this.participantManagementService = participantManagementService;
    }
    
}
