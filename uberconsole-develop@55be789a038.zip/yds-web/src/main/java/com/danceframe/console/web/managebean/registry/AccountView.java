
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.managebean.registry;

import com.danceframe.console.common.model.registry.Account;
import com.danceframe.console.common.model.registry.AccountType;
import com.danceframe.console.service.constant.AccountStatus;
import com.danceframe.console.service.constant.Action;
import com.danceframe.console.web.service.AccountService;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import org.primefaces.event.SelectEvent;


/**
 *
 * @author lmorallos
 */

@ManagedBean (name="accountView")
@ViewScoped
public class AccountView implements Serializable {

    @ManagedProperty(value="#{accountService}")    
    private AccountService accountService;
    
    private static final long serialVersionUID = 1L;
    private List<Account> accountList;
    private Account account = new Account();
    private Account selectedAccount = new Account();
    private List<AccountType> accountTypeList;
    private int pageSize = 10;
    private int pageNumber = 1;
    private int pageAction = 0;
    
   @PostConstruct
    public void init() {
        accountTypeList = accountService.getAccountTypeProviderDao().getAllAccounType();
        accountList = accountService.getAccountProviderDao().getAllUserWithPaging(pageSize, pageNumber, 
                AccountStatus.ACTIVE);
        pageAction = Action.INSERT;
    }
    
    
    public void  save() {   
        int iret = 0;
        String username = account.getUserName();
        if ((username != null) || (username.length() > 0)) {
            addMessage("Saving:" + username + ":" + Integer.toString(pageAction));
            String mode = new String();
            // need to optimize this approach
            if (pageAction == Action.INSERT) {
                 addMessage("Saving Insert");
                 int search = accountService.getAccountProviderDao().searchAllUser(username);
                 if (search == 100) {
                    addMessage("Creating...");
                    iret = accountService.getAccountProviderDao().insertAccount(account);
                    mode = "New";
                 } else {
                     addMessage("Saving failed account alreaady exist.");
                 }
            }
           if (pageAction == Action.UPDATE) {
                addMessage("Saving Update");
                iret = accountService.getAccountProviderDao().updateAccount(account);
                pageAction = Action.INSERT;
            }
            if (iret == 100) {
                addMessage("Sucessful Saving Account:" + mode);
                reloadData();
            } else {
                 addMessage("Failed Saving Account:" + mode);
            }
        }
      
    }
    
    // delete  means deactivate TODO: admin can ractivate user
    public void deleteAction(String username) {
        if ((username != null) || (username.length() > 0)) {
            addMessage("Deleting account :" + username);
            int iret = accountService.getAccountProviderDao().deactivateAccount(username);
            if (iret == 100) {
                addMessage("Deleting Account.");
                reloadData();
            } else {
                 addMessage("Failed deleting Accont.");
            }
         }
    }

    public void onRowSelect(SelectEvent event) {
        Account vaccount =(Account) event.getObject();
        addMessage("Selected:" + account.getUserName());
        account = vaccount;
        pageAction = Action.UPDATE;
    }
    
    public void loadPage(ActionEvent event) {
        if (event != null) {
        accountList = accountService.getAccountProviderDao().getAllUserWithPaging(pageSize, pageNumber, 
                AccountStatus.ACTIVE);
        }
    }
    
    
    public void reloadData() {
        accountList = accountService.getAccountProviderDao().getAllUserWithPaging(pageSize, pageNumber, 
                AccountStatus.ACTIVE);
        
        account.setUserName("");
        account.setEmail("");
        account.setLastName("");
        account.setFirstName("");
        account.setMidName("");
        account.setAddress("");
        account.setProvince("");
        account.setCity("");
        account.setState("");
        account.setCountry("");
        account.setCountry("");
        account.setTelePhone("");
        account.setMobilePhone("");
        account.setAccType(0);
        
    }

    public void  addMessage(String summary) {        
        FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO, summary, null );
        FacesContext.getCurrentInstance().addMessage(null, msg);
    }
    
    /**
     * @return the accountList
     */
    public List<Account> getAccountList() {
        return accountList;
    }

    /**
     * @param accountList the accountList to set
     */
    public void setAccountList(List<Account> accountList) {
        this.accountList = accountList;
    }

    /**
     * @return the account
     */
    public Account getAccount() {
        return account;
    }

    /**
     * @param account the account to set
     */
    public void setAccount(Account account) {
        this.account = account;
    }
    
    /**
     * @return the accountTypeList
     */
    public List<AccountType> getAccountTypeList() {
        return accountTypeList;
    }

    /**
     * @param accountTypeList the accountTypeList to set
     */
    public void setAccountTypeList(List<AccountType> accountTypeList) {
        this.accountTypeList = accountTypeList;
    }

    /**
     * @return the pageSize
     */
    public int getPageSize() {
        return pageSize;
    }

    /**
     * @param pageSize the pageSize to set
     */
    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    /**
     * @return the pageNumber
     */
    public int getPageNumber() {
        return pageNumber;
    }

    /**
     * @param pageNumber the pageNumber to set
     */
    public void setPageNumber(int pageNumber) {
        this.pageNumber = pageNumber;
    }

    /**
     * @return the pageAction
     */
    public int getPageAction() {
        return pageAction;
    }

    /**
     * @param pageAction the pageAction to set
     */
    public void setPageAction(int pageAction) {
        this.pageAction = pageAction;
    }

    /**
     * @return the selectedAccount
     */
    public Account getSelectedAccount() {
        return selectedAccount;
    }

    /**
     * @param selectedAccount the selectedAccount to set
     */
    public void setSelectedAccount(Account selectedAccount) {
        this.selectedAccount = selectedAccount;
    }
    
    /**
     * @return the accountService
     */
    public AccountService getAccountService() {
        return accountService;
    }

    /**
     * @param accountService the accountService to set
     */
    public void setAccountService(AccountService accountService) {
        this.accountService = accountService;
    }
    
    
}