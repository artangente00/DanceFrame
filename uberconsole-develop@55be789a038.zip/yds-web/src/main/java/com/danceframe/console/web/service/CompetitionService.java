/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.service;

import com.danceframe.console.service.dataprovider.ImageProviderDao;
import com.danceframe.console.service.dataprovider.competition.CompetitionProviderDao;
import com.danceframe.console.service.dataprovider.competition.ContactProviderDao;
import com.danceframe.console.service.dataprovider.competition.EventProviderDao;
import com.danceframe.console.service.dataprovider.competition.OrganizerProviderDao;
import com.danceframe.console.service.dataprovider.competition.VenueProviderDao;
import java.io.Serializable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.danceframe.console.service.dataprovider.LookUpProviderDao;
import com.danceframe.console.service.dataprovider.XMLFileProviderDao;
import com.danceframe.console.service.dataprovider.competition.DisplayDefaultProviderDao;
import com.danceframe.console.service.dataprovider.competition.EnablementProviderDao;
import com.danceframe.console.service.dataprovider.competition.FinanceProviderDao;
import com.danceframe.console.service.dataprovider.competition.GenericFormProviderDao;
import com.danceframe.console.service.dataprovider.competition.ScheduleDataProviderDao;
import com.danceframe.console.service.dataprovider.competition.ScheduleProviderDao;
import com.danceframe.console.service.file.xml.HeatListResultXMLReader;

/**
 *
 * @author lmorallos
 */
@Service("competitionService")
public class CompetitionService implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @Autowired
    private CompetitionProviderDao competitionProviderDao;  
    
    @Autowired
    private LookUpProviderDao       lookUpProviderDao;
        
    @Autowired
    private EventProviderDao        eventProviderDao;
    
    @Autowired
    private ContactProviderDao      contactProviderDao;
    
    @Autowired
    private OrganizerProviderDao    organizerProviderDao;
    
    @Autowired
    private VenueProviderDao        venueProviderDao;
    
    @Autowired
    private ImageProviderDao        imageProviderDao;
    
    @Autowired
    private ScheduleProviderDao     scheduleProviderDao;
    
    @Autowired
    private ScheduleDataProviderDao scheduleDataProviderDao;
    
    @Autowired
    private EnablementProviderDao   enablementProviderDao;
    
    @Autowired
    private GenericFormProviderDao  genericFormProviderDao;
    
    @Autowired
    private FinanceProviderDao      financeProviderDao;
    
    @Autowired
    private XMLFileProviderDao      xmlFileProviderDao;
    
    @Autowired
    private DisplayDefaultProviderDao   displayDefaultProviderDao;
    
    
    
    /**
     * @return the competitionProviderDao
     */
    public CompetitionProviderDao getCompetitionProviderDao() {
        return competitionProviderDao;
    }

    /**
     * @param competitionProviderDao the competitionProviderDao to set
     */
    public void setCompetitionProviderDao(CompetitionProviderDao competitionProviderDao) {
        this.competitionProviderDao = competitionProviderDao;
    }

    /**
     * @return the eventProviderDao
     */
    public EventProviderDao getEventProviderDao() {
        return eventProviderDao;
    }

    /**
     * @param eventProviderDao the eventProviderDao to set
     */
    public void setEventProviderDao(EventProviderDao eventProviderDao) {
        this.eventProviderDao = eventProviderDao;
    }

    /**
     * @return the contactProviderDao
     */
    public ContactProviderDao getContactProviderDao() {
        return contactProviderDao;
    }

    /**
     * @param contactProviderDao the contactProviderDao to set
     */
    public void setContactProviderDao(ContactProviderDao contactProviderDao) {
        this.contactProviderDao = contactProviderDao;
    }

    /**
     * @return the organizerProviderDao
     */
    public OrganizerProviderDao getOrganizerProviderDao() {
        return organizerProviderDao;
    }

    /**
     * @param organizerProviderDao the organizerProviderDao to set
     */
    public void setOrganizerProviderDao(OrganizerProviderDao organizerProviderDao) {
        this.organizerProviderDao = organizerProviderDao;
    }

    /**
     * @return the venueProviderDao
     */
    public VenueProviderDao getVenueProviderDao() {
        return venueProviderDao;
    }

    /**
     * @param venueProviderDao the venueProviderDao to set
     */
    public void setVenueProviderDao(VenueProviderDao venueProviderDao) {
        this.venueProviderDao = venueProviderDao;
    }

    /**
     * @return the lookUpProviderDao
     */
    public LookUpProviderDao getLookUpProviderDao() {
        return lookUpProviderDao;
    }

    /**
     * @param lookUpProviderDao the lookUpProviderDao to set
     */
    public void setLookUpProviderDao(LookUpProviderDao lookUpProviderDao) {
        this.lookUpProviderDao = lookUpProviderDao;
    }

    /**
     * @return the imageProviderDao
     */
    public ImageProviderDao getImageProviderDao() {
        return imageProviderDao;
    }

    /**
     * @param imageProviderDao the imageProviderDao to set
     */
    public void setImageProviderDao(ImageProviderDao imageProviderDao) {
        this.imageProviderDao = imageProviderDao;
    }

    /**
     * @return the scheduleProviderDao
     */
    public ScheduleProviderDao getScheduleProviderDao() {
        return scheduleProviderDao;
    }

    /**
     * @param scheduleProviderDao the scheduleProviderDao to set
     */
    public void setScheduleProviderDao(ScheduleProviderDao scheduleProviderDao) {
        this.scheduleProviderDao = scheduleProviderDao;
    }

    /**
     * @return the scheduleDataProviderDao
     */
    public ScheduleDataProviderDao getScheduleDataProviderDao() {
        return scheduleDataProviderDao;
    }

    /**
     * @param scheduleDataProviderDao the scheduleDataProviderDao to set
     */
    public void setScheduleDataProviderDao(ScheduleDataProviderDao scheduleDataProviderDao) {
        this.scheduleDataProviderDao = scheduleDataProviderDao;
    }

    /**
     * @return the enablementProviderDao
     */
    public EnablementProviderDao getEnablementProviderDao() {
        return enablementProviderDao;
    }

    /**
     * @param enablementProviderDao the enablementProviderDao to set
     */
    public void setEnablementProviderDao(EnablementProviderDao enablementProviderDao) {
        this.enablementProviderDao = enablementProviderDao;
    }

    /**
     * @return the genericFormProviderDao
     */
    public GenericFormProviderDao getGenericFormProviderDao() {
        return genericFormProviderDao;
    }

    /**
     * @param genericFormProviderDao the genericFormProviderDao to set
     */
    public void setGenericFormProviderDao(GenericFormProviderDao genericFormProviderDao) {
        this.genericFormProviderDao = genericFormProviderDao;
    }

    /**
     * @return the financeProviderDao
     */
    public FinanceProviderDao getFinanceProviderDao() {
        return financeProviderDao;
    }

    /**
     * @param financeProviderDao the financeProviderDao to set
     */
    public void setFinanceProviderDao(FinanceProviderDao financeProviderDao) {
        this.financeProviderDao = financeProviderDao;
    }

    /**
     * @return the xmlFileProviderDao
     */
    public XMLFileProviderDao getXmlFileProviderDao() {
        return xmlFileProviderDao;
    }

    /**
     * @param xmlFileProviderDao the xmlFileProviderDao to set
     */
    public void setXmlFileProviderDao(XMLFileProviderDao xmlFileProviderDao) {
        this.xmlFileProviderDao = xmlFileProviderDao;
    }

    /**
     * @return the displayDefaultProviderDao
     */
    public DisplayDefaultProviderDao getDisplayDefaultProviderDao() {
        return displayDefaultProviderDao;
    }

    /**
     * @param displayDefaultProviderDao the displayDefaultProviderDao to set
     */
    public void setDisplayDefaultProviderDao(DisplayDefaultProviderDao displayDefaultProviderDao) {
        this.displayDefaultProviderDao = displayDefaultProviderDao;
    }

}
