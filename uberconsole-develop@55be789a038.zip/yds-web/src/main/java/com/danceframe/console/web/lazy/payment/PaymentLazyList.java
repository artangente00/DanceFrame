/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.lazy.payment;

import com.danceframe.console.common.model.payment.Invoice;
import com.danceframe.console.common.model.payment.Payment;
import com.danceframe.console.web.service.InvoiceManagementService;
import com.danceframe.console.web.service.PaymentManagementService;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

/**
 *
 * @author nbonita
 */
public class PaymentLazyList extends LazyDataModel<Payment> {
    
    private static final Logger logger = LogManager.getLogger(PaymentLazyList.class);
    
    private PaymentManagementService paymentManagementService;
    
    private List<Payment> payments;
    private int rowCount;
    private String invoiceID;
    
    public PaymentLazyList(PaymentManagementService pmsc, String iID) {
        paymentManagementService = pmsc;
        invoiceID = iID;
    }

    public List<Payment> load(int first, int pageSize, String sortField,
                             SortOrder sortOrder, Map<String, Object> filters) {
        // filters can be here
        String wherestr = " WHERE invoice_id = '" + invoiceID + "'";
        String wherecnt = wherestr;

        // sorting
        String sortSql = " ORDER BY payment_timestamp ASC";
        wherestr += sortSql;
        
        payments = paymentManagementService.getPaymentProviderDao().getAllWithPaging(wherestr, 
                       pageSize, first);
        
        Long rc = (Long)paymentManagementService.getPaymentProviderDao().getAllCount(wherecnt);
        
        rowCount = rc.intValue();
        setPageSize(pageSize);
        return payments;           
       }
    
    
    @Override
    public Object getRowKey(Payment payment) {
        return payment.getId();
    }
    
    @Override
    public Payment getRowData(String paymentId) {
        Integer id = Integer.valueOf(paymentId);
        for (Payment payment : payments) {
            if(id.equals(payment.getId())){
                return payment;
            }
        }
        return null;
    }
    /**
     * @return the payments
     */
    public List<Payment> getPayments() {
        return payments;
    }

    /**
     * @param payments the payments to set
     */
    public void setPayments(List<Payment> payments) {
        this.payments = payments;
    }

    /**
     * @return the rowCount
     */
    public int getRowCount() {
        return rowCount;
    }

    /**
     * @param rowCount the rowCount to set
     */
    public void setRowCount(int rowCount) {
        this.rowCount = rowCount;
    }

    /**
     * @return the paymentManagementService
     */
    public PaymentManagementService getPaymentManagementService() {
        return paymentManagementService;
    }

    /**
     * @param paymentManagementService the paymentManagementService to set
     */
    public void setPaymentManagementService(PaymentManagementService paymentManagementService) {
        this.paymentManagementService = paymentManagementService;
    }
    
}
