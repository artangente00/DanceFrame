/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.servlet.filter;

import com.danceframe.console.common.model.uam.User;
import com.danceframe.console.service.dataprovider.uam.UserProviderDao;
import com.danceframe.console.web.service.util.CookieHelper;
import com.danceframe.console.web.service.util.SpringContextBean;
import java.io.IOException;
import java.util.Base64;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.dao.EmptyResultDataAccessException;

/**
 *
 * @author lmorallos
 */
@WebFilter(filterName = "ProxyUserFilter", urlPatterns = {"/*"})
public class ProxyUserFilter implements Filter {

    private static final Logger logger = LogManager.getLogger(ProxyUserFilter.class);
    private static final String HTTP_HEADER_AUTH = "authorization";
    private static final int    COOKIE_MAX_AGE = 3600 * 24;
    private static final String NONAUTH_URL = "/faces/error/auth401.xhtml";

    
    private UserProviderDao userProviderDao;
    private User    user = new User();
    
    public ProxyUserFilter() {}
    
    @Override
    public void init(FilterConfig fc) throws ServletException {
        if (userProviderDao==null) {
            userProviderDao = (UserProviderDao)SpringContextBean.getSpringBean("userProviderDao");
        }
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        
        HttpServletRequest httprequest = (HttpServletRequest)request;
        HttpServletResponse httpresponse = (HttpServletResponse)response;
        String errorAuthURL = httprequest.getContextPath() + NONAUTH_URL;
        String uripath = httprequest.getRequestURI();
        if (allowedURI(uripath)) { // pass-thru
            chain.doFilter(request, response);
        } else {
            if (isUserOnHeader(httprequest)) {
                if (!user.isEmpty()) {
                    HttpSession session = httprequest.getSession();
                    setSessionParam(session);
                    processCookies(httprequest, httpresponse);
                    chain.doFilter(request, response);
                } else {
                     HttpSession session = httprequest.getSession(false);
                     if (session != null) {
                         session.invalidate();
                     }
                    CookieHelper.clearCookies(httprequest, httpresponse);
                    httpresponse.sendRedirect(errorAuthURL);
                }
            } else {
                HttpSession session = httprequest.getSession(false);
                if (session != null) {
                    session.invalidate();
                }
                CookieHelper.clearCookies(httprequest, httpresponse);
                httpresponse.sendRedirect(errorAuthURL);
            }
        } 
    }

    @Override
    public void destroy() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    private void processCookies(HttpServletRequest req, HttpServletResponse res) {
        if (!CookieHelper.isCookiePresent(req, CookieHelper.COOKIE_USER))
            CookieHelper.setCookie(req, res,CookieHelper.COOKIE_USER, 
                         user.getUsername(), COOKIE_MAX_AGE);
        if (!CookieHelper.isCookiePresent(req, CookieHelper.COOKIE_FNAME))
            CookieHelper.setCookie(req, res, CookieHelper.COOKIE_FNAME,
                        user.getFirstname(), COOKIE_MAX_AGE);
        if (!CookieHelper.isCookiePresent(req, CookieHelper.COOKIE_LNAME))
            CookieHelper.setCookie(req, res, CookieHelper.COOKIE_LNAME,
                         user.getLastname(), COOKIE_MAX_AGE);
        if (!CookieHelper.isCookiePresent(req, CookieHelper.COOKIE_USERID))
            CookieHelper.setCookie(req, res, CookieHelper.COOKIE_USERID,
                        Integer.toString(user.getId()), COOKIE_MAX_AGE);
    }
    
    private void setSessionParam(HttpSession session) {
        session.setAttribute(CookieHelper.COOKIE_USER, user.getUsername());
        session.setAttribute(CookieHelper.COOKIE_FNAME, user.getFirstname());
        session.setAttribute(CookieHelper.COOKIE_LNAME, user.getLastname());
        session.setAttribute(CookieHelper.COOKIE_USERID, user.getId());
    }
    
    private boolean allowedURI(String uri) {
        boolean retbool = false;
        if (uri.contains("javax.faces.resource")) retbool = true;
        if (uri.contains("/error/")) retbool = true;    
        return retbool;
    }
    
    private boolean isUserOnHeader(HttpServletRequest httprequest ) {
        boolean retbool = false;
        Map<String,String> headers = getHeadersInfo(httprequest);
//        for (Map.Entry<String,String> entry:headers.entrySet()) {
//            logger.info("==>headers key:" + entry.getKey() + " val:" + entry.getValue());
//        }
        String authValue = headers.get(HTTP_HEADER_AUTH);
        if (null != authValue) {
            if (authValue.length() > 0) {
                //logger.info("===> Found Authentication:" + authValue);
                String base64Auth = authValue.replace("Basic", "").trim();
                byte[] decodedBytes = Base64.getDecoder().decode(base64Auth);
                String decodedString = new String(decodedBytes);
                //logger.info("===> Found Authentication (decoded):" + decodedString);
                if (decodedString.indexOf(":") > -1) {
                    String[] authinfo = decodedString.split(":");
                    String username = authinfo[0];
                    // logger.info("===> Found Authentication (username):" + username);
                    resetValues();
                    try {
                        user =userProviderDao.get(username);
                        retbool = true;
                    } catch (EmptyResultDataAccessException ex) {
                         logger.warn("SQL Error: Empty dataset.");
                    }
                }
            }
        }
        return retbool;
    }
    
    private Map<String, String> getHeadersInfo(HttpServletRequest request) {
        Map<String, String> map = new HashMap<String, String>();
        Enumeration headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String key = (String) headerNames.nextElement();
            String value = request.getHeader(key);
            map.put(key, value);
        }
        return map;
    }

    private void resetValues() {
        user = null;
        user = new User();
        user.setId(0);
        user.setUsername("");
        user.setLastname("");
        user.setFirstname("");
        user.setDatecreated(null);
        user.setLastupdated(null);
    }
    /**
     * @return the userProviderDao
     */
    public UserProviderDao getUserProviderDao() {
        return userProviderDao;
    }

    /**
     * @param userProviderDao the userProviderDao to set
     */
    public void setUserProviderDao(UserProviderDao userProviderDao) {
        this.userProviderDao = userProviderDao;
    }
}
