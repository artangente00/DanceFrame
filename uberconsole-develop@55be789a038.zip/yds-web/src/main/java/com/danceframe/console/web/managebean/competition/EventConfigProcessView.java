/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.managebean.competition;

import com.danceframe.console.common.model.basic.LookUp;
import com.danceframe.console.common.model.competition.Event;
import com.danceframe.console.common.model.competition.config.Age;
import com.danceframe.console.common.model.competition.config.Dance;
import com.danceframe.console.common.model.competition.config.Form;
import com.danceframe.console.common.model.competition.config.Level;
import com.danceframe.console.common.model.competition.config.Style;
import com.danceframe.console.common.model.competition.form.EventForm;
import com.danceframe.console.common.model.competition.form.EventFormDance;
import com.danceframe.console.common.model.competition.form.EventFormField;
import com.danceframe.console.common.model.competition.form.EventFormHContent;
import com.danceframe.console.common.model.competition.form.EventFormVertical;
import com.danceframe.console.common.model.competition.form.EventFormXML;
import com.danceframe.console.common.util.Utility;
import com.danceframe.console.service.constant.PublishStatus;
import com.danceframe.console.web.lazy.competition.EventLazyList;
import com.danceframe.console.web.lazy.competition.config.EventFormDanceLazyList;
import com.danceframe.console.web.lazy.competition.config.EventFormHContentLazyList;
import com.danceframe.console.web.lazy.competition.config.EventFormLazyList;
import com.danceframe.console.web.lazy.competition.config.EventVerticalLazyList;
import com.danceframe.console.web.managebean.BaseBean;
import com.danceframe.console.web.service.CompetitionService;
import com.danceframe.console.web.service.EventFormConfigService;
import com.danceframe.console.web.service.util.HttpClientHelper;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.context.RequestContext;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.TabChangeEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.DualListModel;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.StreamedContent;
import org.primefaces.model.UploadedFile;
import org.springframework.dao.EmptyResultDataAccessException;

/**
 *
 * @author lmorallos
 */
@ManagedBean (name="eventConfigProcessView")
@ViewScoped
public class EventConfigProcessView extends BaseBean implements Serializable {
    
    private static final String MODULE_NAME = "EVENTFORMCONFIG";
    private static final Logger logger = LogManager.getLogger(EventConfigProcessView.class);
    private static final String URL = "http://localhost:8080/uberSync/SyncForm";
    
    
    @ManagedProperty(value="#{competitionService}")
    private CompetitionService competitionService;   
     
    @ManagedProperty(value="#{eventFormConfigService}")
    private EventFormConfigService eventFormConfigService;
    
    private static final long serialVersionUID = 1L;
    private LazyDataModel<Event>       eventList = null;
    private Event   selectedEvent = new Event();
    
    private List<Form>  forms;
    private Form        form;
    private List<Age>   ages;
    private Age         age;
    private List<Dance> dances;
    private Dance       dance;
    private List<Style> styles;
    private Style       style;
    private List<Level> levels;
    private Level       level;
    
    private List<LookUp> formTypes;
    private List<LookUp> headerTypes;
    private List<LookUp> entryTypes;
    private int          entryType;
    private int          formType;
    private int          headerType;
    private int          formId;
    private int          currentEventId;
    private String       eventName;
    private int          selectedformId;
    
    
    private LazyDataModel<EventForm> eventFormList = null;
    private LazyDataModel<EventFormHContent> eventFormHCList = null;
    private LazyDataModel<EventFormDance> eventFormDanceList = null;
    private LazyDataModel<EventFormVertical> eventFormVerticalList = null;
    private EventForm       eventForm;
    private EventForm       selectedEventForm;
    private int             activeTab;
    private List<String>    headers;
    private String          header;
    private int             hcontentId;
    private Map<Integer,String> mapHeader;
    
    private List<Dance> dancesTarget;
    private DualListModel<Dance> dancesPickList;
    
    private Map<Integer, String> mapFields;
    private List<LookUp>  formFields;
    private int           formField;
   
    private List<String> genSource;
    private DualListModel<String> genericPickList;
    
    private UploadedFile        xmlFile;
    private boolean             useManual;
    private boolean             disableUpload;
    private EventFormXML        selectedEventFormXML;
    private String              tmpLocation;
    private String              newXMLFile;
    private String              uploadXMLBaseFile;
    private boolean             isXMLUpload;
    private StreamedContent     downloadFile;
    private boolean             isJsonError;
    
    private String              newSTUFile;
    private String              baseFilename;
    
    
    
    @PostConstruct
    public void init() {
        if (eventList == null ) {
            eventList = new EventLazyList(competitionService);
        }

        forms = eventFormConfigService.getFormProviderDao().getAll("");
        ages = eventFormConfigService.getAgeProviderDao().getAll("");
        dances = eventFormConfigService.getDanceProviderDao().getAll("");
        levels = eventFormConfigService.getLevelProviderDao().getAll("");
        styles = eventFormConfigService.getStyleProviderDao().getAll("");
                
        formTypes = competitionService.getLookUpProviderDao().getFormTypes();
        headerTypes = competitionService.getLookUpProviderDao().getFormHeaderTypes();
        entryTypes =  competitionService.getLookUpProviderDao().getFormEntryTypes();
        setFormFields(competitionService.getLookUpProviderDao().getFormFields());
                
        headers = new ArrayList<>();
        dancesTarget = new ArrayList<Dance>();
        dancesPickList = new DualListModel<Dance>(dances,dancesTarget);
        
        genSource = new ArrayList<String>();
        List<String> genTarget = new ArrayList<String>();
        genericPickList = new DualListModel<String>(genSource, genTarget);
        useManual = true;
        disableUpload = true;
        tmpLocation =  System.getProperty("java.io.tmpdir") + File.separator;
        logger.info("==>>INIT tmp location:"  +  tmpLocation);
        
        newSTUFile = new String();
    }
    
    public void onRowSelectEvent(SelectEvent event) {
        selectedEvent =(Event) event.getObject();
        currentEventId = selectedEvent.getId();
        eventName = selectedEvent.getName();
        useManual = selectedEvent.isUseManual();
        eventFormList = new EventFormLazyList(eventFormConfigService, currentEventId);
        logger.info("==>current selected eventid:" + currentEventId + " name:" + eventName);
        newXMLFile = new String();
        newSTUFile = new String();
        selectedEventFormXML = new EventFormXML();
        selectedEventFormXML.setId(0);
        isXMLUpload = false;
        isJsonError = false;
        baseFilename = "";
        try {
            selectedEventFormXML = eventFormConfigService.
               getEventFormXMLProviderDao().get(currentEventId);
        } catch (EmptyResultDataAccessException ex) {
             logger.warn("Warning: Empty For XML using event:" + currentEventId + " " + ex.getMessage());
        }
       
    }
  
    public void onRowSelectEventForm(SelectEvent event) {
        selectedEventForm =  (EventForm) event.getObject();
    }
    
    public void onTabChange(TabChangeEvent event) {
        boolean iseventform = true;
        String strIndex = event.getTab().getId();
        int index = Integer.parseInt(strIndex.replace("tab", ""));
        activeTab = index;
        if (index > 0) {  // form
            if (selectedEventForm == null) {
                activeTab = 0;
                addMessage("Select fully configured form from the list.");
                iseventform = false;
            }
        }
       if ((index == 1) && iseventform) { // horizontal content
          // check  header and form type here
            for (Level lookup:levels) {
                headers.add(lookup.getName());
            }  
            int eventformId = selectedEventForm.getId();
            eventFormHCList = new EventFormHContentLazyList(eventFormConfigService, eventformId);
           
       }
       
        if ((index == 2) && iseventform) { // dance assignment
            if (eventFormHCList.getRowCount() > 0) {
                // populate th
                mapHeader = new HashMap<Integer,String>();
                Iterator<EventFormHContent> hcontentIter = eventFormHCList.iterator();
                while(hcontentIter.hasNext()) {
                    EventFormHContent efhcontent = hcontentIter.next(); 
                    mapHeader.put(efhcontent.getId(),
                            efhcontent.getHorizHeader());
                }
                // get the first header 
                if (!mapHeader.isEmpty()) {
                    Map.Entry<Integer,String> entry = mapHeader.entrySet().iterator().next();
                    int horizcontentId = entry.getKey();
                    // String val = entry.getValue();
                    int eventformId = selectedEventForm.getId();
                    logger.info("hcontent:" + horizcontentId + " evformId" + eventformId);
                    eventFormDanceList = new EventFormDanceLazyList(eventFormConfigService,
                            horizcontentId, eventformId);
                }
                
            } else {
                 addMessage("Please populate the header first.");
            }
        }
       
        if ((index == 3) && iseventform) { // vertical assignment
            // search if the event form already have a field assign to it
            int eventformId = selectedEventForm.getId();
            if (selectedEventForm.getFormType() == 1) { // age only
                int iret = eventFormConfigService.getEventFormFieldProviderDao().search(eventformId);
                if (iret < 0) { // record for the field for the evenform create one;
                    String field = getFormFields().get(0).getDescription();
                    EventFormField eventfield = new EventFormField();
                    eventfield.setFieldName(field);
                    eventfield.setEventformId(eventformId);
                    eventfield.setLinkTo("none");
                    int nret = eventFormConfigService.getEventFormFieldProviderDao().insert(eventfield);
                    String logstr = (nret > 0)? "FormFields:insert successful." : "FormFields:insert failed.";
                    logger.info(logstr);                    
                } 
                List<EventFormField> eventfieldList = eventFormConfigService.getEventFormFieldProviderDao().
                        getAll("WHERE eventform_id="+eventformId);
                mapFields = new HashMap<Integer, String>();
                for (EventFormField eventfield:eventfieldList) {
                    mapFields.put(eventfield.getId(),eventfield.getFieldName());
                }
                // ages...
                String strobj = new String();
                genSource = new ArrayList<String>();
                List<String> genTarget = new ArrayList<String>();
                for (Age age:ages) {
                    strobj = age.getName() + ",(" + age.getDescription() +")";
                    genSource.add(strobj);
                }
                formField = 1; // AGE
                genericPickList = new DualListModel<String>(genSource, genTarget);
                eventFormVerticalList = new EventVerticalLazyList(eventFormConfigService, formField, eventformId);
            }
        }
        
    }
    
    public void closeDialog() {
        selectedEventForm = null;
        currentEventId = 0;
        activeTab = 0;
        newXMLFile = new String();
        newSTUFile = new String();
        if (isXMLUpload) {
            tempFileCleaner();
        }
    }
    
    public void saveVertical() {
        int eventFormId = selectedEventForm.getId();
        Iterator<String> genIter = genericPickList.getTarget().iterator();
        String genstr = new String();
        String code = new String();
        String desc = new String();
        int scnt = 0;
        while(genIter.hasNext()) {
            genstr = genIter.next();
            if (genstr.indexOf(",") > -1) {
                String[] strsplit = genstr.split(",");
                code = strsplit[0];
                desc = strsplit[1];
            } else {
                code = genstr;
                desc = genstr;
            }
            EventFormVertical eventVertical = new EventFormVertical();
            eventVertical.setEventformId(eventFormId);
            eventVertical.setFieldId(formField);
            eventVertical.setCode(code);
            eventVertical.setDescription(desc);
            boolean allow = false;
            if (selectedEventForm.getFormType() == 1) allow = true;
            eventVertical.setAllowall(allow);
            int iret = eventFormConfigService.getEventFormVerticalProviderDao().insert(eventVertical);
            if (iret > 0 )  {
                logger.info("Saving vertical:" + eventVertical.toString() );
                scnt++;
            }            
        }
        if (scnt > 0) {
            addMessage("Vertical Assignment saved.");
            List<String> genTarget = new ArrayList<String>();         
            genericPickList = new DualListModel<String>(genSource, genTarget);
        }
    }
    
    public void deleteVertical(int id) {
         int ret = eventFormConfigService.getEventFormVerticalProviderDao().delete(id);
        if (ret > 0) {
             addMessage("Vertical Assignment Deleted.");
        } else {
             addMessage("Vertical Assignment Delete Failed.");
        }
    }
    
    public void changeHeadersOnDance() {
        addMessage("New HContent Id:" + hcontentId);
        int eventformId = selectedEventForm.getId();
        eventFormDanceList = new EventFormDanceLazyList(eventFormConfigService,
                            hcontentId, eventformId);
        dancesTarget = new ArrayList<Dance>();
                dancesPickList = new DualListModel<Dance>(dances,dancesTarget);
    }
    
    public void saveDance() {
        int eventformId = selectedEventForm.getId();
        EventFormDance eventformDance = new EventFormDance();
        eventformDance.setHorizContentId(hcontentId);
        eventformDance.setEventformId(eventformId);
        StringBuffer code = new StringBuffer();
        StringBuffer description = new StringBuffer();
        Iterator<Dance> targetIter = dancesPickList.getTarget().iterator();
        int icnt = 0;
        while(targetIter.hasNext()) {
            Dance dance = (Dance)targetIter.next();
            code.append(dance.getCode());
            description.append(dance.getName());
            description.append(",");
            icnt++;
        }
        
        if (icnt > 0) {
            if (icnt > 1) {
                int dlen = description.length();
                description.delete(dlen-1, dlen);
            }
            eventformDance.setCode(code.toString());
            eventformDance.setDescription(description.toString());
            int iret = eventFormConfigService.getEventFormDanceProviderDao()
                    .insert(eventformDance);
            if (iret > 0) {
                addMessage("Dance Code Attached to Header.");
                dancesTarget = new ArrayList<Dance>();
                dancesPickList = new DualListModel<Dance>(dances,dancesTarget);
            } else {
                addMessage("Dance Code Attachment to Header Faield.");
            }
        }
    }
    
    public void deleteDance(int id) {
        int ret = eventFormConfigService.getEventFormDanceProviderDao().delete(id);
        if (ret > 0) {
             addMessage("Dance Code Deleted.");
        } else {
             addMessage("Dance Code Delete Failed.");
        }
    }
    
    public void saveHorizContent() {
        EventFormHContent eventformHC = new EventFormHContent();
        int eventformId = selectedEventForm.getId();
        eventformHC.setEventFormId(eventformId);
        eventformHC.setHorizHeader(header);
        int ret = eventFormConfigService.getEventFormHContentProviderDao().insert(eventformHC);
        if (ret > 0) {
             addMessage("Horizontal Content Saved.");
        } else {
             addMessage("Horizontal Content Saving Failed.");
        }
    }
    
    public void deleteHorizContent(int id) {
        int ret = eventFormConfigService.getEventFormHContentProviderDao().delete(id);
        if (ret > 0) {
             addMessage("Horizontal Content Deleted.");
        } else {
             addMessage("Horizontal Content Delete Failed.");
        }
    }
    
    public void saveForm() {
        if (currentEventId > 0) {
            logger.info("Saving id:" + currentEventId);
            eventForm = new EventForm();
            eventForm.setEventId(currentEventId);
            eventForm.setFormId(formId);
            eventForm.setFormType(formType);
            eventForm.setHeaderType(headerType);
            eventForm.setEntryType(entryType);
            int iret = eventFormConfigService.getEventFormProviderDao().insert(eventForm);
            if (iret > 0) {
                addMessage("Saved Form." + iret + " Attached to Event Id." + currentEventId);      
            } else {
               addMessage("Error saving event form.");
            }
        }
    }
    
    public void deleteForm(int id) {
        if (currentEventId > 0) {
            logger.info("Deleting id:" + id);
            int iret = eventFormConfigService.getEventFormProviderDao().delete(id);
            if (iret > 0) {
                addMessage("Form Deleted with id:" + iret + 
                        ". Detacched from  Event Id." + currentEventId);      
            } else {
               addMessage("Error saving event form.");
            }
        }
    }
    
    public void fileDownloader(int ftype) {
        addMessage("Downloading file:" + ftype);
        String mimeType = "text/xml";
        String filename = "eventForm" + currentEventId; 
        if (ftype==1) {
            downloadFile = new DefaultStreamedContent(
                    selectedEventFormXML.xmlGeneratedInputStream(),
                    mimeType,filename + ".xml");
        }
        if (ftype==2) {
            downloadFile = new DefaultStreamedContent(
                    selectedEventFormXML.jsonGeneratedInputStream(),
                    mimeType,filename + ".json");
        }
        if (ftype==3) {
            downloadFile = new DefaultStreamedContent(
                    selectedEventFormXML.xmlManualInputStream(),
                    mimeType,filename + ".xml");
        }
        if (ftype==4) {
           downloadFile = new DefaultStreamedContent(
                    selectedEventFormXML.jsonManualInputStream(),
                    mimeType,filename + ".json"); 
        }
    }
  
    public void saveFireBasePush() {
        boolean process = false;
        logger.info("Firebase Push:" + selectedEvent.getId());
        if (selectedEvent.getPubstatus() == PublishStatus.PUBLISHED) {
            if (selectedEvent.isUseManual()) {
                if ((selectedEventFormXML.isXMLManDisable() && selectedEventFormXML.isJsonManDisable())) {
                    addMessage("No Data to Push Firebase (Manual)", FacesMessage.SEVERITY_INFO);
                } else {
                   process = true;
                } 
            } else {
                if ((selectedEventFormXML.isXMLGenDisable()&& selectedEventFormXML.isJsonGenDisable())) {
                    addMessage("No Data to Push Firebase (Generated)", FacesMessage.SEVERITY_INFO);
                } else {
                    process = true;
                }
            }
            if (process) {
                String strId = Integer.toString(selectedEvent.getId());
                String urlStr = URL + "?id=" + strId;
                logger.info("firebase url-connect:" + urlStr);
                String result = HttpClientHelper.getURL(urlStr);
                logger.info("firebase helper:" + result);
                addMessage("Firebase should be updated by now.", FacesMessage.SEVERITY_INFO);
            }
        } else {
            addMessage("This Event must be published first.", FacesMessage.SEVERITY_INFO);
        }
    }
    
    public void saveManualSetup() {
        context = RequestContext.getCurrentInstance();
        if ( isJsonError) {
            addMessage("There is an error converting the new XML to JSON.");
            return;
        }
        int errcnt = 0;
        logger.info("eventformid:" + selectedEventFormXML.getId());
        if (isXMLUpload) {
            int iret = 0;
            if (selectedEventFormXML.getId() >  0) { // edit

                 iret = eventFormConfigService.getEventFormXMLProviderDao().
                        updateManual(currentEventId, tmpLocation, uploadXMLBaseFile);
            } else { // add
                iret = eventFormConfigService.getEventFormXMLProviderDao().
                        insertManual(currentEventId, tmpLocation, uploadXMLBaseFile);
            }
            if (iret > 0) {
                addMessage("XML/JSON Event Form data saved with event id:"
                         + currentEventId); 
                tempFileCleaner();
            } else {
               addMessage("Error saving XML/JSON event form data.");
                errcnt++;
            }
        }
        // save use manual
        if (selectedEventFormXML.isUseManual() != useManual) {
            int iret = eventFormConfigService.getEventFormXMLProviderDao()
                    .setUseManual(currentEventId, useManual);
            if (iret > 0) {
                addMessage("Saving manual upload data for event Id:" + currentEventId); 
            } else {
               addMessage("Saving manual upload data failed.");
               errcnt++;
            }
        }
        if (errcnt == 0) context.execute("PF('configDialog').hide();");
    }
    
    public void xmlUpload(FileUploadEvent event) throws IOException{
        UploadedFile uploadedXMLFile = event.getFile();
        byte[] bytes=null;
        if (null!=uploadedXMLFile) {
            if (isXMLUpload) tempFileCleaner();
            isJsonError = false;
            newXMLFile = uploadedXMLFile.getFileName();
            addMessage("Uploading XML File:" + newXMLFile);
            bytes = uploadedXMLFile.getContents();
            String fileprefix = Utility.getFilename(newXMLFile); 
            String xmlfilename = new String();
            String jsonfilename = new String();
            String filename = Utility.generateUniqueFileName(fileprefix);  
            
            xmlfilename = filename + ".xml";
            jsonfilename = filename + ".json";
            
            BufferedOutputStream stream = new BufferedOutputStream(
                        new FileOutputStream(new File(tmpLocation,xmlfilename)));
            stream.write(bytes);
            stream.flush();
            stream.close();
            stream = null;
            
            try {
                boolean retbool = eventFormConfigService.getEventFormGenerator().
                    xmlToJson(bytes, tmpLocation, jsonfilename);
                if (retbool) {
                    addMessage("XML Conversion Successful.");
                } else {
                    addMessage("XML Conversion Error.");
                     isJsonError = true;
                }
            } catch (Exception jex ) {
                  addMessage("JSON Error:" + jex.getMessage()); 
                   isJsonError = true;
            }
            uploadXMLBaseFile = filename;
            logger.info("=== basefile:" + uploadXMLBaseFile + " xmlfle:" + xmlfilename +  " jsonfile:" + jsonfilename);
            isXMLUpload = true;
        }
       
    }
    
    public void uploadSTU(FileUploadEvent event) throws IOException{
        UploadedFile uploadedSTUFile = event.getFile();
        byte[] bytes=null;
        if (null!=uploadedSTUFile) {
            // tempFileCleaner();
            isJsonError = false;
            isXMLUpload = false;
            newSTUFile = uploadedSTUFile.getFileName();
            addMessage("Uploading STU File:" + newSTUFile);
            bytes = uploadedSTUFile.getContents();
            baseFilename = Utility.getFilename(newSTUFile); ;
            
            //String filename = Utility.generateUniqueFileName(fileprefix);  
            
            String stufilename = baseFilename + ".stu";
            String xmlallfile = baseFilename + "-all.xml";
            String ubcxmlfile = baseFilename + "-ubc.xml";
            String jsonfile = baseFilename + ".json";
            
            BufferedOutputStream stream = new BufferedOutputStream(
                        new FileOutputStream(new File(tmpLocation, newSTUFile)));
            stream.write(bytes);
            stream.flush();
            stream.close();
            stream = null;
            
            // convert to xml
            logger.info("STU File:" + stufilename );
            if (Utility.isFileExist(tmpLocation, newSTUFile)) {
                addMessage("STU Creation Successful.", FacesMessage.SEVERITY_INFO);
                boolean isxmlall = eventFormConfigService.getSetupFileProcessor().createXMLFromSTU(tmpLocation, stufilename, baseFilename);
                if (isxmlall) {
                     // convert to json
                    isXMLUpload = true; 
                    addMessage("STU Creation Successful.", FacesMessage.SEVERITY_INFO);
                    try {
                        byte[] xmlbytes= Utility.readFileToBytes(tmpLocation, ubcxmlfile);
                        boolean retbool = eventFormConfigService.getEventFormGenerator().
                            xmlToJson(xmlbytes, tmpLocation, jsonfile);
                        if (retbool) {
                            addMessage("XML Conversion Successful.", FacesMessage.SEVERITY_INFO);
                        } else {
                            addMessage("XML Conversion Error.", FacesMessage.SEVERITY_ERROR);
                             isJsonError = true;
                        }
                    } catch (Exception jex ) {
                        addMessage("JSON Error:" + jex.getMessage(), FacesMessage.SEVERITY_ERROR); 
                         isJsonError = true;
                  }
                } else {
                     addMessage("XML File Creation Error.", FacesMessage.SEVERITY_ERROR);
                }
            } else {
                addMessage("STU File Creation Error.", FacesMessage.SEVERITY_ERROR);
            }
            logger.info("=== basefile:" + baseFilename );
        }
    }
    
     public void saveCompgrSTUSetup() {
        context = RequestContext.getCurrentInstance();
        if ( isJsonError) {
            addMessage("There is an error converting the new STU to JSON.");
            newXMLFile = new String();
            return;
        }
        int errcnt = 0;
        logger.info("eventformid:" + selectedEventFormXML.getId());
        if (isXMLUpload) {
            int iret = 0;
            if (selectedEventFormXML.getId() >  0) { // edit
                 iret = eventFormConfigService.getEventFormXMLProviderDao().
                        updateSTUGenerate(currentEventId, tmpLocation, baseFilename);
            } else { // add
                iret = eventFormConfigService.getEventFormXMLProviderDao().
                        insertSTUManual(currentEventId, tmpLocation, baseFilename);
            }
            if (iret > 0) {
                addMessage("STU/XML/JSON Event Form data saved with event id:"
                         + currentEventId); 
                useManual = true;
                int xret = eventFormConfigService.getEventFormXMLProviderDao()
                    .setUseManual(currentEventId, useManual);
                if (xret > 0) {
                    addMessage("Saving manual upload data for event Id:" + currentEventId); 
                } else {
                   addMessage("Saving manual upload data failed.");
                   errcnt++;
                }               
                
                // tempFileCleaner();
            } else {
               addMessage("Error saving STU/XML/JSON event form data.");
                errcnt++;
            }
        }
        // save use manual
        if (selectedEventFormXML.isUseManual() != useManual) {
            int iret = eventFormConfigService.getEventFormXMLProviderDao()
                    .setUseManual(currentEventId, useManual);
            if (iret > 0) {
                addMessage("Saving manual upload data for event Id:" + currentEventId); 
            } else {
               addMessage("Saving manual upload data failed.");
               errcnt++;
            }
        }
        if (errcnt == 0) {
            newXMLFile = new String();
            context.execute("PF('configDialog').hide();");
        }
    }
    
    
    
    
    private void tempFileCleaner() {
        
        String stufilename = baseFilename + ".stu";
        String xmlallfile = baseFilename + "-all.xml";
        String ubcxmlfile = baseFilename + "-ubc.xml";
        String jsonfile = baseFilename + ".json";
        
        if (Utility.deleteFile(tmpLocation, stufilename)) {
            logger.info("delete (ok):" + tmpLocation + ":" + stufilename);
      
        }
        if (Utility.deleteFile(tmpLocation, xmlallfile)) {
            logger.info("delete (ok):" + tmpLocation + ":" + xmlallfile);
      
        }
        if (Utility.deleteFile(tmpLocation, ubcxmlfile)) {
            logger.info("delete (ok):" + tmpLocation + ":" + ubcxmlfile);
      
        }
        if (Utility.deleteFile(tmpLocation, jsonfile)) {
            logger.info("delete (ok):" + tmpLocation + ":" + jsonfile);
      
        }

        String xmlfile = uploadXMLBaseFile + ".xml";
        if (Utility.deleteFile(tmpLocation, xmlfile)) {
            logger.info("delete (ok):" + tmpLocation + ":" + xmlfile);
        } else {
            logger.info("delete (error):" + tmpLocation + ":" + xmlfile);
        }
        
        jsonfile = uploadXMLBaseFile + ".json";
        if (Utility.deleteFile(tmpLocation, jsonfile)) {
            logger.info("delete (ok):" + tmpLocation + ":" + jsonfile);
        } else {
            logger.info("delete (error):" + tmpLocation + ":" + jsonfile);
        }
    }
    /**
     * @return the eventList
     */
    public LazyDataModel<Event> getEventList() {
        return eventList;
    }

    /**
     * @param eventList the eventList to set
     */
    public void setEventList(LazyDataModel<Event> eventList) {
        this.eventList = eventList;
    }

    /**
     * @return the competitionService
     */
    public CompetitionService getCompetitionService() {
        return competitionService;
    }

    /**
     * @param competitionService the competitionService to set
     */
    public void setCompetitionService(CompetitionService competitionService) {
        this.competitionService = competitionService;
    }

    /**
     * @return the eventForm
     */
    public EventForm getEventForm() {
        return eventForm;
    }

    /**
     * @param eventForm the eventForm to set
     */
    public void setEventForm(EventForm eventForm) {
        this.eventForm = eventForm;
    }

    /**
     * @return the eventFormConfigService
     */
    public EventFormConfigService getEventFormConfigService() {
        return eventFormConfigService;
    }

    /**
     * @param eventFormConfigService the eventFormConfigService to set
     */
    public void setEventFormConfigService(EventFormConfigService eventFormConfigService) {
        this.eventFormConfigService = eventFormConfigService;
    }

    /**
     * @return the forms
     */
    public List<Form> getForms() {
        return forms;
    }

    /**
     * @param forms the forms to set
     */
    public void setForms(List<Form> forms) {
        this.forms = forms;
    }

    /**
     * @return the form
     */
    public Form getForm() {
        return form;
    }

    /**
     * @param form the form to set
     */
    public void setForm(Form form) {
        this.form = form;
    }

    /**
     * @return the formTypes
     */
    public List<LookUp> getFormTypes() {
        return formTypes;
    }

    /**
     * @param formTypes the formTypes to set
     */
    public void setFormTypes(List<LookUp> formTypes) {
        this.formTypes = formTypes;
    }

    /**
     * @return the headerTypes
     */
    public List<LookUp> getHeaderTypes() {
        return headerTypes;
    }

    /**
     * @param headerTypes the headerTypes to set
     */
    public void setHeaderTypes(List<LookUp> headerTypes) {
        this.headerTypes = headerTypes;
    }

    /**
     * @return the formType
     */
    public int getFormType() {
        return formType;
    }

    /**
     * @param formType the formType to set
     */
    public void setFormType(int formType) {
        this.formType = formType;
    }

    /**
     * @return the headerType
     */
    public int getHeaderType() {
        return headerType;
    }

    /**
     * @param headerType the headerType to set
     */
    public void setHeaderType(int headerType) {
        this.headerType = headerType;
    }

    /**
     * @return the formId
     */
    public int getFormId() {
        return formId;
    }

    /**
     * @param formId the formId to set
     */
    public void setFormId(int formId) {
        this.formId = formId;
    }

    /**
     * @return the ages
     */
    public List<Age> getAges() {
        return ages;
    }

    /**
     * @param ages the ages to set
     */
    public void setAges(List<Age> ages) {
        this.ages = ages;
    }

    /**
     * @return the age
     */
    public Age getAge() {
        return age;
    }

    /**
     * @param age the age to set
     */
    public void setAge(Age age) {
        this.age = age;
    }

    /**
     * @return the styles
     */
    public List<Style> getStyles() {
        return styles;
    }

    /**
     * @param styles the styles to set
     */
    public void setStyles(List<Style> styles) {
        this.styles = styles;
    }

    /**
     * @return the style
     */
    public Style getStyle() {
        return style;
    }

    /**
     * @param style the style to set
     */
    public void setStyle(Style style) {
        this.style = style;
    }

    /**
     * @return the levels
     */
    public List<Level> getLevels() {
        return levels;
    }

    /**
     * @param levels the levels to set
     */
    public void setLevels(List<Level> levels) {
        this.levels = levels;
    }

    /**
     * @return the level
     */
    public Level getLevel() {
        return level;
    }

    /**
     * @param level the level to set
     */
    public void setLevel(Level level) {
        this.level = level;
    }

    /**
     * @return the dances
     */
    public List<Dance> getDances() {
        return dances;
    }

    /**
     * @param dances the dances to set
     */
    public void setDances(List<Dance> dances) {
        this.dances = dances;
    }

    /**
     * @return the dance
     */
    public Dance getDance() {
        return dance;
    }

    /**
     * @param dance the dance to set
     */
    public void setDance(Dance dance) {
        this.dance = dance;
    }

    /**
     * @return the eventFormList
     */
    public LazyDataModel<EventForm> getEventFormList() {
        return eventFormList;
    }

    /**
     * @param eventFormList the eventFormList to set
     */
    public void setEventFormList(LazyDataModel<EventForm> eventFormList) {
        this.eventFormList = eventFormList;
    }

    /**
     * @return the currentEventId
     */
    public int getCurrentEventId() {
        return currentEventId;
    }

    /**
     * @param currentEventId the currentEventId to set
     */
    public void setCurrentEventId(int currentEventId) {
        this.currentEventId = currentEventId;
    }

    /**
     * @return the entryTypes
     */
    public List<LookUp> getEntryTypes() {
        return entryTypes;
    }

    /**
     * @param entryTypes the entryTypes to set
     */
    public void setEntryTypes(List<LookUp> entryTypes) {
        this.entryTypes = entryTypes;
    }

    /**
     * @return the entryType
     */
    public int getEntryType() {
        return entryType;
    }

    /**
     * @param entryType the entryType to set
     */
    public void setEntryType(int entryType) {
        this.entryType = entryType;
    }

    /**
     * @return the eventName
     */
    public String getEventName() {
        return eventName;
    }

    /**
     * @param eventName the eventName to set
     */
    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    /**
     * @return the selectedformId
     */
    public int getSelectedformId() {
        return selectedformId;
    }

    /**
     * @param selectedformId the selectedformId to set
     */
    public void setSelectedformId(int selectedformId) {
        this.selectedformId = selectedformId;
    }

    /**
     * @return the selectedEventForm
     */
    public EventForm getSelectedEventForm() {
        return selectedEventForm;
    }

    /**
     * @param selectedEventForm the selectedEventForm to set
     */
    public void setSelectedEventForm(EventForm selectedEventForm) {
        this.selectedEventForm = selectedEventForm;
    }

    /**
     * @return the activeTab
     */
    public int getActiveTab() {
        return activeTab;
    }

    /**
     * @param activeTab the activeTab to set
     */
    public void setActiveTab(int activeTab) {
        this.activeTab = activeTab;
    }

    /**
     * @return the headers
     */
    public List<String> getHeaders() {
        return headers;
    }

    /**
     * @param headers the headers to set
     */
    public void setHeaders(List<String> headers) {
        this.headers = headers;
    }

    /**
     * @return the header
     */
    public String getHeader() {
        return header;
    }

    /**
     * @param header the header to set
     */
    public void setHeader(String header) {
        this.header = header;
    }

    /**
     * @return the eventFormHCList
     */
    public LazyDataModel<EventFormHContent> getEventFormHCList() {
        return eventFormHCList;
    }

    /**
     * @param eventFormHCList the eventFormHCList to set
     */
    public void setEventFormHCList(LazyDataModel<EventFormHContent> eventFormHCList) {
        this.eventFormHCList = eventFormHCList;
    }

    /**
     * @return the hcontentId
     */
    public int getHcontentId() {
        return hcontentId;
    }

    /**
     * @param hcontentId the hcontentId to set
     */
    public void setHcontentId(int hcontentId) {
        this.hcontentId = hcontentId;
    }

    /**
     * @return the mapHeader
     */
    public Map<Integer,String> getMapHeader() {
        return mapHeader;
    }

    /**
     * @param mapHeader the mapHeader to set
     */
    public void setMapHeader(Map<Integer,String> mapHeader) {
        this.mapHeader = mapHeader;
    }

    /**
     * @return the dancesTarget
     */
    public List<Dance> getDancesTarget() {
        return dancesTarget;
    }

    /**
     * @param dancesTarget the dancesTarget to set
     */
    public void setDancesTarget(List<Dance> dancesTarget) {
        this.dancesTarget = dancesTarget;
    }

    /**
     * @return the dancesPickList
     */
    public DualListModel<Dance> getDancesPickList() {
        return dancesPickList;
    }

    /**
     * @param dancesPickList the dancesPickList to set
     */
    public void setDancesPickList(DualListModel<Dance> dancesPickList) {
        this.dancesPickList = dancesPickList;
    }

    /**
     * @return the eventFormDanceList
     */
    public LazyDataModel<EventFormDance> getEventFormDanceList() {
        return eventFormDanceList;
    }

    /**
     * @param eventFormDanceList the eventFormDanceList to set
     */
    public void setEventFormDanceList(LazyDataModel<EventFormDance> eventFormDanceList) {
        this.eventFormDanceList = eventFormDanceList;
    }

    /**
     * @return the formFields
     */
    public List<LookUp> getFormFields() {
        return formFields;
    }

    /**
     * @param formFields the formFields to set
     */
    public void setFormFields(List<LookUp> formFields) {
        this.formFields = formFields;
    }

    /**
     * @return the mapFields
     */
    public Map<Integer, String> getMapFields() {
        return mapFields;
    }

    /**
     * @param mapFields the mapFields to set
     */
    public void setMapFields(Map<Integer, String> mapFields) {
        this.mapFields = mapFields;
    }

    /**
     * @return the formField
     */
    public int getFormField() {
        return formField;
    }

    /**
     * @param formField the formField to set
     */
    public void setFormField(int formField) {
        this.formField = formField;
    }

    /**
     * @return the genericPickList
     */
    public DualListModel<String> getGenericPickList() {
        return genericPickList;
    }

    /**
     * @param genericPickList the genericPickList to set
     */
    public void setGenericPickList(DualListModel<String> genericPickList) {
        this.genericPickList = genericPickList;
    }

    /**
     * @return the eventFormVerticalList
     */
    public LazyDataModel<EventFormVertical> getEventFormVerticalList() {
        return eventFormVerticalList;
    }

    /**
     * @param eventFormVerticalList the eventFormVerticalList to set
     */
    public void setEventFormVerticalList(LazyDataModel<EventFormVertical> eventFormVerticalList) {
        this.eventFormVerticalList = eventFormVerticalList;
    }

    /**
     * @return the xmlFile
     */
    public UploadedFile getXmlFile() {
        return xmlFile;
    }

    /**
     * @param xmlFile the xmlFile to set
     */
    public void setXmlFile(UploadedFile xmlFile) {
        this.xmlFile = xmlFile;
    }

    /**
     * @return the useManual
     */
    public boolean isUseManual() {
        return useManual;
    }

    /**
     * @param useManual the useManual to set
     */
    public void setUseManual(boolean useManual) {
        this.useManual = useManual;
    }

    /**
     * @return the disableUpload
     */
    public boolean isDisableUpload() {
        return disableUpload;
    }

    /**
     * @param disableUpload the disableUpload to set
     */
    public void setDisableUpload(boolean disableUpload) {
        this.disableUpload = disableUpload;
    }


    /**
     * @return the selectedEvent
     */
    public Event getSelectedEvent() {
        return selectedEvent;
    }

    /**
     * @param selectedEvent the selectedEvent to set
     */
    public void setSelectedEvent(Event selectedEvent) {
        this.selectedEvent = selectedEvent;
    }

    /**
     * @return the selectedEventFormXML
     */
    public EventFormXML getSelectedEventFormXML() {
        return selectedEventFormXML;
    }

    /**
     * @param selectedEventFormXML the selectedEventFormXML to set
     */
    public void setSelectedEventFormXML(EventFormXML selectedEventFormXML) {
        this.selectedEventFormXML = selectedEventFormXML;
    }

    /**
     * @return the newXMLFile
     */
    public String getNewXMLFile() {
        return newXMLFile;
    }

    /**
     * @param newXMLFile the newXMLFile to set
     */
    public void setNewXMLFile(String newXMLFile) {
        this.newXMLFile = newXMLFile;
    }

    /**
     * @return the downloadFile
     */
    public StreamedContent getDownloadFile() {
        return downloadFile;
    }

    /**
     * @param downloadFile the downloadFile to set
     */
    public void setDownloadFile(StreamedContent downloadFile) {
        this.downloadFile = downloadFile;
    }

    /**
     * @return the newSTUFile
     */
    public String getNewSTUFile() {
        return newSTUFile;
    }

    /**
     * @param newSTUFile the newSTUFile to set
     */
    public void setNewSTUFile(String newSTUFile) {
        this.newSTUFile = newSTUFile;
    }

    /**
     * @return the baseFilename
     */
    public String getBaseFilename() {
        return baseFilename;
    }

    /**
     * @param baseFilename the baseFilename to set
     */
    public void setBaseFilename(String baseFilename) {
        this.baseFilename = baseFilename;
    }
}
