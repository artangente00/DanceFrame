/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.lazy.payment;

import com.danceframe.console.common.model.invoice.InvoicePayment;
import com.danceframe.console.web.service.InvoicePaymentService;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

/**
 *
 * @author lmorallos
 */
public class InvoicePaymentLazyList extends LazyDataModel<InvoicePayment> {
    
    private static final Logger logger = LogManager.getLogger(InvoicePaymentLazyList.class);
     
    private InvoicePaymentService invoicePaymentService;

    private List<InvoicePayment> invoicePayments;
    private int rowCount;

    
    public InvoicePaymentLazyList(InvoicePaymentService invoicePaymentService) {
        this.invoicePaymentService = invoicePaymentService;
    }
    
     public List<InvoicePayment> load(int first, int pageSize, String sortField,
                             SortOrder sortOrder, Map<String, Object> filters) {
           // filters can be here
       String wherestr = new String();
       String wherecnt = new String();
        
       if (filters.containsKey("invoiceNo")) {
           String value = (String)filters.get("invoiceNo");
           if (value.length() > 0)
           {
               wherestr = wherestr + " WHERE invoice_no like '" + value.toUpperCase() + "%'";
              
           }
       }
        wherecnt = wherestr;
        // sorting
        String sortSql = new String();
        if (sortField != null) {
            if (sortField.equalsIgnoreCase("invoiceNo")) {
                sortSql = " ORDER BY invoice_no ASC";
            } 
         } else {
            sortSql = " ORDER BY invoice_no ASC";
            
        }
        wherestr += sortSql;
        logger.info("Page Query (sortfield):(" + sortField + ") " +  wherestr);
        invoicePayments = invoicePaymentService.getInvoicePaymentProviderDao().getAllWithPaging(wherestr, 
                       pageSize, first);
        Long rc = (Long)invoicePaymentService.getInvoicePaymentProviderDao().getAllCount(wherecnt);
        
        rowCount = rc.intValue();
        setPageSize(pageSize);
        return invoicePayments;           
       }
    
    
    
    @Override
    public Object getRowKey(InvoicePayment invpay) {
        return invpay.getInvoicePaymentId();
    }
    
    @Override
    public InvoicePayment getRowData(String invpayId) {
        Integer id = Integer.valueOf(invpayId);
        for (InvoicePayment invpayment : invoicePayments) {
            if(id.equals(invpayment.getInvoicePaymentId())){
                return invpayment;
            }
        }
        return null;
    }
    
    /**
     * @return the invoicePaymentService
     */
    public InvoicePaymentService getInvoicePaymentService() {
        return invoicePaymentService;
    }

    /**
     * @param invoicePaymentService the invoicePaymentService to set
     */
    public void setInvoicePaymentService(InvoicePaymentService invoicePaymentService) {
        this.invoicePaymentService = invoicePaymentService;
    }

    /**
     * @return the invoicePayments
     */
    public List<InvoicePayment> getInvoicePayments() {
        return invoicePayments;
    }

    /**
     * @param invoicePayments the invoicePayments to set
     */
    public void setInvoicePayments(List<InvoicePayment> invoicePayments) {
        this.invoicePayments = invoicePayments;
    }

    /**
     * @return the rowCount
     */
    public int getRowCount() {
        return rowCount;
    }

    /**
     * @param rowCount the rowCount to set
     */
    public void setRowCount(int rowCount) {
        this.rowCount = rowCount;
    }
    
    
    
}
