/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.lazy.uam;

import com.danceframe.console.common.model.uam.Syslog;
import com.danceframe.console.web.service.UserManagementService;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

/**
 *
 * @author lmorallos
 */
public class SysLogLazyList extends LazyDataModel<Syslog> {
    
    private static final Logger logger = LogManager.getLogger(SysLogLazyList.class);
    private UserManagementService userManagementService;

    private List<Syslog> syslogs;
    private int rowCount;
    
    public SysLogLazyList(UserManagementService umsc) {
        userManagementService = umsc;  
    }
    
     public List<Syslog> load(int first, int pageSize, String sortField,
                             SortOrder sortOrder, Map<String, Object> filters) {
           // filters can be here
       String wherestr = new String();
       String wherecnt = new String();
        
       if (filters.containsKey("username")) {
           String value = (String)filters.get("username");
           if (value.length() > 0)
           {
               wherestr = wherestr + " AND UPPER(username) like '%" + value.toUpperCase() + "%'";
              
           }
       }
        wherecnt = wherestr;
        // sorting
        String sortSql = new String();
        if (sortField != null) {
            if (sortField.equalsIgnoreCase("username")) {
                sortSql = " ORDER BY username ASC";
            } 
         } else {
            sortSql = " ORDER BY username ASC";
            
        }
        wherestr += sortSql;
        logger.info("Page Query (sortfield):(" + sortField + ") " +  wherestr);
        syslogs = userManagementService.getSyslogProviderDao().getAllWithPaging(wherestr, 
                       pageSize, first);
//        for (User obj:users) {
//            logger.info("user search:" + obj.toString());
//        }
        Long rc = (Long)userManagementService.getSyslogProviderDao().getAllCount(wherecnt);
        
        rowCount = rc.intValue();
        setPageSize(pageSize);
        return syslogs;           
       }
    
    
    @Override
    public Object getRowKey(Syslog syslog) {
        return syslog.getId();
    }
    
    @Override
    public Syslog getRowData(String userId) {
        Integer id = Integer.valueOf(userId);
        for (Syslog syslog : syslogs) {
            if(id.equals(syslog.getId())){
                return syslog;
            }
        }
        return null;
    }
    
    /**
     * @return the userManagementService
     */
    public UserManagementService getUserManagementService() {
        return userManagementService;
    }

    /**
     * @param userManagementService the userManagementService to set
     */
    public void setUserManagementService(UserManagementService userManagementService) {
        this.userManagementService = userManagementService;
    }


    /**
     * @return the rowCount
     */
    public int getRowCount() {
        return rowCount;
    }

    /**
     * @param rowCount the rowCount to set
     */
    public void setRowCount(int rowCount) {
        this.rowCount = rowCount;
    }

    /**
     * @return the syslogs
     */
    public List<Syslog> getSyslogs() {
        return syslogs;
    }

    /**
     * @param syslogs the syslogs to set
     */
    public void setSyslogs(List<Syslog> syslogs) {
        this.syslogs = syslogs;
    }
    
    
    
}
