/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.service.util;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author lmorallos
 */
public final class CookieHelper {
    
    public static final String COOKIE_USER = "uname";
    
    public static final String COOKIE_USERID = "userid";
    
    public static final String COOKIE_LNAME = "lname";
    
    public static final String COOKIE_FNAME = "fname";
    
    public static final void setCookie(HttpServletRequest request, HttpServletResponse response, 
            String name, String value, int expiry) {

        Cookie cookie = null;
        Cookie[] userCookies = request.getCookies();
        if (userCookies != null && userCookies.length > 0 ) {
            for (int i = 0; i < userCookies.length; i++) {
                if (userCookies[i].getName().equals(name)) {
                    cookie = userCookies[i];
                    break;
                }
            }
        }
        
        if (cookie != null) {
            if (cookie.getValue() == null) {
               cookie.setValue(value); 
               cookie.setMaxAge(expiry);
            }
        } else {
            cookie = new Cookie(name, value);
            cookie.setPath(request.getContextPath());
        }

        cookie.setMaxAge(expiry);
        response.addCookie(cookie);
    }

    public final static Cookie getCookie(HttpServletRequest request, String name) {

        Cookie cookie = null;

        Cookie[] userCookies = request.getCookies();
        if (userCookies != null && userCookies.length > 0 ) {
            for (int i = 0; i < userCookies.length; i++) {
                if (userCookies[i].getName().equals(name)) {
                    cookie = userCookies[i];
                    return cookie;
                }
            }
        }
        return null;
    }
    
    
    public final static boolean isCookiePresent(HttpServletRequest request, String name) {
        boolean retbool = false;
        Cookie[] cookies = request.getCookies();
        if (null != cookies) {
            for (Cookie cookie:cookies) {
                if (cookie.getName().equals(name)) {
                    retbool = true;
                    break;
                }
            }
        }
        return retbool;
    }
    
    
    public final static void clearCookies(HttpServletRequest request, HttpServletResponse response) {
        Cookie[] cookies = request.getCookies();
        if (null != cookies) {
            for (Cookie cookie:cookies) {
                // cookie.setValue("");
                cookie.setMaxAge(0);
                response.addCookie(cookie);    
            }
        }
    }
}
