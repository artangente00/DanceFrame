/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.lazy.people;

import com.danceframe.console.common.model.people.People;
import com.danceframe.console.web.service.PeopleManagementService;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

/**
 *
 * @author nbonita
 */
public class PeopleLazyList extends LazyDataModel<People> {
    
    private static final Logger logger = LogManager.getLogger(PeopleLazyList.class);
    
    private PeopleManagementService peopleManagementService;
    
    private List<People> peoples;
    private int rowCount;
    
    public PeopleLazyList(PeopleManagementService pmsc) {
        peopleManagementService = pmsc;
    }

    public List<People> load(int first, int pageSize, String sortField,
                             SortOrder sortOrder, Map<String, Object> filters) {
           // filters can be here
       String wherestr = new String();
       String wherecnt = new String();
        
       if (filters.containsKey("eMail")) {
           String value = (String)filters.get("eMail");
           if (value.length() > 0)
           {
               wherestr = wherestr + " WHERE UPPER(email) like '%" + value.toUpperCase() + "%'";
              
           }
       }
        wherecnt = wherestr;
        // sorting
        String sortSql = new String();
        if (sortField != null) {
            if (sortField.equalsIgnoreCase("email")) {
                sortSql = " ORDER BY email ASC";
            } 
         } else {
            sortSql = " ORDER BY email ASC";
            
        }
        wherestr += sortSql;
        logger.info("Page Query (sortfield):(" + sortField + ") " +  wherestr);
        peoples = peopleManagementService.getPeopleProviderDao().getAllWithPaging(wherestr, 
                       pageSize, first);
//        for (User obj:users) {
//            logger.info("user search:" + obj.toString());
//        }
        Long rc = (Long)peopleManagementService.getPeopleProviderDao().getAllCount(wherecnt);
        
        rowCount = rc.intValue();
        setPageSize(pageSize);
        return peoples;           
       }
    
    
    @Override
    public Object getRowKey(People people) {
        return people.getId();
    }
    
    @Override
    public People getRowData(String peopleId) {
        Integer id = Integer.valueOf(peopleId);
        for (People people : peoples) {
            if(id.equals(people.getId())){
                return people;
            }
        }
        return null;
    }
    /**
     * @return the peoples
     */
    public List<People> getPeoples() {
        return peoples;
    }

    /**
     * @param peoples the peoples to set
     */
    public void setPeoples(List<People> peoples) {
        this.peoples = peoples;
    }

    /**
     * @return the rowCount
     */
    public int getRowCount() {
        return rowCount;
    }

    /**
     * @param rowCount the rowCount to set
     */
    public void setRowCount(int rowCount) {
        this.rowCount = rowCount;
    }

    /**
     * @return the peopleManagementService
     */
    public PeopleManagementService getPeopleManagementService() {
        return peopleManagementService;
    }

    /**
     * @param peopleManagementService the peopleManagementService to set
     */
    public void setPeopleManagementService(PeopleManagementService peopleManagementService) {
        this.peopleManagementService = peopleManagementService;
    }
    
}
