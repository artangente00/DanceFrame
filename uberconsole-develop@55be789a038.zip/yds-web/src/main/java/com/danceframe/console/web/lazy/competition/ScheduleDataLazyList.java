/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.lazy.competition;

import com.danceframe.console.common.model.competition.ScheduleData;
import com.danceframe.console.web.service.CompetitionService;
import java.util.List;
import java.util.Map;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

/**
 *
 * @author lmorallos
 */
public class ScheduleDataLazyList extends LazyDataModel<ScheduleData>{
    
    private CompetitionService competitionService; 
    
    private List<ScheduleData> scheduleDatas;
    private int rowCount;
    private int eventId;
    
    
    public ScheduleDataLazyList(CompetitionService csrv, int evId) {
        competitionService = csrv;
        eventId = evId;
    }
    
    public List<ScheduleData> load(int first, int pageSize, String sortField,
                             SortOrder sortOrder, Map<String, Object> filters) {
        
       String wherestr = " WHERE event_id=" + eventId;
       String wherecnt = wherestr;
       
       String sortSql = " ORDER BY hdrorder ASC, header_name ASC, tvalorder ASC";
       wherestr += sortSql;
       
        scheduleDatas = competitionService.getScheduleDataProviderDao().getAllWithPaging(wherestr, 
                pageSize, first);
        Long rc = (Long)competitionService.getScheduleDataProviderDao().getAllCount(wherecnt);
        
        rowCount = rc.intValue();
        setPageSize(pageSize);
       
       return scheduleDatas;
    } 
    
    @Override
    public Object getRowKey(ScheduleData scheddata) {
        return scheddata.getId();
    }
    
    @Override
    public ScheduleData getRowData(String eveId) {
        Integer id = Integer.valueOf(eveId);
        for (ScheduleData scheddata : scheduleDatas) {
            if(id.equals(scheddata.getId())){
                return scheddata;
            }
        }
        return null;
    }

    /**
     * @return the competitionService
     */
    public CompetitionService getCompetitionService() {
        return competitionService;
    }

    /**
     * @param competitionService the competitionService to set
     */
    public void setCompetitionService(CompetitionService competitionService) {
        this.competitionService = competitionService;
    }

    /**
     * @return the scheduleData
     */
    public List<ScheduleData> getScheduleDatas() {
        return scheduleDatas;
    }

    /**
     * @param scheduleData the scheduleData to set
     */
    public void setScheduleDatas(List<ScheduleData> scheduleDatas) {
        this.scheduleDatas = scheduleDatas;
    }

    /**
     * @return the rowCount
     */
    public int getRowCount() {
        return rowCount;
    }

    /**
     * @param rowCount the rowCount to set
     */
    public void setRowCount(int rowCount) {
        this.rowCount = rowCount;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }
    
    
    
    
}
