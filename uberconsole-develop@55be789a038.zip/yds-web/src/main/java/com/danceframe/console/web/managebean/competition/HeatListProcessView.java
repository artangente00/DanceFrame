/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.managebean.competition;

import com.danceframe.console.common.model.competition.Event;
import com.danceframe.console.common.model.heatlist.HeatList;
import com.danceframe.console.common.model.heatlist.HeatListEvent;
import com.danceframe.console.common.util.Utility;
import com.danceframe.console.web.lazy.competition.HeatListLazyList;
import com.danceframe.console.web.managebean.BaseBean;
import com.danceframe.console.web.service.CompetitionService;
import com.danceframe.console.web.service.HeatListService;
import com.danceframe.console.web.service.util.HttpClientHelper;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.context.RequestContext;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.StreamedContent;
import org.primefaces.model.UploadedFile;
import org.springframework.dao.EmptyResultDataAccessException;

/**
 *
 * @author lmorallos
 */
@ManagedBean (name="heatListView")
@ViewScoped
public class HeatListProcessView extends BaseBean implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private static final Logger logger = LogManager.getLogger(HeatListProcessView.class);
    private LazyDataModel<Event>    eventList = null;
    private Event           selectedEvent = new Event();
    private Event           uploadEvent = new Event();
 
    private HeatListEvent   heatEvent;
    private int             eventYear;
    private int             eventId;
    private HeatList        heatList;
    private String          tmpLocation;
    private String          tmpHeatListFile;
    private String          tmpSetupFile;
    private StreamedContent generatedHeatList;
    private boolean         allowedDownload;
    
    @ManagedProperty(value="#{heatListService}")
    private HeatListService heatListService;
    
    @ManagedProperty(value="#{competitionService}")
    private CompetitionService competitionService;   
    
    @PostConstruct
    public void init() {
        if (eventList == null) {
            eventList = new HeatListLazyList(competitionService);
        }
        allowedDownload = false;
        tmpLocation =  System.getProperty("java.io.tmpdir") + File.separator;
        logger.info("==>>INIT tmp location(heatlist):"  +  tmpLocation);
        heatEvent = new HeatListEvent();
        tmpHeatListFile = new String();
        tmpSetupFile = new String();
    }
    
    public void newHeatList(int eventId) {
        //resetData();
        // check if need overwrite if the heatlist already exist
        uploadEvent = new Event();
        try {
            uploadEvent = competitionService.getEventProviderDao().get(eventId);
        } catch (EmptyResultDataAccessException ex) {
            logger.warn("Warning: Empty Event using  id:" + eventId + " " + ex.getMessage());
        }
        
        tmpHeatListFile = new String();
        tmpSetupFile = new String();
        heatList = new HeatList();
        heatList.setEventId(uploadEvent.getId());
        heatList.setDescription(uploadEvent.getName());
        heatList.setAsof(new Date(System.currentTimeMillis()));
        heatList.setCompDate(uploadEvent.getDateStart());
    }


    public void uploadHeatList(FileUploadEvent e) throws IOException{
        UploadedFile uploadHeatList=e.getFile();
        byte[] bytes=null;
        if (null!=uploadHeatList) {
            String heatfilename = uploadHeatList.getFileName();
            bytes = uploadHeatList.getContents();
            addMessage("Upload Program Info File:" + heatfilename);
            logger.info("Uploaded Heat List file:" + heatfilename);
            String fileext = Utility.getExtension(heatfilename);
            String fileprefix = Utility.getFilename(heatfilename); 
            String type = fileext.replace(".", "");
            String mimeType = "text/" + type;
            String filename = new String();
            filename = Utility.generateUniqueFileName(fileprefix,"HITX");
            heatList.setFilename(heatfilename);
            if (fileext !=null) filename = filename + "." + fileext;
            tmpHeatListFile = filename;
            logger.info("Heatlist Tmp File:" +  tmpHeatListFile);
            // read the file line by line
            BufferedOutputStream stream = new BufferedOutputStream(
                        new FileOutputStream(new File(tmpLocation,filename)));
            stream.write(bytes);
            stream.flush();
            stream.close();
            stream = null;
        }
    }
    
    public void uploadSetupFile(FileUploadEvent e) throws IOException{
        UploadedFile uploadSetupFile=e.getFile();
        byte[] bytes=null;
        if (null!=uploadSetupFile) {
            String setupfilename = uploadSetupFile.getFileName();
            bytes = uploadSetupFile.getContents();
            addMessage("Uploaded Setup File:" + setupfilename);
            logger.info("Uploaded Setup File:" + setupfilename);
            String fileext = Utility.getExtension(setupfilename);
            String fileprefix = Utility.getFilename(setupfilename); 
            String type = fileext.replace(".", "");
            String mimeType = "text/" + type;
            String filename = new String();
            filename = Utility.generateUniqueFileName(fileprefix,"HSTU");
            heatList.setSetupFile(setupfilename);
            if (fileext !=null) filename = filename + "." + fileext;
            tmpSetupFile = filename;
            logger.info("setupfilename Tmp File:" +  tmpSetupFile);
            // read the file line by line
            BufferedOutputStream stream = new BufferedOutputStream(
                        new FileOutputStream(new File(tmpLocation,filename)));
            stream.write(bytes);
            stream.flush();
            stream.close();
            stream = null;
        }
    }
    
    public void save() {
        context = RequestContext.getCurrentInstance();
        String tmpfile = tmpLocation + "/" + tmpHeatListFile;
        String tmpsetupFile = tmpLocation + "/" + tmpSetupFile;
        if ((null != heatList.getFilename()) && (null != heatList.getSetupFile())) {
            int havedata = heatListService.getHeatListProviderDao().checkHeatListDataExist(heatList.getEventId());
            if (havedata > 0) {
                logger.info("Deleting heatlist information before inserting heatlist data");
                int iret = heatListService.getHeatListProviderDao().deleteHeatListByEventId(heatList.getEventId());
                if (iret < 1)  logger.info("Existing heatlist information cleared for event:" + heatList.getEventId());
            }
            int heatid = heatListService.getHeatListProviderDao().insertHeatList(heatList);
            if (heatid > 0) {
                try {
                    heatList.setId(heatid);
                    heatListService.getHeatListReader().fileToDatabase(tmpfile, heatList.getId());
                    addMessage("HeatList Information Added:" + heatid);
                    
                    heatListService.getHeatListReader().setupFileToDatabase(tmpsetupFile, heatList.getId());
                     addMessage("HeatList Setup File Added:" + heatid);
                     
                    File progfile = new File(tmpfile);
                    byte[] progbytes = Files.readAllBytes(progfile.toPath());
                    heatList.setProgData(progbytes);
                    
                    int progret = heatListService.getHeatListProviderDao().saveHeatlistData(heatList, 1);
                    if (progret < 1)  logger.error("There is an error saving raw Programmng Info.");
                    
                    File setupfile = new File(tmpsetupFile);
                    byte[] stubytes = Files.readAllBytes(setupfile.toPath());
                    heatList.setSetupData(stubytes);
                            
                    int sturet = heatListService.getHeatListProviderDao().saveHeatlistData(heatList, 2);
                    if (sturet < 1)  logger.error("There is an error saving raw Setup File Info.");
                    
                    context.execute("PF('heatlistDialog').hide();");
                    resetData();
                } catch (IOException iox) {
                    addMessage("HeatList File Upload Error", FacesMessage.SEVERITY_WARN);
                }
            } else {
                addMessage("Error Saving Heatlist for this event", FacesMessage.SEVERITY_WARN);
            }
        } else {
            if ((null != heatList.getFilename()) && (null == heatList.getSetupFile())) {
                addMessage("Error Saving - Missing Setup File", FacesMessage.SEVERITY_WARN);
            } else if ((null == heatList.getFilename()) && (null != heatList.getSetupFile())) {
                addMessage("Error Saving - Missing Program Info", FacesMessage.SEVERITY_WARN);
            } else {
                addMessage("Error Saving - No Program Info and Setup File", FacesMessage.SEVERITY_WARN);
            }
        }
    }
    
    public void delete(int eventId) {
        int havedata = heatListService.getHeatListProviderDao().checkHeatListDataExist(eventId);
        if (havedata > 0) {
            int heatid = heatListService.getHeatListProviderDao().deleteHeatListByEventId(eventId);
            if (heatid > 0) {
                 addMessage("Success deleting heat list.");
            } else {
                 addMessage("Error deleting heat list.", FacesMessage.SEVERITY_WARN);
            }
        } else {
             addMessage("No Heat List Data to Delete for this Event.", FacesMessage.SEVERITY_INFO);
        }
    }
    
    public void downloadHeatList(int id) {
        String mimeType = "text/html";
        String filename = "GeneratedHeatList-" + id + ".html"; 
        generatedHeatList = null;
        allowedDownload = false;
        int havedata = heatListService.getHeatListProviderDao().checkHeatListDataExist(id);
        if (havedata > 0) {
            try {
                boolean retheat = heatListService.getHeatListWriter().writeToFile(tmpLocation, filename, id);
                if (retheat) {
                    File genfile = new File(tmpLocation, filename);
                    if (genfile.exists()) {
                        byte[] contents = new byte[(int)genfile.length()];
                        FileInputStream fis = new FileInputStream(genfile);
                        fis.read(contents);
                        fis.close();
                        generatedHeatList = new DefaultStreamedContent(
                            new ByteArrayInputStream(contents),
                            mimeType,filename);
                        Utility.deleteFile(tmpLocation, filename);
                        allowedDownload = true;
                    }
                } else {
                     addMessage("No heat list data for this event.", FacesMessage.SEVERITY_WARN); 
                }
            } catch (IOException io) {
               addMessage("Error generating heat list output.", FacesMessage.SEVERITY_WARN); 
            }
        } else {
             addMessage("No Heat Lst Data to Generate for this Event.", FacesMessage.SEVERITY_WARN); 
        }
    }
    
    public void closeDialog() {
         resetData();
    }
    
    public void resetData() {
        uploadEvent = new Event();
        heatList = null;
        generatedHeatList = null;
        allowedDownload = false;
        if (Utility.deleteFile(tmpLocation, tmpHeatListFile)) {
            logger.info("Heatlist temporary file deleted.");
        }
        if (Utility.deleteFile(tmpLocation, tmpSetupFile)) {
            logger.info("Setup File temporary file deleted.");
        }
    }
   
    public void displayHelpPDF() {
        try {
            faces = FacesContext.getCurrentInstance();
            URL url = faces.getExternalContext().getResource("/resources/pdf/help.pdf");
            File file = Paths.get(url.toURI()).toFile();
            System.out.println(file.getAbsolutePath());;
            HttpClientHelper.openFile(file, faces, "application/pdf");
        } catch (URISyntaxException | MalformedURLException ex) {
                logger.error(ex.getMessage());
        }
    }
    
    
    /**
     * @return the eventList
     */
    public LazyDataModel<Event> getEventList() {
        if (eventList == null) {
            eventList = new HeatListLazyList(competitionService);
        }
        return eventList;
    }

    /**
     * @param eventList the eventList to set
     */
    public void setEventList(LazyDataModel<Event> eventList) {
        this.eventList = eventList;
    }

    /**
     * @return the selectedEvent
     */
    public Event getSelectedEvent() {
        return selectedEvent;
    }

    /**
     * @param selectedEvent the selectedEvent to set
     */
    public void setSelectedEvent(Event selectedEvent) {
        this.selectedEvent = selectedEvent;
    }

    /**
     * @return the heatListService
     */
    public HeatListService getHeatListService() {
        return heatListService;
    }

    /**
     * @param heatListService the heatListService to set
     */
    public void setHeatListService(HeatListService heatListService) {
        this.heatListService = heatListService;
    }

    /**
     * @return the heatEvent
     */
    public HeatListEvent getHeatEvent() {
        return heatEvent;
    }

    /**
     * @param heatEvent the heatEvent to set
     */
    public void setHeatEvent(HeatListEvent heatEvent) {
        this.heatEvent = heatEvent;
    }

    /**
     * @return the competitionService
     */
    public CompetitionService getCompetitionService() {
        return competitionService;
    }

    /**
     * @param competitionService the competitionService to set
     */
    public void setCompetitionService(CompetitionService competitionService) {
        this.competitionService = competitionService;
    }

    /**
     * @return the eventYear
     */
    public int getEventYear() {
        return eventYear;
    }

    /**
     * @param eventYear the eventYear to set
     */
    public void setEventYear(int eventYear) {
        this.eventYear = eventYear;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the heatList
     */
    public HeatList getHeatList() {
        return heatList;
    }

    /**
     * @param heatList the heatList to set
     */
    public void setHeatList(HeatList heatList) {
        this.heatList = heatList;
    }


    /**
     * @return the generatedHeatList
     */
    public StreamedContent getGeneratedHeatList() {
        return generatedHeatList;
    }

    /**
     * @param generatedHeatList the generatedHeatList to set
     */
    public void setGeneratedHeatList(StreamedContent generatedHeatList) {
        this.generatedHeatList = generatedHeatList;
    }

    /**
     * @return the allowedDownload
     */
    public boolean isAllowedDownload() {
        return allowedDownload;
    }

    /**
     * @param allowedDownload the allowedDownload to set
     */
    public void setAllowedDownload(boolean allowedDownload) {
        this.allowedDownload = allowedDownload;
    }

    /**
     * @return the uploadEvent
     */
    public Event getUploadEvent() {
        return uploadEvent;
    }

    /**
     * @param uploadEvent the uploadEvent to set
     */
    public void setUploadEvent(Event uploadEvent) {
        this.uploadEvent = uploadEvent;
    }

    /**
     * @return the tmpSetupFile
     */
    public String getTmpSetupFile() {
        return tmpSetupFile;
    }

    /**
     * @param tmpSetupFile the tmpSetupFile to set
     */
    public void setTmpSetupFile(String tmpSetupFile) {
        this.tmpSetupFile = tmpSetupFile;
    }
    
}
