/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.service;

import com.danceframe.console.service.dataprovider.payment.InvoiceProviderDao;
import java.io.Serializable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author nbonita
 */
    @Service("invoiceManagementService")
public class InvoiceManagementService implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @Autowired
    private InvoiceProviderDao invoiceProviderDao;

    
    /**
     * @return the invoiceProviderDao
     */
    public InvoiceProviderDao getInvoiceProviderDao() {
        return invoiceProviderDao;
    }

    /**
     * @param invoiceProviderDao the invoiceProviderDao to set
     */
    public void setInvoiceProviderDao(InvoiceProviderDao invoiceProviderDao) {
        this.invoiceProviderDao = invoiceProviderDao;
    }
    
}