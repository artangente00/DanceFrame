/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.managebean.competition;

import com.danceframe.console.common.model.heatlist.result.MasterJudge;
import com.danceframe.console.web.lazy.competition.MasterJudgeLazyList;
import com.danceframe.console.web.managebean.BaseBean;
import com.danceframe.console.web.service.HeatListResultService;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.context.RequestContext;
import org.primefaces.event.SelectEvent;
import org.primefaces.model.LazyDataModel;

/**
 *
 * @author lmorallos
 */
@ManagedBean(name = "masterJudgeView")
@ViewScoped
public class MasterJudgeView extends BaseBean implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private static final Logger logger = LogManager.getLogger(MasterJudgeView.class);
    
    @ManagedProperty(value = "#{heatListResultService}")
    private HeatListResultService heatListResultService;
    

    private LazyDataModel<MasterJudge> masterJudges = null;
    private MasterJudge selectedMasterJudge = null;
    private List<MasterJudge> selectedMasterJudges = null;
     private MasterJudge inputMasterJudge = new MasterJudge();
    
    private int destinationId;
    
    @PostConstruct
    public void init() {
        if (masterJudges == null) {
             masterJudges = new MasterJudgeLazyList(heatListResultService);
        }
        selectedMasterJudge = new MasterJudge();
        selectedMasterJudges = new ArrayList<>();       ;
    }
    
    public void onRowSelect(SelectEvent event) {
       context = RequestContext.getCurrentInstance();
       selectedMasterJudge = (MasterJudge)event.getObject();
       if (selectedMasterJudge != null) {
           logger.info("selected:" + selectedMasterJudge.toString());
           inputMasterJudge = new MasterJudge();
           inputMasterJudge.setId(selectedMasterJudge.getId());
           inputMasterJudge.setFirstname(selectedMasterJudge.getFirstname());
           inputMasterJudge.setLastname(selectedMasterJudge.getLastname());
           logger.info("input:" + inputMasterJudge.toString());
           context.execute("PF('editMpDialog').show();");
       }
    }
    
    public void save() {
        context = RequestContext.getCurrentInstance();
        if (inputMasterJudge != null) {
            int iret = heatListResultService.getHeatListResultMasterJudgeProviderDao().update(inputMasterJudge);
            if (iret > 0) {
                addMessage("Successful Updating Master Judge."); 
                context.execute("PF('editMpDialog').hide();");
            } else {
                addMessage("Failed Updaing Master Judge." ); 
            }
        }
    }
    
    
    public void unified() {
        context = RequestContext.getCurrentInstance();
        if (selectedMasterJudges.size() > 1) { 
            for (MasterJudge judge:selectedMasterJudges) {
                logger.info("Unified:" + judge.toString());
            }
            destinationId = 0;
            context.execute("PF('unifiedDialog').show();");
        } else {
            addMessage("Must be at least 2 names to merge" ); 
        }
    }
    
    public void merge() {
        context = RequestContext.getCurrentInstance();
        logger.info("master person id:" + destinationId);
        if (destinationId > 0) {
            int ctr = 0;
            for (MasterJudge judge:selectedMasterJudges) {
                if (destinationId != judge.getId()) {
                    int iret = heatListResultService.getHeatListResultMasterJudgeProviderDao().unifiedMasterJudge(judge.getId(), destinationId);
                    ctr++;
                }
            }
            if (ctr > 0) {
                String message = "No of name merged: " + ctr + " to id:" + destinationId;
                addMessage(message);
                context.execute("PF('unifiedDialog').hide();");
            } else {
                addMessage("No data has been merged.");
            }
        }        
    }

    /**
     * @return the heatListResultService
     */
    public HeatListResultService getHeatListResultService() {
        return heatListResultService;
    }

    /**
     * @param heatListResultService the heatListResultService to set
     */
    public void setHeatListResultService(HeatListResultService heatListResultService) {
        this.heatListResultService = heatListResultService;
    }

    /**
     * @return the masterJudges
     */
    public LazyDataModel<MasterJudge> getMasterJudges() {
        return masterJudges;
    }

    /**
     * @param masterJudges the masterJudges to set
     */
    public void setMasterJudges(LazyDataModel<MasterJudge> masterJudges) {
        this.masterJudges = masterJudges;
    }

    /**
     * @return the selectedMasterJudge
     */
    public MasterJudge getSelectedMasterJudge() {
        return selectedMasterJudge;
    }

    /**
     * @param selectedMasterJudge the selectedMasterJudge to set
     */
    public void setSelectedMasterJudge(MasterJudge selectedMasterJudge) {
        this.selectedMasterJudge = selectedMasterJudge;
    }

    /**
     * @return the selectedMasterJudges
     */
    public List<MasterJudge> getSelectedMasterJudges() {
        return selectedMasterJudges;
    }

    /**
     * @param selectedMasterJudges the selectedMasterJudges to set
     */
    public void setSelectedMasterJudges(List<MasterJudge> selectedMasterJudges) {
        this.selectedMasterJudges = selectedMasterJudges;
    }

    /**
     * @return the inputMasterJuge
     */
    public MasterJudge getInputMasterJudge() {
        return inputMasterJudge;
    }

    /**
     * @param inputMasterJuge the inputMasterJuge to set
     */
    public void setInputMasterJudge(MasterJudge inputMasterJudge) {
        this.inputMasterJudge = inputMasterJudge;
    }

    /**
     * @return the destinationId
     */
    public int getDestinationId() {
        return destinationId;
    }

    /**
     * @param destinationId the destinationId to set
     */
    public void setDestinationId(int destinationId) {
        this.destinationId = destinationId;
    }
    
    
    
}
