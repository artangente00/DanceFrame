/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.lazy.competition.config;

import com.danceframe.console.common.model.competition.form.EventFormVertical;
import com.danceframe.console.web.service.EventFormConfigService;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

/**
 *
 * @author lmorallos
 */
public class EventVerticalLazyList extends LazyDataModel<EventFormVertical>{
 
    private static final Logger logger = LogManager.getLogger(EventVerticalLazyList.class);
     
    private EventFormConfigService eventFormConfigService;
      
    private List<EventFormVertical> eventFormVertical;
    private int rowCount;
    private int eventFieldId;
    private int eventFormId;
    
    public EventVerticalLazyList(EventFormConfigService efcs, int efid, int eformid) {
        eventFormConfigService = efcs;
        eventFieldId = efid;
        eventFormId = eformid;
    }
    
    public List<EventFormVertical> load(int first, int pageSize, String sortField,
                             SortOrder sortOrder, Map<String, Object> filters) {
        
       String wherestr = " WHERE eventform_id=" + eventFormId + 
               " AND eventfield_id=" + eventFieldId;
       String wherecnt = wherestr;
       
       String sortSql = " ORDER BY eventfield_id  ASC";
       wherestr += sortSql;
       
       
        eventFormVertical = eventFormConfigService.getEventFormVerticalProviderDao().getAllWithPaging(wherestr, 
                pageSize, first);
        Long rc = (Long)eventFormConfigService.getEventFormVerticalProviderDao().getAllCount(wherecnt);
        
        rowCount = rc.intValue();
        setPageSize(pageSize);
       
       return eventFormVertical;
    
    }
    

    /**
     * @return the eventFieldId
     */
    public int getEventFieldId() {
        return eventFieldId;
    }

    /**
     * @param eventFieldId the eventFieldId to set
     */
    public void setEventFieldId(int eventFieldId) {
        this.eventFieldId = eventFieldId;
    }

    /**
     * @return the eventFormId
     */
    public int getEventFormId() {
        return eventFormId;
    }

    /**
     * @param eventFormId the eventFormId to set
     */
    public void setEventFormId(int eventFormId) {
        this.eventFormId = eventFormId;
    }

    /**
     * @return the eventFormConfigService
     */
    public EventFormConfigService getEventFormConfigService() {
        return eventFormConfigService;
    }

    /**
     * @param eventFormConfigService the eventFormConfigService to set
     */
    public void setEventFormConfigService(EventFormConfigService eventFormConfigService) {
        this.eventFormConfigService = eventFormConfigService;
    }

    /**
     * @return the rowCount
     */
    public int getRowCount() {
        return rowCount;
    }

    /**
     * @param rowCount the rowCount to set
     */
    public void setRowCount(int rowCount) {
        this.rowCount = rowCount;
    }

    /**
     * @return the eventFormVertical
     */
    public List<EventFormVertical> getEventFormVertical() {
        return eventFormVertical;
    }

    /**
     * @param eventFormVertical the eventFormVertical to set
     */
    public void setEventFormVertical(List<EventFormVertical> eventFormVertical) {
        this.eventFormVertical = eventFormVertical;
    }
     
     
}
