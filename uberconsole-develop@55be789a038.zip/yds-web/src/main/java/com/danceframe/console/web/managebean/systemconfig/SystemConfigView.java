/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.managebean.systemconfig;

import com.danceframe.console.common.model.competition.Event;
import com.danceframe.console.common.model.systemconfig.SystemConfig;
import com.danceframe.console.common.util.Utility;
import com.danceframe.console.web.managebean.BaseBean;
import com.danceframe.console.web.service.SystemConfigService;
import com.danceframe.console.web.service.util.HttpClientHelper;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.context.RequestContext;

/**
 *
 * @author nbonita
 */
@ManagedBean(name = "systemConfigView")
@ViewScoped
public class SystemConfigView extends BaseBean implements Serializable {

    public static final String MODULE_NAME = "SYSTEMCONFIG";
    private static final Logger logger = LogManager.getLogger(SystemConfigView.class);
    private static final String URL = "http://localhost:8080/uberSync/SyncSystemConfig";
    
    @ManagedProperty(value = "#{systemConfigService}")
    private SystemConfigService systemConfigService;

    private SystemConfig iosOverrideFlag = null;
    private SystemConfig stripePublishableKey = null;
    private SystemConfig stripeSecretKey = null;
    private SystemConfig sendgridApiKey = null;
    private SystemConfig newUserNotifyListEmail = null;
    private SystemConfig forgotPasswordTokenExpirationTime = null;    
    private List<SystemConfig> emailTemplatesList = null;
    private SystemConfig dynamicLinkEventURI = null;
    private SystemConfig iosSupportEmail = null;
    private SystemConfig androidSupportEmail = null;
    private SystemConfig firebaseWebApiKey = null;
    private SystemConfig minimumVersion = null;
    private SystemConfig errorNotifyList = null;
    private List<SystemConfig> shortLinkConfigsList = null;
    private List<SystemConfig> paymentMethodsList = null;
    
    private static final long serialVersionUID = 1L;    

    @PostConstruct
    public void init() {
        Utility.isNullDebug(getSystemConfigService().getSystemConfigProviderDao(), this.getClass().getName());
        
        //get config items from database
        if(getIosOverrideFlag() == null) {
            setIosOverrideFlag(getSystemConfigService().getSystemConfigProviderDao().get("ao_flag"));
        }
        if(getStripePublishableKey() == null) {
            setStripePublishableKey(getSystemConfigService().getSystemConfigProviderDao().get("stripePK"));
        }
        if(getStripeSecretKey() == null) {
            setStripeSecretKey(getSystemConfigService().getSystemConfigProviderDao().get("stripeSK"));
        }
        if(getSendgridApiKey() == null) {
            setSendgridApiKey(getSystemConfigService().getSystemConfigProviderDao().get("sendgridApiKey"));
        }
        if(getNewUserNotifyListEmail() == null) {
            setNewUserNotifyListEmail(getSystemConfigService().getSystemConfigProviderDao().get("nu_notify_list"));
        }
        if(getForgotPasswordTokenExpirationTime() == null) {
            setForgotPasswordTokenExpirationTime(getSystemConfigService().getSystemConfigProviderDao().get("forgot_password_token_expiration_time"));
        }
        if(getEmailTemplatesList() == null) {
            emailTemplatesList = getSystemConfigService().getSystemConfigProviderDao().getAll("WHERE systemconfig_category='email_template' AND systemconfig_name<>'' AND systemconfig_value<>''");
            System.out.println("emailTemplatesList SIZE: " + emailTemplatesList.size());
        }
        if(getDynamicLinkEventURI() == null) {
            setDynamicLinkEventURI(getSystemConfigService().getSystemConfigProviderDao().get("dynamic_link_event_uri"));
        }
        if(getIosSupportEmail() == null) {
            setIosSupportEmail(getSystemConfigService().getSystemConfigProviderDao().get("ios_support_email"));
        }
        if(getAndroidSupportEmail() == null) {
            setAndroidSupportEmail(getSystemConfigService().getSystemConfigProviderDao().get("android_support_email"));
        }
        if(getFirebaseWebApiKey() == null) {
            setFirebaseWebApiKey(getSystemConfigService().getSystemConfigProviderDao().get("webApiKey"));
        }
        if(getMinimumVersion() == null) {
            setMinimumVersion(getSystemConfigService().getSystemConfigProviderDao().get("minimum_version"));
        }
        if(getErrorNotifyList() == null) {
            setErrorNotifyList(getSystemConfigService().getSystemConfigProviderDao().get("error_notify_list"));
        }
        if(getShortLinkConfigsList() == null) {
            shortLinkConfigsList = getSystemConfigService().getSystemConfigProviderDao().getAll("WHERE systemconfig_category='shortlink_config' AND systemconfig_name<>'' AND systemconfig_value<>''");
            System.out.println("shortLinkConfigsList SIZE: " + shortLinkConfigsList.size());
        }
        if(getPaymentMethodsList() == null) {
            paymentMethodsList = getSystemConfigService().getSystemConfigProviderDao().getAll("WHERE systemconfig_category='payment_method' AND systemconfig_name<>'' AND systemconfig_value<>''");
            System.out.println("paymentMethodsList SIZE: " + paymentMethodsList.size());
        }
    }

    public void addEmailTemplate() {
        SystemConfig dummyConfig = new SystemConfig();
        dummyConfig.setId(0);
        dummyConfig.setType("private");
        dummyConfig.setCategory("email_template");
        getEmailTemplatesList().add(dummyConfig);
        System.out.println("Adding blank email template...");
    }
    
    public void removeEmailTemplate(SystemConfig templateToRemove) {
        context = RequestContext.getCurrentInstance();
        System.out.println("Removing email template: name[" + templateToRemove.getName() + "], id[" + templateToRemove.getId() + "]");
        if(templateToRemove.getId() > 0) {            
            //erase name,value, enabled; marked as deletion when saving/syncing
            templateToRemove.setName("");
            templateToRemove.setValue("");
            templateToRemove.setEnabled("");
            if( (templateToRemove.getPushid() == null) || (templateToRemove.getPushid().isEmpty()) ) {
                SystemConfig objectFromDb = getSystemConfigService().getSystemConfigProviderDao().get(templateToRemove.getId());
                templateToRemove.setPushid(objectFromDb.getPushid());
            }
            int iret = getSystemConfigService().getSystemConfigProviderDao().update(templateToRemove);
        }
        getEmailTemplatesList().remove(templateToRemove);
    }
    
    public void addShortLinkConfig() {
        SystemConfig dummyShortlinkConfig = new SystemConfig();
        dummyShortlinkConfig.setId(0);
        dummyShortlinkConfig.setType("private");
        dummyShortlinkConfig.setCategory("shortlink_config");
        getShortLinkConfigsList().add(dummyShortlinkConfig);
        System.out.println("Adding blank shortlink config...");
    }
    
    public void removeShortLinkConfig(SystemConfig shortlinkConfigToRemove) {
        context = RequestContext.getCurrentInstance();
        System.out.println("Removing shortlink config: name[" + shortlinkConfigToRemove.getName() + "], id[" + shortlinkConfigToRemove.getId() + "]");
        if(shortlinkConfigToRemove.getId() > 0) {            
            //erase name,value, enabled; marked as deletion when saving/syncing
            shortlinkConfigToRemove.setName("");
            shortlinkConfigToRemove.setValue("");
            shortlinkConfigToRemove.setEnabled("");
            if( (shortlinkConfigToRemove.getPushid() == null) || (shortlinkConfigToRemove.getPushid().isEmpty()) ) {
                SystemConfig objectFromDb = getSystemConfigService().getSystemConfigProviderDao().get(shortlinkConfigToRemove.getId());
                shortlinkConfigToRemove.setPushid(objectFromDb.getPushid());
            }
            int iret = getSystemConfigService().getSystemConfigProviderDao().update(shortlinkConfigToRemove);
        }
        getEmailTemplatesList().remove(shortlinkConfigToRemove);
    }
    
    public void addPaymentMethod() {
        SystemConfig dummyPaymentMethod = new SystemConfig();
        dummyPaymentMethod.setId(0);
        dummyPaymentMethod.setType("private");
        dummyPaymentMethod.setCategory("payment_method");
        getPaymentMethodsList().add(dummyPaymentMethod);
        System.out.println("Adding blank payment_method config...");
    }
    
    public void removePaymentMethod(SystemConfig paymentMethodToRemove) {
        context = RequestContext.getCurrentInstance();
        System.out.println("Removing payment_method config: name[" + paymentMethodToRemove.getName() + "], id[" + paymentMethodToRemove.getId() + "]");
        if(paymentMethodToRemove.getId() > 0) {            
            //erase name,value, enabled; marked as deletion when saving/syncing
            paymentMethodToRemove.setName("");
            paymentMethodToRemove.setValue("");
            paymentMethodToRemove.setEnabled("");
            if( (paymentMethodToRemove.getPushid() == null) || (paymentMethodToRemove.getPushid().isEmpty()) ) {
                SystemConfig objectFromDb = getSystemConfigService().getSystemConfigProviderDao().get(paymentMethodToRemove.getId());
                paymentMethodToRemove.setPushid(objectFromDb.getPushid());
            }
            int iret = getSystemConfigService().getSystemConfigProviderDao().update(paymentMethodToRemove);
        }
        getPaymentMethodsList().remove(paymentMethodToRemove);
    }
    
    public void save() {
        context = RequestContext.getCurrentInstance();
        int iret = -1;
        String succesfully_saved_configs = "";
        String failed_saving_configs = "";
        
        //save ao_flag config to database
        iret = getSystemConfigService().getSystemConfigProviderDao().update(getIosOverrideFlag());
        if (iret > 0) {
            succesfully_saved_configs += getIosOverrideFlag().getName() + ", ";
        } else {
            failed_saving_configs += getIosOverrideFlag().getName() + ", ";
        }
        
        //save stripe_publishable_key config to database
        iret = getSystemConfigService().getSystemConfigProviderDao().update(getStripePublishableKey());
        if (iret > 0) {
            succesfully_saved_configs += getStripePublishableKey().getName() + ", ";
        } else {
            failed_saving_configs += getStripePublishableKey().getName() + ", ";
        }
        
        //save stripe_secret_key config to database
        iret = getSystemConfigService().getSystemConfigProviderDao().update(getStripeSecretKey());
        if (iret > 0) {
            succesfully_saved_configs += getStripeSecretKey().getName() + ", ";
        } else {
            failed_saving_configs += getStripeSecretKey().getName() + ", ";
        }
        
        //save sendgridApiKey config to database
        iret = getSystemConfigService().getSystemConfigProviderDao().update(getSendgridApiKey());
        if (iret > 0) {
            succesfully_saved_configs += getSendgridApiKey().getName() + ", ";
        } else {
            failed_saving_configs += getSendgridApiKey().getName() + ", ";
        }       
      
        //save newUserNotifyListEmail config to database
        iret = getSystemConfigService().getSystemConfigProviderDao().update(getNewUserNotifyListEmail());
        if (iret > 0) {
            succesfully_saved_configs += getNewUserNotifyListEmail().getName() + ", ";
        } else {
            failed_saving_configs += getNewUserNotifyListEmail().getName() + ", ";
        }
        
        //save forgotPasswordTokenExpirationTime config to database
        iret = getSystemConfigService().getSystemConfigProviderDao().update(getForgotPasswordTokenExpirationTime());
        if (iret > 0) {
            succesfully_saved_configs += getForgotPasswordTokenExpirationTime().getName() + ", ";
        } else {
            failed_saving_configs += getForgotPasswordTokenExpirationTime().getName() + ", ";
        }

        //save contents of emailTemplatesList
        for(SystemConfig oneEmailTemplate: emailTemplatesList) {
            iret = -1;
            if(oneEmailTemplate.getId() > 0) {                
                iret = getSystemConfigService().getSystemConfigProviderDao().update(oneEmailTemplate);
                if (iret > 0) {
                    succesfully_saved_configs += oneEmailTemplate.getName() + ", ";
                } else {
                    failed_saving_configs += oneEmailTemplate + ", ";
                }
            } else {
                if(oneEmailTemplate.getName().isEmpty()) {
                    logger.info("Ignoring empty template..");
                } else {
                    iret = getSystemConfigService().getSystemConfigProviderDao().insert(oneEmailTemplate);
                    if (iret > 0) {
                        succesfully_saved_configs += oneEmailTemplate.getName() + ", ";
                    } else {
                        failed_saving_configs += oneEmailTemplate + ", ";
                    }
                }
            }            
        }
        
        //reload list 
        emailTemplatesList = getSystemConfigService().getSystemConfigProviderDao().getAll("WHERE systemconfig_category='email_template' AND systemconfig_name<>'' AND systemconfig_value<>''");
        
        //save dynamicLinkEventURI config to database
        iret = getSystemConfigService().getSystemConfigProviderDao().update(getDynamicLinkEventURI());
        if (iret > 0) {
            succesfully_saved_configs += getDynamicLinkEventURI().getName() + ", ";
        } else {
            failed_saving_configs += getDynamicLinkEventURI().getName() + ", ";
        }
        
        //save iosSupportEmail config to database
        iret = getSystemConfigService().getSystemConfigProviderDao().update(getIosSupportEmail());
        if (iret > 0) {
            succesfully_saved_configs += getIosSupportEmail().getName() + ", ";
        } else {
            failed_saving_configs += getIosSupportEmail().getName() + ", ";
        }
        
        //save androidSupportEmail config to database
        iret = getSystemConfigService().getSystemConfigProviderDao().update(getAndroidSupportEmail());
        if (iret > 0) {
            succesfully_saved_configs += getAndroidSupportEmail().getName() + ", ";
        } else {
            failed_saving_configs += getAndroidSupportEmail().getName() + ", ";
        }
        
        //save firebaseWebApiKey config to database
        iret = getSystemConfigService().getSystemConfigProviderDao().update(getFirebaseWebApiKey());
        if (iret > 0) {
            succesfully_saved_configs += getFirebaseWebApiKey().getName() + ", ";
        } else {
            failed_saving_configs += getFirebaseWebApiKey().getName() + ", ";
        }
        
        //save minimum_version config to database
        iret = getSystemConfigService().getSystemConfigProviderDao().update(getMinimumVersion());
        if (iret > 0) {
            succesfully_saved_configs += getMinimumVersion().getName() + ", ";
        } else {
            failed_saving_configs += getMinimumVersion().getName() + ", ";
        }
        
        //save error_notify_list config to database
        iret = getSystemConfigService().getSystemConfigProviderDao().update(getErrorNotifyList());
        if (iret > 0) {
            succesfully_saved_configs += getErrorNotifyList().getName() + ", ";
        } else {
            failed_saving_configs += getErrorNotifyList().getName() + ", ";
        }
        
        //save contents of shortLinkConfigsList
        for(SystemConfig oneShortLinkConfig: shortLinkConfigsList) {
            iret = -1;
            if(oneShortLinkConfig.getId() > 0) {                
                iret = getSystemConfigService().getSystemConfigProviderDao().update(oneShortLinkConfig);
                if (iret > 0) {
                    succesfully_saved_configs += oneShortLinkConfig.getName() + ", ";
                } else {
                    failed_saving_configs += oneShortLinkConfig + ", ";
                }
            } else {
                if(oneShortLinkConfig.getName().isEmpty()) {
                    logger.info("Ignoring empty template..");
                } else {
                    iret = getSystemConfigService().getSystemConfigProviderDao().insert(oneShortLinkConfig);
                    if (iret > 0) {
                        succesfully_saved_configs += oneShortLinkConfig.getName() + ", ";
                    } else {
                        failed_saving_configs += oneShortLinkConfig + ", ";
                    }
                }
            }            
        }
        
        //reload list 
        shortLinkConfigsList = getSystemConfigService().getSystemConfigProviderDao().getAll("WHERE systemconfig_category='shortlink_config' AND systemconfig_name<>'' AND systemconfig_value<>''");
        
        //save contents of emailTemplatesList
        for(SystemConfig onePaymentMethod: paymentMethodsList) {
            iret = -1;
            if(onePaymentMethod.getId() > 0) {                
                iret = getSystemConfigService().getSystemConfigProviderDao().update(onePaymentMethod);
                if (iret > 0) {
                    succesfully_saved_configs += onePaymentMethod.getName() + ", ";
                } else {
                    failed_saving_configs += onePaymentMethod + ", ";
                }
            } else {
                if(onePaymentMethod.getName().isEmpty()) {
                    logger.info("Ignoring empty payment_method..");
                } else {
                    iret = getSystemConfigService().getSystemConfigProviderDao().insert(onePaymentMethod);
                    if (iret > 0) {
                        succesfully_saved_configs += onePaymentMethod.getName() + ", ";
                    } else {
                        failed_saving_configs += onePaymentMethod + ", ";
                    }
                }
            }            
        }
        
        //reload list 
        paymentMethodsList = getSystemConfigService().getSystemConfigProviderDao().getAll("WHERE systemconfig_category='payment_method' AND systemconfig_name<>'' AND systemconfig_value<>''");
        
        //display message
        if(!succesfully_saved_configs.isEmpty()) {
            addMessage("Sucessfully saved system configs: " + succesfully_saved_configs.substring(0, succesfully_saved_configs.length()-2));
        }
        if(!failed_saving_configs.isEmpty()) {
            addMessage("Failed saving system configs: " + failed_saving_configs.substring(0, failed_saving_configs.length()-2));
        }        
        
        //publish all configs to uberSync
        String urlStr = URL + "?config_name=ALL_CONFIG";
        String result = HttpClientHelper.getURL(urlStr);
        logger.info("Pushing config[ALL_CONFIG] to uberSync: " + result);
        System.out.println("Pushing config[ALL_CONFIG] to uberSync: " + result);
        
    }

    /**
     * @return the systemConfigService
     */
    public SystemConfigService getSystemConfigService() {
        return systemConfigService;
    }

    /**
     * @param systemConfigService the systemConfigService to set
     */
    public void setSystemConfigService(SystemConfigService systemConfigService) {
        this.systemConfigService = systemConfigService;
    }

    /**
     * @return the iosOverrideFlag
     */
    public SystemConfig getIosOverrideFlag() {
        if(iosOverrideFlag == null) {
            setIosOverrideFlag(getSystemConfigService().getSystemConfigProviderDao().get("ao_flag"));
        }
        return iosOverrideFlag;
    }

    /**
     * @param iosOverrideFlag the iosOverrideFlag to set
     */
    public void setIosOverrideFlag(SystemConfig iosOverrideFlag) {
        this.iosOverrideFlag = iosOverrideFlag;
    }

    /**
     * @return the stripePublishableKey
     */
    public SystemConfig getStripePublishableKey() {
        return stripePublishableKey;
    }

    /**
     * @param stripePublishableKey the stripePublishableKey to set
     */
    public void setStripePublishableKey(SystemConfig stripePublishableKey) {
        this.stripePublishableKey = stripePublishableKey;
    }

    /**
     * @return the stripeSecretKey
     */
    public SystemConfig getStripeSecretKey() {
        return stripeSecretKey;
    }

    /**
     * @param stripeSecretKey the stripeSecretKey to set
     */
    public void setStripeSecretKey(SystemConfig stripeSecretKey) {
        this.stripeSecretKey = stripeSecretKey;
    }

    /**
     * @return the sendgridApiKey
     */
    public SystemConfig getSendgridApiKey() {
        return sendgridApiKey;
    }

    /**
     * @param sendgridApiKey the sendgridApiKey to set
     */
    public void setSendgridApiKey(SystemConfig sendgridApiKey) {
        this.sendgridApiKey = sendgridApiKey;
    }

    /**
     * @return the newUserNotifyListEmail
     */
    public SystemConfig getNewUserNotifyListEmail() {
        return newUserNotifyListEmail;
    }

    /**
     * @param newUserNotifyListEmail the newUserNotifyListEmail to set
     */
    public void setNewUserNotifyListEmail(SystemConfig newUserNotifyListEmail) {
        this.newUserNotifyListEmail = newUserNotifyListEmail;
    }

    /**
     * @return the emailTemplatesList
     */
    public List<SystemConfig> getEmailTemplatesList() {
        return emailTemplatesList;
    }

    /**
     * @param emailTemplatesList the emailTemplatesList to set
     */
    public void setEmailTemplatesList(List<SystemConfig> emailTemplatesList) {
        this.emailTemplatesList = emailTemplatesList;
    }

    /**
     * @return the forgotPasswordTokenExpirationTime
     */
    public SystemConfig getForgotPasswordTokenExpirationTime() {
        return forgotPasswordTokenExpirationTime;
    }

    /**
     * @param forgotPasswordTokenExpirationTime the forgotPasswordTokenExpirationTime to set
     */
    public void setForgotPasswordTokenExpirationTime(SystemConfig forgotPasswordTokenExpirationTime) {
        this.forgotPasswordTokenExpirationTime = forgotPasswordTokenExpirationTime;
    }

    
    /**
     * @return the dynamicLinkEventURI
     */
    public SystemConfig getDynamicLinkEventURI() {
        return dynamicLinkEventURI;
    }

    /**
     * @param dynamicLinkEventURI the dynamicLinkEventURI to set
     */
    public void setDynamicLinkEventURI(SystemConfig dynamicLinkEventURI) {
        this.dynamicLinkEventURI = dynamicLinkEventURI;
    }

    /**
     * @return the iosSupportEmail
     */
    public SystemConfig getIosSupportEmail() {
        return iosSupportEmail;
    }

    /**
     * @param iosSupportEmail the iosSupportEmail to set
     */
    public void setIosSupportEmail(SystemConfig iosSupportEmail) {
        this.iosSupportEmail = iosSupportEmail;
    }

    /**
     * @return the androidSupportEmail
     */
    public SystemConfig getAndroidSupportEmail() {
        return androidSupportEmail;
    }

    /**
     * @param androidSupportEmail the androidSupportEmail to set
     */
    public void setAndroidSupportEmail(SystemConfig androidSupportEmail) {
        this.androidSupportEmail = androidSupportEmail;
    }

    /**
     * @return the firebaseWebApiKey
     */
    public SystemConfig getFirebaseWebApiKey() {
        return firebaseWebApiKey;
    }

    /**
     * @param firebaseWebApiKey the firebaseWebApiKey to set
     */
    public void setFirebaseWebApiKey(SystemConfig firebaseWebApiKey) {
        this.firebaseWebApiKey = firebaseWebApiKey;
    }

    /**
     * @return the shortLinkConfigsList
     */
    public List<SystemConfig> getShortLinkConfigsList() {
        return shortLinkConfigsList;
    }

    /**
     * @param shortLinkConfigsList the shortLinkConfigsList to set
     */
    public void setShortLinkConfigsList(List<SystemConfig> shortLinkConfigsList) {
        this.shortLinkConfigsList = shortLinkConfigsList;
    }

    /**
     * @return the minimumVersion
     */
    public SystemConfig getMinimumVersion() {
        return minimumVersion;
    }

    /**
     * @param minimumVersion the minimumVersion to set
     */
    public void setMinimumVersion(SystemConfig minimumVersion) {
        this.minimumVersion = minimumVersion;
    }

    /**
     * @return the errorNotifyList
     */
    public SystemConfig getErrorNotifyList() {
        return errorNotifyList;
    }

    /**
     * @param errorNotifyList the errorNotifyList to set
     */
    public void setErrorNotifyList(SystemConfig errorNotifyList) {
        this.errorNotifyList = errorNotifyList;
    }

    /**
     * @return the paymentMethodsList
     */
    public List<SystemConfig> getPaymentMethodsList() {
        return paymentMethodsList;
    }

    /**
     * @param paymentMethodsList the paymentMethodsList to set
     */
    public void setPaymentMethodsList(List<SystemConfig> paymentMethodsList) {
        this.paymentMethodsList = paymentMethodsList;
    }
    
}
