/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.lazy.invoice;

import com.danceframe.console.common.model.payment.Invoice;
import com.danceframe.console.web.service.InvoiceManagementService;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

/**
 *
 * @author nbonita
 */
public class InvoiceLazyList extends LazyDataModel<Invoice> {
    
    private static final Logger logger = LogManager.getLogger(InvoiceLazyList.class);
    
    private InvoiceManagementService invoiceManagementService;
    
    private List<Invoice> invoices;
    private int rowCount;
    private String userPushID;
    
    public InvoiceLazyList(InvoiceManagementService imsc, String uPushID) {
        invoiceManagementService = imsc;
        userPushID = uPushID;
    }

    public List<Invoice> load(int first, int pageSize, String sortField,
                             SortOrder sortOrder, Map<String, Object> filters) {
        // filters can be here
        String wherestr = " WHERE user_push_id = '" + userPushID + "'";
        String wherecnt = wherestr;

        // sorting
        String sortSql = " ORDER BY event_title ASC";
        wherestr += sortSql;
        
        invoices = invoiceManagementService.getInvoiceProviderDao().getAllWithPaging(wherestr, 
                       pageSize, first);
        
        Long rc = (Long)invoiceManagementService.getInvoiceProviderDao().getAllCount(wherecnt);
        
        rowCount = rc.intValue();
        setPageSize(pageSize);
        return invoices;           
       }
    
    
    @Override
    public Object getRowKey(Invoice invoice) {
        return invoice.getId();
    }
    
    @Override
    public Invoice getRowData(String invoiceId) {
        Integer id = Integer.valueOf(invoiceId);
        for (Invoice invoice : invoices) {
            if(id.equals(invoice.getId())){
                return invoice;
            }
        }
        return null;
    }
    /**
     * @return the invoices
     */
    public List<Invoice> getInvoices() {
        return invoices;
    }

    /**
     * @param invoices the invoices to set
     */
    public void setInvoices(List<Invoice> invoices) {
        this.invoices = invoices;
    }

    /**
     * @return the rowCount
     */
    public int getRowCount() {
        return rowCount;
    }

    /**
     * @param rowCount the rowCount to set
     */
    public void setRowCount(int rowCount) {
        this.rowCount = rowCount;
    }

    /**
     * @return the invoiceManagementService
     */
    public InvoiceManagementService getInvoiceManagementService() {
        return invoiceManagementService;
    }

    /**
     * @param invoiceManagementService the invoiceManagementService to set
     */
    public void setInvoiceManagementService(InvoiceManagementService invoiceManagementService) {
        this.invoiceManagementService = invoiceManagementService;
    }
    
}
