/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.lazy.uam;

import com.danceframe.console.common.model.uam.User;
import com.danceframe.console.web.service.UserManagementService;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

/**
 *
 * @author lmorallos
 */
public class UserLazyList extends LazyDataModel<User> {
    
    private static final Logger logger = LogManager.getLogger(UserLazyList.class);
    
    private UserManagementService userManagementService;
    
    private List<User> users;
    private int rowCount;
    
    public UserLazyList(UserManagementService umsc) {
        userManagementService = umsc;
    }

    public List<User> load(int first, int pageSize, String sortField,
                             SortOrder sortOrder, Map<String, Object> filters) {
           // filters can be here
       String wherestr = new String();
       String wherecnt = new String();
        
       if (filters.containsKey("username")) {
           String value = (String)filters.get("username");
           if (value.length() > 0)
           {
               wherestr = wherestr + " AND UPPER(username) like '%" + value.toUpperCase() + "%'";
              
           }
       }
        wherecnt = wherestr;
        // sorting
        String sortSql = new String();
        if (sortField != null) {
            if (sortField.equalsIgnoreCase("username")) {
                sortSql = " ORDER BY username ASC";
            } 
         } else {
            sortSql = " ORDER BY username ASC";
            
        }
        wherestr += sortSql;
        logger.info("Page Query (sortfield):(" + sortField + ") " +  wherestr);
        users = userManagementService.getUserProviderDao().getAllWithPaging(wherestr, 
                       pageSize, first);
//        for (User obj:users) {
//            logger.info("user search:" + obj.toString());
//        }
        Long rc = (Long)userManagementService.getUserProviderDao().getAllCount(wherecnt);
        
        rowCount = rc.intValue();
        setPageSize(pageSize);
        return users;           
       }
    
    
    @Override
    public Object getRowKey(User user) {
        return user.getId();
    }
    
    @Override
    public User getRowData(String userId) {
        Integer id = Integer.valueOf(userId);
        for (User user : users) {
            if(id.equals(user.getId())){
                return user;
            }
        }
        return null;
    }
    /**
     * @return the users
     */
    public List<User> getUsers() {
        return users;
    }

    /**
     * @param users the users to set
     */
    public void setUsers(List<User> users) {
        this.users = users;
    }

    /**
     * @return the rowCount
     */
    public int getRowCount() {
        return rowCount;
    }

    /**
     * @param rowCount the rowCount to set
     */
    public void setRowCount(int rowCount) {
        this.rowCount = rowCount;
    }

    /**
     * @return the userManagementService
     */
    public UserManagementService getUserManagementService() {
        return userManagementService;
    }

    /**
     * @param userManagementService the userManagementService to set
     */
    public void setUserManagementService(UserManagementService userManagementService) {
        this.userManagementService = userManagementService;
    }
    
}
