/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.managebean.uam;

import com.danceframe.console.common.model.uam.User;
import com.danceframe.console.common.util.Utility;
import com.danceframe.console.service.constant.UserAction;
import com.danceframe.console.service.constant.UserActive;
import com.danceframe.console.web.lazy.uam.UserLazyList;
import com.danceframe.console.web.managebean.BaseBean;
import java.io.Serializable;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.context.RequestContext;
import org.primefaces.event.SelectEvent;
import org.primefaces.model.LazyDataModel;

/**
 *
 * @author lmorallos
 */
@ManagedBean (name="userManagementView")
@ViewScoped
public class UserManagementView extends BaseBean implements Serializable {
 
    public static final String MODULE_NAME = "USERMANAGEMENT";
    private static final Logger logger = LogManager.getLogger(UserManagementView.class);

    private static final long serialVersionUID = 1L;
    private LazyDataModel<User> userList = null;
    private User    user = new User();
    private User    selectedUser = new User();
    private boolean unReadOnly;
    
    @PostConstruct
    public void init() {
        Utility.isNullDebug(getUserManagementService().getUserProviderDao(), this.getClass().getName());
        if (userList == null) {
            userList = new UserLazyList(getUserManagementService());
        }
        this.getHeaderUser();
       
    }
    
    public void onRowSelect(SelectEvent event) {
        context = RequestContext.getCurrentInstance();
        User vuser = (User)event.getObject();
        if (vuser.getId()== 9999) {
            addMessage("Admin account not allowed to be edited.");
        } else {
            unReadOnly = true;
            user.setId(vuser.getId());
            user.setUsername(vuser.getUsername());
            user.setFirstname(vuser.getFirstname());
            user.setLastname(vuser.getLastname());
            user.setActive(vuser.isActive());
            context.execute("PF('userInfoDialog').show();");
        }
    }
    
    public void addNew() {
        resetValues();
    }
    
    public void save() {
        context = RequestContext.getCurrentInstance();
        int iret = -1;
        int mode = 0;
        user.setSysuid(this.getUserid());
        if (user.getId() > 0) {
            iret = getUserManagementService().getUserProviderDao().update(user);
            mode = 2;
        } else { // add
            iret = getUserManagementService().getUserProviderDao().insert(user);
            mode = 1;
        }
        if (iret > 0) {
            String action = (mode == 1)?UserAction.INSERT:UserAction.UPDATE ;
            addMessage("Sucessful Saving User Information-" + action);
            resetValues();
            context.execute("PF('userInfoDialog').hide();");
        } else {
            addMessage("Failed Saving User Information.");
        }
    }
    
    public void delete(int id) {
        int iret = -1;
        if (id > 0) {
            if (id == 9999) {
                addMessage("Admin account not allowed to be deleted.");
            } else {
                iret = getUserManagementService().getUserProviderDao().delete(id, this.getUserid());
                if (iret == 100) {
                    addMessage("User Information Deleted with ID." + Integer.toString(id));
                    resetValues();
                } else {
                    addMessage("Failed deleting user information.");
                }  
            }
        }
    }
    
    private void resetValues() {
        user = null;
        user = new User();
        user.setId(0);
        user.setFirstname("");
        user.setLastname("");
        user.setActive(UserActive.INACTIVE);
         unReadOnly = false;
    }
    
    
    /**
     * @return the user
     */
    public User getUser() {
        return user;
    }

    /**
     * @param user the user to set
     */
    public void setUser(User user) {
        this.user = user;
    }

    /**
     * @return the selectedUser
     */
    public User getSelectedUser() {
        return selectedUser;
    }

    /**
     * @param selectedUser the selectedUser to set
     */
    public void setSelectedUser(User selectedUser) {
        this.selectedUser = selectedUser;
    }

    /**
     * @return the userManagementService
     */
 
    
    /**
     * @return the userList
     */
    public LazyDataModel<User> getUserList() {
        if (userList == null) {
            userList = new UserLazyList(getUserManagementService());
        } 
        return userList;
    }

    /**
     * @param userList the userList to set
     */
    public void setUserList(LazyDataModel<User> userList) {
        this.userList = userList;
    }

    /**
     * @return the unReadOnly
     */
    public boolean isUnReadOnly() {
        return unReadOnly;
    }

    /**
     * @param unReadOnly the unReadOnly to set
     */
    public void setUnReadOnly(boolean unReadOnly) {
        this.unReadOnly = unReadOnly;
    }
    
}
