/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.lazy.competition;

import com.danceframe.console.common.model.competition.FormData;
import com.danceframe.console.web.service.CompetitionService;
import java.util.List;
import java.util.Map;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

/**
 *
 * @author lmorallos
 */
public class GenericFormLazyList extends LazyDataModel<FormData> {
    
    private CompetitionService competitionService; 
    
    private List<FormData> formDatas;
    private int rowCount;
    private int eventId;
    private String code;
    
    
    public GenericFormLazyList(CompetitionService csrv, int evId, String cd) {
        competitionService = csrv;
        eventId = evId;
        code = cd;
    }

    public List<FormData> load(int first, int pageSize, String sortField,
                             SortOrder sortOrder, Map<String, Object> filters) {
        
        String wherestr = " WHERE code='" + code + "' AND event_id=" + eventId;
        String wherecnt = wherestr;
       
        String sortSql = " ORDER BY ordervalue ASC";
        wherestr += sortSql;
       
        formDatas = competitionService.getGenericFormProviderDao().getAllWithPaging(wherestr, 
                pageSize, first);
        Long rc = (Long)competitionService.getGenericFormProviderDao().getAllCount(wherecnt);
        
        rowCount = rc.intValue();
        setPageSize(pageSize);
        return formDatas;
    }
    
    @Override
    public Object getRowKey(FormData formdata) {
        return formdata.getId();
    }
    
    @Override
    public FormData getRowData(String frmId) {
        Integer id = Integer.valueOf(frmId);
        for (FormData formdata : formDatas) {
            if(id.equals(formdata.getId())){
                return formdata;
            }
        }
        return null;
    }
    
    /**
     * @return the competitionService
     */
    public CompetitionService getCompetitionService() {
        return competitionService;
    }

    /**
     * @param competitionService the competitionService to set
     */
    public void setCompetitionService(CompetitionService competitionService) {
        this.competitionService = competitionService;
    }

    /**
     * @return the formDatas
     */
    public List<FormData> getFormDatas() {
        return formDatas;
    }

    /**
     * @param formDatas the formDatas to set
     */
    public void setFormDatas(List<FormData> formDatas) {
        this.formDatas = formDatas;
    }

    /**
     * @return the rowCount
     */
    public int getRowCount() {
        return rowCount;
    }

    /**
     * @param rowCount the rowCount to set
     */
    public void setRowCount(int rowCount) {
        this.rowCount = rowCount;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * @param code the code to set
     */
    public void setCode(String code) {
        this.code = code;
    }
            
}
