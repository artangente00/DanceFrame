/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.service;

import com.danceframe.console.service.dataprovider.uam.SyslogProviderDao;
import com.danceframe.console.service.dataprovider.uam.UserProviderDao;
import java.io.Serializable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author lmorallos
 */
@Service("userManagementService")
public class UserManagementService implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @Autowired
    private UserProviderDao userProviderDao;

    @Autowired
    private SyslogProviderDao syslogProviderDao;
    
    /**
     * @return the userProviderDao
     */
    public UserProviderDao getUserProviderDao() {
        return userProviderDao;
    }

    /**
     * @param userProviderDao the userProviderDao to set
     */
    public void setUserProviderDao(UserProviderDao userProviderDao) {
        this.userProviderDao = userProviderDao;
    }

    /**
     * @return the syslogProviderDao
     */
    public SyslogProviderDao getSyslogProviderDao() {
        return syslogProviderDao;
    }

    /**
     * @param syslogProviderDao the syslogProviderDao to set
     */
    public void setSyslogProviderDao(SyslogProviderDao syslogProviderDao) {
        this.syslogProviderDao = syslogProviderDao;
    }
    
    
}
