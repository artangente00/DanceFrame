/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.managebean;

import com.danceframe.console.web.service.util.AppInfo;
import com.danceframe.console.web.service.util.HttpClientHelper;
import java.io.Serializable;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author lmorallos
 */
@ManagedBean (name="footerBean")
@ViewScoped
public class FooterBean implements Serializable {
    
    @ManagedProperty(value="#{appInfo}")
    private AppInfo appInfo;
    
    private static final long serialVersionUID = 1L;
    private String   buildVersion;
    private String   buildDate;
    private String uberSaveVersion;
    private String uberSyncVersion;
    private static final String uberSyncURL = "http://localhost:8080/uberSync";
    
    @PostConstruct
    public void init() {
        buildVersion = appInfo.getBuildVersion();
        buildDate = appInfo.getBuildDate();
        setUberSaveVersion(parseUberSaveVersion());
        setUberSyncVersion(parseUberSyncVersion());
    }

    public String parseUberSyncVersion() {
        String result = "";
        try {
        String versionString = HttpClientHelper.getURL(uberSyncURL);
        if(!versionString.isEmpty()) {
            String[] lowerHalfArray = versionString.split("<i>Version: </i>");
            if(lowerHalfArray.length > 1) {
                String[] upperHalfArray = lowerHalfArray[1].split("<br />");
                if(upperHalfArray.length > 0) {
                    result = upperHalfArray[0].trim();
                }
            }
        }
        
        System.out.println("Retrieved uberSync version string: " + versionString);    
        System.out.println("Retrieved uberSync version: " + result); 
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return result;
    }

    public String parseUberSaveVersion() {
        String result = "";
        String uberSaveURL = "https://ubersave.useradd.com";
        HttpServletRequest origRequest = (HttpServletRequest)FacesContext.getCurrentInstance().getExternalContext().getRequest();
        String appURL = origRequest.getRequestURL().toString();
        System.out.println("URL of this app: " + appURL);
        if(appURL.contains("web9.useradd.com")) {
            uberSaveURL = "https://ubersave.useradd.com/dev";
        }
        String versionString = HttpClientHelper.getURL(uberSaveURL);
        if(!versionString.isEmpty()) {
            String[] lowerHalfArray = versionString.split("<i>Version: </i>");
            if(lowerHalfArray.length > 1) {
                String[] upperHalfArray = lowerHalfArray[1].split("<br />");
                if(upperHalfArray.length > 0) {
                    result = upperHalfArray[0].trim();
                }
            }
        }
        System.out.println("Retrieved uberSave version string: " + versionString);
        System.out.println("Retrieved uberSave version: " + result);
        return result;
    }
    
    /**
     * @return the buildVersion
     */
    public String getBuildVersion() {
        return buildVersion;
    }

    /**
     * @param buildVersion the buildVersion to set
     */
    public void setBuildVersion(String buildVersion) {
        this.buildVersion = buildVersion;
    }

    /**
     * @return the buildDAte
     */
    public String getBuildDate() {
        return buildDate;
    }

    /**
     * @param buildDAte the buildDAte to set
     */
    public void setBuildDAte(String buildDate) {
        this.buildDate = buildDate;
    }

    /**
     * @return the appInfo
     */
    public AppInfo getAppInfo() {
        return appInfo;
    }

    /**
     * @param appInfo the appInfo to set
     */
    public void setAppInfo(AppInfo appInfo) {
        this.appInfo = appInfo;
    }

    /**
     * @return the uberSaveVersion
     */
    public String getUberSaveVersion() {
        return uberSaveVersion;
    }

    /**
     * @param uberSaveVersion the uberSaveVersion to set
     */
    public void setUberSaveVersion(String uberSaveVersion) {
        this.uberSaveVersion = uberSaveVersion;
    }

    /**
     * @return the uberSyncVersion
     */
    public String getUberSyncVersion() {
        return uberSyncVersion;
    }

    /**
     * @param uberSyncVersion the uberSyncVersion to set
     */
    public void setUberSyncVersion(String uberSyncVersion) {
        this.uberSyncVersion = uberSyncVersion;
    }
    
}
