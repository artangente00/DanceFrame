/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.service;

import com.danceframe.console.service.dataprovider.competition.config.AgeProviderDao;
import com.danceframe.console.service.dataprovider.competition.config.DanceProviderDao;
import com.danceframe.console.service.dataprovider.competition.config.EventFormCellAllowProviderDao;
import com.danceframe.console.service.dataprovider.competition.config.EventFormDanceProviderDao;
import com.danceframe.console.service.dataprovider.competition.config.EventFormFieldProviderDao;
import com.danceframe.console.service.dataprovider.competition.config.EventFormHContentProviderDao;
import com.danceframe.console.service.dataprovider.competition.config.EventFormProviderDao;
import com.danceframe.console.service.dataprovider.competition.config.EventFormVerticalProviderDao;
import com.danceframe.console.service.dataprovider.competition.config.EventFormXMLProviderDao;
import com.danceframe.console.service.dataprovider.competition.config.FormProviderDao;
import com.danceframe.console.service.dataprovider.competition.config.LevelProviderDao;
import com.danceframe.console.service.dataprovider.competition.config.StyleProviderDao;
import com.danceframe.console.service.file.form.SetupFileProcessor;
import com.danceframe.console.service.xml.EventFormGenerator;
import java.io.Serializable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author lmorallos
 */
@Service("eventFormConfigService")
public class EventFormConfigService implements Serializable  {
    
    private static final long serialVersionUID = 1L;
    
    @Autowired
    private AgeProviderDao ageProviderDao;
    
    @Autowired
    private DanceProviderDao danceProviderDao;
    
    @Autowired
    private FormProviderDao formProviderDao;
    
    @Autowired
    private LevelProviderDao levelProviderDao;
    
    @Autowired   
    private StyleProviderDao styleProviderDao;
    
    @Autowired
    private EventFormProviderDao eventFormProviderDao;
    
    @Autowired
    private EventFormHContentProviderDao eventFormHContentProviderDao;
    
    @Autowired
    private EventFormDanceProviderDao  eventFormDanceProviderDao;
    
    @Autowired
    private EventFormVerticalProviderDao eventFormVerticalProviderDao;
    
    @Autowired
    private EventFormFieldProviderDao eventFormFieldProviderDao;
    
    @Autowired
    private EventFormCellAllowProviderDao eventFormCellAllowProviderDao;

    @Autowired
    private EventFormXMLProviderDao eventFormXMLProviderDao;
    
    @Autowired
    private EventFormGenerator eventFormGenerator;
    
    @Autowired
    private SetupFileProcessor setupFileProcessor;
    
    /**
     * @return the ageProviderDao
     */
    public AgeProviderDao getAgeProviderDao() {
        return ageProviderDao;
    }

    /**
     * @param ageProviderDao the ageProviderDao to set
     */
    public void setAgeProviderDao(AgeProviderDao ageProviderDao) {
        this.ageProviderDao = ageProviderDao;
    }

    /**
     * @return the danceProviderDao
     */
    public DanceProviderDao getDanceProviderDao() {
        return danceProviderDao;
    }

    /**
     * @param danceProviderDao the danceProviderDao to set
     */
    public void setDanceProviderDao(DanceProviderDao danceProviderDao) {
        this.danceProviderDao = danceProviderDao;
    }

    /**
     * @return the formProviderDao
     */
    public FormProviderDao getFormProviderDao() {
        return formProviderDao;
    }

    /**
     * @param formProviderDao the formProviderDao to set
     */
    public void setFormProviderDao(FormProviderDao formProviderDao) {
        this.formProviderDao = formProviderDao;
    }

    /**
     * @return the levelProviderDao
     */
    public LevelProviderDao getLevelProviderDao() {
        return levelProviderDao;
    }

    /**
     * @param levelProviderDao the levelProviderDao to set
     */
    public void setLevelProviderDao(LevelProviderDao levelProviderDao) {
        this.levelProviderDao = levelProviderDao;
    }

    /**
     * @return the styleProviderDao
     */
    public StyleProviderDao getStyleProviderDao() {
        return styleProviderDao;
    }

    /**
     * @param styleProviderDao the styleProviderDao to set
     */
    public void setStyleProviderDao(StyleProviderDao styleProviderDao) {
        this.styleProviderDao = styleProviderDao;
    }

    /**
     * @return the eventFormProviderDao
     */
    public EventFormProviderDao getEventFormProviderDao() {
        return eventFormProviderDao;
    }

    /**
     * @param eventFormProviderDao the eventFormProviderDao to set
     */
    public void setEventFormProviderDao(EventFormProviderDao eventFormProviderDao) {
        this.eventFormProviderDao = eventFormProviderDao;
    }

    /**
     * @return the eventFormHContentProviderDao
     */
    public EventFormHContentProviderDao getEventFormHContentProviderDao() {
        return eventFormHContentProviderDao;
    }

    /**
     * @param eventFormHContentProviderDao the eventFormHContentProviderDao to set
     */
    public void setEventFormHContentProviderDao(EventFormHContentProviderDao eventFormHContentProviderDao) {
        this.eventFormHContentProviderDao = eventFormHContentProviderDao;
    }

    /**
     * @return the eventFormDanceProviderDao
     */
    public EventFormDanceProviderDao getEventFormDanceProviderDao() {
        return eventFormDanceProviderDao;
    }

    /**
     * @param eventFormDanceProviderDao the eventFormDanceProviderDao to set
     */
    public void setEventFormDanceProviderDao(EventFormDanceProviderDao eventFormDanceProviderDao) {
        this.eventFormDanceProviderDao = eventFormDanceProviderDao;
    }

    /**
     * @return the eventFormVerticalProviderDao
     */
    public EventFormVerticalProviderDao getEventFormVerticalProviderDao() {
        return eventFormVerticalProviderDao;
    }

    /**
     * @param eventFormVerticalProviderDao the eventFormVerticalProviderDao to set
     */
    public void setEventFormVerticalProviderDao(EventFormVerticalProviderDao eventFormVerticalProviderDao) {
        this.eventFormVerticalProviderDao = eventFormVerticalProviderDao;
    }

    /**
     * @return the eventFormFieldProviderDao
     */
    public EventFormFieldProviderDao getEventFormFieldProviderDao() {
        return eventFormFieldProviderDao;
    }

    /**
     * @param eventFormFieldProviderDao the eventFormFieldProviderDao to set
     */
    public void setEventFormFieldProviderDao(EventFormFieldProviderDao eventFormFieldProviderDao) {
        this.eventFormFieldProviderDao = eventFormFieldProviderDao;
    }

    /**
     * @return the eventFormCellAllowProviderDao
     */
    public EventFormCellAllowProviderDao getEventFormCellAllowProviderDao() {
        return eventFormCellAllowProviderDao;
    }

    /**
     * @param eventFormCellAllowProviderDao the eventFormCellAllowProviderDao to set
     */
    public void setEventFormCellAllowProviderDao(EventFormCellAllowProviderDao eventFormCellAllowProviderDao) {
        this.eventFormCellAllowProviderDao = eventFormCellAllowProviderDao;
    }

    /**
     * @return the eventFormXMLProviderDao
     */
    public EventFormXMLProviderDao getEventFormXMLProviderDao() {
        return eventFormXMLProviderDao;
    }

    /**
     * @param eventFormXMLProviderDao the eventFormXMLProviderDao to set
     */
    public void setEventFormXMLProviderDao(EventFormXMLProviderDao eventFormXMLProviderDao) {
        this.eventFormXMLProviderDao = eventFormXMLProviderDao;
    }

    /**
     * @return the eventFormGenerator
     */
    public EventFormGenerator getEventFormGenerator() {
        return eventFormGenerator;
    }

    /**
     * @param eventFormGenerator the eventFormGenerator to set
     */
    public void setEventFormGenerator(EventFormGenerator eventFormGenerator) {
        this.eventFormGenerator = eventFormGenerator;
    }

    /**
     * @return the setupFileProcessor
     */
    public SetupFileProcessor getSetupFileProcessor() {
        return setupFileProcessor;
    }

    /**
     * @param setupFileProcessor the setupFileProcessor to set
     */
    public void setSetupFileProcessor(SetupFileProcessor setupFileProcessor) {
        this.setupFileProcessor = setupFileProcessor;
    }

    
}
