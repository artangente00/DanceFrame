/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.managebean.competition;

import com.danceframe.console.common.exception.YDSException;
import com.danceframe.console.common.model.competition.Event;
import com.danceframe.console.common.model.heatlist.result.HeatResultProgram;
import com.danceframe.console.common.model.heatlist.result.HeatlistResultXML;
import com.danceframe.console.common.util.Utility;
import com.danceframe.console.web.lazy.competition.HeatResultLazyList;
import com.danceframe.console.web.managebean.BaseBean;
import com.danceframe.console.web.service.CompetitionService;
import com.danceframe.console.web.service.HeatListResultService;
import com.danceframe.console.web.service.util.HttpClientHelper;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.context.RequestContext;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.StreamedContent;
import org.primefaces.model.UploadedFile;

/**
 *
 * @author lmorallos
 */
@ManagedBean (name="heatResultView")
@ViewScoped
public class HeatResultProcessor extends BaseBean implements Serializable{
    
    private static final long serialVersionUID = 1L;
    private static final String MARKER = "DATA_FILE";
    private static final String ROOTSTR = "<root>";
    
    private static final Logger logger = LogManager.getLogger(HeatResultProcessor.class);

    private LazyDataModel<Event>    eventList = null;
    private Event                   selectedEvent;
    private HeatlistResultXML       heatlistResultXML;
    private int                     eventId;
    private StreamedContent         xmlDownload;
    private HeatlistResultXML       resultXML;
    private HeatlistResultXML       heatlistResultHTM;
    private HeatlistResultXML       heatlistResultDAT;
    private HeatlistResultXML       heatlistResultHTL;
    private HeatlistResultXML       heatlistResultSCR;    
    private int                     mode;
    private boolean                 dispError;
    private String                  tmpLocation;
    private boolean                 errorRendered;
    private boolean                 errorLinkEnable;
    private boolean                 disableSaveButton;
    private boolean                 disableInput;
    private String                  URLstring;
    private String                  errMessage;
    private String                  strColor;
    private String                  icon;
    
    
    
    @ManagedProperty(value="#{heatListResultService}")
    private HeatListResultService   heatListResultService;
    
    @ManagedProperty(value="#{competitionService}")
    private CompetitionService      competitionService; 
    
    @PostConstruct
    public void init() {
        if (eventList == null) {
            eventList = new HeatResultLazyList(competitionService);
        }
        heatlistResultXML = null;
        heatlistResultHTM = null;
        heatlistResultDAT = null;
        heatlistResultHTL = null;
        heatlistResultSCR = null;
        resultXML = null;
        xmlDownload = null;
        tmpLocation = System.getProperty("java.io.tmpdir") + File.separator;
        errorRendered = false;
        errorLinkEnable = false;
        URLstring = null;
        disableSaveButton = false;
        disableInput = false;
        errMessage = "Error Found. Click this link to view.";
        strColor = "red";
        icon = "fa-warning";
    }
    
     public void uploadXMLHeatResult(FileUploadEvent e) throws IOException{
        UploadedFile uploadHeatList=e.getFile();
        byte[] bytes=null;

        if (null!=uploadHeatList) {
            heatlistResultXML = new HeatlistResultXML();
            String heatResultfile = uploadHeatList.getFileName();
            bytes = uploadHeatList.getContents();
            addMessage("Uploaded file:" + heatResultfile + " with event id:" + getEventId());
            logger.info("Uploaded HeatList Result file:" + heatResultfile + " eventid:" + eventId);
            heatlistResultXML.setFilename(heatResultfile);
            heatlistResultXML.setUploadtime(new Date(System.currentTimeMillis()));
            heatlistResultXML.setCode("XMLHRI");
            heatlistResultXML.setEventId(eventId);
            heatlistResultXML.setData(bytes);
        }
        
    }
     
    public void uploadHTMHeatResult(FileUploadEvent e) throws IOException{
        errorRendered = false;
        UploadedFile uploadHeatList=e.getFile();
        byte[] bytes=null;

        if (null!=uploadHeatList) {
            heatlistResultHTM = new HeatlistResultXML();
            String heatResultfile = uploadHeatList.getFileName();
            bytes = uploadHeatList.getContents();
            addMessage("Uploaded CompMgr HTM file:" + heatResultfile + " with event id:" + getEventId());
            logger.info("Uploaded HTM HeatList Result file:" + heatResultfile + " eventid:" + eventId);
            heatlistResultHTM.setFilename(heatResultfile);
            heatlistResultHTM.setUploadtime(new Date(System.currentTimeMillis()));
            heatlistResultHTM.setCode("HTMHRI");
            heatlistResultHTM.setEventId(eventId);
            heatlistResultHTM.setData(bytes);
        }
        
    }
    
    public void uploadDATHeatResult(FileUploadEvent e) throws IOException{
        errorRendered = false;
        UploadedFile uploadHeatList=e.getFile();
        byte[] bytes=null;

        if (null!=uploadHeatList) {
            heatlistResultDAT = new HeatlistResultXML();
            String heatResultfile = uploadHeatList.getFileName();
            bytes = uploadHeatList.getContents();
            addMessage("Uploaded CompMgr file:" + heatResultfile + " with event id:" + getEventId());
            logger.info("Uploaded DAT HeatList Result file:" + heatResultfile + " eventid:" + eventId);
            heatlistResultDAT.setFilename(heatResultfile);
            heatlistResultDAT.setUploadtime(new Date(System.currentTimeMillis()));
            heatlistResultDAT.setCode("DATHRI");
            heatlistResultDAT.setEventId(eventId);
            heatlistResultDAT.setData(bytes);
        }
        
    }
    
     public void uploadHTLHeatResult(FileUploadEvent e) throws IOException{
        errorRendered = false;
        UploadedFile uploadHeatList=e.getFile();
        byte[] bytes=null;

        if (null!=uploadHeatList) {
            heatlistResultHTL = new HeatlistResultXML();
            String heatResultfile = uploadHeatList.getFileName();
            bytes = uploadHeatList.getContents();
            addMessage("Uploaded CompMgr Heatlist HTL file:" + heatResultfile + " with event id:" + getEventId());
            logger.info("Uploaded HTL HeatList Result file:" + heatResultfile + " eventid:" + eventId);
            heatlistResultHTL.setFilename(heatResultfile);
            heatlistResultHTL.setUploadtime(new Date(System.currentTimeMillis()));
            heatlistResultHTL.setCode("HTLHRI");
            heatlistResultHTL.setEventId(eventId);
            heatlistResultHTL.setData(bytes);
        }
        
    }
    
    public void uploadSCRHeatResult(FileUploadEvent e) throws IOException{
        errorRendered = false;
        UploadedFile uploadHeatList=e.getFile();
        byte[] bytes=null;

        if (null!=uploadHeatList) {
            heatlistResultSCR = new HeatlistResultXML();
            String heatResultfile = uploadHeatList.getFileName();
            bytes = uploadHeatList.getContents();
            addMessage("Uploaded CompMgr ScoreSheet file:" + heatResultfile + " with event id:" + getEventId());
            logger.info("Uploaded SCR HeatList Result file:" + heatResultfile + " eventid:" + eventId);
            heatlistResultSCR.setFilename(heatResultfile);
            heatlistResultSCR.setUploadtime(new Date(System.currentTimeMillis()));
            heatlistResultSCR.setCode("SCRHRI");
            heatlistResultSCR.setEventId(eventId);
            heatlistResultSCR.setData(bytes);
        }
        
    }
    
    public void saveXML() {
        errorRendered = false;
        disableSaveButton = false;
        disableInput = false;
        errorLinkEnable = false;
        if (eventId == 0) {
            addMessage("Missing Event ID, refresh page.", FacesMessage.SEVERITY_ERROR);
        } {
            if (mode == 1) {
                rawUpload();
            }
            if (mode == 2) {
                xmlUpload();
            }
            if (mode == 3) {
                if (Utility.isValidURL(URLstring)) {
                    processURL();
                } else {
                     addMessage("Invalid URL", FacesMessage.SEVERITY_ERROR);
                }
            }
            if (mode == 5) {
                scrUpload();
            }
        }
    }
    
    private void processURL() {
        boolean retboolHTM = false;
        boolean retboolDAT = false;
        logger.info("Saving Mode:" + mode);
        if (URLstring.length() > 0) {
            try {
                URI uri = new URI(URLstring);
                String host = uri.getHost();
                String proto = uri.toURL().getProtocol();
                String domainURL = proto + "://" + host;
                logger.info("URL Domain:" + domainURL);
                
                String htmFilename = Utility.getFilenameFromURL(URLstring).toLowerCase() + ".htm";
                String directory = tmpLocation;
                logger.info("URL target htmlFile:" + htmFilename + " temp dir:" + directory );
                retboolHTM = HttpClientHelper.saveURLContentToFile(URLstring, directory, htmFilename);
                String strDataLine = null;
                if (retboolHTM) {
                    addMessage("HTML File Successfully Created.", FacesMessage.SEVERITY_INFO); 
                    logger.info("HTML File Created:" + htmFilename);
                    String fullPath = directory + "/" + htmFilename;
                    try {
                        if (Utility.isFileExist(fullPath)) { 
                            BufferedReader reader = new BufferedReader(new FileReader(fullPath));
                            String line = reader.readLine();
                            while (line != null) {
                                    line = reader.readLine();
                                    if (line.contains(MARKER)) {
                                        strDataLine = line;
                                        break;
                                    }
                            }
                            reader.close();
                        }
                    } catch (IOException io) {
                        addMessage("Error Scanning MARKER.", FacesMessage.SEVERITY_ERROR); 
                    }
                } else {
                    addMessage("Error Creating HTML File.", FacesMessage.SEVERITY_ERROR); 
                }
                String datFilename = null;
                if (strDataLine != null) {
                    logger.info("Marker:" + strDataLine);
                    datFilename = Utility.getFilenameFromURL(strDataLine).toLowerCase() + ".dat";
                    int ldx = strDataLine.lastIndexOf(ROOTSTR);

                    String tmpstr = strDataLine.substring(ldx,strDataLine.length());
                    tmpstr = tmpstr.replace("\">", "");
                    tmpstr = tmpstr.replace(ROOTSTR, "");
                    String datURL = domainURL + tmpstr;
                    logger.info("DAT URL:" + datURL + " DAT Filename:" + datFilename );
                    retboolDAT = HttpClientHelper.saveURLContentToFile(datURL, directory, datFilename);
                    if (retboolDAT) {
                        logger.info("DAT File Created:" + datFilename);
                        addMessage("DAT File Successfully Created.", FacesMessage.SEVERITY_INFO); 
                    }
                }
                if (retboolHTM  && retboolDAT) {
                    // start saving the files here 
                    boolean htmready = false;
                    try {
                        heatlistResultHTM = new HeatlistResultXML();
                        addMessage("SavingCompMgr URL HTM file:" + htmFilename + " with event id:" + getEventId());
                        logger.info("Uploaded HTM HeatList Result file:" + htmFilename + " eventid:" + eventId);
                        heatlistResultHTM.setFilename(htmFilename);
                        heatlistResultHTM.setUploadtime(new Date(System.currentTimeMillis()));
                        heatlistResultHTM.setCode("HTMHRIURL");
                        heatlistResultHTM.setEventId(eventId);
                        heatlistResultHTM.setData(Utility.readFileToBytes(directory, htmFilename));
                        htmready = true;
                    } catch (IOException io) {
                        logger.error("Error loading HTML File:" + htmFilename);
                    }
                    
                    boolean datready = false;
                    try {
                        heatlistResultDAT = new HeatlistResultXML();
                        addMessage("SavingCompMgr URL DAT file:" + datFilename + " with event id:" + getEventId());
                        logger.info("Uploaded DAT HeatList Result file:" + datFilename + " eventid:" + eventId);
                        heatlistResultDAT.setFilename(datFilename);
                        heatlistResultDAT.setUploadtime(new Date(System.currentTimeMillis()));
                        heatlistResultDAT.setCode("DATHRIURL");
                        heatlistResultDAT.setEventId(eventId);
                        heatlistResultDAT.setData(Utility.readFileToBytes(directory, datFilename));
                        datready = true;
                    } catch (IOException io) {
                        logger.error("Error loading DAT File:" + datFilename);
                    }
                    
                    if (htmready && datready) {
                        String xmlFilename = Utility.getFilename(heatlistResultHTM.getFilename()) + ".xml";
                        boolean retproc = heatListResultService.getHeatListResultXMLReader().createXMLonUberHeatT4(tmpLocation, heatlistResultHTM.getFilename(), 
                            heatlistResultDAT.getFilename(), xmlFilename);
                   
                        logger.info("is HTM:" + htmready + " isDAT:" + datready + " retproc:" + retproc);
                        if (retproc) {
                            String xmFullpath = tmpLocation + xmlFilename;
                            logger.info("XML Fullpath:" + xmFullpath + " retproc:" + retproc);
                            try {
                                if (!Utility.isFileExist(xmFullpath)) {
                                    addMessage("XML File intemporary location", FacesMessage.SEVERITY_ERROR);
                                } else {
                                    heatlistResultXML = new HeatlistResultXML();
                                    Path path = Paths.get(xmFullpath);
                                    byte[] data = Files.readAllBytes(path);
                                    addMessage("XML Created file:" + xmlFilename + " with event id:" + eventId);
                                    logger.info("Uploaded HeatList Result file:" + xmlFilename + " eventid:" + eventId);
                                    heatlistResultXML.setFilename(xmlFilename);
                                    heatlistResultXML.setUploadtime(new Date(System.currentTimeMillis()));
                                    heatlistResultXML.setCode("RAW2XMLHRI");
                                    heatlistResultXML.setEventId(eventId);
                                    heatlistResultXML.setData(data);

                                    context = RequestContext.getCurrentInstance();
                                    int saveret = competitionService.getXmlFileProviderDao().insertXMLFileToDB(heatlistResultXML);
                                    if (saveret > 0) {
                                        addMessage("Processed XML saved to DB");
                                        HeatResultProgram program = null;
                                        try {
                                           heatlistResultXML.setId(saveret);
                                           program = heatListResultService.
                                                getHeatListResultXMLReader().xmlToProgramObject(heatlistResultXML);
                                           addMessage("XML Transformation to Objects Success.");
                                        } catch (YDSException ex) {
                                            addMessage("XML Transformation to Objects Error.", FacesMessage.SEVERITY_ERROR);
                                            logger.warn(ex.getMessage());
                                        }
                                        if (program != null) {
                                            try {
                                                boolean retbool = heatListResultService.
                                                    getHeatListResultXMLReader().objectToDatabase(program);
                                                addMessage("Object saved to Database.");
                                            } catch (YDSException ex) {
                                                addMessage("Saving to Database Error.", FacesMessage.SEVERITY_ERROR);
                                                logger.warn(ex.getMessage());
                                            }
                                        }
                                        heatlistResultXML = null;
                                        setEventId(0);
                                        disableSaveButton = true;
                                        disableInput = true;
                                        errorRendered = true;
                                        errorLinkEnable = true;
                                        errMessage = "Successfully Processed.";
                                        strColor = "green";
                                        icon = "fa-check-circle";
                                        //context.execute("PF('heatlistResultURLDialog').hide();");   
                                    } else {
                                        addMessage("Error saving XML File to DB.", FacesMessage.SEVERITY_ERROR);
                                    }
                                }
                            } catch (IOException ex) {
                                logger.error(ex.getMessage());
                            }
                        } else {
                            addMessage("Error in Building XML File (3).", FacesMessage.SEVERITY_ERROR);
                            errorRendered = true;
                        }   
                    } else {
                         addMessage("Unable to load COMPMGR Files.", FacesMessage.SEVERITY_ERROR); 
                    }                   
                } else {
                    addMessage("COMPMGR Files Creation Error.", FacesMessage.SEVERITY_ERROR); 
                }
            } catch (URISyntaxException | MalformedURLException ex) {
                logger.error(ex.getMessage());
            }
        } else {
            addMessage("Empty URL Input.", FacesMessage.SEVERITY_ERROR);
        }
    }
    
    
    private void rawUpload() {
        logger.info("Saving Mode:" + mode);
        if ((heatlistResultHTM == null) && (heatlistResultDAT == null)) {           
            addMessage("Please Upload HTM and DAT CompMgr Files.", FacesMessage.SEVERITY_ERROR);
        } else if ((heatlistResultHTM == null) || (heatlistResultDAT == null)){
             if (heatlistResultHTM == null) {
              addMessage("Please Upload CompMgr HTM File", FacesMessage.SEVERITY_ERROR);
            } if (heatlistResultDAT == null) {
              addMessage("Please Upload CompMgr DAT File", FacesMessage.SEVERITY_ERROR);
            } 
        } else {
            if ((heatlistResultHTM.getData().length == 0) & (heatlistResultDAT.getData().length == 0)) {
                addMessage("CompMgr HTM and DAT Files are empty.", FacesMessage.SEVERITY_ERROR);
            } else if ((heatlistResultHTM.getData().length == 0) || (heatlistResultDAT.getData().length == 0)) {
                if (heatlistResultHTM.getData().length == 0) {
                    addMessage("CompMgr HTM File is empty.", FacesMessage.SEVERITY_ERROR);
                } if (heatlistResultDAT.getData().length == 0) {
                    addMessage("CompMgr DAT File is empty.", FacesMessage.SEVERITY_ERROR);
                } 
            } else {
                // save the both data first on the tmpLocation
                
                String htmFullpath = tmpLocation + heatlistResultHTM.getFilename();
                String datFullpath = tmpLocation + heatlistResultDAT.getFilename();
                String xmlFilename = Utility.getFilename(heatlistResultHTM.getFilename()) + ".xml";
                
                Utility.deleteFile(tmpLocation, heatlistResultHTM.getFilename());
                Utility.deleteFile(tmpLocation, heatlistResultDAT.getFilename());
                
                logger.info("HTM:" + htmFullpath + " DAT:" + datFullpath + " XML:" + xmlFilename);
                
                boolean isHtmOk = Utility.writeBytesToFile(htmFullpath, heatlistResultHTM.getData());
                boolean isDATOk = Utility.writeBytesToFile(datFullpath, heatlistResultDAT.getData());
                
                if (isHtmOk && isDATOk) {
                   boolean retproc = heatListResultService.getHeatListResultXMLReader().createXMLonUberHeatT4(tmpLocation, heatlistResultHTM.getFilename(), 
                            heatlistResultDAT.getFilename(), xmlFilename);
                   
                   logger.info("is HTM:" + isHtmOk + " isDAT:" + isDATOk + " retproc:" + retproc);
                   if (retproc) {
                        String xmFullpath = tmpLocation + xmlFilename;
                        logger.info("XML Fullpath:" + xmFullpath + " retproc:" + retproc);
                        try {
                            if (!Utility.isFileExist(xmFullpath)) {
                                addMessage("XML File intemporary location", FacesMessage.SEVERITY_ERROR);
                            } else {
                                heatlistResultXML = new HeatlistResultXML();
                                Path path = Paths.get(xmFullpath);
                                byte[] data = Files.readAllBytes(path);
                                addMessage("XML Created file:" + xmlFilename + " with event id:" + eventId);
                                logger.info("Uploaded HeatList Result file:" + xmlFilename + " eventid:" + eventId);
                                heatlistResultXML.setFilename(xmlFilename);
                                heatlistResultXML.setUploadtime(new Date(System.currentTimeMillis()));
                                heatlistResultXML.setCode("RAW2XMLHRI");
                                heatlistResultXML.setEventId(eventId);
                                heatlistResultXML.setData(data);
                                
                                context = RequestContext.getCurrentInstance();
                                int saveret = competitionService.getXmlFileProviderDao().insertXMLFileToDB(heatlistResultXML);
                                if (saveret > 0) {
                                    addMessage("Processed XML saved to DB");
                                    HeatResultProgram program = null;
                                    try {
                                       heatlistResultXML.setId(saveret);
                                       program = heatListResultService.
                                            getHeatListResultXMLReader().xmlToProgramObject(heatlistResultXML);
                                       addMessage("XML Transformation to Objects Success.");
                                    } catch (YDSException ex) {
                                        addMessage("XML Transformation to Objects Error.", FacesMessage.SEVERITY_ERROR);
                                        logger.warn(ex.getMessage());
                                    }
                                    if (program != null) {
                                        try {
                                            boolean retbool = heatListResultService.
                                                getHeatListResultXMLReader().objectToDatabase(program);
                                            addMessage("Object saved to Database.");
                                        } catch (YDSException ex) {
                                            addMessage("Saving to Database Error.", FacesMessage.SEVERITY_ERROR);
                                            logger.warn(ex.getMessage());
                                        }
                                    }
                                    heatlistResultXML = null;
                                    setEventId(0);
                                    disableSaveButton = true;
                                    disableInput = true;
                                    errorRendered = true;
                                    errorLinkEnable = true;
                                    errMessage = "Successfully Processed.";
                                    strColor = "green";
                                    icon = "fa-check-circle";
                                    //context.execute("PF('heatlistResultRawDialog').hide();");   
                                } else {
                                    addMessage("Error saving XML File to DB.", FacesMessage.SEVERITY_ERROR);
                                }
                            }
                        } catch (IOException ex) {
                            logger.error(ex.getMessage());
                        }
                   } else {
                       addMessage("Error in Building XML File (2).", FacesMessage.SEVERITY_ERROR);
                       errorRendered = true;
                   }
                } else {
                    addMessage("Error in Building XML File (1).", FacesMessage.SEVERITY_ERROR);
                    errorRendered = true;
                }
            } 
        }
    }

    
    private void xmlUpload() {
        if (heatlistResultXML != null) {
            context = RequestContext.getCurrentInstance();
            int saveret = competitionService.getXmlFileProviderDao().insertXMLFileToDB(heatlistResultXML);
            if (saveret > 0) {
                addMessage("Uploaded file saved.");
                 // push to database
                HeatResultProgram program = null;
                try {
                    heatlistResultXML.setId(saveret);
                    program = heatListResultService.
                         getHeatListResultXMLReader().xmlToProgramObject(heatlistResultXML);
                    addMessage("XML Transformation to Objects Success.");
                } catch (YDSException ex) {
                     addMessage("XML Transformation to Objects Error.", FacesMessage.SEVERITY_ERROR);
                     logger.warn(ex.getMessage());
                }
                if (program != null) {
                    try {
                        boolean retbool = heatListResultService.
                            getHeatListResultXMLReader().objectToDatabase(program);
                           addMessage("Object saved to Database.");
                    } catch (YDSException ex) {
                        addMessage("Saving to Database Error.", FacesMessage.SEVERITY_ERROR);
                        logger.warn(ex.getMessage());
                    }
                }
                heatlistResultXML = null;
                setEventId(0);
                disableSaveButton = true;
                disableInput = true;              
                errorRendered = true;
                errorLinkEnable = true;
                errMessage = "Successfully Processed.";
                strColor = "green";
                icon = "fa-check-circle";
                //context.execute("PF('heatlistResultXMLDialog').hide();");
            } else {
                addMessage("Uploaded file error.", FacesMessage.SEVERITY_ERROR);
                errorRendered = true;
            }
        } else {
            addMessage("Please upload file to process.", FacesMessage.SEVERITY_WARN);
            errorRendered = true;
        }
    }
    
    private void scrUpload() {
        logger.info("Saving Mode:" + mode);
        if ((heatlistResultHTL == null) && (heatlistResultSCR == null)) {           
            addMessage("Please Upload HTL and SCR CompMgr Files.", FacesMessage.SEVERITY_ERROR);
        } else if ((heatlistResultHTL == null) || (heatlistResultSCR == null)){
             if (heatlistResultHTL == null) {
              addMessage("Please Upload CompMgr (Heatlist) HTL File", FacesMessage.SEVERITY_ERROR);
            } if (heatlistResultSCR == null) {
              addMessage("Please Upload CompMgr (ScoreSheet) SCR File", FacesMessage.SEVERITY_ERROR);
            } 
        } else {
            if ((heatlistResultHTL.getData().length == 0) & (heatlistResultSCR.getData().length == 0)) {
                addMessage("CompMgr HTL and SCR Files are empty.", FacesMessage.SEVERITY_ERROR);
            } else if ((heatlistResultHTL.getData().length == 0) || (heatlistResultSCR.getData().length == 0)) {
                if (heatlistResultHTL.getData().length == 0) {
                    addMessage("CompMgr (Heatlist) HTL File is empty.", FacesMessage.SEVERITY_ERROR);
                } if (heatlistResultSCR.getData().length == 0) {
                    addMessage("CompMgr (ScoreSheet) SCR File is empty.", FacesMessage.SEVERITY_ERROR);
                } 
            } else {
                // save the both data first on the tmpLocation
                
                String htlFullpath = tmpLocation + heatlistResultHTL.getFilename();
                String scrFullpath = tmpLocation + heatlistResultSCR.getFilename();
                String xmlFilename = Utility.getFilename(heatlistResultHTL.getFilename())+ "-result" + ".xml";
                
                Utility.deleteFile(tmpLocation, heatlistResultHTL.getFilename());
                Utility.deleteFile(tmpLocation, heatlistResultSCR.getFilename());
                
                logger.info("HTL:" + htlFullpath + " SCR:" + scrFullpath + " XML:" + xmlFilename);
                
                boolean isHTLOk = Utility.writeBytesToFile(htlFullpath, heatlistResultHTL.getData());
                boolean isSCROk = Utility.writeBytesToFile(scrFullpath, heatlistResultSCR.getData());
                
                if (isHTLOk && isSCROk) {
                   boolean retproc = heatListResultService.getHeatListResultXMLReader().createXMLonUberHeatT5(tmpLocation, heatlistResultHTL.getFilename(), 
                            heatlistResultSCR.getFilename(), xmlFilename);
                   
                   logger.info("isHTL:" + isHTLOk + " isSCR:" + isSCROk + " retproc:" + retproc);
                   if (retproc) {
                        String xmFullpath = tmpLocation + xmlFilename;
                        logger.info("XML Fullpath:" + xmFullpath + " retproc:" + retproc);
                        try {
                            if (!Utility.isFileExist(xmFullpath)) {
                                addMessage("XML File intemporary location", FacesMessage.SEVERITY_ERROR);
                            } else {
                                heatlistResultXML = new HeatlistResultXML();
                                Path path = Paths.get(xmFullpath);
                                byte[] data = Files.readAllBytes(path);
                                addMessage("XML Created file:" + xmlFilename + " with event id:" + eventId);
                                logger.info("Uploaded HeatList Result file:" + xmlFilename + " eventid:" + eventId);
                                heatlistResultXML.setFilename(xmlFilename);
                                heatlistResultXML.setUploadtime(new Date(System.currentTimeMillis()));
                                heatlistResultXML.setCode("RAW2XMLHRI");
                                heatlistResultXML.setEventId(eventId);
                                heatlistResultXML.setData(data);
                                
                                context = RequestContext.getCurrentInstance();
                                int saveret = competitionService.getXmlFileProviderDao().insertXMLFileToDB(heatlistResultXML);
                                if (saveret > 0) {
                                    addMessage("Processed XML saved to DB");
                                    HeatResultProgram program = null;
                                    try {
                                       heatlistResultXML.setId(saveret);
                                       program = heatListResultService.
                                            getHeatListResultXMLReader().xmlToProgramObject(heatlistResultXML);
                                       addMessage("XML Transformation to Objects Success.");
                                    } catch (YDSException ex) {
                                        addMessage("XML Transformation to Objects Error.", FacesMessage.SEVERITY_ERROR);
                                        logger.warn(ex.getMessage());
                                    }
                                    if (program != null) {
                                        try {
                                            boolean retbool = heatListResultService.
                                                getHeatListResultXMLReader().objectToDatabase(program);
                                            addMessage("Object saved to Database.");
                                        } catch (YDSException ex) {
                                            addMessage("Saving to Database Error.", FacesMessage.SEVERITY_ERROR);
                                            logger.warn(ex.getMessage());
                                        }
                                    }
                                    heatlistResultXML = null;
                                    setEventId(0);
                                    disableSaveButton = true;
                                    disableInput = true;
                                    errorRendered = true;
                                    errorLinkEnable = true;
                                    errMessage = "Successfully Processed.";
                                    strColor = "green";
                                    icon = "fa-check-circle";
                                    //context.execute("PF('heatlistResultRawDialog').hide();");   
                                } else {
                                    addMessage("Error saving XML File to DB.", FacesMessage.SEVERITY_ERROR);
                                }
                            }
                        } catch (IOException ex) {
                            logger.error(ex.getMessage());
                        }
                   } else {
                       addMessage("Error in Building XML File (2).", FacesMessage.SEVERITY_ERROR);
                       errorRendered = true;
                   }
                } else {
                    addMessage("Error in Building XML File (1).", FacesMessage.SEVERITY_ERROR);
                    errorRendered = true;
                }
            } 
        }
    }

    
    
     public void uploadURL(int id) {
        errMessage = "Error Found. Click this link to view.";
        strColor = "red";
        icon = "fa-warning";
        errorRendered = false;
        errorLinkEnable = false;
        disableInput = false;
        disableSaveButton = false;
        mode = 3;
        eventId = id;
        logger.info("User selected event id for URL compmgr processing:" + eventId);
        heatlistResultXML = null; 
        heatlistResultHTM = null;
        heatlistResultDAT = null;
        URLstring = new String();
    }
    
    
    public void uploadRawFiles(int id) {
        errMessage = "Error Found. Click this link to view.";
        strColor = "red";
        icon = "fa-warning";
        errorRendered = false;
        errorLinkEnable = false;
        disableInput = false;
        disableSaveButton = false;
        mode = 1;
        eventId = id;
        logger.info("User selected event id for uploading 2 compmgr files:" + eventId);
        heatlistResultXML = null; 
        heatlistResultHTM = null;
        heatlistResultDAT = null;
    }
    
    public void uploadSCR(int id) {
        errMessage = "Error Found. Click this link to view.";
        strColor = "red";
        icon = "fa-warning";
        errorRendered = false;
        errorLinkEnable = false;
        disableInput = false;
        disableSaveButton = false;
        mode = 5;
        eventId = id;
        logger.info("User selected event id for uploading 2 compmgr (scoresheet) files:" + eventId);
        heatlistResultXML = null; 
        heatlistResultHTM = null;
        heatlistResultDAT = null;
    }
      
    public void uploadXML(int id) {
        errMessage = "Error Found.";
        strColor = "red";
        icon = "fa-warning";
        errorRendered = false;
        errorLinkEnable = true;
        disableInput = false;
        disableSaveButton = false;
        mode = 2;
        eventId = id;
        heatlistResultXML = null; 
        heatlistResultHTM = null;
        heatlistResultDAT = null;
        logger.info("User selected event id for upload:" + eventId);
    }
    
    public void close() {
        mode = 0;
        heatlistResultXML = null;
        heatlistResultHTM = null;
        heatlistResultDAT = null;
        eventId = 0;
        errorRendered = false;
        disableSaveButton = false;
    }
    
    public void closeRaw() {
        mode = 0;
        heatlistResultXML = null; 
        heatlistResultHTM = null;
        heatlistResultDAT = null;
        eventId = 0;
        errorRendered = false;
        disableSaveButton = false;
    }
    
    public void closeSCR() {
        mode = 0;
        heatlistResultXML = null; 
        heatlistResultHTL = null;
        heatlistResultSCR = null;
        eventId = 0;
        errorRendered = false;
        disableSaveButton = false;
    }
    
    public void closeURL() {
        mode = 0;
        heatlistResultXML = null; 
        heatlistResultHTM = null;
        heatlistResultDAT = null;
        eventId = 0;
        errorRendered = false;
        disableSaveButton = false;
    }
    
    public void downloadXML(int id) {
        String mimeType = "text/xml";
        resultXML = null;
        try {
            resultXML = heatListResultService.getHeatListResultProviderDao().getHeatResultXML(id);
            if (resultXML != null) {
                logger.info("eventId:" + id + "resultxml-(notnull):" +  resultXML.toString());
                if (resultXML.getData().length > 0) {
                    Event eventData = competitionService.getEventProviderDao().get(id);
                    String oldprogram = "<program>";
                    String newprogram = "<program euid=\"" + eventData.getUid() +  "\" name=\"" + eventData.getName() + "\">";
                    logger.info("Generating HeatResult:" + newprogram);
                    int oproglen = oldprogram.getBytes().length;
                    int nproglen = newprogram.getBytes().length;
                    int datalen = resultXML.getData().length;
                    int newlen = (datalen + nproglen);

                    byte[] newbyte = new byte[newlen+1];
                    byte[] dataByte = resultXML.getData();
                    byte[] newProgByte = newprogram.getBytes();
                    // copy program
                    int cnt = 0;
                    for (int i=0; i < newProgByte.length; i++) {
                        newbyte[cnt] = newProgByte[i];
                        cnt++;
                    }
                    for (int i=9; i < dataByte.length; i++) {
                        newbyte[cnt] = dataByte[i];
                        cnt++;
                    }
                    xmlDownload = new DefaultStreamedContent(
                            new ByteArrayInputStream(newbyte),
                            mimeType,resultXML.getFilename());
                } else {
                    addMessage("Cannot download the xml data.", FacesMessage.SEVERITY_WARN); 
                }
            } else {
                xmlDownload = null;
                addMessage("Cannot find the xml data.", FacesMessage.SEVERITY_WARN); 
            }
        } catch (Exception ex) {
           xmlDownload = null;
           ex.printStackTrace();
           
           addMessage("Error downloading xml data.", FacesMessage.SEVERITY_WARN); 
        }
    }
    
    public void displayHelpPDF() {
        try {
            faces = FacesContext.getCurrentInstance();
            URL url = faces.getExternalContext().getResource("/resources/pdf/help.pdf");
            File file = Paths.get(url.toURI()).toFile();
            System.out.println(file.getAbsolutePath());;
            HttpClientHelper.openFile(file, faces, "application/pdf");
        } catch (URISyntaxException | MalformedURLException ex) {
                logger.error(ex.getMessage());
        }
    }
    
    
    public void displayErrorLog() {
        faces = FacesContext.getCurrentInstance();
        File file = new File(tmpLocation, "HeatresultError.log");
        System.out.println(file.getAbsolutePath());
        HttpClientHelper.openFile(file, faces, "text/plain");
    }
    
    
    /**
     * @return the competitionService
     */
    public CompetitionService getCompetitionService() {
        return competitionService;
    }

    /**
     * @param competitionService the competitionService to set
     */
    public void setCompetitionService(CompetitionService competitionService) {
        this.competitionService = competitionService;
    }

    /**
     * @return the eventList
     */
    public LazyDataModel<Event> getEventList() {
        if (eventList == null) {
            eventList = new HeatResultLazyList(competitionService);
        }
        return eventList;
    }

    /**
     * @param eventList the eventList to set
     */
    public void setEventList(LazyDataModel<Event> eventList) {
        this.eventList = eventList;
    }

    /**
     * @return the selectedEvent
     */
    public Event getSelectedEvent() {
        return selectedEvent;
    }

    /**
     * @param selectedEvent the selectedEvent to set
     */
    public void setSelectedEvent(Event selectedEvent) {
        this.selectedEvent = selectedEvent;
    }

    /**
     * @return the heatlistResultXML
     */
    public HeatlistResultXML getHeatlistResultXML() {
        return heatlistResultXML;
    }

    /**
     * @param heatlistResultXML the heatlistResultXML to set
     */
    public void setHeatlistResultXML(HeatlistResultXML heatlistResultXML) {
        this.heatlistResultXML = heatlistResultXML;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

  
    /**
     * @return the heatListResultService
     */
    public HeatListResultService getHeatListResultService() {
        return heatListResultService;
    }

    /**
     * @param heatListResultService the heatListResultService to set
     */
    public void setHeatListResultService(HeatListResultService heatListResultService) {
        this.heatListResultService = heatListResultService;
    }

    /**
     * @return the xmlDownload
     */
    public StreamedContent getXmlDownload() {
        return xmlDownload;
    }

    /**
     * @param xmlDownload the xmlDownload to set
     */
    public void setXmlDownload(StreamedContent xmlDownload) {
        this.xmlDownload = xmlDownload;
    }

    /**
     * @return the resultXML
     */
    public HeatlistResultXML getResultXML() {
        return resultXML;
    }

    /**
     * @param resultXML the resultXML to set
     */
    public void setResultXML(HeatlistResultXML resultXML) {
        this.resultXML = resultXML;
    }

    /**
     * @return the heatlistResultHTM
     */
    public HeatlistResultXML getHeatlistResultHTM() {
        return heatlistResultHTM;
    }

    /**
     * @param heatlistResultHTM the heatlistResultHTM to set
     */
    public void setHeatlistResultHTM(HeatlistResultXML heatlistResultHTM) {
        this.heatlistResultHTM = heatlistResultHTM;
    }

    /**
     * @return the heatlistResultDAT
     */
    public HeatlistResultXML getHeatlistResultDAT() {
        return heatlistResultDAT;
    }

    /**
     * @param heatlistResultDAT the heatlistResultDAT to set
     */
    public void setHeatlistResultDAT(HeatlistResultXML heatlistResultDAT) {
        this.heatlistResultDAT = heatlistResultDAT;
    }

    /**
     * @return the mode
     */
    public int getMode() {
        return mode;
    }

    /**
     * @param mode the mode to set
     */
    public void setMode(int mode) {
        this.mode = mode;
    }

    /**
     * @return the dispError
     */
    public boolean isDispError() {
        return dispError;
    }

    /**
     * @param dispError the dispError to set
     */
    public void setDispError(boolean dispError) {
        this.dispError = dispError;
    }

    /**
     * @return the tmpLocation
     */
    public String getTmpLocation() {
        return tmpLocation;
    }

    /**
     * @param tmpLocation the tmpLocation to set
     */
    public void setTmpLocation(String tmpLocation) {
        this.tmpLocation = tmpLocation;
    }

    /**
     * @return the errorRendered
     */
    public boolean isErrorRendered() {
        return errorRendered;
    }

    /**
     * @param errorRendered the errorRendered to set
     */
    public void setErrorRendered(boolean errorRendered) {
        this.errorRendered = errorRendered;
    }

    /**
     * @return the URLstring
     */
    public String getURLstring() {
        return URLstring;
    }

    /**
     * @param URLstring the URLstring to set
     */
    public void setURLstring(String URLstring) {
        this.URLstring = URLstring;
    }
 
    /**
     * @return the disableInput
     */
    public boolean isDisableInput() {
        return disableInput;
    }

    /**
     * @param disableInput the disableInput to set
     */
    public void setDisableInput(boolean disableInput) {
        this.disableInput = disableInput;
    }

    /**
     * @return the errMessage
     */
    public String getErrMessage() {
        return errMessage;
    }

    /**
     * @param errMessage the errMessage to set
     */
    public void setErrMessage(String errMessage) {
        this.errMessage = errMessage;
    }

    /**
     * @return the strColor
     */
    public String getStrColor() {
        return strColor;
    }

    /**
     * @param strColor the strColor to set
     */
    public void setStrColor(String strColor) {
        this.strColor = strColor;
    }

    /**
     * @return the icon
     */
    public String getIcon() {
        return icon;
    }

    /**
     * @param icon the icon to set
     */
    public void setIcon(String icon) {
        this.icon = icon;
    }

    /**
     * @return the errorLinkEnable
     */
    public boolean isErrorLinkEnable() {
        return errorLinkEnable;
    }

    /**
     * @param errorLinkEnable the errorLinkEnable to set
     */
    public void setErrorLinkEnable(boolean errorLinkEnable) {
        this.errorLinkEnable = errorLinkEnable;
    }

    /**
     * @return the disableSaveButton
     */
    public boolean isDisableSaveButton() {
        return disableSaveButton;
    }

    /**
     * @param disableSaveButton the disableSaveButton to set
     */
    public void setDisableSaveButton(boolean disableSaveButton) {
        this.disableSaveButton = disableSaveButton;
    }

    /**
     * @return the heatlistResultHTL
     */
    public HeatlistResultXML getHeatlistResultHTL() {
        return heatlistResultHTL;
    }

    /**
     * @param heatlistResultHTL the heatlistResultHTL to set
     */
    public void setHeatlistResultHTL(HeatlistResultXML heatlistResultHTL) {
        this.heatlistResultHTL = heatlistResultHTL;
    }

    /**
     * @return the heatlistResultSCR
     */
    public HeatlistResultXML getHeatlistResultSCR() {
        return heatlistResultSCR;
    }

    /**
     * @param heatlistResultSCR the heatlistResultSCR to set
     */
    public void setHeatlistResultSCR(HeatlistResultXML heatlistResultSCR) {
        this.heatlistResultSCR = heatlistResultSCR;
    }

    
}
