/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.managebean.uam;

import com.danceframe.console.common.model.uam.Syslog;
import com.danceframe.console.web.lazy.uam.SysLogLazyList;
import com.danceframe.console.web.managebean.BaseBean;
import java.io.Serializable;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.model.LazyDataModel;

/**
 *
 * @author lmorallos
 */
@ManagedBean (name="sysLogView")
@ViewScoped
public class SysLogView extends BaseBean implements Serializable {
    
    public static final String MODULE_NAME = "SYSDBLOG";
    private static final Logger logger = LogManager.getLogger(SysLogView.class);
    
    private static final long serialVersionUID = 1L;
 
    private LazyDataModel<Syslog> syslogList = null;
    
    @PostConstruct
    public void init() {
        if (syslogList == null) {
            syslogList = new SysLogLazyList(getUserManagementService());
        }
    }

    /**
     * @return the syslogList
     */
    public LazyDataModel<Syslog> getSyslogList() {
        return syslogList;
    }

    /**
     * @param syslogList the syslogList to set
     */
    public void setSyslogList(LazyDataModel<Syslog> syslogList) {
        this.syslogList = syslogList;
    }
     
}
