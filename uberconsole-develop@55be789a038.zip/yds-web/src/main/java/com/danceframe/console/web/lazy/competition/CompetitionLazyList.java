/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.lazy.competition;

import com.danceframe.console.common.model.competition.Competition;
import com.danceframe.console.web.service.CompetitionService;
import java.util.List;
import java.util.Map;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

/**
 *
 * @author lmorallos
 */
public class CompetitionLazyList extends LazyDataModel<Competition>{
    
    private CompetitionService competitionService; 
    
    private List<Competition> competitions;
    private int rowCount;
    
    
    public CompetitionLazyList(CompetitionService compsvc) {
        competitionService = compsvc;
    }
    
    @Override
    public List<Competition> load(int first, int pageSize, String sortField,
                             SortOrder sortOrder, Map<String, Object> filters) {
       
       // filters can be here
       String wherestr = new String();
       String wherecnt = new String();
        
       if (filters.containsKey("name")) {
           String value = (String)filters.get("name");
           if (value.length() > 0)
           {
               wherestr = " WHERE UPPER(name) like '%" + value.toUpperCase() + "%'";
               wherecnt = wherestr;
           }
       }
       // sorting
       String sortSql = new String();
        if (sortField != null) {
            sortSql = " ORDER BY "+ columnToField(sortField) +" "
                    +(sortOrder.equals(SortOrder.ASCENDING) ?
                        "ASC" :
                        "DESC");
            wherestr += sortSql;
        } else {
            sortSql = " ORDER BY name ASC";
            wherestr += sortSql;
        }
        
        //System.out.println("Page Query:" + wherestr);
        competitions = competitionService.getCompetitionProviderDao().getAllWithPaging(wherestr, 
                       pageSize, first);
              
        Long rc = (Long)competitionService.getCompetitionProviderDao().getAllCount(wherecnt);
        
        rowCount = rc.intValue();
        setPageSize(pageSize);
        
        return competitions;        
    }
    
    private String columnToField(String fieldname) {
        String retfield = new String();
        if (fieldname.equalsIgnoreCase("id")) retfield = "competition_id";
        if (fieldname.equalsIgnoreCase("name")) retfield = "name";
        return retfield;
    }
    

    @Override
    public Object getRowKey(Competition competition) {
        return competition.getId();
    }
    
    @Override
    public Competition getRowData(String compId) {
        Integer id = Integer.valueOf(compId);

        for (Competition competition : competitions) {
            if(id.equals(competition.getId())){
                return competition;
            }
        }

        return null;
    }
    /**
     * @return the competitionService
     */
    public CompetitionService getCompetitionService() {
        return competitionService;
    }

    /**
     * @param competitionService the competitionService to set
     */
    public void setCompetitionService(CompetitionService competitionService) {
        this.competitionService = competitionService;
    }

    /**
     * @return the rowCount
     */
    @Override
    public int getRowCount() {
        return rowCount;
    }

    /**
     * @param rowCount the rowCount to set
     */
    @Override
    public void setRowCount(int rowCount) {
        this.rowCount = rowCount;
    }
    
    
    
}
