/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.managebean.competition;

import com.danceframe.console.common.model.heatlist.result.HeatlistResultXML;
import com.danceframe.console.common.model.heatlist.result.MasterPerson;
import com.danceframe.console.web.lazy.competition.MasterPersonLazyList;
import com.danceframe.console.web.managebean.BaseBean;
import com.danceframe.console.web.service.HeatListResultService;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.context.RequestContext;
import org.primefaces.event.SelectEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.StreamedContent;

/**
 *
 * @author lmorallos
 */
@ManagedBean(name = "masterPersonView")
@ViewScoped
public class MasterPersonView extends BaseBean implements Serializable{
    
    private static final long serialVersionUID = 1L;
    
    private static final Logger logger = LogManager.getLogger(MasterPersonView.class);
    
    @ManagedProperty(value = "#{heatListResultService}")
    private HeatListResultService heatListResultService;
    

    private LazyDataModel<MasterPerson> masterPersons = null;
    private MasterPerson selectedMasterPerson = null;
    private List<MasterPerson> selectedMasterPersons = null;
    private MasterPerson inputMasterPerson = new MasterPerson();
    private String tmpLocation;
    private StreamedContent xmlDownload;
    private HeatlistResultXML resultXML; 
    
    private int destinationId;
    
    @PostConstruct
    public void init() {
        if (masterPersons == null) {
             masterPersons = new MasterPersonLazyList(heatListResultService);
        }
        selectedMasterPerson = new MasterPerson();
        selectedMasterPersons = new ArrayList<>();
        
        tmpLocation = System.getProperty("java.io.tmpdir") + File.separator;
        logger.info("==>>INIT tmp location:" + tmpLocation);
        
    }
    
    public void onRowSelect(SelectEvent event) {
       context = RequestContext.getCurrentInstance();
       selectedMasterPerson = (MasterPerson)event.getObject();
       if (selectedMasterPerson != null) {
           logger.info("selected:" + selectedMasterPerson.toString());
           inputMasterPerson = new MasterPerson();
           inputMasterPerson.setId(selectedMasterPerson.getId());
           inputMasterPerson.setFirstname(selectedMasterPerson.getFirstname());
           inputMasterPerson.setLastname(selectedMasterPerson.getLastname());
           logger.info("input:" + inputMasterPerson.toString());
           context.execute("PF('editMpDialog').show();");
       }
    }
    
    public void save() {
        context = RequestContext.getCurrentInstance();
        if (inputMasterPerson != null) {
            int iret = heatListResultService.getHeatListResultMasterPersonProviderDao().update(inputMasterPerson);
            if (iret > 0) {
                addMessage("Successful Updating Master Person."); 
                context.execute("PF('editMpDialog').hide();");
            } else {
                addMessage("Failed Updaing Master Person." ); 
            }
        }
    }
    
    
    public void unified() {
        context = RequestContext.getCurrentInstance();
        if (selectedMasterPersons.size() > 1) { 
            for (MasterPerson person:selectedMasterPersons) {
                logger.info(person.toString());
            }
            destinationId = 0;
            context.execute("PF('unifiedDialog').show();");
        } else {
            addMessage("Must be at least 2 names to merge" ); 
        }
    }
    
    public void merge() {
        context = RequestContext.getCurrentInstance();
        logger.info("master person id:" + destinationId);
        if (destinationId > 0) {
            int ctr = 0;
            for (MasterPerson person:selectedMasterPersons) {
                if (destinationId != person.getId()) {
                    int iret = heatListResultService.getHeatListResultMasterPersonProviderDao().unifiedMasterPerson(person.getId(), destinationId);
                    ctr++;
                }
            }
            if (ctr > 0) {
                String message = "No of name merged: " + ctr + " to id:" + destinationId;
                addMessage(message);
                context.execute("PF('unifiedDialog').hide();");
            } else {
                addMessage("No data has been merged.");
            }
        }        
    }
    
    public void downloadXML(int id) {
        String mimeType = "text/xml";
        resultXML = null;
        try {
            resultXML = heatListResultService.getHeatListResultXMLWriter().databaseToXML(tmpLocation, id);
            if (resultXML != null) {
                logger.info("eventId:" + id + "resultxml-(notnull):" +  resultXML.toString());
                if (resultXML.getData().length > 0) {
                    xmlDownload = new DefaultStreamedContent(
                            new ByteArrayInputStream(resultXML.getData()),
                            mimeType,resultXML.getFilename());
                } else {
                    addMessage("Cannot download the xml data.", FacesMessage.SEVERITY_WARN); 
                }
            } else {
                xmlDownload = null;
                addMessage("Cannot find the xml data.", FacesMessage.SEVERITY_WARN); 
            }
        } catch (Exception ex) {
           xmlDownload = null;
           ex.printStackTrace();
           
           addMessage("Error downloading xml data.", FacesMessage.SEVERITY_WARN); 
        }
    }
    
    /**
     * @return the heatListResultService
     */
    public HeatListResultService getHeatListResultService() {
        return heatListResultService;
    }

    /**
     * @param heatListResultService the heatListResultService to set
     */
    public void setHeatListResultService(HeatListResultService heatListResultService) {
        this.heatListResultService = heatListResultService;
    }

    /**
     * @return the masterPersons
     */
    public LazyDataModel<MasterPerson> getMasterPersons() {
        return masterPersons;
    }

    /**
     * @param masterPersons the masterPersons to set
     */
    public void setMasterPersons(LazyDataModel<MasterPerson> masterPersons) {
        this.masterPersons = masterPersons;
    }

    /**
     * @return the selectedMasterPerson
     */
    public MasterPerson getSelectedMasterPerson() {
        return selectedMasterPerson;
    }

    /**
     * @param selectedMasterPerson the selectedMasterPerson to set
     */
    public void setSelectedMasterPerson(MasterPerson selectedMasterPerson) {
        this.selectedMasterPerson = selectedMasterPerson;
    }

    /**
     * @return the selectedMasterPersons
     */
    public List<MasterPerson> getSelectedMasterPersons() {
        return selectedMasterPersons;
    }

    /**
     * @param selectedMasterPersons the selectedMasterPersons to set
     */
    public void setSelectedMasterPersons(List<MasterPerson> selectedMasterPersons) {
        this.selectedMasterPersons = selectedMasterPersons;
    }

    /**
     * @return the destinationId
     */
    public int getDestinationId() {
        return destinationId;
    }

    /**
     * @param destinationId the destinationId to set
     */
    public void setDestinationId(int destinationId) {
        this.destinationId = destinationId;
    }

    /**
     * @return the inputMasterPerson
     */
    public MasterPerson getInputMasterPerson() {
        return inputMasterPerson;
    }

    /**
     * @param inputMasterPerson the inputMasterPerson to set
     */
    public void setInputMasterPerson(MasterPerson inputMasterPerson) {
        this.inputMasterPerson = inputMasterPerson;
    }
    
     /**
     * @return the xmlDownload
     */
    public StreamedContent getXmlDownload() {
        return xmlDownload;
    }

    /**
     * @param xmlDownload the xmlDownload to set
     */
    public void setXmlDownload(StreamedContent xmlDownload) {
        this.xmlDownload = xmlDownload;
    }
    
    /**
     * @return the resultXML
     */
    public HeatlistResultXML getResultXML() {
        return resultXML;
    }

    /**
     * @param resultXML the resultXML to set
     */
    public void setResultXML(HeatlistResultXML resultXML) {
        this.resultXML = resultXML;
    }

    /**
     * @return the tmpLocation
     */
    public String getTmpLocation() {
        return tmpLocation;
    }

    /**
     * @param tmpLocation the tmpLocation to set
     */
    public void setTmpLocation(String tmpLocation) {
        this.tmpLocation = tmpLocation;
    }
}
