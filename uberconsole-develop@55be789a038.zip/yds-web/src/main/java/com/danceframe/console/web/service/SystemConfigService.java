/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.service;

import com.danceframe.console.service.dataprovider.systemconfig.SystemConfigProviderDao;
import java.io.Serializable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author nbonita
 */
@Service("systemConfigService")
public class SystemConfigService implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @Autowired
    private SystemConfigProviderDao systemConfigProviderDao;

    
    /**
     * @return the userProviderDao
     */
    public SystemConfigProviderDao getSystemConfigProviderDao() {
        return systemConfigProviderDao;
    }

    /**
     * @param userProviderDao the userProviderDao to set
     */
    public void setSystemConfigProviderDao(SystemConfigProviderDao systemConfigProviderDao) {
        this.systemConfigProviderDao = systemConfigProviderDao;
    }

    
    
}
