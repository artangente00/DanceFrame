/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.managebean.registry;

import com.danceframe.console.common.model.registry.Account;
import com.danceframe.console.service.constant.AccountStatus;
import com.danceframe.console.service.dataprovider.AccountProviderDao;
import com.danceframe.console.web.service.AccountService;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;


/**
 *
 * @author lmorallos
 */
@ManagedBean (name="accountActivateView")
@ViewScoped
public class AccountActivateView implements Serializable {
    
    @ManagedProperty(value="#{accountService}")    
    private AccountService accountService;
    
    private static final long serialVersionUID = 1L;
    private List<Account> deactiveAccountList;
    private Account selectedAccount = new Account();
    private int pageSize = 10;
    private int pageNumber = 1;
    
    @PostConstruct
    public void init() {
         if (accountService.getAccountProviderDao() == null) {
            System.out.println("NULL Account");
        } else {
            System.out.println("NOT NULL Account");
        }
         reloadData();
    }
    
    public void activateAction(String username) {
        if ((username != null) || (username.length() > 0)) {
            addMessage("Activating account :" + username);
            int iret = accountService.getAccountProviderDao().activateAccount(username);
            if (iret == 100) {
                addMessage("Account activated.");
                reloadData();
            } else {
                 addMessage("Failed activating Accont.");
            }
         }
    }
    
     public void  addMessage(String summary) {        
        FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO, summary, null );
        FacesContext.getCurrentInstance().addMessage(null, msg);
    }

     public void loadPage(ActionEvent event) {
         if (event != null) {
            reloadData();
         }
     }
     
     public void reloadData() {
          deactiveAccountList = accountService.getAccountProviderDao().getAllUserWithPaging(pageSize, pageNumber, 
                AccountStatus.DEACTIVE); 
     }    

    /**
     * @return the deactiveAccountList
     */
    public List<Account> getDeactiveAccountList() {
        return deactiveAccountList;
    }

    /**
     * @param deactiveAccountList the deactiveAccountList to set
     */
    public void setDeactiveAccountList(List<Account> deactiveAccountList) {
        this.deactiveAccountList = deactiveAccountList;
    }

    /**
     * @return the selectedAccount
     */
    public Account getSelectedAccount() {
        return selectedAccount;
    }

    /**
     * @param selectedAccount the selectedAccount to set
     */
    public void setSelectedAccount(Account selectedAccount) {
        this.selectedAccount = selectedAccount;
    }

    /**
     * @return the pageSize
     */
    public int getPageSize() {
        return pageSize;
    }

    /**
     * @param pageSize the pageSize to set
     */
    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    /**
     * @return the pageNumber
     */
    public int getPageNumber() {
        return pageNumber;
    }

    /**
     * @param pageNumber the pageNumber to set
     */
    public void setPageNumber(int pageNumber) {
        this.pageNumber = pageNumber;
    }

    /**
     * @return the accountService
     */
    public AccountService getAccountService() {
        return accountService;
    }

    /**
     * @param accountService the accountService to set
     */
    public void setAccountService(AccountService accountService) {
        this.accountService = accountService;
    }
}
