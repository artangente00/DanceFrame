/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.lazy.competition.config;

import com.danceframe.console.common.model.competition.form.EventFormHContent;
import com.danceframe.console.web.service.EventFormConfigService;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

/**
 *
 * @author lmorallos
 */
public class EventFormHContentLazyList extends LazyDataModel<EventFormHContent>{
    
    private static final Logger logger = LogManager.getLogger(EventFormHContentLazyList.class);
    private EventFormConfigService eventFormConfigService;
    
    private List<EventFormHContent> eventhcontents;
    private int rowCount;
    private int eventFormId;
    
    public EventFormHContentLazyList(EventFormConfigService efc, int efId) {
        eventFormConfigService = efc;
        eventFormId = efId;
        
    }
    
    public List<EventFormHContent> load(int first, int pageSize, String sortField,
                             SortOrder sortOrder, Map<String, Object> filters) {
        
       String wherestr = " WHERE eventform_id=" + eventFormId;
       String wherecnt = wherestr;
       
       String sortSql = " ORDER BY hcontent_id  ASC";
       wherestr += sortSql;
        
        eventhcontents = eventFormConfigService.getEventFormHContentProviderDao().getAllWithPaging(wherestr, 
                pageSize, first);
        Long rc = (Long)eventFormConfigService.getEventFormHContentProviderDao().getAllCount(wherecnt);
        
        rowCount = rc.intValue();
        setPageSize(pageSize);
        return eventhcontents; 
    }
    
    @Override
    public Object getRowKey(EventFormHContent eventformhc) {
        return eventformhc.getId();
    }
    
    @Override
    public EventFormHContent getRowData(String hcontentId) {
        Integer id = Integer.valueOf(hcontentId);
        for (EventFormHContent evenhc : eventhcontents) {
            if(id.equals(evenhc.getId())){
                return evenhc;
            }
        }
        return null;
    }

    /**
     * @return the eventhcontents
     */
    public List<EventFormHContent> getEventhcontents() {
        return eventhcontents;
    }

    /**
     * @param eventhcontents the eventhcontents to set
     */
    public void setEventhcontents(List<EventFormHContent> eventhcontents) {
        this.eventhcontents = eventhcontents;
    }

    /**
     * @return the rowCount
     */
    public int getRowCount() {
        return rowCount;
    }

    /**
     * @param rowCount the rowCount to set
     */
    public void setRowCount(int rowCount) {
        this.rowCount = rowCount;
    }

    /**
     * @return the eventFormId
     */
    public int getEventFormId() {
        return eventFormId;
    }

    /**
     * @param eventFormId the eventFormId to set
     */
    public void setEventFormId(int eventFormId) {
        this.eventFormId = eventFormId;
    }
    
    
    
}
