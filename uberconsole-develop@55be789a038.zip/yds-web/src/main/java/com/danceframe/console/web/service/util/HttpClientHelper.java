/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.service.util;

import com.danceframe.console.common.util.Utility;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletResponse;
import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CookieStore;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 *
 * @author lmorallos
 */
public final class HttpClientHelper {

    private static final Logger logger = LogManager.getLogger(HttpClientHelper.class);
    
    public static final String getURL(String url) {
        String strout = new String();
        try {
         
            CloseableHttpClient httpclient = HttpClients.createDefault();
            CookieStore cookieStore = new BasicCookieStore();
            HttpClientContext context = HttpClientContext.create();
            context.setCookieStore(cookieStore);

            HttpGet httpget = new HttpGet(url);  
            logger.info("visiting url:" + url);
            ResponseHandler<String> responseHandler = response -> {
                int status = response.getStatusLine().getStatusCode();
                if (status >= 200 && status < 300) {
                    HttpEntity entity = response.getEntity();
                    return entity != null ? EntityUtils.toString(entity) : null;
                } else {
                    throw new ClientProtocolException("Unexpected response status: " + status);
                }
            };
            
            strout = httpclient.execute(httpget, responseHandler, context);
            logger.info("output from url:" + strout);
        } catch (MalformedURLException ex) {;
            logger.error(ex.getMessage());
        } catch (IOException io) {
            logger.error(io.getMessage());
        }
        return strout;   
    }   

    public static final void openFile(File file, FacesContext facesContext, String mimetype) {
        ExternalContext externalContext = facesContext.getExternalContext();
        HttpServletResponse response = (HttpServletResponse) externalContext.getResponse();
        BufferedInputStream input = null;
        BufferedOutputStream output = null;

        try {
            // Open file.
            input = new BufferedInputStream(new FileInputStream(file), 10240);

            // Init servlet response.
            response.reset();
            // lire un fichier pdf
            // response.setHeader("Content-type", "application/pdf"); 
            response.setHeader("Content-type", mimetype); 
            response.setContentLength((int)file.length());

            response.setHeader("Content-disposition", "inline; filename=" + file.getName());
            response.setHeader("pragma", "public");
            output = new BufferedOutputStream(response.getOutputStream(), 10240);

            // Write file contents to response.
            byte[] buffer = new byte[10240];
            int length;
            while ((length = input.read(buffer)) > 0) {
                output.write(buffer, 0, length);
            }

            // Finalize task.
            output.flush();
            output.close();
           input.close();
        } catch (IOException ex) {
            logger.error(ex.getMessage());
        }        
    }
  
    public static final boolean saveURLContentToFile(String url, String directory, String filename) {
        boolean retbool = false;
        try {
         
            CloseableHttpClient httpclient = HttpClients.createDefault();
            CookieStore cookieStore = new BasicCookieStore();
            HttpClientContext context = HttpClientContext.create();
            context.setCookieStore(cookieStore);

            HttpGet httpget = new HttpGet(url);  
            logger.info("visiting url:" + url);
            ResponseHandler<String> responseHandler = response -> {
                int status = response.getStatusLine().getStatusCode();
                if (status >= 200 && status < 300) {
                    HttpEntity entity = response.getEntity();
                    return entity != null ? EntityUtils.toString(entity) : null;
                } else {
                    throw new ClientProtocolException("Unexpected response status: " + status);
                }
            };
            
            String strout = httpclient.execute(httpget, responseHandler, context);
            if (strout.length() > 0) {
                logger.info("Entity found!");
                String filePath = directory + "/" + filename;
                FileOutputStream fos = new FileOutputStream(new File(filePath));
                fos.write(strout.getBytes());
                fos.close();
                retbool = Utility.isFileExist(filePath);
            } else {
                retbool = false;
            }
        } catch (MalformedURLException ex) {
            logger.error(ex.getMessage());
        } catch (IOException io) {
            logger.error(io.getMessage());
        }
        
        return retbool;
    }
    
    
    
}
