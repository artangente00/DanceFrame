/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.service;


import com.danceframe.console.service.dataprovider.people.PeopleProviderDao;
import java.io.Serializable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author nbonita
 */
@Service("peopleManagementService")
public class PeopleManagementService implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @Autowired
    private PeopleProviderDao peopleProviderDao;

    
    /**
     * @return the peopleProviderDao
     */
    public PeopleProviderDao getPeopleProviderDao() {
        return peopleProviderDao;
    }

    /**
     * @param peopleProviderDao the peopleProviderDao to set
     */
    public void setPeopleProviderDao(PeopleProviderDao peopleProviderDao) {
        this.peopleProviderDao = peopleProviderDao;
    }
    
}
