/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.service;

import com.danceframe.console.service.dataprovider.competition.EventProviderDao;
import com.danceframe.console.service.file.xml.CompManagerXMLWriter;
import java.io.Serializable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author ftangente
 */
@Service("dbctoxmlService")
public class DBCtoXMLService implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
     @Autowired
     private EventProviderDao eventProviderDao;
     
     @Autowired
     private CompManagerXMLWriter compmanagerxmlWriter;
     

    /**
     * @return the compmanagerxmlWriter
     */
    public CompManagerXMLWriter getCompmanagerxmlWriter() {
        return compmanagerxmlWriter;
    }

    /**
     * @param compmanagerxmlWriter the compmanagerxmlWriter to set
     */
    public void setCompmanagerxmlWriter(CompManagerXMLWriter compmanagerxmlWriter) {
        this.compmanagerxmlWriter = compmanagerxmlWriter;
    }
     
     
     /**
     * @return the eventProviderDao
     */
    public EventProviderDao getEventProviderDao() {
        return eventProviderDao;
    }

    /**
     * @param eventProviderDao the eventProviderDao to set
     */
    public void setEventProviderDao(EventProviderDao eventProviderDao) {
        this.eventProviderDao = eventProviderDao;
    }
}
