/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.service;

import com.danceframe.console.service.dataprovider.BasicDao;
import java.io.Serializable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author lmorallos
 */
@Service("utilityService")
public class UtilityService implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
     @Autowired
     private BasicDao basicDao;
    
    /**
     * @return the basicDao
     */
    public BasicDao getBasicDao() {
        return basicDao;
    }

    /**
     * @param basicDao the basicDao to set
     */
    public void setBasicDao(BasicDao basicDao) {
        this.basicDao = basicDao;
    }
}
