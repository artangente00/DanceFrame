/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.lazy.payment;

import com.danceframe.console.common.model.invoice.InvoicePaymentDetail;
import com.danceframe.console.web.service.InvoicePaymentService;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

/**
 *
 * @author lmorallos
 */
public class InvoicePaymentDetailLazyList extends LazyDataModel<InvoicePaymentDetail> {
    
    private static final Logger logger = LogManager.getLogger(InvoicePaymentDetail.class);
    
    private InvoicePaymentService invoicePaymentService;

    private List<InvoicePaymentDetail> invoicePaymentDetails;
    private int rowCount;
    private String invoicePaymentId;
    
    public InvoicePaymentDetailLazyList(InvoicePaymentService invoicePaymentService, String invoicePaymentId) {
        this.invoicePaymentService = invoicePaymentService;
        this.invoicePaymentId = invoicePaymentId;
    }
    
   
    public List<InvoicePaymentDetail> load(int first, int pageSize, String sortField,
                             SortOrder sortOrder, Map<String, Object> filters) {
           // filters can be here
       String wherestr = new String();
       String wherecnt = new String();
        
//       if (filters.containsKey("invoice")) {
//           String value = (String)filters.get("invoice");
//           if (value.length() > 0)
//           {
//               wherestr = wherestr + " WHERE where invpayment_id='" + getInvoicePaymentId() +  "' AND payment_date like '" + value.toUpperCase() + "%'";
//              
//           }
//       }
        wherestr = wherestr + " WHERE invpayment_id='" + invoicePaymentId + "'";
        wherecnt = wherestr;
        // sorting
        String sortSql = new String();
        if (sortField != null) {
            if (sortField.equalsIgnoreCase("paymentDate")) {
                sortSql = " ORDER BY invpayment_id, payment_date ASC";
            } 
         } else {
            sortSql = " ORDER BY invpayment_id, payment_date ASC";
            
        }
        wherestr += sortSql;
        logger.info("Page Query (sortfield):(" + sortField + ") " +  wherestr);
        invoicePaymentDetails = invoicePaymentService.getInvoicePaymentDetailProviderDao().getAllWithPaging(wherestr, 
                       pageSize, first);

        Long rc = (Long)invoicePaymentService.getInvoicePaymentDetailProviderDao().getAllCount(wherecnt);
        
        rowCount = rc.intValue();
        setPageSize(pageSize);
        return invoicePaymentDetails;           
       }
    
     @Override
    public Object getRowKey(InvoicePaymentDetail invpaydet) {
        return invpaydet.getInvoicePaymnetDetailId();
    }
    
    
    @Override
    public InvoicePaymentDetail getRowData(String invpaydetId) {
        Integer id = Integer.valueOf(invpaydetId);
        for (InvoicePaymentDetail invpaydet : invoicePaymentDetails) {
            if(id.equals(invpaydet.getInvoicePaymnetDetailId())){
                return invpaydet;
            }
        }
        return null;
    }

    /**
     * @return the invoicePaymentService
     */
    public InvoicePaymentService getInvoicePaymentService() {
        return invoicePaymentService;
    }

    /**
     * @param invoicePaymentService the invoicePaymentService to set
     */
    public void setInvoicePaymentService(InvoicePaymentService invoicePaymentService) {
        this.invoicePaymentService = invoicePaymentService;
    }

    /**
     * @return the rowCount
     */
    public int getRowCount() {
        return rowCount;
    }

    /**
     * @param rowCount the rowCount to set
     */
    public void setRowCount(int rowCount) {
        this.rowCount = rowCount;
    }

    /**
     * @return the invoicePaymentId
     */
    public String getInvoicePaymentId() {
        return invoicePaymentId;
    }

    /**
     * @param invoicePaymentId the invoicePaymentId to set
     */
    public void setInvoicePaymentId(String invoicePaymentId) {
        this.invoicePaymentId = invoicePaymentId;
    }
    
    
    
    
}
