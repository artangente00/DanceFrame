/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.lazy.competition;

import com.danceframe.console.common.model.competition.Event;
import com.danceframe.console.web.service.CompetitionService;
import java.util.List;
import java.util.Map;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

/**
 *
 * @author lmorallos
 */
public class EventLazyList extends LazyDataModel<Event> {
    
     private static final Logger logger = LogManager.getLogger(EventLazyList.class);
      private CompetitionService    competitionService; 
      
      private List<Event> events;
      private int rowCount;
      
      public EventLazyList(CompetitionService compsvc) {
        competitionService = compsvc;
      }
      
       public List<Event> load(int first, int pageSize, String sortField,
                             SortOrder sortOrder, Map<String, Object> filters) {
           // filters can be here
       String wherestr = new String();
       String wherecnt = new String();
        
       if (filters.containsKey("name")) {
           String value = (String)filters.get("name");
           if (value.length() > 0)
           {
               wherestr = " WHERE UPPER(event_name) like '%" + value.toUpperCase() + "%'";
               wherecnt = wherestr;
           }
       }
        // sorting
        String sortSql = new String();
        if (sortField != null) {
            if (sortField.equalsIgnoreCase("competitionName")) {
                sortSql = " ORDER BY competition_name ASC, date_start DESC";
            }else {
                sortSql = " ORDER BY competition_name ASC," 
                    + columnToField(sortField) + " "
                    +(sortOrder.equals(SortOrder.ASCENDING) ?
                        "ASC" :
                        "DESC");
            } 
            wherestr += sortSql;
         } else {
            sortSql = " ORDER BY competition_name ASC, event_name ASC, date_start DESC";
            wherestr += sortSql;
        }
        
        logger.info("Page Query (sortfield):(" + sortField + ") " +  wherestr);
        events = competitionService.getEventProviderDao().getAllWithPaging(wherestr, 
                       pageSize, first);
        //for (Event obj:events) {
        //    logger.info("events search:" + obj.toString());
        //}
        Long rc = (Long)competitionService.getEventProviderDao().getAllCount(wherecnt);
        
        rowCount = rc.intValue();
        setPageSize(pageSize);
        return events;           
       }
    
    @Override
    public Object getRowKey(Event event) {
        return event.getId();
    }
    
    @Override
    public Event getRowData(String eventId) {
        Integer id = Integer.valueOf(eventId);
        for (Event event : events) {
            if(id.equals(event.getId())){
                return event;
            }
        }
        return null;
    }
    
    private String columnToField(String fieldname) {
        String retfield = new String();
        if (fieldname.equalsIgnoreCase("id")) retfield = "event_id";
        if (fieldname.equalsIgnoreCase("name")) retfield = "event_name";
        if (fieldname.equalsIgnoreCase("dateStart")) retfield = "date_start";
        if (fieldname.equalsIgnoreCase("dateStop")) retfield = "date_stop";
        if (fieldname.equalsIgnoreCase("deadline")) retfield = "deadline";
        if (fieldname.equalsIgnoreCase("eventyear")) retfield = "event_year";
        if (fieldname.equalsIgnoreCase("website")) retfield = "website";
        if (fieldname.equalsIgnoreCase("competitionId")) retfield = "competition_id";
        if (fieldname.equalsIgnoreCase("status")) retfield = "status";
        return retfield;
    }

    /**
     * @return the competitionService
     */
    public CompetitionService getCompetitionService() {
        return competitionService;
    }

    /**
     * @param competitionService the competitionService to set
     */
    public void setCompetitionService(CompetitionService competitionService) {
        this.competitionService = competitionService;
    }

    /**
     * @return the events
     */
    public List<Event> getEvents() {
        return events;
    }

    /**
     * @param events the events to set
     */
    public void setEvents(List<Event> events) {
        this.events = events;
    }

    /**
     * @return the rowCount
     */
      @Override
    public int getRowCount() {
        return rowCount;
    }

    /**
     * @param rowCount the rowCount to set
     */
      @Override
    public void setRowCount(int rowCount) {
        this.rowCount = rowCount;
    }
}
