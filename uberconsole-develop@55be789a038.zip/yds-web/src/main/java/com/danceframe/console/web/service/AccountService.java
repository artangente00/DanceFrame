/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.service;

import com.danceframe.console.service.dataprovider.AccountProviderDao;
import com.danceframe.console.service.dataprovider.AccountTypeProviderDao;
import java.io.Serializable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author lmorallos
 */
@Service("accountService")
public class AccountService implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @Autowired
    private AccountProviderDao accountProviderDao;
    
    @Autowired
    private AccountTypeProviderDao accountTypeProviderDao;

    /**
     * @return the accountProviderDao
     */
    public AccountProviderDao getAccountProviderDao() {
        return accountProviderDao;
    }

    /**
     * @param accountProviderDao the accountProviderDao to set
     */
    public void setAccountProviderDao(AccountProviderDao accountProviderDao) {
        this.accountProviderDao = accountProviderDao;
    }

    /**
     * @return the accountTypeProviderDao
     */
    public AccountTypeProviderDao getAccountTypeProviderDao() {
        return accountTypeProviderDao;
    }

    /**
     * @param accountTypeProviderDao the accountTypeProviderDao to set
     */
    public void setAccountTypeProviderDao(AccountTypeProviderDao accountTypeProviderDao) {
        this.accountTypeProviderDao = accountTypeProviderDao;
    }
}
