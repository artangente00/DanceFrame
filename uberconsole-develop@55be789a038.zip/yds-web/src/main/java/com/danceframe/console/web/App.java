/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web;

import com.danceframe.console.common.util.Utility;
import com.danceframe.console.web.service.util.HttpClientHelper;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CookieStore;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

/**
 *
 * @author lmorallos
 */
public class App {
    
    private static final String MARKER = "DATA_FILE";
    private static final String ROOTSTR = "<root>";
    
     public static void main( String[] args ) throws IOException, URISyntaxException {
         
        String url = "http://www.comp-mngr.com/usdc22fl/USDC22FL_ScoresheetsByPerson.htm";
        
        URI uri = new URI(url);
        String host = uri.getHost();
        System.out.println(host);
        String proto = uri.toURL().getProtocol();
        System.out.println(proto);
        String domainURL = proto + "://" + host;

       
        String htmFilename = Utility.getFilenameFromURL(url).toLowerCase() + ".htm";
        String directory = "C:/tmp";
        System.out.println(htmFilename);
        System.out.println(directory);
        boolean retbool = HttpClientHelper.saveURLContentToFile(url, directory, htmFilename);
        if (retbool) System.out.println("HTML File Created:" + htmFilename);
        
        String strDataLine = null;
        String fullPath = directory + "/" + htmFilename;
        if (Utility.isFileExist(fullPath)) { 
            BufferedReader reader = new BufferedReader(new FileReader(fullPath));
            String line = reader.readLine();
            while (line != null) {
                    line = reader.readLine();
                    if (line.contains(MARKER)) {
                        strDataLine = line;
                        break;
                    }
            }
            reader.close();
        }
        if (strDataLine != null) {
            System.out.println(strDataLine);
            String datFilename = Utility.getFilenameFromURL(strDataLine).toLowerCase() + ".dat";
            int ldx = strDataLine.lastIndexOf(ROOTSTR);
            
            String tmpstr = strDataLine.substring(ldx,strDataLine.length());
            tmpstr = tmpstr.replace("\">", "");
            tmpstr = tmpstr.replace(ROOTSTR, "");
            String datURL = domainURL + tmpstr;
            System.out.println(datURL);
            System.out.println(datFilename);
            
            retbool = HttpClientHelper.saveURLContentToFile(datURL, directory, datFilename);
            if (retbool) System.out.println("DAT File Created:" + datFilename);
            
        }
        
        // if both exist start processing uberheat
        
     }
    
}
