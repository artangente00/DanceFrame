/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.managebean.competition;


import com.danceframe.console.common.model.competition.Competition;
import com.danceframe.console.common.util.Utility;
import com.danceframe.console.service.constant.PageType;
import com.danceframe.console.service.constant.UserAction;
import com.danceframe.console.web.lazy.competition.CompetitionLazyList;
import com.danceframe.console.web.managebean.BaseBean;
import com.danceframe.console.web.service.CompetitionService;
import java.io.Serializable;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import org.primefaces.context.RequestContext;
import org.primefaces.event.SelectEvent;
import org.primefaces.model.LazyDataModel;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;



/**
 *
 * @author lmorallos
 */

@ManagedBean (name="competitionView")
@ViewScoped
public class CompetitionView extends BaseBean implements Serializable {
 
    public static final String MODULE_NAME = "COMPETITION";
    private static final Logger logger = LogManager.getLogger(CompetitionView.class);

    @ManagedProperty(value="#{competitionService}")
    private CompetitionService competitionService;   
    
    
    private static final long serialVersionUID = 1L;
    private Competition competition = new Competition();
    private Competition selectCompetition = new Competition();
    private int pageType;
    private LazyDataModel<Competition> competitionList = null;
    
    @PostConstruct
    public void init() {
        Utility.isNullDebug(competitionService.getCompetitionProviderDao(), this.getClass().getName());
        if (competitionList == null) {
            competitionList = new CompetitionLazyList(competitionService);
        }
        resetValues();
        // this.setModuleName(MODULE_NAME);
        this.getHeaderUser();
    }
    
    public void addNew() {
        competition = null;
        competition = new Competition();
        competition.setId(0);
        competition.setName("");
    }
    
    public void save() {   
        context = RequestContext.getCurrentInstance();
        int iret = -1;
        int id = competition.getId();
        String name = competition.getName().trim();
        int mode = 0;
        if ((name.length() > 0 ) || (!name.isEmpty())) {
            addMessage("Competition Name:" + name);
            if (id > 0) {
                iret = competitionService.getCompetitionProviderDao().update(competition);                
                mode = 2;
            } else {
                iret = competitionService.getCompetitionProviderDao().insert(competition);                
                mode = 1;
            }
            if (iret > 0) {
                String action = (mode == 1)?UserAction.INSERT:UserAction.UPDATE ;
                // insert syslog here
                addMessage("Sucessful Saving Competition:" + action);
                resetValues();
                context.execute("PF('compDialog').hide();");
            } else {
                 addMessage("Failed Saving Competition." );
            }
        }
    }
    
    public void delete(int id) {
        // recheck stored proc not to delete if there are connections     
        int iret = -1;
        if (id > 0) {
            iret = competitionService.getCompetitionProviderDao().delete(id);
             if (iret > 0) {
                addMessage("Competition Deleted with ID." + Integer.toString(id));
                resetValues();
            } else if (iret == -99) {
                addMessage("Failed deleting Competition, currently assigned to active events.");
            } else {
                addMessage("Failed deleting Competition.");
            }             
        }        
    }
    
    public void onRowSelect(SelectEvent event) {
        Competition vcompetition =(Competition) event.getObject();
        addMessage("Selected:" + vcompetition.getName());
        competition.setId(vcompetition.getId());
        competition.setName(vcompetition.getName());
        setPageType(PageType.EDIT);
    }
    
    private void resetValues() {
        competition = null;
        competition = new Competition();
        competition.setId(0);
        competition.setName("");
    }
    
    /**
     * @return the competition
     */
    public Competition getCompetition() {
        return competition;
    }

    /**
     * @param competition the competition to set
     */
    public void setCompetition(Competition competition) {
        this.competition = competition;
    }

       

    /**
     * @return the competitionService
     */
    public CompetitionService getCompetitionService() {
        return competitionService;
    }

    /**
     * @param competitionService the competitionService to set
     */
    public void setCompetitionService(CompetitionService competitionService) {
        this.competitionService = competitionService;
    }

    /**
     * @return the selectCompetition
     */
    public Competition getSelectCompetition() {
        return selectCompetition;
    }

    /**
     * @param selectCompetition the selectCompetition to set
     */
    public void setSelectCompetition(Competition selectCompetition) {
        this.selectCompetition = selectCompetition;
    }

    /**
     * @return the competitionList
     */
    public LazyDataModel<Competition> getCompetitionList() {
       if (competitionList == null) {
            competitionList = new CompetitionLazyList(competitionService);
        }
        return competitionList;
    }

    /**
     * @param competitionList the competitionList to set
     */
    public void setCompetitionList(LazyDataModel<Competition> competitionList) {
        this.competitionList = competitionList;
    }

    /**
     * @return the pageType
     */
    public int getPageType() {
        return pageType;
    }

    /**
     * @param pageType the pageType to set
     */
    public void setPageType(int pageType) {
        this.pageType = pageType;
    }

    
    
}
