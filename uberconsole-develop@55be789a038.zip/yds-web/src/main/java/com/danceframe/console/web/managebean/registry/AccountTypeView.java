/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.managebean.registry;

import com.danceframe.console.common.model.registry.AccountType;
import com.danceframe.console.web.service.AccountService;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import org.primefaces.event.SelectEvent;


/**
 *
 * @author lmorallos
 */
@ManagedBean (name="accountTypeView")
@ViewScoped
public class AccountTypeView  implements Serializable{
    
    @ManagedProperty(value="#{accountService}")    
    private AccountService accountService;
      
    private static final long serialVersionUID = 1L;
    private List<AccountType> accountTypeList;
    private AccountType accountType = new AccountType();
    private AccountType selectedAccType;

    @PostConstruct
    public void init() {
        accountTypeList = accountService.getAccountTypeProviderDao().getAllAccounType();
    }
    
    public void save() {
        int id = accountType.getId();
        String description = accountType.getDescription();
        if ((description != null) || (description.length() > 0)) {
            addMessage("Saving:" + description);
            String mode = new String();
            int iret = 0;
            if (id > 0) {
                iret = accountService.getAccountTypeProviderDao().updateAccountType(id, description);
                mode = "Update";
            } else {
                iret = accountService.getAccountTypeProviderDao().insertAccountType(description);
                 mode = "New";
            }   
            if (iret == 100) {
                addMessage("Sucessful Saving Account Type:" + mode);
                reloadData();
            } else {
                 addMessage("Failed Saving Account Type:" + mode);
            }
        }

    }
    
    public void delete(String description) {
        if ((description != null) || (description.length() > 0)) {
            addMessage("Delete account type:" + description);
            int iret = accountService.getAccountTypeProviderDao().deleteAccountType(description);
            if (iret == 100) {
                addMessage("Deleting Account Type.");
                reloadData();
            } else {
                 addMessage("Failed deleting Account Type.");
            }
         }
    }
    
    public void onRowSelect(SelectEvent event) {
        AccountType vaccountType =(AccountType) event.getObject();
        addMessage("Selected:" + vaccountType.getDescription());
        accountType.setId(vaccountType.getId());
        accountType.setDescription(vaccountType.getDescription());
    }
    

    public void reloadData() {
           accountTypeList = accountService.getAccountTypeProviderDao().getAllAccounType();
       
           accountType.setId(0);
           accountType.setDescription("");
           
    }
    public void  addMessage(String summary) {        
        FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO, summary, null );
        FacesContext.getCurrentInstance().addMessage(null, msg);
    }
    
    /**
     * @return the accountTypeList
     */
    public List<AccountType> getAccountTypeList() {
        return accountTypeList;
    }

    /**
     * @param accountTypeList the accountTypeList to set
     */
    public void setAccountTypeList(List<AccountType> accountTypeList) {
        this.accountTypeList = accountTypeList;
    }

    /**
     * @return the accountType
     */
    public AccountType getAccountType() {
        return accountType;
    }

    /**
     * @param accountType the accountType to set
     */
    public void setAccountType(AccountType accountType) {
        this.accountType = accountType;
    }
    
    /**
     * @return the selectedAccType
     */
    public AccountType getSelectedAccType() {
        return selectedAccType;
    }

    /**
     * @param selectedAccType the selectedAccType to set
     */
    public void setSelectedAccType(AccountType selectedAccType) {
        this.selectedAccType = selectedAccType;
    }

    /**
     * @return the accountService
     */
    public AccountService getAccountService() {
        return accountService;
    }

    /**
     * @param accountService the accountService to set
     */
    public void setAccountService(AccountService accountService) {
        this.accountService = accountService;
    }
    
    
}
