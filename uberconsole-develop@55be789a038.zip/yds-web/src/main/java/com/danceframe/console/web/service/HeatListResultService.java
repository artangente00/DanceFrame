/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.service;

import com.danceframe.console.service.dataprovider.heatlist.HeatListResultMasterJudgeProviderDao;
import com.danceframe.console.service.dataprovider.heatlist.HeatListResultMasterPersonProviderDao;
import com.danceframe.console.service.dataprovider.heatlist.HeatListResultProviderDao;
import com.danceframe.console.service.file.heatlist.HeatListResultWriter;
import com.danceframe.console.service.file.xml.HeatListResultXMLReader;
import com.danceframe.console.service.file.xml.HeatListResultXMLWriter;
import java.io.Serializable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author lmorallos
 */
@Service("heatListResultService")
public class HeatListResultService implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @Autowired
    private HeatListResultWriter heatListResultWriter;
    
    @Autowired
    private HeatListResultProviderDao heatListResultProviderDao;
    
    @Autowired
    private HeatListResultXMLReader heatListResultXMLReader;
    
    @Autowired
    private HeatListResultXMLWriter heatListResultXMLWriter;
    
    @Autowired
    private HeatListResultMasterPersonProviderDao heatListResultMasterPersonProviderDao;

    @Autowired
    private HeatListResultMasterJudgeProviderDao heatListResultMasterJudgeProviderDao;
    /**
     * @return the heatListResultWriter
     */
    public HeatListResultWriter getHeatListResultWriter() {
        return heatListResultWriter;
    }

    /**
     * @param heatListResultWriter the heatListResultWriter to set
     */
    public void setHeatListResultWriter(HeatListResultWriter heatListResultWriter) {
        this.heatListResultWriter = heatListResultWriter;
    }

    /**
     * @return the heatListResultProviderDao
     */
    public HeatListResultProviderDao getHeatListResultProviderDao() {
        return heatListResultProviderDao;
    }

    /**
     * @param heatListResultProviderDao the heatListResultProviderDao to set
     */
    public void setHeatListResultProviderDao(HeatListResultProviderDao heatListResultProviderDao) {
        this.heatListResultProviderDao = heatListResultProviderDao;
    }

    /**
     * @return the heatListResultXMLReader
     */
    public HeatListResultXMLReader getHeatListResultXMLReader() {
        return heatListResultXMLReader;
    }

    /**
     * @param heatListResultXMLReader the heatListResultXMLReader to set
     */
    public void setHeatListResultXMLReader(HeatListResultXMLReader heatListResultXMLReader) {
        this.heatListResultXMLReader = heatListResultXMLReader;
    }

    /**
     * @return the heatListResultMasterPersonProviderDao
     */
    public HeatListResultMasterPersonProviderDao getHeatListResultMasterPersonProviderDao() {
        return heatListResultMasterPersonProviderDao;
    }

    /**
     * @param heatListResultMasterPersonProviderDao the heatListResultMasterPersonProviderDao to set
     */
    public void setHeatListResultMasterPersonProviderDao(HeatListResultMasterPersonProviderDao heatListResultMasterPersonProviderDao) {
        this.heatListResultMasterPersonProviderDao = heatListResultMasterPersonProviderDao;
    }

    /**
     * @return the heatListResultMasterJudgeProviderDao
     */
    public HeatListResultMasterJudgeProviderDao getHeatListResultMasterJudgeProviderDao() {
        return heatListResultMasterJudgeProviderDao;
    }

    /**
     * @param heatListResultMasterJudgeProviderDao the heatListResultMasterJudgeProviderDao to set
     */
    public void setHeatListResultMasterJudgeProviderDao(HeatListResultMasterJudgeProviderDao heatListResultMasterJudgeProviderDao) {
        this.heatListResultMasterJudgeProviderDao = heatListResultMasterJudgeProviderDao;
    }

    /**
     * @return the heatListResultXMLWriter
     */
    public HeatListResultXMLWriter getHeatListResultXMLWriter() {
        return heatListResultXMLWriter;
    }

    /**
     * @param heatListResultXMLWriter the heatListResultXMLWriter to set
     */
    public void setHeatListResultXMLWriter(HeatListResultXMLWriter heatListResultXMLWriter) {
        this.heatListResultXMLWriter = heatListResultXMLWriter;
    }
    
    
}
