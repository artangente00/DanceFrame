/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.managebean.competition;

import com.danceframe.console.common.model.basic.Image;
import com.danceframe.console.common.model.competition.Competition;
import com.danceframe.console.common.model.competition.Contact;
import com.danceframe.console.common.model.competition.Event;
import com.danceframe.console.common.model.basic.LookUp;
import com.danceframe.console.common.model.competition.DisplayDefault;
import com.danceframe.console.common.model.competition.Enablement;
import com.danceframe.console.common.model.competition.EventSummary;
import com.danceframe.console.common.model.competition.Finance;
import com.danceframe.console.common.model.competition.FormData;
import com.danceframe.console.common.model.competition.Organizer;
import com.danceframe.console.common.model.competition.Schedule;
import com.danceframe.console.common.model.competition.ScheduleData;
import com.danceframe.console.common.model.competition.Venue;
import com.danceframe.console.common.model.systemconfig.SystemConfig;
import com.danceframe.console.common.util.ImageDimension;
import com.danceframe.console.common.util.Utility;
import static com.danceframe.console.common.util.Utility.computeImageScaledValue;
import com.danceframe.console.service.constant.EventStatus;
import com.danceframe.console.service.constant.GenericFormType;
import com.danceframe.console.service.constant.PageType;
import com.danceframe.console.service.constant.PublishStatus;
import com.danceframe.console.web.lazy.competition.CompetitionLazyList;
import com.danceframe.console.web.lazy.competition.EventComparisonLazyList;
import com.danceframe.console.web.lazy.competition.EventLazyList;
import com.danceframe.console.web.lazy.competition.GenericFormLazyList;
import com.danceframe.console.web.lazy.competition.ScheduleDataLazyList;
import com.danceframe.console.web.managebean.BaseBean;
import com.danceframe.console.web.service.CompetitionService;
import com.danceframe.console.web.service.SystemConfigService;
import com.danceframe.console.web.service.util.HttpClientHelper;
import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.imageio.ImageIO;
import javax.net.ssl.HttpsURLConnection;
import org.primefaces.context.RequestContext;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.event.SelectEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.StreamedContent;
import org.primefaces.model.UploadedFile;
import org.springframework.dao.EmptyResultDataAccessException;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author lmorallos
 */
@ManagedBean(name = "eventProcessView")
@ViewScoped
public class EventProcessView extends BaseBean implements Serializable {

    private static final String MODULE_NAME = "EVENT";
    private static final Logger logger = LogManager.getLogger(EventProcessView.class);
    private static final String SCHEDNAME = "Tentative Schedule";
    private static final int IMAGE_WIDTH = 500;
    private static final int IMAGE_HEIGHT = 250;
    private static final String GET_EVENTS_URL = "http://localhost:8080/uberSync/GetEvents";

    @ManagedProperty(value = "#{competitionService}")
    private CompetitionService competitionService;

    @ManagedProperty(value = "#{systemConfigService}")
    private SystemConfigService systemConfigService;

    private static final long serialVersionUID = 1L;
    private LazyDataModel<Competition> competitionList = null;
    private LazyDataModel<Event> eventList = null;
    private LazyDataModel<ScheduleData> schedDataList = null;
    private LazyDataModel<FormData> hotelDataList = null;
    private LazyDataModel<FormData> sponsorDataList = null;
    private LazyDataModel<FormData> infoDataList = null;

    private List<LookUp> eventStatusList;
	private List<LookUp> venueCountryList;
    private Competition competition = new Competition();
    private Event event = new Event();
    private Venue venue = new Venue();
    private Organizer organizer = new Organizer();
    private Contact contact = new Contact();
    private Organizer[] organizers = new Organizer[6];
    private Schedule schedule = new Schedule();
    private ScheduleData scheduleData = new ScheduleData();
    private Enablement enablement = new Enablement();
    private DisplayDefault dispDefault = new DisplayDefault();
    
    private Competition selectCompetition = new Competition();
    private Event selectEvent = new Event();
    private int pageType;
    private boolean disable;
    private int selectTab;
    private String tmpLocation;
    private StreamedContent eventImageFile;
    private List<LookUp> noyesLIst;
    private List<LookUp> publishStatusList;
    private boolean isImageUpload;
    private Image eventImage;
    private boolean published;
    private boolean republished;
    private boolean repubrendered;
    private String publishedStatus;
    private boolean checkBoxDisabled;
    private boolean checkBoxRePubDisabled;
    private int curpubstatus;
    private int newpubstatus;
    private String eventImgFilename;
    private InputStream instream;
    private String uploadImgFilename;
    private String uploadMimeType;
    private ImageDimension imageDimension;
    private boolean renderLastUpdate;
    private String imgStyle;
    private String uberRegister;
    private boolean disableURegister;
    private boolean renderLastPublish;

    private int tmpEventId;
    private ScheduleData selectedScheduleData;
    private boolean updateSchedData;
    private Map<String, String> schedDataHeaderNames;

    private FormData hotelData;
    private FormData sponsorData;
    private FormData infoData;
    private FormData selectedHotelData;
    private FormData selectedSponsorData;
    private FormData selectedInfoData;
    private boolean updateHotel;
    private boolean updateSponsor;
    private boolean updateInfo;
    private boolean uploadHotel;
    private boolean uploadSponsor;
    private boolean uploadInfo;
    private List<String> genUploadFiles;

    private Finance finance;
    private EventSummary eventSummary;

    private boolean editScheduleHeaderEnabled = false;
    private String editScheduleHeaderString = "";

    private LazyDataModel<Event> eventComparisonList = null;
    private Map<String, String> RTDBEvents = null;
    private List<String> RTDBUnmatchedEvents = null;
    private Map<String, Boolean> eventPaymentMethods = null;
    private String selectedPaymentMethods = "";
    private boolean displayUID;
    
    @PostConstruct
    public void init() {
        for (int i = 0; i < 6; i++) {
            organizers[i] = new Organizer();
        }
        disable = true;
        if (competitionList == null) {
            competitionList = new CompetitionLazyList(competitionService);
        }
        if (eventList == null) {
            eventList = new EventLazyList(competitionService);
        }
        eventStatusList = competitionService.getLookUpProviderDao().getEventStatus();
        publishStatusList = competitionService.getLookUpProviderDao().getPublishStatus();
        eventSummary = competitionService.getEventProviderDao().getEventStatusReport();
		venueCountryList = competitionService.getLookUpProviderDao().getCountry();

        tmpLocation = System.getProperty("java.io.tmpdir") + File.separator;
        logger.info("==>>INIT tmp location:" + tmpLocation);
        isImageUpload = false;
        checkBoxDisabled = false;
        curpubstatus = -1;
        eventImageFile = null;
        this.getHeaderUser();
        imgStyle = new String();
        genUploadFiles = new ArrayList<String>();
        
        List<SystemConfig> paymentMethods = getSystemConfigService().getSystemConfigProviderDao().getAll("WHERE systemconfig_category='payment_method' AND systemconfig_name<>''");
        eventPaymentMethods = new HashMap<String, Boolean>();
        for(SystemConfig onePaymentMethod: paymentMethods) {
            eventPaymentMethods.put(onePaymentMethod.getName(), false);
        }
    }

    public void compareWithFirebaseEvents() {

        RTDBEvents = new HashMap<String, String>();
        RTDBUnmatchedEvents = new ArrayList<String>();
        retrieveEventsFromFirebase();

        logger.info("eventComparisonList SIZE: " + eventComparisonList.getRowCount());

        context = RequestContext.getCurrentInstance();
        context.execute("PF('syncFirebaseEventsDialog').show();");
        //setDisableSyncButton(false);
    }

    public void retrieveEventsFromFirebase() {
        //retrieve list of events in Firebase

        logger.info("Retrieving list of events in Firebase...");

        //publish all configs to uberSync
        String result = "";
        String eventsToGet = "ALL";
        String urlStr = GET_EVENTS_URL + "?event_action=sync&event_parameter=" + eventsToGet;
        result = HttpClientHelper.getURL(urlStr);
        logger.info("Retrieved events[" + eventsToGet + "] from RTDB: " + result);

        try {
            result = result.replace("\"[", "[").replace("]\"", "]").replace("\\\"", "\"");
            logger.info("STRIPPED RESULT: " + result);
            JSONObject jsonObject = new JSONObject(new JSONTokener(result));
            if (jsonObject.get("status") != null) {
                if (jsonObject.get("status").toString().equalsIgnoreCase("ok")) {
                    if (jsonObject.getJSONArray("response") != null) {
                        JSONArray jsonArray = jsonObject.getJSONArray("response");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            String oneEventFound = jsonArray.get(i).toString();
                            logger.info("\t ONE EVENT RETRIEVED FROM RTDB: " + oneEventFound);
                            RTDBEvents.put(oneEventFound, "unmatched");
                            RTDBUnmatchedEvents.add(oneEventFound);
                        }
                    }
                } else {
                    RTDBEvents.put("ERROR SYNCING WITH RTDB: " + jsonObject.get("response").toString(), "unmatched");
                }
            } else {
                RTDBEvents.put("ERROR SYNCING WITH RTDB: " + jsonObject.get("response").toString(), "unmatched");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (RTDBEvents.isEmpty()) {
            RTDBEvents.put("No events retrieved from RTDB", "unmatched");
        }
    }

    public String checkRtdbMatch(String eventPushId) {
        String result = "NO MATCH IN RTDB";
        if (RTDBEvents != null) {
            if (RTDBEvents.containsKey(eventPushId)) {
                result = "Matched with: " + eventPushId;
                RTDBEvents.put(eventPushId, "matched");
                RTDBUnmatchedEvents.remove(eventPushId);
                //perform RTDB integrity check
                result += verifyEventIntegrityFromFirebase(eventPushId);
            }
        }
        logger.info("Checking RTDB match for [" + eventPushId + "]: " + result);
        return result;
    }

    public String verifyEventIntegrityFromFirebase(String eventPushID) {
        //verify event integrity from firebase
        String integrityResult = "";
        logger.info("Verifying event integrity with firebase");

        //publish all configs to uberSync
        String result = "";
        String eventsToGet = eventPushID;
        String urlStr = GET_EVENTS_URL + "?event_action=verify_integrity&event_parameter=" + eventsToGet;
        result = HttpClientHelper.getURL(urlStr);
        logger.info("Done verifying integrity of event[" + eventsToGet + "] from RTDB: " + result);

        try {
            result = result.replace("\"[", "[").replace("]\"", "]").replace("\\\"", "\"");
             logger.info("STRIPPED RESULT: " + result);
            JSONObject jsonObject = new JSONObject(new JSONTokener(result));
            if (jsonObject.get("status") != null) {
                if (jsonObject.get("status").toString().equalsIgnoreCase("ok")) {
                    if (jsonObject.getJSONArray("response") != null) {
                        JSONArray jsonArray = jsonObject.getJSONArray("response");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            String oneEventInfo = jsonArray.get(i).toString();
                            integrityResult += "<br />&nbsp;&nbsp;&nbsp;&nbsp; - " + oneEventInfo;
                             logger.info("\t ONE EVENT INFO RETRIEVED FROM RTDB: " + oneEventInfo);
                        }
                    }
                } else {
                    integrityResult = "ERROR VERIFYING INTEGRITY WITH RTDB: " + jsonObject.get("response").toString();
                }
            } else {
                integrityResult = "ERROR VERIFYING INTEGRITY WITH RTDB: " + jsonObject.get("response").toString();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (integrityResult.isEmpty()) {
            integrityResult = "<br /> &nbsp;&nbsp;&nbsp;&nbsp; - No additional info found for this event in RTDB. ";
            integrityResult += "<br /> &nbsp;&nbsp;&nbsp;&nbsp; - Data might be corrupted.";
        }
        return integrityResult;
    }

    public String generateLongDynamicLink(int eventId) {
        String result = "";
         try {
            SystemConfig dynLinkBase = getSystemConfigService().getSystemConfigProviderDao().get("DYN_LINK_BASE");
            if (dynLinkBase != null) {
                result += dynLinkBase.getValue();
            }

            SystemConfig dynLinkWeb = getSystemConfigService().getSystemConfigProviderDao().get("DYN_LINK_WEB");
            if (dynLinkWeb != null) {
                String dynLinkWebValue = dynLinkWeb.getValue();
                int openBracketLocation = dynLinkWebValue.indexOf("{");
                int closeBracketLocation = dynLinkWebValue.indexOf("}");
                if ((openBracketLocation >= 0) && (closeBracketLocation >= 0)) {
                    String placeHolderString = dynLinkWebValue.substring(openBracketLocation, closeBracketLocation + 1);
                    dynLinkWebValue = dynLinkWebValue.replace(placeHolderString, eventId + "");
                }
                result += dynLinkWebValue;
            }

            List<SystemConfig> shortLinkVariablesList = getSystemConfigService().getSystemConfigProviderDao().getAll("WHERE systemconfig_category='shortlink_config' AND systemconfig_name<>'' AND systemconfig_name<>'DYN_LINK_BASE' AND systemconfig_name<>'DYN_LINK_WEB' AND systemconfig_name<>'Id'");
            for (SystemConfig oneShortLinkVariable : shortLinkVariablesList) {
                result += "&" + oneShortLinkVariable.getName() + "=" + oneShortLinkVariable.getValue();
            }
        } catch (EmptyResultDataAccessException e) {
            logger.error("generateLongDynamicLink:" + e.getMessage());
        }
        return result;
    }

    public String generateShortDynamicLink(int eventId) {
        String shortLink = "";

        try {
            SystemConfig firebaseWebApiKey = getSystemConfigService().getSystemConfigProviderDao().get("webApiKey");
            String shortlinkEndpoint = "https://firebasedynamiclinks.googleapis.com/v1/shortLinks?key=" + firebaseWebApiKey.getValue();
            logger.info("generateShortDynamicLink() shortlinkEndpoint: " + shortlinkEndpoint);
            URL url = new URL(shortlinkEndpoint);
            HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");

            String longDynamicLink = generateLongDynamicLink(eventId);
            String input = "{\"longDynamicLink\":\"" + longDynamicLink + "\"}";

            logger.info("generateShortDynamicLink() input: " + input);
            OutputStream os = conn.getOutputStream();
            os.write(input.getBytes());
            os.flush();

             logger.info("generateShortDynamicLink() connection response code: " + conn.getResponseCode());
            if (conn.getResponseCode() == 200) {
                BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

                String shortlinkOutput = "";
                String partialOutput = "";
                while ((partialOutput = br.readLine()) != null) {
                    shortlinkOutput += partialOutput;
                }

                conn.disconnect();

                logger.info("SHORTLINK OUTPUT: " + shortlinkOutput);

                //parse output
                JSONParser parser = new JSONParser();
                org.json.simple.JSONObject outputJSON = (org.json.simple.JSONObject) parser.parse(shortlinkOutput);
                if (outputJSON.get("shortLink") != null) {
                    shortLink = outputJSON.get("shortLink").toString();
                }
                logger.info("Generated shortLink: " + shortLink);
            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }

        //shortLink = "shortLink/" + eventId;
        return shortLink;
    }

    public void regenerateShortDynamicLink(Event targetEvent) {
        String eventShortLink = generateShortDynamicLink(targetEvent.getId());
        targetEvent.setShortLink(eventShortLink);
        context = RequestContext.getCurrentInstance();
        context.execute("PF('regenerateShortlinkButton').enable();");
        //int upRes = competitionService.getEventProviderDao().update(targetEvent);
    }

    public String hasPaymentMethod() {
        String result = "true";
        return result;
    }

    public void onRowSelectCompetition(SelectEvent event) {
        Competition vcompetition = (Competition) event.getObject();
        // reset values
        resetValues();
        this.event.setCompetitionId(vcompetition.getId());
        String eventName = vcompetition.getName();
        this.event.setName(eventName);
        pageType = PageType.NEW;
        disable = false;
        selectTab = 0;
        isImageUpload = false;
        published = false;
        this.event.setPubstatus(PublishStatus.NOT_PUBLISHED);
        this.event.setStatus(EventStatus.CLOSED);
        publishedStatus = publishStatusList.get(this.event.getPubstatus()).getDescription();
        checkBoxDisabled = false;
        curpubstatus = 0;
        repubrendered = false;
        renderLastUpdate = false;
        renderLastPublish = false;
        imgStyle = new String();
        uberRegister = "false";
        disableURegister = true;
        tmpEventId = competitionService.getScheduleDataProviderDao().getTmpEventId();
        schedDataList = new ScheduleDataLazyList(competitionService, tmpEventId);
        schedule.setSchedName(SCHEDNAME);
        updateSchedData = false;
        schedDataHeaderNames = new HashMap<String, String>();
        scheduleData.setHdrOrder(1);
        scheduleData.setTvalOrder(1);
        hotelData.setOrderValue(1);
        sponsorData.setOrderValue(1);
        infoData.setOrderValue(1);
        hotelDataList = new GenericFormLazyList(competitionService,
                tmpEventId, GenericFormType.HOTEL_CODE);
        sponsorDataList = new GenericFormLazyList(competitionService,
                tmpEventId, GenericFormType.SPONSOR_CODE);
        infoDataList = new GenericFormLazyList(competitionService,
                tmpEventId, GenericFormType.INFO_CODE);
        updateHotel = false;
        updateSponsor = false;
        updateInfo = false;

        uploadHotel = false;
        uploadSponsor = false;
        uploadInfo = false;
        displayUID = false;
        if (dispDefault.isAllFalse()) {
             enablement.setFalseAll();
             enablement.setInformationEnable(true);
             dispDefault.setAllFalse();
             dispDefault.setInformationDisplay(true);
        }
    }

    public void onRowSelectEvent(SelectEvent event) {
        Event vevent = (Event) event.getObject();
        int eventid = vevent.getId();
        addMessage("Selected:" + vevent.getName());
        resetValues();
        this.event = vevent;
        curpubstatus = this.event.getPubstatus();
        updateSchedData = false;
        setEditScheduleHeaderEnabled(false);
        try {
            this.eventImage = competitionService.getImageProviderDao().get(this.event.getImageid());
        } catch (EmptyResultDataAccessException ex) {
            logger.warn("Warning: Empty Image using event imageid:" + this.event.getImageid() + " " + ex.getMessage());
        }
        try {
            this.contact = competitionService.getContactProviderDao().getByEventId(eventid);
        } catch (EmptyResultDataAccessException ex) {
            logger.warn("Warning: Empty Contact using event id:" + eventid + " " + ex.getMessage());
        }
        try {
            this.venue = competitionService.getVenueProviderDao().getByEventId(eventid);
        } catch (EmptyResultDataAccessException ex) {
            logger.warn("Warning: Empty Venue using event id:" + eventid + " " + ex.getMessage());
        }

        try {
            this.finance = competitionService.getFinanceProviderDao().getByEventId(eventid);
        } catch (EmptyResultDataAccessException ex) {
            logger.warn("Warning: Empty finance using event id:" + eventid + " " + ex.getMessage());
        }

        try {
            this.schedule = competitionService.getScheduleProviderDao().get(eventid);
            composeSchedHeaderNames();
        } catch (EmptyResultDataAccessException ex) {
            logger.warn("Warning: Empty schedule using event id:" + eventid + " " + ex.getMessage());
        }

        try {
            int itmp = competitionService.getScheduleDataProviderDao().movetoTemporary(eventid);
        } catch (EmptyResultDataAccessException ex) {
            logger.warn("Warning: Empty schedulelist using event id:" + eventid + " " + ex.getMessage());
        }

        int hdrOrder = 0;
        try {
            hdrOrder = competitionService.getScheduleDataProviderDao().
                    getLastHeaderOrder(eventid);
        } catch (EmptyResultDataAccessException ex) {
            logger.warn("Warning: Empty schedule list using event id:" + eventid + " " + ex.getMessage());
        }
        hdrOrder++;
        scheduleData.setHdrOrder(hdrOrder);
        scheduleData.setTvalOrder(1);
        composeSchedHeaderNames();
        schedDataList = new ScheduleDataLazyList(competitionService, eventid);
        if ((null == this.schedule.getSchedName())
                || this.schedule.getSchedName().isEmpty()) {
            this.schedule.setSchedName(SCHEDNAME);
        }
        try {
            List<Organizer> orgList = competitionService.getOrganizerProviderDao().getAllByEventId(eventid);
            for (int i = 0; i < orgList.size(); i++) {
                organizers[i] = orgList.get(i);
            }
        } catch (EmptyResultDataAccessException ex) {
            logger.warn("Warning: Empty Organizer using event id:" + eventid + " " + ex.getMessage());
        }
        try {
            enablement = competitionService.getEnablementProviderDao().get(eventid);
            logger.info("enablement (row):" + enablement.toString());

        } catch (EmptyResultDataAccessException ex) {
            logger.warn("Warning: Empty enablement using event id:" + eventid + " " + ex.getMessage());
        }
        
        try {
            dispDefault = competitionService.getDisplayDefaultProviderDao().get(eventid);
            logger.info("display default (row):" + dispDefault.toString());

        } catch (EmptyResultDataAccessException ex) {
            logger.warn("Warning: Empty display default using event id:" + eventid + " " + ex.getMessage());
        }
        
        // if the display default are all false turn on enablement
        if (dispDefault.isAllFalse()) {
             enablement.setFalseAll();
             enablement.setInformationEnable(true);
             dispDefault.setAllFalse();
             dispDefault.setInformationDisplay(true);
        }
        
        pageType = PageType.EDIT;
        disable = false;
        selectTab = 0;
        isImageUpload = false;

        checkBoxDisabled = ((PublishStatus.NOT_PUBLISHED == curpubstatus)
                || (PublishStatus.PUBLISHED == curpubstatus)) ? false : true;
        checkBoxRePubDisabled = (PublishStatus.PUBLISHED == curpubstatus) ? false : true;

        published = ((PublishStatus.PUBLISHED == curpubstatus)
                || (PublishStatus.PUBLISH_PENDING == curpubstatus)
                || (PublishStatus.PUBLISH_IN_PROGRESS == curpubstatus)) ? true : false;

        republished = ((PublishStatus.REPUBLISH_PENDING == curpubstatus)
                || (PublishStatus.REPUBLISH_IN_PROGRESS == curpubstatus)) ? true : false;

        repubrendered = ((PublishStatus.PUBLISHED == curpubstatus)
                || (PublishStatus.REPUBLISH_PENDING == curpubstatus)
                || (PublishStatus.REPUBLISH_IN_PROGRESS == curpubstatus)) ? true : false;
        publishedStatus = publishStatusList.get(curpubstatus).getDescription();
        newpubstatus = curpubstatus;
        renderLastUpdate = true;
        renderLastPublish = true;
        disableURegister = false;
        uberRegister = (this.event.isUberRegister()) ? "true" : "false";
        imgStyle = new String();
        // streamed from the database
        if (this.event.getImageid() > 0) {
            // image 
            String filename = this.event.getImgFilename();
            String fileext = Utility.getExtension(filename);
            String fileprefix = Utility.getFilePrefix(filename);

            eventImgFilename = fileprefix + "." + fileext;
            logger.info("filename:" + filename + " ext:" + fileext
                    + " prefix:" + fileprefix + " ->ifn:" + eventImgFilename);
            if (eventImage != null) {
                try {
                    BufferedImage bi = ImageIO.read(eventImage.imageByInputStream());
                    int width = bi.getWidth();
                    int height = bi.getHeight();
                    ImageDimension imageSize = new ImageDimension(width, height);
                    ImageDimension boundary = new ImageDimension(IMAGE_WIDTH, IMAGE_HEIGHT);
                    imageDimension = computeImageScaledValue(imageSize, boundary);
                    String imgSize = "(" + Integer.toString(width) + "px wide x "
                            + Integer.toString(height) + "px high)";
                    eventImgFilename = eventImgFilename + " " + imgSize;
                    logger.info("=>image info:" + imgSize);
                    eventImageFile = new DefaultStreamedContent(eventImage.imageByInputStream(),
                            this.event.getMimeType(), this.event.getImgFilename());
                    imgStyle = "border: 1px solid; border-color: black;";
                } catch (IOException io) {
                    io.printStackTrace();
                }
            }
        }
        int mret = competitionService.getGenericFormProviderDao().moveEventToTemp(eventid, GenericFormType.HOTEL);
        if (mret < 0) {
            logger.info("Moving data to temporary table: HOTEL");
        }
        mret = competitionService.getGenericFormProviderDao().moveEventToTemp(eventid, GenericFormType.SPONSOR);
        if (mret < 0) {
            logger.info("Moving data to temporary table: SPONSOR");
        }
        mret = competitionService.getGenericFormProviderDao().moveEventToTemp(eventid, GenericFormType.INFO);
        if (mret < 0) {
            logger.info("Moving data to temporary table: INFO");
        }

        int tmporder = 0;
        try {
            tmporder = competitionService.getGenericFormProviderDao().lastOrder(eventid, GenericFormType.HOTEL_CODE);
        } catch (EmptyResultDataAccessException ex) {
            logger.warn("Warning: Empty hotel using event id:" + eventid + " " + ex.getMessage());
        }
        tmporder++;
        hotelData.setOrderValue(tmporder);

        tmporder = 0;
        try {
            tmporder = competitionService.getGenericFormProviderDao().lastOrder(eventid, GenericFormType.SPONSOR_CODE);
        } catch (EmptyResultDataAccessException ex) {
            logger.warn("Warning: Empty sponsor using event id:" + eventid + " " + ex.getMessage());
        }
        tmporder++;
        sponsorData.setOrderValue(tmporder);

        tmporder = 0;
        try {
            tmporder = competitionService.getGenericFormProviderDao().lastOrder(eventid, GenericFormType.INFO_CODE);
        } catch (EmptyResultDataAccessException ex) {
            logger.warn("Warning: Empty info using event id:" + eventid + " " + ex.getMessage());
        }
        tmporder++;
        infoData.setOrderValue(tmporder);

        hotelDataList = new GenericFormLazyList(competitionService,
                eventid, GenericFormType.HOTEL_CODE);
        sponsorDataList = new GenericFormLazyList(competitionService,
                eventid, GenericFormType.SPONSOR_CODE);
        infoDataList = new GenericFormLazyList(competitionService,
                eventid, GenericFormType.INFO_CODE);
        updateHotel = false;
        updateSponsor = false;
        updateInfo = false;

        uploadHotel = false;
        uploadSponsor = false;
        uploadInfo = false;
        
        logger.info("UPDATING EVENT PAYMENT METHODS CHECKBOXES...");
        String eventPaymentMethodsString = "";
        if(vevent.getPaymentMethods() != null) {
            eventPaymentMethodsString = vevent.getPaymentMethods();
        }
        Iterator eventPaymentMethodsIterator = eventPaymentMethods.entrySet().iterator();        
        while (eventPaymentMethodsIterator.hasNext()) {
            Map.Entry oneEventPaymentMethod = (Map.Entry)eventPaymentMethodsIterator.next();
            if(!oneEventPaymentMethod.getKey().toString().isEmpty()) {
                if(eventPaymentMethodsString.contains(oneEventPaymentMethod.getKey().toString())) {
                     logger.info("EVENT contains: " + oneEventPaymentMethod.getKey().toString());
                    oneEventPaymentMethod.setValue(true);
                } else {
                    oneEventPaymentMethod.setValue(false);
                }
            }
        }
        
        logger.info("LIST OF UPDATED eventPaymentMethods...");
        Iterator eventPaymentMethodsIterator2 = eventPaymentMethods.entrySet().iterator();        
        while (eventPaymentMethodsIterator2.hasNext()) {
            Map.Entry oneEventPaymentMethod2 = (Map.Entry)eventPaymentMethodsIterator2.next();
            logger.info("PAYMENT METHOD [" + oneEventPaymentMethod2.getKey().toString() + "]:" + oneEventPaymentMethod2.getValue());
        }
        displayUID = true;
    }
    
    public void updatePaymentMethod(String paymentMethodName) {
        String eventPaymentMethodsString = "";
        if(this.event.getPaymentMethods() != null) {
            eventPaymentMethodsString = this.event.getPaymentMethods();
        }
         logger.info("CURRENT PAYMENT METHODS: " + this.event.getPaymentMethods());
        if(eventPaymentMethodsString.contains(paymentMethodName)) {
             logger.info("REMOVING PAYMENT METHOD: " + paymentMethodName);
            this.event.setPaymentMethods(this.event.getPaymentMethods().replace(paymentMethodName, ""));
        } else {
             logger.info("ADDING PAYMENT METHOD: " + paymentMethodName);
            this.event.setPaymentMethods(this.event.getPaymentMethods() + "," + paymentMethodName);            
        }
        selectedPaymentMethods = this.event.getPaymentMethods();
        
        if(!selectedPaymentMethods.isEmpty()) {
            selectedPaymentMethods = selectedPaymentMethods.replaceAll("null", "");
            selectedPaymentMethods = selectedPaymentMethods.replaceAll(",,,,", ",");
            selectedPaymentMethods = selectedPaymentMethods.replaceAll(",,,", ",");
            selectedPaymentMethods = selectedPaymentMethods.replaceAll(",,", ",");
            if(selectedPaymentMethods.charAt(selectedPaymentMethods.length()-1) == ',') {
                selectedPaymentMethods = selectedPaymentMethods.substring(0, selectedPaymentMethods.length()-1);
            }
            if(selectedPaymentMethods.charAt(0) == ',') {
                selectedPaymentMethods = selectedPaymentMethods.substring(1, selectedPaymentMethods.length());
            }
        }
         logger.info("UPDATED SELECTED PAYMENT METHODS: " + selectedPaymentMethods);
    }
    
    public void save() {
        if (!isDisplayDefaultHasValue()) {
            addMessage("Please check default display for this event.", FacesMessage.SEVERITY_ERROR);
        } else {
            context = RequestContext.getCurrentInstance();
            int errcnt = 0;
//        if (event.getWebsite().length() > 0) {
//            String website = Utility.urlPrefix(event.getWebsite());
//            event.setWebsite(website);
//        }
//            System.out.println("SAVING selectedPaymentMethods: " + selectedPaymentMethods);
            this.event.setPaymentMethods(selectedPaymentMethods);
            
            boolean startProcess = false;
            if (event.getDateStop().getTime() == event.getDateStart().getTime()) {
                startProcess = true;
            } else {
                if (event.getDateStop().getTime() > event.getDateStart().getTime()) {
                    long diff = event.getDateStop().getTime() - event.getDateStart().getTime() ;
                    int days = (int)TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
                    if (days <= 14) {
                        startProcess = true;
                    } else {
                       addMessage("Stop Date cannot be more that 14 days later than Start Date."); 
                    }
                } else {
                    addMessage("Stop Date must be greater or equal to Start Date.");
                }
            }
            
            if (startProcess) {
                if (pageType == PageType.NEW) {

                    this.event.setPubstatus(newpubstatus);
                    this.event.setUberRegister(false);
                    int eventid = competitionService.getEventProviderDao().insert(event);
                    if (eventid > 0) {
                        addMessage("Saving events information with:" + eventid);
                        //create shortlink for this event
                        String eventShortLink = generateShortDynamicLink(eventid);
                        this.event.setShortLink(eventShortLink);
                        event.setId(eventid);
                        int upRes = competitionService.getEventProviderDao().update(event);
                        if (isImageUpload) {
                            event.setImgFilename(uploadImgFilename);
                            event.setMimeType(uploadMimeType);
                            int imageid = competitionService.getImageProviderDao().insertEventImageFile(eventid,
                                    tmpLocation, event.getImgFilename(), event.getMimeType());
                            if (imageid > 0) {
                                event.setImageid(imageid);
                                addMessage("Image saved in the database with image id:" + imageid);
                                int iret = competitionService.getEventProviderDao().updateImageFile(eventid, imageid);
                                try {
                                    if (instream != null) {
                                        instream.close();
                                    }
                                } catch (IOException io) {
                                    io.printStackTrace();
                                }
                                Utility.deleteFile(tmpLocation, event.getImgFilename());
                                if (iret < 0) {
                                    errcnt++;
                                }
                            } else {
                                if (imageid < 1) {
                                    errcnt++;
                                }
                            }
                        }
                        // add move here 
                        if (!contact.isEmpty()) {
                            contact.setEventid(eventid);
                            int cret = competitionService.getContactProviderDao().insert(contact);
                            if (cret < 0) {
                                errcnt++;
                            }
                        }
                        if (!venue.isEmpty()) {
                            venue.setEventid(eventid);
                            int vret = competitionService.getVenueProviderDao().insert(venue);
                            if (vret < 0) {
                                errcnt++;
                            }
                        }
                        if (!schedule.getSchedName().isEmpty()) {
                            schedule.setEventId(eventid);
                            int sret = competitionService.getScheduleProviderDao().insert(schedule, tmpEventId);
                            if (sret < 0) {
                                errcnt++;
                            }
                        }

                        if (!finance.isEmpty()) {
                            finance.setEventId(eventid);
                            int vret = competitionService.getFinanceProviderDao().insert(finance);
                            if (vret < 0) {
                                errcnt++;
                            }
                        }

                        for (int i = 0; i < 6; i++) {
                            Organizer orgobj = organizers[i];
                            int oevtid = orgobj.getEventid();
                            int oid = orgobj.getId();
                            String oname = orgobj.getName();
                            if ((oevtid == 0) && (oid == 0)
                                    && (null != oname) && (oname.length() > 0)) {
                                orgobj.setEventid(eventid);
                                logger.info("organizer:" + i + " data:" + orgobj.toString());
                                int ioret = competitionService.getOrganizerProviderDao().insert(orgobj);
                                //if (ioret > 100) errcnt++;
                            }
                        }
                        int nret = 0;
                        long cnt = 0;

                        cnt = competitionService.getGenericFormProviderDao().countData(tmpEventId, GenericFormType.HOTEL_CODE);
                        if (cnt > 0) {
                            nret = competitionService.getGenericFormProviderDao().
                                    insertToEvent(eventid, GenericFormType.HOTEL, tmpEventId);
                            if (nret < 0) {
                                errcnt++;
                            }
                        }
                        cnt = competitionService.getGenericFormProviderDao().countData(tmpEventId, GenericFormType.SPONSOR_CODE);
                        if (cnt > 0) {
                            nret = competitionService.getGenericFormProviderDao().
                                    insertToEvent(eventid, GenericFormType.SPONSOR, tmpEventId);
                            if (nret < 0) {
                                errcnt++;
                            }
                        }
                        cnt = competitionService.getGenericFormProviderDao().countData(tmpEventId, GenericFormType.INFO_CODE);
                        if (cnt > 0) {
                            nret = competitionService.getGenericFormProviderDao().
                                    insertToEvent(eventid, GenericFormType.INFO, tmpEventId);
                            if (nret < 0) {
                                errcnt++;
                            }
                        }

                        enablement.setEventId(eventid);
                        int eret = competitionService.getEnablementProviderDao().insert(enablement);
                        if (eret > 0) {
                            logger.info("enablement:" + enablement.toString());
                        } else {
                            logger.info("error enablement.");
                        }

                        dispDefault.setEventId(eventid);
                        int dret = competitionService.getDisplayDefaultProviderDao().insert(dispDefault);
                        if (dret > 0) {
                            logger.info("Display Default:" + enablement.toString());
                        } else {
                            logger.info("error Display Default.");
                        }


                        if (errcnt == 0) {
                            addMessage("All objects for Event saved." + eventid);
                            eventSummary = competitionService.getEventProviderDao().getEventStatusReport();
                            if (genUploadFiles.size() > 0) {
                                for (String filename : genUploadFiles) {
                                    Utility.deleteFile(tmpLocation, filename);
                                }
                            }
                            resetValues();
                        } else {
                            addMessage("Error saving event objects.");
                        }
                    } else {
                        addMessage("Errorsaving event objects.error:" + eventid);
                    }
                    context.execute("PF('eventNewDialog').hide();");
                }
                if (pageType == PageType.EDIT) {
                    int eventid = this.event.getId();
                    boolean tmpuregister = (uberRegister.equalsIgnoreCase("true")) ? true : false;
                    this.event.setUberRegister(tmpuregister);
                    this.event.setPubstatus(newpubstatus);
                    int vterr = competitionService.getEventProviderDao().update(event);
                    // check if there was an upload            
                    if (vterr == 100) {
                        if (isImageUpload) {
                            int iret = 0;
                            event.setImgFilename(uploadImgFilename);
                            event.setMimeType(uploadMimeType);
                            if (event.getImageid() > 0) {
                                iret = competitionService.getImageProviderDao().
                                        updateEventImageFile(event.getImageid(), tmpLocation,
                                                event.getImgFilename(), event.getMimeType());
                            } else {
                                int imageid = competitionService.getImageProviderDao().insertEventImageFile(eventid,
                                        tmpLocation, event.getImgFilename(), event.getMimeType());
                                if (imageid > 0) {
                                    event.setImageid(imageid);
                                    iret = competitionService.getEventProviderDao().updateImageFile(eventid, imageid);
                                }
                            }
                            try {
                                if (instream != null) {
                                    instream.close();
                                }
                            } catch (IOException io) {
                                io.printStackTrace();
                            }
                            if (Utility.deleteFile(tmpLocation, event.getImgFilename())) {
                                logger.info("delete (ok):" + tmpLocation + ":" + event.getImgFilename());
                            } else {
                                logger.info("delete (error):" + tmpLocation + ":" + event.getImgFilename());
                            }
                            if (iret < 0) {
                                errcnt++;
                            }
                        }
                        int vret = 0;
                        addMessage("Updating events information with:" + eventid);
                        if (!venue.isEmpty()) {
                            if (venue.getEventid() == 0) {
                                venue.setEventid(eventid);
                                vret = competitionService.getVenueProviderDao().insert(venue);
                            } else {
                                vret = competitionService.getVenueProviderDao().update(venue);
                            }
                            if (vret < 0) {
                                errcnt++;
                            }
                        }
                        int cret = 0;
                        if (!contact.isEmpty()) {
                            if (contact.getEventid() == 0) {
                                contact.setEventid(eventid);
                                cret = competitionService.getContactProviderDao().insert(contact);
                            } else {
                                cret = competitionService.getContactProviderDao().update(contact);
                            }
                            if (cret < 0) {
                                errcnt++;
                            }
                        }
                        int sret = 0;
                        if (!schedule.getSchedName().isEmpty()) {
                            if (schedule.getEventId() == 0) {
                                schedule.setEventId(eventid);
                                sret = competitionService.getScheduleProviderDao().insert(schedule, eventid);
                            } else {
                                sret = competitionService.getScheduleProviderDao().update(schedule);
                            }
                            if (sret < 0) {
                                errcnt++;
                            }
                        }

                        int fret = 0;
                        if (!finance.isEmpty()) {
                            if (finance.getEventId() == 0) {
                                finance.setEventId(eventid);
                                fret = competitionService.getFinanceProviderDao().insert(finance);
                            } else {
                                fret = competitionService.getFinanceProviderDao().update(finance);
                            }
                            if (fret < 0) {
                                errcnt++;
                            }
                        }

                        int nret = 0;
                        nret = competitionService.getGenericFormProviderDao().
                                updateToEvent(eventid, GenericFormType.HOTEL);
                        if (nret < 0) {
                            errcnt++;
                        }
                        nret = competitionService.getGenericFormProviderDao().
                                updateToEvent(eventid, GenericFormType.SPONSOR);
                        if (nret < 0) {
                            errcnt++;
                        }
                        nret = competitionService.getGenericFormProviderDao().
                                updateToEvent(eventid, GenericFormType.INFO);
                        if (nret < 0) {
                            errcnt++;
                        }

                        for (int i = 0; i < 6; i++) {
                            Organizer orgobj = organizers[i];
                            int oevtid = orgobj.getEventid();
                            int oid = orgobj.getId();
                            String oname = orgobj.getName();
                            int ioret = 0;
                            if ((null != oname) && (oname.length() > 0)) {
                                if ((oevtid == 0) && (oid == 0)) {
                                    orgobj.setEventid(eventid);
                                    ioret = competitionService.getOrganizerProviderDao().insert(orgobj);
                                } else {
                                    ioret = competitionService.getOrganizerProviderDao().update(orgobj);
                                }
                            } else {
                                if ((oevtid > 0) && (oid > 0)) {
                                    ioret = competitionService.getOrganizerProviderDao().delete(oid);
                                }
                            }
                        }
                        int eret = 0;
                        if (enablement.getEventId() == 0) {
                            enablement.setEventId(eventid);
                            eret = competitionService.getEnablementProviderDao().insert(enablement);
                        } else {
                            eret = competitionService.getEnablementProviderDao().update(enablement);
                        }
                        if (eret > 0) {
                            logger.info("enablement (update):" + enablement.toString());
                        } else {
                            logger.info("error enablement (update).");
                        }

                        int dret = 0;
                        if (enablement.getEventId() == 0) {
                            dispDefault.setEventId(eventid);
                            dret = competitionService.getDisplayDefaultProviderDao().insert(dispDefault);
                        } else {
                            dret = competitionService.getDisplayDefaultProviderDao().update(dispDefault);
                        }
                        if (dret > 0) {
                            logger.info("Display Default (update):" + enablement.toString());
                        } else {
                            logger.info("error Display Default (update).");
                        }

                        if (errcnt == 0) {
                            addMessage("All objects for Event updated." + eventid);
                            eventSummary = competitionService.getEventProviderDao().getEventStatusReport();
                            resetValues();
                        } else {
                            addMessage("Error updating event objects." + eventid);
                        }
                    } else {
                        addMessage("Error: Competition with Date/Stop already exist. updating event error:" + eventid);
                    }
                    context.execute("PF('eventEditDialog').hide();");
                }
                selectTab = 0;
                disable = true;
            }
        }
    }

    public void checkBoxRePublish() {
        if (repubrendered) {
            if (republished) {
                published = false;
                newpubstatus = (curpubstatus == 5) ? PublishStatus.REPUBLISH_PENDING : curpubstatus;
                checkBoxDisabled = true;
            } else {
                published = true;
                checkBoxDisabled = false;
                curpubstatus = PublishStatus.PUBLISHED;
                newpubstatus = PublishStatus.PUBLISHED;
            }
            publishedStatus = publishStatusList.get(newpubstatus).getDescription();
        }
    }

    public void checkBox() {
        if (pageType == PageType.NEW) {
            if (published) {
                newpubstatus = PublishStatus.PUBLISH_PENDING;
            } else {
                newpubstatus = PublishStatus.NOT_PUBLISHED;
            }
        }
        if (pageType == PageType.EDIT) {
            if (published) {
                newpubstatus = (curpubstatus == 5) ? PublishStatus.PUBLISHED : PublishStatus.PUBLISH_PENDING;
                if (repubrendered) {
                    checkBoxRePubDisabled = false;
                }
            } else {
                newpubstatus = (curpubstatus == 0) ? PublishStatus.NOT_PUBLISHED : PublishStatus.UNPUBLISH_PENDING;
                if (repubrendered) {
                    checkBoxRePubDisabled = true;
                }
            }
            republished = false;
        }
        publishedStatus = publishStatusList.get(newpubstatus).getDescription();
    }

    public void delete(int eventid, int pubstatus) {
        if (pubstatus == PublishStatus.NOT_PUBLISHED) {
            int vterr = competitionService.getEventProviderDao().delete(eventid);
            if (vterr == 100) {
                addMessage("Delete Event Successful.");
            } else {
                addMessage("Delete Event Failed.");
            }
        } else {
            addMessage("Only unpublished events are allowed to be deleted.", FacesMessage.SEVERITY_WARN);
        }
    }

    public void copy(int eventid) {
        Event tmpEvent = new Event();
        Organizer[] tmpOrganizers = new Organizer[6];
        String newName = new String();
        try {
            tmpEvent = competitionService.getEventProviderDao().get(eventid);
            newName = "Copy " + tmpEvent.getName();
        } catch (EmptyResultDataAccessException ex) {
            logger.warn("Warning: Empty Event using  id:" + eventid + " " + ex.getMessage());
        }
        for (int i = 0; i < 6; i++) {
            tmpOrganizers[i] = new Organizer();
        }

        try {
            List<Organizer> orgList = competitionService.getOrganizerProviderDao().getAllByEventId(eventid);
            for (int i = 0; i < orgList.size(); i++) {
                tmpOrganizers[i] = orgList.get(i);
            }
        } catch (EmptyResultDataAccessException ex) {
            logger.warn("Warning: Empty Organizer using event id:" + eventid + " " + ex.getMessage());
        }

        int newEventId = competitionService.getEventProviderDao().copy(eventid, newName);
        if (newEventId > 0) {
            for (int i = 0; i < 6; i++) {
                Organizer orgobj = tmpOrganizers[i];
                String oname = orgobj.getName();
                if ((null != oname) && (oname.length() > 0)) {
                    orgobj.setEventid(newEventId);
                    logger.info("organizer:" + i + " data:" + orgobj.toString());
                    int ioret = competitionService.getOrganizerProviderDao().insert(orgobj);
                }
            }
            addMessage("Copying event sucessful.");
        } else {
            addMessage("Copying event failed.");
        }

    }

    public String uploadImage(FileUploadEvent e) throws IOException {
        String retstr = new String();
        UploadedFile uploadedImage = e.getFile();

        byte[] bytes = null;

        if (null != uploadedImage) {
            bytes = uploadedImage.getContents();
            // image data
            BufferedImage bi = ImageIO.read(new ByteArrayInputStream(bytes));
            int width = bi.getWidth();
            int height = bi.getHeight();
            ImageDimension imageSize = new ImageDimension(width, height);
            ImageDimension boundary = new ImageDimension(IMAGE_WIDTH, IMAGE_HEIGHT);
            imageDimension = computeImageScaledValue(imageSize, boundary);
            String imgSize = "(" + Integer.toString(width) + "px wide x "
                    + Integer.toString(height) + "px high)";
            logger.info("===>image info:" + imgSize);

            String fileext = Utility.getExtension(uploadedImage.getFileName());
            String fileprefix = Utility.getFilename(uploadedImage.getFileName());
            String type = fileext.replace(".", "");
            String mimeType = "image/" + type;
            String filename = new String();
            filename = Utility.generateUniqueFileName(fileprefix);

            if (fileext != null) {
                filename = filename + "." + fileext;
            }
            String fullpath = tmpLocation + filename;
            BufferedOutputStream stream = new BufferedOutputStream(
                    new FileOutputStream(new File(tmpLocation, filename)));
            stream.write(bytes);
            stream.flush();
            stream.close();
            stream = null;
            eventImgFilename = Utility.getFilePrefix(filename) + "."
                    + fileext + " " + imgSize;
            uploadImgFilename = filename;
            uploadMimeType = mimeType;
            logger.info("=>upload image filename:" + filename);
            isImageUpload = true;
            imgStyle = "border: 1px solid; border-color: black;";
            loadImage();
        }

        addMessage("File Name:" + uploadedImage.getFileName()
                + " with size " + uploadedImage.getSize() + " Uploaded Successfully");

        return retstr;
    }

    public void onRowScheduleData(SelectEvent event) {
        updateSchedData = true;
        setEditScheduleHeaderEnabled(true);
        scheduleData = (ScheduleData) event.getObject();
    }

    public void onChangeHeaderNames() {
        String tmpHeaderName = scheduleData.getHeaderName();
        //addMessage("header name:" + tmpHeaderName);

        int fineventId = (pageType == PageType.NEW) ? tmpEventId : this.event.getId();
        int hdrorder = 0;
        try {
            hdrorder = competitionService.getScheduleDataProviderDao().getHeaderOrder(scheduleData.getHeaderName(), fineventId);
            setEditScheduleHeaderEnabled(true);
        } catch (EmptyResultDataAccessException ex) {
            logger.warn("Warning: Empty ScheduleData hdrOrder using event id:" + fineventId + " " + ex.getMessage());
        }
        if (hdrorder == 0) { // if zero probably new headername lets look for the last headerlist + 1
            try {
                hdrorder = competitionService.getScheduleDataProviderDao().getLastHeaderOrder(fineventId);
            } catch (EmptyResultDataAccessException ex) {
                logger.warn("Warning: Empty ScheduleData hdrOrder using event id:" + fineventId + " " + ex.getMessage());
            }
            hdrorder++;
            setEditScheduleHeaderEnabled(false);
        }
        scheduleData.setHdrOrder(hdrorder);
        int tvalOrder = 0;
        try {
            tvalOrder = competitionService.getScheduleDataProviderDao().getLastTimeValueOrder(tmpHeaderName, fineventId);
        } catch (EmptyResultDataAccessException ex) {
            logger.warn("Warning: Empty schedule list(tvalOrder) using event id:" + fineventId + " " + ex.getMessage());
        }
        tvalOrder++;
        scheduleData.setTvalOrder(tvalOrder);
    }

    public void editHeaderName() {
        setEditScheduleHeaderString(scheduleData.getHeaderName());
        context = RequestContext.getCurrentInstance();
        context.execute("PF('editHeaderDialog').show();");
    }

    public void saveEditedHeaderName() {
        String newHeaderName = getEditScheduleHeaderString();
        if (newHeaderName.trim().isEmpty()) {
            addMessage("Edit Header: Blank header names are not allowed.");
        } else {
            String oldHeaderName = scheduleData.getHeaderName();
            scheduleData.setHeaderName(getEditScheduleHeaderString());

            int fineventId = (pageType == PageType.NEW) ? tmpEventId : this.event.getId();
            String wherestr = " WHERE event_id=" + fineventId + " AND header_name = \'" + oldHeaderName + "\'";
            List<ScheduleData> schedDataList = competitionService.getScheduleDataProviderDao().getAll(wherestr);
            int updateCounter = 0;
            for (ScheduleData schedData : schedDataList) {
                schedData.setHeaderName(newHeaderName);
                int iret = 0;
                iret = competitionService.getScheduleDataProviderDao().update(schedData);
                if (iret > 0) {
                    updateCounter++;
                }
            }

            resetScheduleData();
            composeSchedHeaderNames();
            setEditScheduleHeaderEnabled(false);

            addMessage("Header name updated: " + newHeaderName + " (" + updateCounter + " schedules)");
        }
        context = RequestContext.getCurrentInstance();
        context.execute("PF('editHeaderDialog').hide();");
    }

    public void composeSchedHeaderNames() {
        int fineventId = (pageType == PageType.NEW) ? tmpEventId : this.event.getId();
        List<String> schedDataList = competitionService.
                getScheduleDataProviderDao().getHeaderNames(fineventId);
        schedDataHeaderNames = new HashMap();
        for (String schedName : schedDataList) {
            schedDataHeaderNames.put(schedName, schedName);
        }
    }

    public void saveSchedule() {
        if (scheduleData.getHeaderName().isEmpty()) {
            addMessage("Header Name is Required.", FacesMessage.SEVERITY_ERROR);
            return;
        }
        int fineventId = (pageType == PageType.NEW) ? tmpEventId : this.event.getId();
        scheduleData.setEventId(fineventId);
        int iret = 0;

        if (updateSchedData) {
            iret = competitionService.getScheduleDataProviderDao().update(scheduleData);
        } else {
            try {
                iret = competitionService.getScheduleDataProviderDao().insert(scheduleData);
            } catch (Exception ex) {
                iret = -99;
            }
        }
        if (iret > 0) {
            addMessage("Schedule Data Saved.");
            resetScheduleData();
            composeSchedHeaderNames();
            int hdrOrder = 0;
            try {
                hdrOrder = competitionService.getScheduleDataProviderDao().
                        getLastHeaderOrder(fineventId);
            } catch (EmptyResultDataAccessException ex) {
                logger.warn("Warning: Empty schedule list (hdrOrder) using event id:" + fineventId + " " + ex.getMessage());
            }
            hdrOrder++;
            scheduleData.setHdrOrder(hdrOrder);
            scheduleData.setTvalOrder(1);
        } else {
            addMessage("Error saving Schedule Data.");
        }
    }

    public void deleteSchedule(int id) {
        int iret = competitionService.getScheduleDataProviderDao().delete(id);
        if (iret > 0) {
            addMessage("Schedule Data Deleted.");
        } else {
            addMessage("Error deleting Schedule Data.");
        }
    }

    public void genericUploadImage(FileUploadEvent e) throws IOException {
        UploadedFile uploadedImage = e.getFile();
        byte[] bytes = null;
        String code = (String) e.getComponent().getAttributes().get("code");
        if (null != uploadedImage) {
            String imgfilename = uploadedImage.getFileName();
            addMessage(imgfilename + " for code:" + code);
            // image data
            bytes = uploadedImage.getContents();
            BufferedImage bi = ImageIO.read(new ByteArrayInputStream(bytes));
            int width = bi.getWidth();
            int height = bi.getHeight();
            String imgSize = "(" + Integer.toString(width) + "px wide x "
                    + Integer.toString(height) + "px high)";
            logger.info("===>image info:" + imgSize);

            String fileext = Utility.getExtension(uploadedImage.getFileName());
            String fileprefix = Utility.getFilename(uploadedImage.getFileName());
            String type = fileext.replace(".", "");
            String mimeType = "image/" + type;
            String filename = new String();
            String imgcode = new String();
            if (code.equalsIgnoreCase(GenericFormType.HOTEL_CODE)) {
                imgcode = GenericFormType.IMG_HOTEL_CODE;
            }
            if (code.equalsIgnoreCase(GenericFormType.SPONSOR_CODE)) {
                imgcode = GenericFormType.IMG_SPONSOR_CODE;
            }
            if (code.equalsIgnoreCase(GenericFormType.INFO_CODE)) {
                imgcode = GenericFormType.IMG_INFO_CODE;
            }

            filename = Utility.generateUniqueFileName(fileprefix, imgcode);
            if (fileext != null) {
                filename = filename + "." + fileext;
            }
            BufferedOutputStream stream = new BufferedOutputStream(
                    new FileOutputStream(new File(tmpLocation, filename)));
            stream.write(bytes);
            stream.flush();
            stream.close();
            stream = null;
            genUploadFiles.add(filename);
            String imageInfo = Utility.getFilePrefix(filename, imgcode) + "."
                    + fileext + " " + imgSize;
            if (code.equalsIgnoreCase(GenericFormType.HOTEL_CODE)) {
                hotelData.setImage(bytes);
                hotelData.setFilename(filename);
                hotelData.setDisplayFilename(imageInfo);
                hotelData.setMimeType(mimeType);
                uploadHotel = true;
            }
            if (code.equalsIgnoreCase(GenericFormType.SPONSOR_CODE)) {
                sponsorData.setImage(bytes);
                sponsorData.setFilename(filename);
                sponsorData.setDisplayFilename(imageInfo);
                sponsorData.setMimeType(mimeType);
                uploadSponsor = true;
            }
            if (code.equalsIgnoreCase(GenericFormType.INFO_CODE)) {
                infoData.setImage(bytes);
                infoData.setFilename(filename);
                infoData.setDisplayFilename(imageInfo);
                infoData.setMimeType(mimeType);
                uploadInfo = true;
            }
            logger.info("=>upload image filename:" + filename);
        }
        addMessage("File Name:" + uploadedImage.getFileName()
                + " with size " + uploadedImage.getSize() + " Uploaded Successfully");
    }

    public void onRowGenericSelection(SelectEvent event) {
        String code = (String) event.getComponent().getAttributes().get("code");
        addMessage("Selected On Row code:" + code);
        FormData formdata = new FormData();
        formdata = (FormData) event.getObject();
        if (code.equalsIgnoreCase(GenericFormType.HOTEL_CODE)) {
            updateHotel = true;
            hotelData = formdata;
        }
        if (code.equalsIgnoreCase(GenericFormType.SPONSOR_CODE)) {
            updateSponsor = true;
            sponsorData = formdata;
        }
        if (code.equalsIgnoreCase(GenericFormType.INFO_CODE)) {
            updateInfo = true;
            infoData = formdata;
        }
    }

    public void saveGenericForm(ActionEvent event) {
        String code = (String) event.getComponent().getAttributes().get("code");
        int codeType = 0;
        boolean updatemode = false;
        boolean validtype = false;
        boolean upload = false;
        FormData formdata = new FormData();
        if (code.equalsIgnoreCase(GenericFormType.HOTEL_CODE)) {
            if (updateHotel) {
                updatemode = true;
            }
            codeType = GenericFormType.HOTEL;
            formdata = hotelData;
            validtype = true;
            if (uploadHotel) {
                upload = true;
            }
        }
        if (code.equalsIgnoreCase(GenericFormType.SPONSOR_CODE)) {
            if (updateSponsor) {
                updatemode = true;
            }
            codeType = GenericFormType.SPONSOR;
            formdata = sponsorData;
            validtype = true;
            if (uploadSponsor) {
                upload = true;
            }
        }
        if (code.equalsIgnoreCase(GenericFormType.INFO_CODE)) {
            if (updateInfo) {
                updatemode = true;
            }
            codeType = GenericFormType.INFO;
            formdata = infoData;
            validtype = true;
            if (uploadInfo) {
                upload = true;
            }
        }
        if ((null == formdata.getImage() || formdata.getImage().length == 0)
                && (null == formdata.getUrl() || formdata.getUrl().length() == 0)
                && (null == formdata.getDescription() || formdata.getDescription().length() == 0)) {
            addMessage("Empty Generic Form data for:" + code, FacesMessage.SEVERITY_ERROR);
            return;
        }
        if (validtype) {
            int iret = 0;
            formdata.setCodeType(codeType);
            int fineventId = (pageType == PageType.NEW) ? tmpEventId : this.event.getId();
            formdata.setEventId(fineventId);
            if (updatemode) {
                iret = competitionService.getGenericFormProviderDao().update(formdata);
            } else {
                formdata.setImageId(0);
                iret = competitionService.getGenericFormProviderDao().insert(formdata);
            }
            if (iret > 0) {
                addMessage("Successful saving data for generic form:" + code);
                if (upload) {
                    int xret = 0;
                    if (updatemode) {
                        if (formdata.getImageId() > 0) {
                            xret = competitionService.getImageProviderDao().
                                    updateGenericFormImageFile(formdata.getImageId(), tmpLocation, formdata.getFilename(), formdata.getMimeType(), code);
                            logger.info("Generic Form Update Mode uploading return:" + xret);
                        } else {
                            int imgid = competitionService.getImageProviderDao().
                                    inserGenericFormImageFile(formdata.getId(), tmpLocation, formdata.getFilename(), formdata.getMimeType(), code);
                            logger.info("Generic Form Insert Mode uploading image id:" + imgid);
                            if (imgid > 0) {
                                xret = competitionService.getGenericFormProviderDao().updateImageId(formdata.getId(), imgid);
                            }
                        }
                    } else {
                        int imgid = competitionService.getImageProviderDao().
                                inserGenericFormImageFile(iret, tmpLocation, formdata.getFilename(), formdata.getMimeType(), code);
                        logger.info("Generic Form Insert Mode uploading image id:" + imgid);
                        if (imgid > 0) {
                            xret = competitionService.getGenericFormProviderDao().updateImageId(iret, imgid);
                        }
                    }
                    if (xret > 0) {
                        addMessage("Successful saving of Generic Form image for:" + code);
                    } else {
                        addMessage("Error saving image for generic form:" + code);
                    }
                } else {
                    addMessage("User did not upload image for form:" + code);
                }
                int genircOrder = 0;
                try {
                    genircOrder = competitionService.getGenericFormProviderDao().lastOrder(fineventId, code);
                    genircOrder++;
                    if (code.equalsIgnoreCase(GenericFormType.HOTEL_CODE)) {
                        hotelData = null;
                        hotelData = new FormData();
                        hotelData.setOrderValue(genircOrder);
                        uploadHotel = false;
                        updateHotel = false;
                    }
                    if (code.equalsIgnoreCase(GenericFormType.SPONSOR_CODE)) {
                        sponsorData = null;
                        sponsorData = new FormData();
                        sponsorData.setOrderValue(genircOrder);
                        uploadSponsor = false;
                        updateSponsor = false;
                    }
                    if (code.equalsIgnoreCase(GenericFormType.INFO_CODE)) {
                        infoData = null;
                        infoData = new FormData();
                        infoData.setOrderValue(genircOrder);
                        uploadInfo = false;
                        updateInfo = false;
                    }
                } catch (EmptyResultDataAccessException ex) {
                    logger.warn("Warning: Empty schedule list (hdrOrder) using event id:" + fineventId + " " + ex.getMessage());
                }

            } else {
                addMessage("Error saving data for generic form:" + code);
            }
        }
    }

    public void deleteGenericForm(int id) {
        faces = FacesContext.getCurrentInstance();
        Map<String, String> params = faces.getExternalContext().getRequestParameterMap();
        String code = params.get("code");
        int iret = competitionService.getGenericFormProviderDao().delete(id);
        if (iret > 0) {
            addMessage("Delete successful on  Generic form data for  :" + code + " id:" + id);
        } else {
            addMessage("Error deleting Generic form data for  :" + code + " id:" + id);
        }
    }

    public void closeDialog() {
        if (isImageUpload) {
            try {
                if (instream != null) {
                    instream.close();
                }
            } catch (IOException io) {
                io.printStackTrace();
            }
            if ((null != uploadImgFilename) && (uploadImgFilename.length() > 0)) {
                Utility.deleteFile(tmpLocation, uploadImgFilename);
            }
        }
        // add deleting of images from the temp table before calling clear temp
        if (genUploadFiles.size() > 0) {
            for (String filename : genUploadFiles) {
                Utility.deleteFile(tmpLocation, filename);
            }
        }
        resetValues();
        eventImageFile = null;
        eventImgFilename = null;
    }

    public void checkboxEnable() {
        if (!enablement.isVenueEnable()) dispDefault.setVenueDisplay(false);
        if (!enablement.isContactEnable()) dispDefault.setContactDisplay(false); 
        if (!enablement.isOrganizerEnable()) dispDefault.setOrganizerDisplay(false);
        if (!enablement.isScheduleEnable()) dispDefault.setScheduleDisplay(false);
        if (!enablement.isHotelEnable()) dispDefault.setHotelDisplay(false); 
        if (!enablement.isSponsorEnable()) dispDefault.setSponsorDisplay(false);
        if (!enablement.isInformationEnable()) dispDefault.setInformationDisplay(false);
        if (!enablement.isFinanceEnable()) dispDefault.setFinanceDisplay(false);  
    }
    
    public void checkBoxDisplayDefaultEvent() {
        dispDefault.setVenueDisplay(false);dispDefault.setContactDisplay(false); dispDefault.setOrganizerDisplay(false);
        dispDefault.setScheduleDisplay(false);dispDefault.setHotelDisplay(false); dispDefault.setSponsorDisplay(false);
        dispDefault.setInformationDisplay(false);dispDefault.setFinanceDisplay(false);        
    }
    
   public void checkBoxDisplayDefaultVenue() {
        dispDefault.setEventDisplay(false);dispDefault.setContactDisplay(false); dispDefault.setOrganizerDisplay(false);
        dispDefault.setScheduleDisplay(false);dispDefault.setHotelDisplay(false); dispDefault.setSponsorDisplay(false);
        dispDefault.setInformationDisplay(false);dispDefault.setFinanceDisplay(false);        
    }
   
    public void checkBoxDisplayDefaultContact() {
        dispDefault.setEventDisplay(false);dispDefault.setVenueDisplay(false); dispDefault.setOrganizerDisplay(false);
        dispDefault.setScheduleDisplay(false);dispDefault.setHotelDisplay(false); dispDefault.setSponsorDisplay(false);
        dispDefault.setInformationDisplay(false);dispDefault.setFinanceDisplay(false);        
    }
    
    public void checkBoxDisplayDefaultOrganizer() {
        dispDefault.setEventDisplay(false);dispDefault.setVenueDisplay(false); dispDefault.setContactDisplay(false);
        dispDefault.setScheduleDisplay(false);dispDefault.setHotelDisplay(false); dispDefault.setSponsorDisplay(false);
        dispDefault.setInformationDisplay(false);dispDefault.setFinanceDisplay(false);        
        logger.info(dispDefault.toString());
    }
    
     public void checkBoxDisplayDefaultSchedule() {
        dispDefault.setEventDisplay(false);dispDefault.setVenueDisplay(false); dispDefault.setContactDisplay(false); 
        dispDefault.setOrganizerDisplay(false);dispDefault.setHotelDisplay(false); dispDefault.setSponsorDisplay(false);
        dispDefault.setInformationDisplay(false);dispDefault.setFinanceDisplay(false);        
    }
    
    public void checkBoxDisplayDefaultHotel() {
        dispDefault.setEventDisplay(false);dispDefault.setVenueDisplay(false); dispDefault.setContactDisplay(false); 
        dispDefault.setOrganizerDisplay(false);dispDefault.setScheduleDisplay(false); dispDefault.setSponsorDisplay(false);
        dispDefault.setInformationDisplay(false);dispDefault.setFinanceDisplay(false);        
    }
    
     public void checkBoxDisplayDefaultSponsor() {
        dispDefault.setEventDisplay(false);dispDefault.setVenueDisplay(false); dispDefault.setContactDisplay(false); 
        dispDefault.setOrganizerDisplay(false);dispDefault.setScheduleDisplay(false); dispDefault.setHotelDisplay(false);
        dispDefault.setInformationDisplay(false);dispDefault.setFinanceDisplay(false);        
    }
     
    public void checkBoxDisplayDefaultInfo() {
        dispDefault.setEventDisplay(false);dispDefault.setVenueDisplay(false); dispDefault.setContactDisplay(false); 
        dispDefault.setOrganizerDisplay(false);dispDefault.setScheduleDisplay(false); dispDefault.setHotelDisplay(false);
        dispDefault.setSponsorDisplay(false);dispDefault.setFinanceDisplay(false);        
    } 
    
     public void checkBoxDisplayDefaultFinance() {
        dispDefault.setEventDisplay(false);dispDefault.setVenueDisplay(false); dispDefault.setContactDisplay(false); 
        dispDefault.setOrganizerDisplay(false);dispDefault.setScheduleDisplay(false); dispDefault.setHotelDisplay(false);
        dispDefault.setSponsorDisplay(false);dispDefault.setInformationDisplay(false); 
    } 
    
    
    
    private void resetValues() {
        int fineventId = (pageType == PageType.NEW) ? tmpEventId : this.event.getId();
        int iret = competitionService.getScheduleDataProviderDao().deleteTmpDataByID(fineventId);
        if (iret < 0) {
            logger.info("Event: error cleaning up schedlist with eventId:" + fineventId);
        }
        int nret = competitionService.getGenericFormProviderDao().cleanupTemp(fineventId);
        if (nret < 0) {
            logger.info("Event: error cleaning up generic form data with eventId:" + fineventId);
        }

        this.event = null;
        eventImage = null;
        contact = null;
        venue = null;
        schedule = null;
        scheduleData = null;
        enablement = null;
        hotelData = null;
        sponsorData = null;
        infoData = null;
        finance = null;
        for (int i = 0; i < 6; i++) {
            organizers[i] = null;
        }
        this.event = new Event();
        contact = new Contact();
        venue = new Venue();
        schedule = new Schedule();
        scheduleData = new ScheduleData();
        hotelData = new FormData();
        sponsorData = new FormData();
        infoData = new FormData();
        enablement = new Enablement();
        finance = new Finance();
        enablement.setVenueEnable(false);
        enablement.setHotelEnable(false);
        enablement.setContactEnable(false);
        enablement.setScheduleEnable(false);
        enablement.setOrganizerEnable(false);
        enablement.setSponsorEnable(false);
        enablement.setFinanceEnable(false);
        for (int i = 0; i < 6; i++) {
            organizers[i] = new Organizer();
        }
        isImageUpload = false;
        uploadImgFilename = null;
        uploadMimeType = null;
        eventImageFile = null;
        tmpEventId = 0;
        if (genUploadFiles.size() > 0) {
            for (String filename : genUploadFiles) {
                Utility.deleteFile(tmpLocation, filename);
            }
            genUploadFiles.clear();
        }
        enablement.setInformationEnable(true);
        dispDefault.setEventDisplay(false);dispDefault.setVenueDisplay(false);dispDefault.setContactDisplay(false);
        dispDefault.setOrganizerDisplay(false);dispDefault.setScheduleDisplay(false);dispDefault.setHotelDisplay(false);
        dispDefault.setSponsorDisplay(false);dispDefault.setInformationDisplay(true);dispDefault.setFinanceDisplay(false);  
    }

    private void resetScheduleData() {
        scheduleData = null;
        scheduleData = new ScheduleData();
        scheduleData.setTimeValue("");
        scheduleData.setDescription("");
        scheduleData.setHeaderName("");
        updateSchedData = false;
    }

    private void loadImage() {
        try {
            if (isImageUpload) {
                logger.info("=>mimetype:" + uploadMimeType
                        + " filename:" + uploadImgFilename);
                instream = new FileInputStream(new File(tmpLocation, uploadImgFilename));
                eventImageFile = new DefaultStreamedContent(instream, uploadMimeType, eventImgFilename);
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    
    private boolean isDisplayDefaultHasValue() {
        if (dispDefault.isEventDisplay()) return true;
        if (dispDefault.isVenueDisplay()) return true;
        if (dispDefault.isContactDisplay()) return true;
        if (dispDefault.isOrganizerDisplay()) return true;
        if (dispDefault.isScheduleDisplay()) return true;
        if (dispDefault.isHotelDisplay()) return true;
        if (dispDefault.isSponsorDisplay()) return true;
        if (dispDefault.isInformationDisplay()) return true;
        if (dispDefault.isFinanceDisplay()) return true;  
        return false;
    }
    
    
    
    /**
     * @return the eventImageFile
     */
    public StreamedContent getEventImageFile() {
        return eventImageFile;
    }

    /**
     * @return the competition
     */
    public Competition getCompetition() {
        return competition;
    }

    /**
     * @param competition the competition to set
     */
    public void setCompetition(Competition competition) {
        this.competition = competition;
    }

    /**
     * @return the event
     */
    public Event getEvent() {
        return event;
    }

    /**
     * @param event the event to set
     */
    public void setEvent(Event event) {
        this.event = event;
    }

    /**
     * @return the venue
     */
    public Venue getVenue() {
        return venue;
    }

    /**
     * @param venue the venue to set
     */
    public void setVenue(Venue venue) {
        this.venue = venue;
    }

    /**
     * @return the organizer
     */
    public Organizer getOrganizer() {
        return organizer;
    }

    /**
     * @param organizer the organizer to set
     */
    public void setOrganizer(Organizer organizer) {
        this.organizer = organizer;
    }

    /**
     * @return the contact
     */
    public Contact getContact() {
        return contact;
    }

    /**
     * @param contact the contact to set
     */
    public void setContact(Contact contact) {
        this.contact = contact;
    }

    /**
     * @return the organizers
     */
    public Organizer[] getOrganizers() {
        return organizers;
    }

    /**
     * @param organizers the organizers to set
     */
    public void setOrganizers(Organizer[] organizers) {
        this.organizers = organizers;
    }

    /**
     * @return the competitionService
     */
    public CompetitionService getCompetitionService() {
        return competitionService;
    }

    /**
     * @param competitionService the competitionService to set
     */
    public void setCompetitionService(CompetitionService competitionService) {
        this.competitionService = competitionService;
    }

    /**
     * @return the eventStatusList
     */
    public List<LookUp> getEventStatusList() {
        return eventStatusList;
    }

    /**
     * @param eventStatusList the eventStatusList to set
     */
    public void setEventStatusList(List<LookUp> eventStatusList) {
        this.eventStatusList = eventStatusList;
    }

    /**
     * @return the selectCompetition
     */
    public Competition getSelectCompetition() {
        return selectCompetition;
    }

    /**
     * @param selectCompetition the selectCompetition to set
     */
    public void setSelectCompetition(Competition selectCompetition) {
        this.selectCompetition = selectCompetition;
    }

    /**
     * @return the selectEvent
     */
    public Event getSelectEvent() {
        return selectEvent;
    }

    /**
     * @param selectEvent the selectEvent to set
     */
    public void setSelectEvent(Event selectEvent) {
        this.selectEvent = selectEvent;
    }

    /**
     * @return the pageType
     */
    public int getPageType() {
        return pageType;
    }

    /**
     * @param pageType the pageType to set
     */
    public void setPageType(int pageType) {
        this.pageType = pageType;
    }

    /**
     * @return the disable
     */
    public boolean isDisable() {
        return disable;
    }

    /**
     * @param disable the disable to set
     */
    public void setDisable(boolean disable) {
        this.disable = disable;
    }

    /**
     * @return the selectTab
     */
    public int getSelectTab() {
        return selectTab;
    }

    /**
     * @param selectTab the selectTab to set
     */
    public void setSelectTab(int selectTab) {
        this.selectTab = selectTab;
    }

    /**
     * @return the competitionList
     */
    public LazyDataModel<Competition> getCompetitionList() {
        if (competitionList == null) {
            competitionList = new CompetitionLazyList(competitionService);
        }
        return competitionList;
    }

    /**
     * @param competitionList the competitionList to set
     */
    public void setCompetitionList(LazyDataModel<Competition> competitionList) {
        this.competitionList = competitionList;
    }

    /**
     * @return the eventList
     */
    public LazyDataModel<Event> getEventList() {
        if (eventList == null) {
            eventList = new EventLazyList(competitionService);
        }
        return eventList;
    }

    /**
     * @param eventList the eventList to set
     */
    public void setEventList(LazyDataModel<Event> eventList) {
        this.eventList = eventList;
    }

    /**
     * @param eventImageFile the eventImageFile to set
     */
    public void setEventImageFile(StreamedContent eventImageFile) {
        this.eventImageFile = eventImageFile;
    }

    /**
     * @return the noyesLIst
     */
    public List<LookUp> getNoyesLIst() {
        return noyesLIst;
    }

    /**
     * @param noyesLIst the noyesLIst to set
     */
    public void setNoyesLIst(List<LookUp> noyesLIst) {
        this.noyesLIst = noyesLIst;
    }

    /**
     * @return the publishStatusList
     */
    public List<LookUp> getPublishStatusList() {
        return publishStatusList;
    }

    /**
     * @param publishStatusList the publishStatusList to set
     */
    public void setPublishStatusList(List<LookUp> publishStatusList) {
        this.publishStatusList = publishStatusList;
    }

    /**
     * @return the eventImage
     */
    public Image getEventImage() {
        return eventImage;
    }

    /**
     * @param eventImage the eventImage to set
     */
    public void setEventImage(Image eventImage) {
        this.eventImage = eventImage;
    }

    /**
     * @return the published
     */
    public boolean isPublished() {
        return published;
    }

    /**
     * @param published the published to set
     */
    public void setPublished(boolean published) {
        this.published = published;
    }

    /**
     * @return the publishedStatus
     */
    public String getPublishedStatus() {
        return publishedStatus;
    }

    /**
     * @param publishedStatus the publishedStatus to set
     */
    public void setPublishedStatus(String publishedStatus) {
        this.publishedStatus = publishedStatus;
    }

    /**
     * @return the checkBoxDisabled
     */
    public boolean isCheckBoxDisabled() {
        return checkBoxDisabled;
    }

    /**
     * @param checkBoxDisabled the checkBoxDisabled to set
     */
    public void setCheckBoxDisabled(boolean checkBoxDisabled) {
        this.checkBoxDisabled = checkBoxDisabled;
    }

    /**
     * @return the eventImgFilename
     */
    public String getEventImgFilename() {
        return eventImgFilename;
    }

    /**
     * @param eventImgFilename the eventImgFilename to set
     */
    public void setEventImgFilename(String eventImgFilename) {
        this.eventImgFilename = eventImgFilename;
    }

    /**
     * @return the republished
     */
    public boolean isRepublished() {
        return republished;
    }

    /**
     * @param republished the republished to set
     */
    public void setRepublished(boolean republished) {
        this.republished = republished;
    }

    /**
     * @return the repubrendered
     */
    public boolean isRepubrendered() {
        return repubrendered;
    }

    /**
     * @param repubrendered the repubrendered to set
     */
    public void setRepubrendered(boolean repubrendered) {
        this.repubrendered = repubrendered;
    }

    /**
     * @return the checkBoxRePubDisabled
     */
    public boolean isCheckBoxRePubDisabled() {
        return checkBoxRePubDisabled;
    }

    /**
     * @param checkBoxRePubDisabled the checkBoxRePubDisabled to set
     */
    public void setCheckBoxRePubDisabled(boolean checkBoxRePubDisabled) {
        this.checkBoxRePubDisabled = checkBoxRePubDisabled;
    }

    /**
     * @return the renderLastUpdate
     */
    public boolean isRenderLastUpdate() {
        return renderLastUpdate;
    }

    /**
     * @param renderLastUpdate the renderLastUpdate to set
     */
    public void setRenderLastUpdate(boolean renderLastUpdate) {
        this.renderLastUpdate = renderLastUpdate;
    }

    /**
     * @return the imgStyle
     */
    public String getImgStyle() {
        return imgStyle;
    }

    /**
     * @param imgStyle the imgStyle to set
     */
    public void setImgStyle(String imgStyle) {
        this.imgStyle = imgStyle;
    }

    /**
     * @return the uberRegister
     */
    public String getUberRegister() {
        return uberRegister;
    }

    /**
     * @param uberRegister the uberRegister to set
     */
    public void setUberRegister(String uberRegister) {
        this.uberRegister = uberRegister;
    }

    /**
     * @return the disableURegister
     */
    public boolean isDisableURegister() {
        return disableURegister;
    }

    /**
     * @param disableURegister the disableURegister to set
     */
    public void setDisableURegister(boolean disableURegister) {
        this.disableURegister = disableURegister;
    }

    /**
     * @return the schedule
     */
    public Schedule getSchedule() {
        return schedule;
    }

    /**
     * @param schedule the schedule to set
     */
    public void setSchedule(Schedule schedule) {
        this.schedule = schedule;
    }

    /**
     * @return the scheduleData
     */
    public ScheduleData getScheduleData() {
        return scheduleData;
    }

    /**
     * @param scheduleData the scheduleData to set
     */
    public void setScheduleData(ScheduleData scheduleData) {
        this.scheduleData = scheduleData;
    }

    /**
     * @return the schedDataList
     */
    public LazyDataModel<ScheduleData> getSchedDataList() {
        return schedDataList;
    }

    /**
     * @param schedDataList the schedDataList to set
     */
    public void setSchedDataList(LazyDataModel<ScheduleData> schedDataList) {
        this.schedDataList = schedDataList;
    }

    /**
     * @return the selectedScheduleData
     */
    public ScheduleData getSelectedScheduleData() {
        return selectedScheduleData;
    }

    /**
     * @param selectedScheduleData the selectedScheduleData to set
     */
    public void setSelectedScheduleData(ScheduleData selectedScheduleData) {
        this.selectedScheduleData = selectedScheduleData;
    }

    /**
     * @return the updateShedData
     */
    public boolean isUpdateSchedData() {
        return updateSchedData;
    }

    /**
     * @param updateShedData the updateShedData to set
     */
    public void setUpdateShedData(boolean updateShedData) {
        this.updateSchedData = updateShedData;
    }

    /**
     * @return the schedDataHeaderNames
     */
    public Map<String, String> getSchedDataHeaderNames() {
        return schedDataHeaderNames;
    }

    /**
     * @param schedDataHeaderNames the schedDataHeaderNames to set
     */
    public void setSchedDataHeaderNames(Map<String, String> schedDataHeaderNames) {
        this.schedDataHeaderNames = schedDataHeaderNames;
    }

    /**
     * @return the enablement
     */
    public Enablement getEnablement() {
        return enablement;
    }

    /**
     * @param enablement the enablement to set
     */
    public void setEnablement(Enablement enablement) {
        this.enablement = enablement;
    }

    /**
     * @return the renderLastPublish
     */
    public boolean isRenderLastPublish() {
        return renderLastPublish;
    }

    /**
     * @param renderLastPublish the renderLastPublish to set
     */
    public void setRenderLastPublish(boolean renderLastPublish) {
        this.renderLastPublish = renderLastPublish;
    }

    /**
     * @return the hotelData
     */
    public FormData getHotelData() {
        return hotelData;
    }

    /**
     * @param hotelData the hotelData to set
     */
    public void setHotelData(FormData hotelData) {
        this.hotelData = hotelData;
    }

    /**
     * @return the sponsorData
     */
    public FormData getSponsorData() {
        return sponsorData;
    }

    /**
     * @param sponsorData the sponsorData to set
     */
    public void setSponsorData(FormData sponsorData) {
        this.sponsorData = sponsorData;
    }

    /**
     * @return the infoData
     */
    public FormData getInfoData() {
        return infoData;
    }

    /**
     * @param infoData the infoData to set
     */
    public void setInfoData(FormData infoData) {
        this.infoData = infoData;
    }

    /**
     * @return the hotelDataList
     */
    public LazyDataModel<FormData> getHotelDataList() {
        return hotelDataList;
    }

    /**
     * @param hotelDataList the hotelDataList to set
     */
    public void setHotelDataList(LazyDataModel<FormData> hotelDataList) {
        this.hotelDataList = hotelDataList;
    }

    /**
     * @return the sponsorDataList
     */
    public LazyDataModel<FormData> getSponsorDataList() {
        return sponsorDataList;
    }

    /**
     * @param sponsorDataList the sponsorDataList to set
     */
    public void setSponsorDataList(LazyDataModel<FormData> sponsorDataList) {
        this.sponsorDataList = sponsorDataList;
    }

    /**
     * @return the infoDataList
     */
    public LazyDataModel<FormData> getInfoDataList() {
        return infoDataList;
    }

    /**
     * @param infoDataList the infoDataList to set
     */
    public void setInfoDataList(LazyDataModel<FormData> infoDataList) {
        this.infoDataList = infoDataList;
    }

    /**
     * @return the selectedHotelData
     */
    public FormData getSelectedHotelData() {
        return selectedHotelData;
    }

    /**
     * @param selectedHotelData the selectedHotelData to set
     */
    public void setSelectedHotelData(FormData selectedHotelData) {
        this.selectedHotelData = selectedHotelData;
    }

    /**
     * @return the selectedSponsorData
     */
    public FormData getSelectedSponsorData() {
        return selectedSponsorData;
    }

    /**
     * @param selectedSponsorData the selectedSponsorData to set
     */
    public void setSelectedSponsorData(FormData selectedSponsorData) {
        this.selectedSponsorData = selectedSponsorData;
    }

    /**
     * @return the selectedInfoData
     */
    public FormData getSelectedInfoData() {
        return selectedInfoData;
    }

    /**
     * @param selectedInfoData the selectedInfoData to set
     */
    public void setSelectedInfoData(FormData selectedInfoData) {
        this.selectedInfoData = selectedInfoData;
    }

    /**
     * @return the updateHotel
     */
    public boolean isUpdateHotel() {
        return updateHotel;
    }

    /**
     * @param updateHotel the updateHotel to set
     */
    public void setUpdateHotel(boolean updateHotel) {
        this.updateHotel = updateHotel;
    }

    /**
     * @return the updateSponsor
     */
    public boolean isUpdateSponsor() {
        return updateSponsor;
    }

    /**
     * @param updateSponsor the updateSponsor to set
     */
    public void setUpdateSponsor(boolean updateSponsor) {
        this.updateSponsor = updateSponsor;
    }

    /**
     * @return the updateInfo
     */
    public boolean isUpdateInfo() {
        return updateInfo;
    }

    /**
     * @param updateInfo the updateInfo to set
     */
    public void setUpdateInfo(boolean updateInfo) {
        this.updateInfo = updateInfo;
    }

    /**
     * @return the uploadHotel
     */
    public boolean isUploadHotel() {
        return uploadHotel;
    }

    /**
     * @param uploadHotel the uploadHotel to set
     */
    public void setUploadHotel(boolean uploadHotel) {
        this.uploadHotel = uploadHotel;
    }

    /**
     * @return the uploadSponsor
     */
    public boolean isUploadSponsor() {
        return uploadSponsor;
    }

    /**
     * @param uploadSponsor the uploadSponsor to set
     */
    public void setUploadSponsor(boolean uploadSponsor) {
        this.uploadSponsor = uploadSponsor;
    }

    /**
     * @return the uploadInfo
     */
    public boolean isUploadInfo() {
        return uploadInfo;
    }

    /**
     * @param uploadInfo the uploadInfo to set
     */
    public void setUploadInfo(boolean uploadInfo) {
        this.uploadInfo = uploadInfo;
    }

    /**
     * @return the genUploadFiles
     */
    public List<String> getGenUploadFiles() {
        return genUploadFiles;
    }

    /**
     * @param genUploadFiles the genUploadFiles to set
     */
    public void setGenUploadFiles(List<String> genUploadFiles) {
        this.genUploadFiles = genUploadFiles;
    }

    /**
     * @return the imageDimension
     */
    public ImageDimension getImageDimension() {
        return imageDimension;
    }

    /**
     * @param imageDimension the imageDimension to set
     */
    public void setImageDimension(ImageDimension imageDimension) {
        this.imageDimension = imageDimension;
    }

    /**
     * @return the finance
     */
    public Finance getFinance() {
        return finance;
    }

    /**
     * @param finance the finance to set
     */
    public void setFinance(Finance finance) {
        this.finance = finance;
    }

    /**
     * @return the eventSummary
     */
    public EventSummary getEventSummary() {
        return eventSummary;
    }

    /**
     * @param eventSummary the eventSummary to set
     */
    public void setEventSummary(EventSummary eventSummary) {
        this.eventSummary = eventSummary;
    }

    /**
     * @return the editScheduleHeaderEnabled
     */
    public boolean isEditScheduleHeaderEnabled() {
        return editScheduleHeaderEnabled;
    }

    /**
     * @param editScheduleHeaderEnabled the editScheduleHeaderEnabled to set
     */
    public void setEditScheduleHeaderEnabled(boolean editScheduleHeaderEnabled) {
        this.editScheduleHeaderEnabled = editScheduleHeaderEnabled;
    }

    /**
     * @return the editScheduleHeaderString
     */
    public String getEditScheduleHeaderString() {
        return editScheduleHeaderString;
    }

    /**
     * @param editScheduleHeaderString the editScheduleHeaderString to set
     */
    public void setEditScheduleHeaderString(String editScheduleHeaderString) {
        this.editScheduleHeaderString = editScheduleHeaderString;
    }

    /**
     * @return the eventComparisonList
     */
    public LazyDataModel<Event> getEventComparisonList() {
        if (eventComparisonList == null) {
            eventComparisonList = new EventComparisonLazyList(competitionService);
        }
        return eventComparisonList;
    }

    /**
     * @param eventComparisonList the eventComparisonList to set
     */
    public void setEventComparisonList(LazyDataModel<Event> eventComparisonList) {
        this.eventComparisonList = eventComparisonList;
    }

    /**
     * @return the RTDBEvents
     */
    public Map<String, String> getRTDBEvents() {
        return RTDBEvents;
    }

    /**
     * @param RTDBEvents the RTDBEvents to set
     */
    public void setRTDBEvents(Map<String, String> RTDBEvents) {
        this.RTDBEvents = RTDBEvents;
    }

    /**
     * @return the RTDBUnmatchedEvents
     */
    public List<String> getRTDBUnmatchedEvents() {
        return RTDBUnmatchedEvents;
    }

    /**
     * @param RTDBUnmatchedEvents the RTDBUnmatchedEvents to set
     */
    public void setRTDBUnmatchedEvents(List<String> RTDBUnmatchedEvents) {
        this.RTDBUnmatchedEvents = RTDBUnmatchedEvents;
    }

    /**
     * @return the systemConfigService
     */
    public SystemConfigService getSystemConfigService() {
        return systemConfigService;
    }

    /**
     * @param systemConfigService the systemConfigService to set
     */
    public void setSystemConfigService(SystemConfigService systemConfigService) {
        this.systemConfigService = systemConfigService;
    }

    /**
     * @return the eventPaymentMethods
     */
    public Map<String, Boolean> getEventPaymentMethods() {
        return eventPaymentMethods;
    }

    /**
     * @param eventPaymentMethods the eventPaymentMethods to set
     */
    public void setEventPaymentMethods(Map<String, Boolean> eventPaymentMethods) {
        this.eventPaymentMethods = eventPaymentMethods;
    }

    /**
     * @return the selectedPaymentMethods
     */
    public String getSelectedPaymentMethods() {
        return selectedPaymentMethods;
    }

    /**
     * @param selectedPaymentMethods the selectedPaymentMethods to set
     */
    public void setSelectedPaymentMethods(String selectedPaymentMethods) {
        this.selectedPaymentMethods = selectedPaymentMethods;
    }

    /**
     * @return the dispDefault
     */
    public DisplayDefault getDispDefault() {
        return dispDefault;
    }

    /**
     * @param dispDefault the dispDefault to set
     */
    public void setDispDefault(DisplayDefault dispDefault) {
        this.dispDefault = dispDefault;
    }

    /**
     * @return the displayUID
     */
    public boolean isDisplayUID() {
        return displayUID;
    }

    /**
     * @param displayUID the displayUID to set
     */
    public void setDisplayUID(boolean displayUID) {
        this.displayUID = displayUID;
    }
	
	/**
     * @return the venueCountryList
     */
    public List<LookUp> getVenueCountryList() {
        return venueCountryList;
    }

    /**
     * @param venueCountryList the venueCountryList to set
     */
    public void setVenueCountryList(List<LookUp> venueCountryList) {
        this.venueCountryList = venueCountryList;
    }

}
