/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.lazy.competition;

import com.danceframe.console.common.model.heatlist.result.MasterPerson;
import com.danceframe.console.common.model.invoice.InvoicePayment;
import com.danceframe.console.web.service.HeatListResultService;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

/**
 *
 * @author lmorallos
 */
public class MasterPersonLazyList extends LazyDataModel<MasterPerson> {
    
    private static final Logger logger = LogManager.getLogger(MasterPersonLazyList.class);
    
    private HeatListResultService heatListResultService;

    private List<MasterPerson> masterPersons;
    private int rowCount;
    
     public MasterPersonLazyList(HeatListResultService heatListResultService) {
        this.heatListResultService = heatListResultService;
    }
    
     public List<MasterPerson> load(int first, int pageSize, String sortField,
                             SortOrder sortOrder, Map<String, Object> filters) {
           // filters can be here
       String wherestr = new String();
       String wherecnt = new String();
        
       if (filters.containsKey("lastname")) {
           String value = (String)filters.get("lastname");
           if (value.length() > 0)
           {
               wherestr = wherestr + " WHERE UPPER(lastname) like '" + value.toUpperCase() + "%'";
              
           }
       }
        wherecnt = wherestr;
        // sorting
        String sortSql = new String();
        if (sortField != null) {
            if (sortField.equalsIgnoreCase("lastname")) {
                sortSql = " ORDER BY lastname, firstname ASC";
            } 
         } else {
            sortSql = " ORDER BY lastname, firstname ASC";
            
        }
        wherestr += sortSql;
        logger.info("Page Query (sortfield):(" + sortField + ") " +  wherestr);
        masterPersons = heatListResultService.getHeatListResultMasterPersonProviderDao().getAllWithPaging(wherestr, 
                       pageSize, first);
        Long rc = (Long)heatListResultService.getHeatListResultMasterPersonProviderDao().getAllCount(wherecnt);
        
        rowCount = rc.intValue();
        setPageSize(pageSize);
        return masterPersons;           
    }

     @Override
    public Object getRowKey(MasterPerson person) {
        return person.getId();
    }
    
    @Override
    public MasterPerson getRowData(String pid) {
        Integer id = Integer.valueOf(pid);
        for (MasterPerson person : masterPersons) {
            if(id.equals(person.getId())){
                return person;
            }
        }
        return null;
    }
    
    /**
     * @return the heatListResultService
     */
    public HeatListResultService getHeatListResultService() {
        return heatListResultService;
    }

    /**
     * @param heatListResultService the heatListResultService to set
     */
    public void setHeatListResultService(HeatListResultService heatListResultService) {
        this.heatListResultService = heatListResultService;
    }

    /**
     * @return the masterPersons
     */
    public List<MasterPerson> getMasterPersons() {
        return masterPersons;
    }

    /**
     * @param masterPersons the masterPersons to set
     */
    public void setMasterPersons(List<MasterPerson> masterPersons) {
        this.masterPersons = masterPersons;
    }

    /**
     * @return the rowCount
     */
    public int getRowCount() {
        return rowCount;
    }

    /**
     * @param rowCount the rowCount to set
     */
    public void setRowCount(int rowCount) {
        this.rowCount = rowCount;
    }
    
}
