/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.service.util;

import java.io.Serializable;
import java.util.Properties;
import javax.annotation.Resource;
import org.springframework.stereotype.Component;

/**
 *
 * @author lmorallos
 */
@Component("appInfo")
public class AppInfo implements Serializable {
    
    
    @Resource(name="ydsProperties")
    private Properties ydsProperties;
     
    private String buildVersion;    
    private String buildDate;
    private String imgDirectory;
    private String tmpDirectory;

    /**
     * @return the buildVersion
     */
    public String getBuildVersion() {
        return ydsProperties.getProperty("build.version");
    }
    
    /**
     * @return the buildDate
     */
    public String getBuildDate() {
        return ydsProperties.getProperty("build.date");
    }

    /**
     * @return the imgDirectory
     */
    public String getImgDirectory() {
       return ydsProperties.getProperty("image.directory");
    }

    /**
     * @return the tmpDirectory
     */
    public String getTmpDirectory() {
       return ydsProperties.getProperty("temp.directory");
    }
    
    
}
