/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.service;

import com.danceframe.console.service.dataprovider.heatlist.HeatListProviderDao;
import com.danceframe.console.service.file.heatlist.HeatListReader;
import com.danceframe.console.service.file.heatlist.HeatListWriter;
import java.io.Serializable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author lmorallos
 */
@Service("heatListService")
public class HeatListService implements Serializable{
    
    private static final long serialVersionUID = 1L;
    
    @Autowired
    private HeatListWriter heatListWriter;
    
    @Autowired
    private HeatListReader heatListReader;
    
    @Autowired
    private HeatListProviderDao heatListProviderDao;

    /**
     * @return the heatListWriter
     */
    public HeatListWriter getHeatListWriter() {
        return heatListWriter;
    }

    /**
     * @param heatListWriter the heatListWriter to set
     */
    public void setHeatListWriter(HeatListWriter heatListWriter) {
        this.heatListWriter = heatListWriter;
    }

    /**
     * @return the heatListReader
     */
    public HeatListReader getHeatListReader() {
        return heatListReader;
    }

    /**
     * @param heatListReader the heatListReader to set
     */
    public void setHeatListReader(HeatListReader heatListReader) {
        this.heatListReader = heatListReader;
    }

    /**
     * @return the heatListProviderDao
     */
    public HeatListProviderDao getHeatListProviderDao() {
        return heatListProviderDao;
    }

    /**
     * @param heatListProviderDao the heatListProviderDao to set
     */
    public void setHeatListProviderDao(HeatListProviderDao heatListProviderDao) {
        this.heatListProviderDao = heatListProviderDao;
    }
    
    
    
}
