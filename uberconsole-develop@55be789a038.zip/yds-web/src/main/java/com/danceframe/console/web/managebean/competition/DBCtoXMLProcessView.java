/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.managebean.competition;

import com.danceframe.compmgr.binary.service.file.XMLGenerator;
import com.danceframe.console.common.exception.YDSException;
import com.danceframe.console.common.util.Utility;
import com.danceframe.console.service.dataprovider.competition.EventProviderDao;
import com.danceframe.console.service.file.xml.CompManagerXMLWriter;
import com.danceframe.console.web.managebean.BaseBean;
import com.danceframe.console.web.service.DBCtoXMLService;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.primefaces.model.UploadedFile;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 *
 * @author ftangente
 */
@ManagedBean (name="dbctoxmlProcessView")
@ViewScoped
public class DBCtoXMLProcessView extends BaseBean implements Serializable {
    
    private static final Logger logger = LogManager.getLogger(DBCtoXMLProcessView.class);
    private static final String URL = "http://localhost:8080/uberSync/SyncForm";
	private XMLGenerator xmlGenerator;
    
    @ManagedProperty(value="#{dbctoxmlService}")
    private DBCtoXMLService dbctoxmlService;
    
    private static final long serialVersionUID = 1L;
    private StreamedContent         xmlDownload;
    
    private UploadedFile        xmlFile;
    private boolean             useManual;
    private boolean             disableUpload;
    private String              tmpLocation;
    private String              newXMLFile;
    private String              uploadXMLBaseFile;
    private String              uploadDBCBaseFile;
    private boolean             isXMLUpload;
    private boolean             isDBCUpload;
    private StreamedContent     downloadFile;
    private boolean             isJsonError;
    private String              newDBCFile;
    private String              baseFilename;
    private StreamedContent generatedXML;
    private boolean         allowedDownload;
    private StreamedContent logFile;
    private StreamedContent debugFile;
    
    
    
    @PostConstruct
    public void init() {

        tmpLocation =  System.getProperty("java.io.tmpdir") + File.separator;
        logger.info("==>>INIT tmp location:"  +  tmpLocation);
        
        newDBCFile = new String();
        newXMLFile = new String();
        allowedDownload = false;

    }
    
    
    
    public void processXML() throws YDSException, IOException {
                
				boolean debug = true;
                ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("uaydsServiceConfig.xml");
                EventProviderDao eventProviderDao = (EventProviderDao) ctx.getBean("eventProviderDao");
                CompManagerXMLWriter compManagerXMLWriter = (CompManagerXMLWriter)ctx.getBean("compManagerXMLWriter");
                newXMLFile = newDBCFile.replaceAll(".dbc", "") + ".xml";
                String filename = newDBCFile.replaceAll(".dbc", "") + ".xml";
                
                String errfile = tmpLocation + newXMLFile.replaceAll(".xml", "") + "Debug.log";
                String logfile = tmpLocation + newXMLFile.replaceAll(".xml", "") + "Log.log";
                String mimeType = "text/txt";
                String xmlfilename = tmpLocation + newXMLFile;
                String infile = tmpLocation + newDBCFile;
                
                boolean quite = true;
                ClassPathXmlApplicationContext cty = new ClassPathXmlApplicationContext("springCompMgrService.xml");
                XMLGenerator xmlGenerator = (XMLGenerator)cty.getBean("xmlGenerator");
                
                
                
                try {
                    if (compManagerXMLWriter.createXMLOutput(tmpLocation, newDBCFile, filename, debug)) {
                        xmlGenerator.setErrorfile(errfile);
                        xmlGenerator.setLogfile(logfile);
                        xmlGenerator.setNoStatistics(false);
                        xmlGenerator.setQuite(quite);
                        xmlGenerator.setDebug(debug);
                        xmlGenerator.binaryToXML(infile, xmlfilename, true);
                        System.out.println("Log Downloaded");
                
                        System.out.println("XML Created.");
                        addMessage("DBC to XML Convertion Successful.", FacesMessage.SEVERITY_INFO); 
                    }
                   
                } catch (YDSException ex) {
                    ex.printStackTrace();
                }

    }
    
    public void downloadXML() throws YDSException, FileNotFoundException, IOException {
        
               String mimeType = "text/xml";
               String filename = newDBCFile.replaceAll(".dbc", "") + ".xml";
               generatedXML = null;
               allowedDownload = false;

                File genfile = new File(tmpLocation, filename);
                if (genfile.exists()) {
                    byte[] contents = new byte[(int)genfile.length()];
                    FileInputStream fis = new FileInputStream(genfile);
                    fis.read(contents);
                    fis.close();
                    generatedXML = new DefaultStreamedContent(
                            new ByteArrayInputStream(contents),
                            mimeType,filename);

                    allowedDownload = true;
                }
              
                
    }
	
	public void downloadLog() throws YDSException, FileNotFoundException, IOException {
        
        String logfile = newXMLFile.replaceAll(".xml", "") + "Log.log";
        String mimeType = "text/txt";
        logFile = null;
        allowedDownload = false;
        
        File genfile = new File(tmpLocation,logfile);
        if (genfile.exists()) {
            byte[] contents = new byte[(int)genfile.length()];
            FileInputStream fis = new FileInputStream(genfile);
            fis.read(contents);
            fis.close();
            logFile = new DefaultStreamedContent(
                    new ByteArrayInputStream(contents),
                    mimeType,logfile);
            
            allowedDownload = true;
        }
    }
	
	public void downloadDebug() throws YDSException, FileNotFoundException, IOException {
              
               String debugfile = newXMLFile.replaceAll(".xml", "") + "Debug.log";
               String mimeType = "text/txt";
               debugFile = null;
               allowedDownload = false;

                File genfile = new File(tmpLocation,debugfile);
                if (genfile.exists()) {
                    byte[] contents = new byte[(int)genfile.length()];
                    FileInputStream fis = new FileInputStream(genfile);
                    fis.read(contents);
                    fis.close();
                    debugFile = new DefaultStreamedContent(
                            new ByteArrayInputStream(contents),
                            mimeType,debugfile);

                    allowedDownload = true;
                }
            
    }
    
    
    public void uploadDBC(FileUploadEvent event) throws IOException{
        UploadedFile uploadedDBCFile = event.getFile();
        byte[] bytes=null;
        
        if (null!=uploadedDBCFile) {
            if (isDBCUpload) tempFileCleaner();
            isJsonError = false;
            newDBCFile = uploadedDBCFile.getFileName();
            addMessage("Uploading DBC File:" + newDBCFile);    
            bytes = uploadedDBCFile.getContents();
            String fileprefix = Utility.getFilename(newXMLFile); 
            String dbcfilename = uploadedDBCFile.getFileName();

            BufferedOutputStream stream = new BufferedOutputStream(
                        new FileOutputStream(new File(tmpLocation,dbcfilename)));
            stream.write(bytes);
            stream.flush();
            stream.close();
            stream = null;
            
            uploadDBCBaseFile = dbcfilename;
            logger.info("=== basefile:" + uploadDBCBaseFile + " dbcfle:" + dbcfilename);
            isDBCUpload = true;
        }
            
    }
    
    
    
    private void tempFileCleaner() {
        
        String stufilename = baseFilename + ".stu";
        String xmlallfile = baseFilename + "-all.xml";
        String ubcxmlfile = baseFilename + "-ubc.xml";
        String jsonfile = baseFilename + ".json";
        String dbcfilename = baseFilename + ".dbc";
        
        if (Utility.deleteFile(tmpLocation, stufilename)) {
            logger.info("delete (ok):" + tmpLocation + ":" + stufilename);
      
        }
        if (Utility.deleteFile(tmpLocation, xmlallfile)) {
            logger.info("delete (ok):" + tmpLocation + ":" + xmlallfile);
      
        }
        if (Utility.deleteFile(tmpLocation, ubcxmlfile)) {
            logger.info("delete (ok):" + tmpLocation + ":" + ubcxmlfile);
      
        }
        if (Utility.deleteFile(tmpLocation, jsonfile)) {
            logger.info("delete (ok):" + tmpLocation + ":" + jsonfile);
      
        }
        if (Utility.deleteFile(tmpLocation, dbcfilename)) {
            logger.info("delete (ok):" + tmpLocation + ":" + dbcfilename);
      
        }

        String xmlfile = uploadXMLBaseFile + ".xml";
        if (Utility.deleteFile(tmpLocation, xmlfile)) {
            logger.info("delete (ok):" + tmpLocation + ":" + xmlfile);
        } else {
            logger.info("delete (error):" + tmpLocation + ":" + xmlfile);
        }
        
        jsonfile = uploadXMLBaseFile + ".json";
        if (Utility.deleteFile(tmpLocation, jsonfile)) {
            logger.info("delete (ok):" + tmpLocation + ":" + jsonfile);
        } else {
            logger.info("delete (error):" + tmpLocation + ":" + jsonfile);
        }
    }
    
	/**
     * @return the dbctoxmlService
     */
    public DBCtoXMLService getDbctoxmlService() {
        return dbctoxmlService;
    }

    /**
     * @param dbctoxmlService the dbctoxmlService to set
     */
    public void setDbctoxmlService(DBCtoXMLService dbctoxmlService) {
        this.dbctoxmlService = dbctoxmlService;
    }

    /**
     * @return the xmlFile
     */
    public UploadedFile getXmlFile() {
        return xmlFile;
    }

    /**
     * @param xmlFile the xmlFile to set
     */
    public void setXmlFile(UploadedFile xmlFile) {
        this.xmlFile = xmlFile;
    }

    /**
     * @return the useManual
     */
    public boolean isUseManual() {
        return useManual;
    }

    /**
     * @param useManual the useManual to set
     */
    public void setUseManual(boolean useManual) {
        this.useManual = useManual;
    }

    /**
     * @return the disableUpload
     */
    public boolean isDisableUpload() {
        return disableUpload;
    }

    /**
     * @param disableUpload the disableUpload to set
     */
    public void setDisableUpload(boolean disableUpload) {
        this.disableUpload = disableUpload;
    }

    /**
     * @return the newXMLFile
     */
    public String getNewXMLFile() {
        return newXMLFile;
    }

    /**
     * @param newXMLFile the newXMLFile to set
     */
    public void setNewXMLFile(String newXMLFile) {
        this.newXMLFile = newXMLFile;
    }

    /**
     * @return the downloadFile
     */
    public StreamedContent getDownloadFile() {
        return downloadFile;
    }

    /**
     * @param downloadFile the downloadFile to set
     */
    public void setDownloadFile(StreamedContent downloadFile) {
        this.downloadFile = downloadFile;
    }

    
   /**
     * @return the newDBCFile
     */
    public String getNewDBCFile() {
        return newDBCFile;
    }

    /**
     * @param newSTUFile the newDBCFile to set
     */
    public void setNewDBCFile(String newDBCFile) {
        this.newDBCFile = newDBCFile;
    }

    /**
     * @return the baseFilename
     */
    public String getBaseFilename() {
        return baseFilename;
    }

    /**
     * @param baseFilename the baseFilename to set
     */
    public void setBaseFilename(String baseFilename) {
        this.baseFilename = baseFilename;
    }
    
    /**
     * @return the generatedXML
     */
    public StreamedContent getGeneratedXML() {
        return generatedXML;
    }

    /**
     * @param generatedXML the generatedXML to set
     */
    public void setGeneratedXML(StreamedContent generatedXML) {
        this.generatedXML = generatedXML;
    }
    
     /**
     * @return the allowedDownload
     */
    public boolean isAllowedDownload() {
        return allowedDownload;
    }

    /**
     * @param allowedDownload the allowedDownload to set
     */
    public void setAllowedDownload(boolean allowedDownload) {
        this.allowedDownload = allowedDownload;
    }
    
    /**
     * @return the DebugFile
     */
    public StreamedContent getDebugFile() {
        return debugFile;
    }

    /**
     * @param DebugFile the DebugFile to set
     */
    public void setDebugFile(StreamedContent debugFile) {
        this.debugFile = debugFile;
    }

    /**
     * @return the LogFile
     */
    public StreamedContent getLogFile() {
        return logFile;
    }

    /**
     * @param LogFile the LogFile to set
     */
    public void setLogFile(StreamedContent logFile) {
        this.logFile = logFile;
    }
	 
}