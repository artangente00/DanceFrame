/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.lazy.competition;

import com.danceframe.console.common.model.competition.Event;
import com.danceframe.console.web.service.CompetitionService;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

/**
 *
 * @author lmorallos
 */
public class HeatResultLazyList extends LazyDataModel<Event> {
    
    private static final Logger logger = LogManager.getLogger(HeatResultLazyList.class);
    private CompetitionService    competitionService; 
    
    private List<Event> events;
    private int rowCount;
    
    public HeatResultLazyList(CompetitionService compsvc) {
        competitionService = compsvc;
    }
    
    public List<Event> load(int first, int pageSize, String sortField,
                             SortOrder sortOrder, Map<String, Object> filters) {
           // filters can be here
       String wherestr = new String();
       String wherecnt = new String();
       
       if (filters.containsKey("name")) {
           String value = (String)filters.get("name");
           if (value.length() > 0)
           {
               wherestr = " WHERE UPPER(event_name) like '%" + value.toUpperCase() + "%'";
              
           }
       }
       wherecnt = wherestr;
        // sorting
        String sortSql = new String();
        if (sortField != null) {
            if (sortField.equalsIgnoreCase("competitionName")) {
                sortSql = " ORDER BY competition_name ASC, date_start DESC";
            } 
         } else {
            sortSql = " ORDER BY competition_name ASC, event_name ASC, date_start DESC";
            
        }
        wherestr += sortSql;
        logger.info("Page Query (sortfield):(" + sortField + ") " +  wherestr);
        events = competitionService.getEventProviderDao().getAllWithPaging(wherestr, 
                       pageSize, first);
        Long rc = (Long)competitionService.getEventProviderDao().getAllCount(wherecnt);
        
        rowCount = rc.intValue();
        setPageSize(pageSize);
        return events;           
       }
    
    
     @Override
    public Object getRowKey(Event event) {
        return event.getId();
    }
    
    @Override
    public Event getRowData(String eventId) {
        Integer id = Integer.valueOf(eventId);
        for (Event event : events) {
            if(id.equals(event.getId())){
                return event;
            }
        }
        return null;
    }
    

    /**
     * @return the competitionService
     */
    public CompetitionService getCompetitionService() {
        return competitionService;
    }

    /**
     * @param competitionService the competitionService to set
     */
    public void setCompetitionService(CompetitionService competitionService) {
        this.competitionService = competitionService;
    }

    /**
     * @return the events
     */
    public List<Event> getEvents() {
        return events;
    }

    /**
     * @param events the events to set
     */
    public void setEvents(List<Event> events) {
        this.events = events;
    }

    /**
     * @return the rowCount
     */
    public int getRowCount() {
        return rowCount;
    }

    /**
     * @param rowCount the rowCount to set
     */
    public void setRowCount(int rowCount) {
        this.rowCount = rowCount;
    }

}
