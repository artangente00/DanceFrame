/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.lazy.competition.config;

import com.danceframe.console.common.model.competition.form.EventForm;
import com.danceframe.console.web.service.EventFormConfigService;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

/**
 *
 * @author lmorallos
 */
public class EventFormLazyList extends LazyDataModel<EventForm> {
    
    private static final Logger logger = LogManager.getLogger(EventFormLazyList.class);
    private EventFormConfigService eventFormConfigService;

    private List<EventForm> eventforms;
    private int rowCount;
    private int eventId;
    
    public EventFormLazyList(EventFormConfigService evcm, int evtid) {
       eventFormConfigService = evcm;
       eventId = evtid;
    }
     public List<EventForm> load(int first, int pageSize, String sortField,
                             SortOrder sortOrder, Map<String, Object> filters) {
           // filters can be here
       String wherestr = " WHERE event_id=" + eventId;
       String wherecnt = wherestr;
        

        String sortSql = " ORDER BY form_name ASC";
        wherestr += sortSql;
        eventforms = eventFormConfigService.getEventFormProviderDao().getAllWithPaging(wherestr, 
                pageSize, first);
        Long rc = (Long)eventFormConfigService.getEventFormProviderDao().getAllCount(wherecnt);
        
        rowCount = rc.intValue();
        setPageSize(pageSize);
        return eventforms;           
       }
    
    @Override
    public Object getRowKey(EventForm eventform) {
        return eventform.getId();
    }
    
    @Override
    public EventForm getRowData(String eventformId) {
        Integer id = Integer.valueOf(eventformId);

        for (EventForm eventform : eventforms) {
            if(id.equals(eventform.getId())){
                return eventform;
            }
        }

        return null;
    }

    /**
     * @return the eventforms
     */
    public List<EventForm> getEventforms() {
        return eventforms;
    }

    /**
     * @param eventforms the eventforms to set
     */
    public void setEventforms(List<EventForm> eventforms) {
        this.eventforms = eventforms;
    }

    /**
     * @return the rowCount
     */
    public int getRowCount() {
        return rowCount;
    }

    /**
     * @param rowCount the rowCount to set
     */
    public void setRowCount(int rowCount) {
        this.rowCount = rowCount;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }
    
    
}
