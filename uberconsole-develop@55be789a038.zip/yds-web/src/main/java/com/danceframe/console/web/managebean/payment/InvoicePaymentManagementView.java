/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.managebean.payment;

import com.danceframe.console.common.model.basic.LookUp;
import com.danceframe.console.common.model.invoice.InvoicePayment;
import com.danceframe.console.common.model.invoice.InvoicePaymentDetail;
import com.danceframe.console.web.lazy.payment.InvoicePaymentDetailLazyList;
import com.danceframe.console.web.lazy.payment.InvoicePaymentLazyList;
import com.danceframe.console.web.managebean.BaseBean;
import com.danceframe.console.web.service.InvoicePaymentService;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import org.primefaces.context.RequestContext;
import org.primefaces.event.SelectEvent;
import org.primefaces.model.LazyDataModel;

/**
 *
 * @author lmorallos
 */
@ManagedBean(name = "invoicePaymentView")
@ViewScoped
public class InvoicePaymentManagementView extends BaseBean implements Serializable {
    
    @ManagedProperty(value = "#{invoicePaymentService}")
    private InvoicePaymentService invoicePaymentService;
    
    private static final long serialVersionUID = 1L;
    
    private LazyDataModel<InvoicePayment> invoicePayments = null;
    private InvoicePayment selectedInvoicePayment = null;
    private LazyDataModel<InvoicePaymentDetail> invoicePaymentDetails;
    private InvoicePaymentDetail selectedInvPaymentDetail = null;
    private InvoicePaymentDetail inputInvPaymentDetail = null;
    private List<LookUp> paymentTypeList = null;
    private int payType = 0;
    private double receivedAmount = 0.0;
    private boolean sendEmail = false;
    
    @PostConstruct
    public void init() {
         if (invoicePayments == null) {
             invoicePayments = new InvoicePaymentLazyList(invoicePaymentService);
         }
         if (paymentTypeList == null) {
             paymentTypeList = new ArrayList<>();
             paymentTypeList.add(new LookUp(1,"CASH", 1, "CASH"));
             paymentTypeList.add(new LookUp(2,"DEBIT", 2, "DEBIT"));
             paymentTypeList.add(new LookUp(3,"CREDIT", 3, "CREDIT"));
         }
         payType = 0;
         receivedAmount = 0.0;
    }
    
    public void onRowSelect(SelectEvent event) {
       context = RequestContext.getCurrentInstance();
        selectedInvoicePayment = (InvoicePayment)event.getObject();
        if (selectedInvoicePayment != null) {
            if (selectedInvoicePayment.getInvoicePaymentId() > 0) {
                sendEmail = selectedInvoicePayment.isSendMail();
                invoicePaymentDetails = new InvoicePaymentDetailLazyList(invoicePaymentService, 
                        Integer.toString(selectedInvoicePayment.getInvoicePaymentId() ));
                resetValues();                
                context.execute("PF('invPayDetailDialog').show();");
            }
        }
    }
    
    public void checkSendMail() {
        if (selectedInvoicePayment != null) {
            String firebaseAuthId = selectedInvoicePayment.getFirebaseAuthId();
            String freibaseEventId = selectedInvoicePayment.getFirebaseEventId();
            int ret  = invoicePaymentService.getInvoicePaymentProviderDao().setSendMail(firebaseAuthId, freibaseEventId, true);
            if (ret > 0) {
                addMessage("Send email flag is ON for this Invoice", FacesMessage.SEVERITY_INFO);
            } else {
                addMessage("Error: Setting Sendmail flag for Invoice.",  FacesMessage.SEVERITY_WARN);
            }
        }
       
    }
    
    public void savePayDetail() {
        if (receivedAmount == 0.0) {
            addMessage("Recieved Amount must be valid (0.0 detected)" , FacesMessage.SEVERITY_WARN); 
        } else {
            inputInvPaymentDetail.setPayType(payType);
            double balance = inputInvPaymentDetail.getBalance() - receivedAmount;
            inputInvPaymentDetail.setReceivedAmount(receivedAmount);
            inputInvPaymentDetail.setBalance(balance);
            if (inputInvPaymentDetail != null) {
                int ret = invoicePaymentService.getInvoicePaymentDetailProviderDao().insert(inputInvPaymentDetail);
                if (ret > 0) {
                    addMessage("Successful Saving Payment Details." ); 
                    // update new Balance
                    selectedInvoicePayment.setReceivedAmount(receivedAmount);
                    selectedInvoicePayment.setBalance(balance);
                    int uret = invoicePaymentService.getInvoicePaymentProviderDao().update(selectedInvoicePayment);
                    if (uret > 0) {
                         addMessage("Successful Updaing Invoice Payment." ); 
                    } else {
                        addMessage("Failed Updaing Invoice Payment." ); 
                    }
                    resetValues();
                } else {
                     addMessage("Failed Saving Payment Details." );
                }
            }
        }
        
    }
    
    private void resetValues() {
        payType = 0;
        receivedAmount = 0.0;
        inputInvPaymentDetail = new InvoicePaymentDetail();
        inputInvPaymentDetail.setInvoicePaymentId(selectedInvoicePayment.getInvoicePaymentId());
        inputInvPaymentDetail.setInvoiceAmount(selectedInvoicePayment.getInvoiceAmount());
        inputInvPaymentDetail.setBalance(selectedInvoicePayment.getBalance());
        
        
    }
     public void onRowSelectDetail(SelectEvent event) {
         
     }

    /**
     * @return the invoicePaymentService
     */
    public InvoicePaymentService getInvoicePaymentService() {
        return invoicePaymentService;
    }

    /**
     * @param invoicePaymentService the invoicePaymentService to set
     */
    public void setInvoicePaymentService(InvoicePaymentService invoicePaymentService) {
        this.invoicePaymentService = invoicePaymentService;
    }

    /**
     * @return the invoicePayments
     */
    public LazyDataModel<InvoicePayment> getInvoicePayments() {
        return invoicePayments;
    }

    /**
     * @param invoicePayments the invoicePayments to set
     */
    public void setInvoicePayments(LazyDataModel<InvoicePayment> invoicePayments) {
        this.invoicePayments = invoicePayments;
    }

    /**
     * @return the selectedInvoicePayment
     */
    public InvoicePayment getSelectedInvoicePayment() {
        return selectedInvoicePayment;
    }

    /**
     * @param selectedInvoicePayment the selectedInvoicePayment to set
     */
    public void setSelectedInvoicePayment(InvoicePayment selectedInvoicePayment) {
        this.selectedInvoicePayment = selectedInvoicePayment;
    }

    /**
     * @return the invoicePaymentDetails
     */
    public LazyDataModel<InvoicePaymentDetail> getInvoicePaymentDetails() {
        return invoicePaymentDetails;
    }

    /**
     * @param invoicePaymentDetails the invoicePaymentDetails to set
     */
    public void setInvoicePaymentDetails(LazyDataModel<InvoicePaymentDetail> invoicePaymentDetails) {
        this.invoicePaymentDetails = invoicePaymentDetails;
    }

    /**
     * @return the selectedInvPaymentDetail
     */
    public InvoicePaymentDetail getSelectedInvPaymentDetail() {
        return selectedInvPaymentDetail;
    }

    /**
     * @param selectedInvPaymentDetail the selectedInvPaymentDetail to set
     */
    public void setSelectedInvPaymentDetail(InvoicePaymentDetail selectedInvPaymentDetail) {
        this.selectedInvPaymentDetail = selectedInvPaymentDetail;
    }

    /**
     * @return the inputInvPaymentDetail
     */
    public InvoicePaymentDetail getInputInvPaymentDetail() {
        return inputInvPaymentDetail;
    }

    /**
     * @param inputInvPaymentDetail the inputInvPaymentDetail to set
     */
    public void setInputInvPaymentDetail(InvoicePaymentDetail inputInvPaymentDetail) {
        this.inputInvPaymentDetail = inputInvPaymentDetail;
    }

    /**
     * @return the paymentTypeList
     */
    public List<LookUp> getPaymentTypeList() {
        return paymentTypeList;
    }

    /**
     * @param paymentTypeList the paymentTypeList to set
     */
    public void setPaymentTypeList(List<LookUp> paymentTypeList) {
        this.paymentTypeList = paymentTypeList;
    }

    /**
     * @return the payType
     */
    public int getPayType() {
        return payType;
    }

    /**
     * @param payType the payType to set
     */
    public void setPayType(int payType) {
        this.payType = payType;
    }

    /**
     * @return the receivedAmount
     */
    public double getReceivedAmount() {
        return receivedAmount;
    }

    /**
     * @param receivedAmount the receivedAmount to set
     */
    public void setReceivedAmount(double receivedAmount) {
        this.receivedAmount = receivedAmount;
    }

    /**
     * @return the sendEmail
     */
    public boolean isSendEmail() {
        return sendEmail;
    }

    /**
     * @param sendEmail the sendEmail to set
     */
    public void setSendEmail(boolean sendEmail) {
        this.sendEmail = sendEmail;
    }

 
    
}
