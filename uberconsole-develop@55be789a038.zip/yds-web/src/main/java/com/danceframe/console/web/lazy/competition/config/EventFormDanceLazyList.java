/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.lazy.competition.config;

import com.danceframe.console.common.model.competition.form.EventFormDance;
import com.danceframe.console.web.service.EventFormConfigService;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

/**
 *
 * @author lmorallos
 */
public class EventFormDanceLazyList extends LazyDataModel<EventFormDance> {
    
    private static final Logger logger = LogManager.getLogger(EventFormDanceLazyList.class);
    private EventFormConfigService eventFormConfigService;

    private List<EventFormDance> eventformDances;
    private int rowCount;
    private int hContentId;
    private int eventFormId;
    
    public EventFormDanceLazyList(EventFormConfigService efcs, int hcId, int evfId) {
        eventFormConfigService = efcs;
        hContentId = hcId;
        eventFormId = evfId;
    }
    
    public List<EventFormDance> load(int first, int pageSize, String sortField,
                             SortOrder sortOrder, Map<String, Object> filters) {
        
       String wherestr = " WHERE eventform_id=" + eventFormId + 
               " AND hcontent_id=" + hContentId;
       String wherecnt = wherestr;
       
       String sortSql = " ORDER BY hcontent_id  ASC";
       wherestr += sortSql;
       
        eventformDances = eventFormConfigService.getEventFormDanceProviderDao().getAllWithPaging(wherestr, 
                pageSize, first);
        Long rc = (Long)eventFormConfigService.getEventFormDanceProviderDao().getAllCount(wherecnt);
        
        rowCount = rc.intValue();
        setPageSize(pageSize);
       
       return eventformDances;
    } 
    
    @Override
    public Object getRowKey(EventFormDance eventformdance) {
        return eventformdance.getId();
    }
    
    @Override
    public EventFormDance getRowData(String danceId) {
        Integer id = Integer.valueOf(danceId);
        for (EventFormDance evedance : eventformDances) {
            if(id.equals(evedance.getId())){
                return evedance;
            }
        }
        return null;
    }
    /**
     * @return the eventFormConfigService
     */
    public EventFormConfigService getEventFormConfigService() {
        return eventFormConfigService;
    }

    /**
     * @param eventFormConfigService the eventFormConfigService to set
     */
    public void setEventFormConfigService(EventFormConfigService eventFormConfigService) {
        this.eventFormConfigService = eventFormConfigService;
    }

    /**
     * @return the eventformDances
     */
    public List<EventFormDance> getEventformDances() {
        return eventformDances;
    }

    /**
     * @param eventformDances the eventformDances to set
     */
    public void setEventformDances(List<EventFormDance> eventformDances) {
        this.eventformDances = eventformDances;
    }

    /**
     * @return the rowCount
     */
    public int getRowCount() {
        return rowCount;
    }

    /**
     * @param rowCount the rowCount to set
     */
    public void setRowCount(int rowCount) {
        this.rowCount = rowCount;
    }

    /**
     * @return the hContentId
     */
    public int gethContentId() {
        return hContentId;
    }

    /**
     * @param hContentId the hContentId to set
     */
    public void sethContentId(int hContentId) {
        this.hContentId = hContentId;
    }

    /**
     * @return the eventFormId
     */
    public int getEventFormId() {
        return eventFormId;
    }

    /**
     * @param eventFormId the eventFormId to set
     */
    public void setEventFormId(int eventFormId) {
        this.eventFormId = eventFormId;
    }
}
