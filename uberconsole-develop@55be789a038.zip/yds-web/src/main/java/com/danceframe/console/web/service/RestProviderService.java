/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.service;

import com.danceframe.console.service.rest.ImageListRestProvider;
import com.danceframe.console.service.rest.ImageStoreRestProvider;
import java.io.Serializable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author lmorallos
 */
@Service("restProviderService")
public class RestProviderService implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @Autowired
    private ImageListRestProvider imageListRestProvider;
    
    @Autowired
    private ImageStoreRestProvider imageStoreRestProvider;

    /**
     * @return the imageListRestProvider
     */
    public ImageListRestProvider getImageListRestProvider() {
        return imageListRestProvider;
    }

    /**
     * @param imageListRestProvider the imageListRestProvider to set
     */
    public void setImageListRestProvider(ImageListRestProvider imageListRestProvider) {
        this.imageListRestProvider = imageListRestProvider;
    }

    /**
     * @return the imageStoreRestProvider
     */
    public ImageStoreRestProvider getImageStoreRestProvider() {
        return imageStoreRestProvider;
    }

    /**
     * @param imageStoreRestProvider the imageStoreRestProvider to set
     */
    public void setImageStoreRestProvider(ImageStoreRestProvider imageStoreRestProvider) {
        this.imageStoreRestProvider = imageStoreRestProvider;
    }
    
    
    
    
}
