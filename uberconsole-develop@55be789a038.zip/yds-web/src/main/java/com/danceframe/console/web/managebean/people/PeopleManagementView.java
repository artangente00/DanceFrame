/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.web.managebean.people;

import com.danceframe.console.common.model.participant.Participant;
import com.danceframe.console.common.model.payment.Invoice;
import com.danceframe.console.common.model.payment.Payment;
import com.danceframe.console.common.model.people.People;
import com.danceframe.console.common.util.Utility;
import com.danceframe.console.service.constant.ParticipantAction;
import com.danceframe.console.service.constant.PeopleAction;
import com.danceframe.console.service.dataprovider.people.PeopleProviderDao;
import com.danceframe.console.web.lazy.invoice.InvoiceLazyList;
import com.danceframe.console.web.lazy.participant.ParticipantLazyList;
import com.danceframe.console.web.lazy.payment.PaymentLazyList;
import com.danceframe.console.web.lazy.people.PeopleLazyList;
import com.danceframe.console.web.managebean.BaseBean;
import com.danceframe.console.web.service.InvoiceManagementService;
import com.danceframe.console.web.service.ParticipantManagementService;
import com.danceframe.console.web.service.PaymentManagementService;
import com.danceframe.console.web.service.PeopleManagementService;
import com.danceframe.console.web.service.util.CookieHelper;
import com.danceframe.console.web.service.util.HttpClientHelper;
import java.io.Serializable;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.primefaces.context.RequestContext;
import org.primefaces.event.SelectEvent;
import org.primefaces.model.LazyDataModel;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 *
 * @author nbonita
 */
@ManagedBean(name = "peopleManagementView")
@ViewScoped
public class PeopleManagementView extends BaseBean implements Serializable {
    
    public static final String MODULE_NAME = "PEOPLEMANAGEMENT";
    private static final Logger logger = LogManager.getLogger(PeopleManagementView.class);
    private static final String URL = "http://localhost:8080/uberSync/SyncPeople";
    private static final String GET_URL = "http://localhost:8080/uberSync/GetPeople";
    private static final String SYNC_PARTICIPANTS_URL = "http://localhost:8080/uberSync/SyncParticipants";
    private static final String SYNC_INVOICE_URL = "http://localhost:8080/uberSync/SyncInvoice";
    
    @ManagedProperty(value = "#{peopleManagementService}")
    private PeopleManagementService peopleManagementService;

    @ManagedProperty(value = "#{participantManagementService}")
    private ParticipantManagementService participantManagementService;
    
    @ManagedProperty(value = "#{invoiceManagementService}")
    private InvoiceManagementService invoiceManagementService;
    
    @ManagedProperty(value = "#{paymentManagementService}")
    private PaymentManagementService paymentManagementService;

    private static final long serialVersionUID = 1L;
    private LazyDataModel<People> peopleList = null;
    private People onePeople = new People();
    private People selectedPeople = new People();
    private List<People> unsavedPeople = new ArrayList<People>();

    private LazyDataModel<Participant> participantList = null;
    private Participant selectedParticipant = new Participant();
    
    private LazyDataModel<Invoice> invoiceList = null;
    private Invoice selectedInvoice = new Invoice();

    private LazyDataModel<Payment> paymentList = null;
    private Payment selectedPayment = new Payment();
    private Payment newPayment = new Payment();
    
    @PostConstruct
    public void init() {
        Utility.isNullDebug(getPeopleManagementService().getPeopleProviderDao(), this.getClass().getName());
        if (getPeopleList() == null) {
            setPeopleList(new PeopleLazyList(getPeopleManagementService()));
        }
    }

    public void syncWithFirebase() {
        getUnsavedPeople().clear();

        System.out.println("Reconciling list with Firebase Authentication");
        logger.info("Reconciling list with Firebase Authentication");

        //publish all configs to uberSync
        String result = "";
        String peopleToGet = "ALL_UNSAVED";
        String urlStr = GET_URL + "?people_action=sync&people_parameter=" + peopleToGet;
        result = HttpClientHelper.getURL(urlStr);
        logger.info("Retrieved people[" + peopleToGet + "] from RTDB: " + result);

        try {
            result = result.replace("\"[", "[").replace("]\"", "]").replace("\\\"", "\"");
            System.out.println("STRIPPED RESULT: " + result);
            JSONObject jsonObject = new JSONObject(new JSONTokener(result));
            if (jsonObject.get("status") != null) {
                if (jsonObject.get("status").toString().equalsIgnoreCase("ok")) {
                    if (jsonObject.getJSONArray("response") != null) {
                        JSONArray jsonArray = jsonObject.getJSONArray("response");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            String oneUnsavedFound = jsonArray.get(i).toString();
                            logger.info("\t ONE FOUND: " + oneUnsavedFound);
                            People oneUnsavedPeople = new People();
                            oneUnsavedPeople.seteMail(oneUnsavedFound);
                            getUnsavedPeople().add(oneUnsavedPeople);
                        }
                    }
                } else {
                    People oneUnsavedPeople = new People();
                    oneUnsavedPeople.seteMail("ERROR SYNCING WITH RTDB: " + jsonObject.get("response").toString());
                    getUnsavedPeople().add(oneUnsavedPeople);
                }
            } else {
                People oneUnsavedPeople = new People();
                oneUnsavedPeople.seteMail("ERROR SYNCING WITH RTDB.");
                getUnsavedPeople().add(oneUnsavedPeople);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (getUnsavedPeople().size() <= 0) {
            People oneUnsavedPeople = new People();
            oneUnsavedPeople.seteMail("No unsaved people found in RTDB.");
            getUnsavedPeople().add(oneUnsavedPeople);
        }
        
        context = RequestContext.getCurrentInstance();
        context.execute("PF('unsavedPeopleDialog').show();");
    }

    public void confimSync() {
        context = RequestContext.getCurrentInstance();
        context.execute("PF('importDonePoller').start();");
        
        System.out.println("Started importing unsaved people from RTDB...");
        logger.info("Started importing unsaved people from RTDB...");

        //publish all configs to uberSync
        String result = "";
        String peopleToImport = "ALL_UNSAVED";
        String urlStr = GET_URL + "?people_action=import&people_parameter=" + peopleToImport;
        result = HttpClientHelper.getURL(urlStr);
        logger.info("Imported people[" + peopleToImport + "] from RTDB: " + result);

        try {
            result = result.replace("\"[", "[").replace("]\"", "]").replace("\\\"", "\"");
            System.out.println("STRIPPED RESULT: " + result);
            JSONObject jsonObject = new JSONObject(new JSONTokener(result));
            if (jsonObject.get("status") != null) {
                if (jsonObject.get("status").toString().equalsIgnoreCase("ok")) {
                    if (jsonObject.get("response") != null) {
                        String importResponse = jsonObject.get("response").toString();
                        System.out.println("IMPORT RESPONSE: " + importResponse);
                        logger.info("IMPORT RESPONSE: " + importResponse);
                        addMessage("Imported unsaved people from RTDB: " + importResponse);
                    }
                } else {
                    String importResponse = jsonObject.get("response").toString();
                    addMessage("ERROR importing unsaved people from RTDB: " + importResponse);

                }
            } else {
                String importResponse = jsonObject.get("response").toString();
                addMessage("ERROR importing unsaved people from RTDB. ");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        context.execute("PF('importDonePoller').stop();");
        //context.execute("PF('unsavedPeopleDialog').hide();");
    }

    public String checkImportDone(String peopleEmail) {
        
        String result = "NO";
        ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("uaydsServiceConfig.xml");
        PeopleProviderDao peopleProviderDao = (PeopleProviderDao)ctx.getBean("peopleProviderDao");        
        long matchCount = peopleProviderDao.getAllCount(" WHERE UPPER(email) = '" + peopleEmail.toUpperCase() + "'");
        if(matchCount > 0) {
            result = "Done";
        }
        System.out.println("Checking import status for email[" + peopleEmail + "]: " + result);
        return result;
    }
    
    public void onRowSelect(SelectEvent event) {
        context = RequestContext.getCurrentInstance();
        People vpeople = (People) event.getObject();
        System.out.println("SELECTED EMAIL: " + vpeople.geteMail());
        if (vpeople.getId() > 0) {
            getOnePeople().setId(vpeople.getId());
            getOnePeople().setFirstName(vpeople.getFirstName());
            getOnePeople().setLastName(vpeople.getLastName());
            getOnePeople().setStudioName(vpeople.getStudioName());
            getOnePeople().seteMail(vpeople.geteMail());
            getOnePeople().setGender(vpeople.getGender());
            getOnePeople().setBirthday(vpeople.getBirthday());
            getOnePeople().setCategory(vpeople.getCategory());
            getOnePeople().setInvoiceAddress(vpeople.getInvoiceAddress());
            getOnePeople().setFirebaseAuthenticationID(vpeople.getFirebaseAuthenticationID());
            getOnePeople().setLoginProvider(vpeople.getLoginProvider());
            getOnePeople().setDateCreated(vpeople.getDateCreated());
            getOnePeople().setDateSignedIn(vpeople.getDateSignedIn());
            getOnePeople().setFacebookUserUID(vpeople.getFacebookUserUID());
            
            setParticipantList(new ParticipantLazyList(getParticipantManagementService(), vpeople.getFirebaseAuthenticationID()));
            setInvoiceList(new InvoiceLazyList(getInvoiceManagementService(), vpeople.getFirebaseAuthenticationID()));
            
            context.execute("PF('peopleInfoDialog').show();");
        }
    }

    public void viewParticipants(String firebasePushID) {
        System.out.println("Viewing participants for people[FirebaseID:" + firebasePushID + "]...");
        setParticipantList(new ParticipantLazyList(getParticipantManagementService(), firebasePushID));
        context = RequestContext.getCurrentInstance();
        context.execute("PF('participantsDialog').show();");
    }
    
    public void viewInvoices(String firebasePushID) {
        System.out.println("Viewing invoices for people[FirebaseID:" + firebasePushID + "]...");
        setInvoiceList(new InvoiceLazyList(getInvoiceManagementService(), firebasePushID));
        context = RequestContext.getCurrentInstance();
        context.execute("PF('invoicesDialog').show();");
    }

    public void onParticipantRowSelect(SelectEvent event) {
        context = RequestContext.getCurrentInstance();
        Participant vparticipant = (Participant) event.getObject();
        System.out.println("SELECTED PARTICIPANT: " + vparticipant.getParticipantPushId());
        if (vparticipant.getId() > 0) {
            getSelectedParticipant().setId(vparticipant.getId());
            getSelectedParticipant().setParticipantPushId(vparticipant.getParticipantPushId());
            getSelectedParticipant().setUserPushId(vparticipant.getUserPushId());
            getSelectedParticipant().setFirstName(vparticipant.getFirstName());
            getSelectedParticipant().setLastName(vparticipant.getLastName());            
            getSelectedParticipant().seteMail(vparticipant.geteMail());
            getSelectedParticipant().setGender(vparticipant.getGender());
            getSelectedParticipant().setBirthday(vparticipant.getBirthday());
            getSelectedParticipant().setCategory(vparticipant.getCategory());
            getSelectedParticipant().setParticipantType(vparticipant.getParticipantType());
            getSelectedParticipant().setCoupleId(vparticipant.getCoupleId());
            getSelectedParticipant().setCoupleName(vparticipant.getCoupleName());
            context.execute("PF('participantInfoDialog').show();");
        }
    }

    public void onInvoiceRowSelect(SelectEvent event) {
        System.out.println("SELECTING INVOICE...");
        context = RequestContext.getCurrentInstance();
        Invoice vinvoice = (Invoice) event.getObject();
        System.out.println("SELECTED INVOICE: " + vinvoice.getId());
        if (vinvoice.getId() > 0) {
            getSelectedInvoice().setId(vinvoice.getId());
            getSelectedInvoice().setUserPushId(vinvoice.getUserPushId());
            getSelectedInvoice().setEventPushId(vinvoice.getEventPushId());
            getSelectedInvoice().setBillingName(vinvoice.getBillingName());
            getSelectedInvoice().setBillingAddress(vinvoice.getBillingAddress());
            getSelectedInvoice().setEventTitle(vinvoice.getEventTitle());
            getSelectedInvoice().setTotalAmount(vinvoice.getTotalAmount());
            getSelectedInvoice().setRecievedAmount(vinvoice.getRecievedAmount());
            getSelectedInvoice().setCreatedTimestamp(vinvoice.getCreatedTimestamp());
            getSelectedInvoice().setModifiedTimestamp(vinvoice.getModifiedTimestamp());
            getSelectedInvoice().setRtdbEtransferPaymentJson(vinvoice.getRtdbEtransferPaymentJson());
            context.execute("PF('invoiceInfoDialog').show();");
        }
    }
    
    public void showAddPaymentDialog(int invoiceID) {
        System.out.println("ADDING PAYMENT FOR invoiceID: " + invoiceID);
        context = RequestContext.getCurrentInstance();
        getNewPayment().setId(0);
        getNewPayment().setInvoiceId(invoiceID);
        getNewPayment().setAmountPaid("");
        getNewPayment().setPaymentTimestamp("");
        getNewPayment().setTypeOfPayment("");
        getNewPayment().setUberConsoleUserId("");
        context.execute("PF('addPaymentDialog').show();");
    }
    public void saveInvoicePayment() {        
        context = RequestContext.getCurrentInstance();
        
        boolean validPayment = true;
        String addPaymentMessage = "";
        
        if(newPayment.getAmountPaid().isEmpty()) {
            validPayment = false;
            addPaymentMessage += "Please input an amount.<br />";
        }
        
        if(newPayment.getTypeOfPayment().isEmpty()) {
            validPayment = false;
            addPaymentMessage += "Please indicate the type of payment.<br />";
        }
           
        if(validPayment) {
            FacesContext faces = FacesContext.getCurrentInstance();
            ExternalContext externalContext = faces.getExternalContext();
            String currentUserID = externalContext.getSessionMap().get(CookieHelper.COOKIE_USER).toString();
            
            newPayment.setPaymentTimestamp(System.currentTimeMillis() + "");
            newPayment.setUberConsoleUserId(currentUserID);
            int iret = paymentManagementService.getPaymentProviderDao().insert(newPayment);
            if (iret > 0) {
                addPaymentMessage += "New payment added: " + newPayment.getAmountPaid();
            }
            //update invoice received amount
            Invoice oneInvoice = invoiceManagementService.getInvoiceProviderDao().get(newPayment.getInvoiceId());
            String pattern = "###,###.###";
            DecimalFormat decimalFormat = new DecimalFormat(pattern);
            if(oneInvoice.getRecievedAmount().isEmpty()) {
                oneInvoice.setRecievedAmount("0");
            }
            String updatedReceivedAmount = decimalFormat.format(Double.parseDouble(oneInvoice.getRecievedAmount()) + Double.parseDouble(newPayment.getAmountPaid()));
            oneInvoice.setRecievedAmount(updatedReceivedAmount);
            invoiceManagementService.getInvoiceProviderDao().update(oneInvoice);
            
            //push invoice updates to RTDB via uberSync
            //publish participant to uberSync            
            String invoiceIdToPush = oneInvoice.getId() + "";
            String urlStr = SYNC_INVOICE_URL + "?invoice_id=" + invoiceIdToPush;
            String result = HttpClientHelper.getURL(urlStr);
            logger.info("Pushing invoice[ID:" + invoiceIdToPush + "] to uberSync: " + result);
            System.out.println("Pushing invoice[ID:" + invoiceIdToPush + "] to uberSync: " + result);
        }
        addMessage(addPaymentMessage);
        
        context.execute("PF('addPaymentDialog').hide();");
    }
    public void showInvoicePaymentsList(int invoiceID) {
        context = RequestContext.getCurrentInstance();
        
        //if (getPaymentList() == null) {
            setPaymentList(new PaymentLazyList(getPaymentManagementService(), invoiceID + ""));
        //}
        
        context.execute("PF('listPaymentsDialog').show();");
    }
    
    public void deleteParticipant(int id) {
        int iret = -1;
        if (id > 0) {            
            iret = getParticipantManagementService().getParticipantProviderDao().delete(id);
            if (iret == 100) {
                addMessage("Participant information deleted with ID." + Integer.toString(id));
                resetParticipantValues();
            } else {
                addMessage("Failed deleting participant information.");
            }
        }
    }
    public void saveParticipant() {
        context = RequestContext.getCurrentInstance();
        int iret = -1;
        int mode = 0;
        if (getSelectedParticipant().getId() > 0) {
            iret = getParticipantManagementService().getParticipantProviderDao().update(getSelectedParticipant());
            mode = 2;
        } else { // add
            iret = getParticipantManagementService().getParticipantProviderDao().insert(getSelectedParticipant());
            mode = 1;
        }
        if (iret > 0) {
            String action = (mode == 1) ? ParticipantAction.INSERT : ParticipantAction.UPDATE;
            addMessage("Sucessful saved participant information. (" + action + ")");

            //publish participant to uberSync
            
            String participantIdToPush = getSelectedParticipant().getId() + "";
            String urlStr = SYNC_PARTICIPANTS_URL + "?participant_id=" + participantIdToPush;
            String result = HttpClientHelper.getURL(urlStr);
            logger.info("Pushing participant[ID:" + participantIdToPush + "] to uberSync: " + result);
            System.out.println("Pushing participant[ID:" + participantIdToPush + "] to uberSync: " + result);
            
            
            resetParticipantValues();
            context.execute("PF('participantInfoDialog').hide();");

        } else {
            addMessage("Failed saving People information.");
        }
    }

    public void addNew() {
        resetValues();
    }

    public void save() {
        context = RequestContext.getCurrentInstance();
        int iret = -1;
        int mode = 0;
        if (getOnePeople().getId() > 0) {
            iret = getPeopleManagementService().getPeopleProviderDao().update(getOnePeople());
            mode = 2;
        } else { // add
            iret = getPeopleManagementService().getPeopleProviderDao().insert(getOnePeople());
            mode = 1;
        }
        if (iret > 0) {
            String action = (mode == 1) ? PeopleAction.INSERT : PeopleAction.UPDATE;
            addMessage("Sucessful saved people information. (" + action + ")");

            //publish all configs to uberSync
            String peopleIdToPush = getOnePeople().getId() + "";
            String urlStr = URL + "?people_id=" + peopleIdToPush;
            String result = HttpClientHelper.getURL(urlStr);
            logger.info("Pushing people[ID:" + peopleIdToPush + "] to uberSync: " + result);
            System.out.println("Pushing people[ID:" + peopleIdToPush + "] to uberSync: " + result);

            resetValues();
            context.execute("PF('peopleInfoDialog').hide();");

        } else {
            addMessage("Failed saving People information.");
        }
    }

    public void delete(int id) {
        int iret = -1;
        if (id > 0) {
            iret = getPeopleManagementService().getPeopleProviderDao().delete(id);
            if (iret == 100) {
                addMessage("People information deleted with ID." + Integer.toString(id));
                resetValues();
            } else {
                addMessage("Failed deleting user information.");
            }
        }
    }

    private void resetValues() {
        setOnePeople(null);
        setOnePeople(new People());

        getOnePeople().setId(0);
        getOnePeople().setFirstName("");
        getOnePeople().setLastName("");
        getOnePeople().setStudioName("");
        getOnePeople().seteMail("");
        getOnePeople().setGender("");
        getOnePeople().setBirthday("");
        getOnePeople().setCategory("");
        getOnePeople().setInvoiceAddress("");
        getOnePeople().setFirebaseAuthenticationID("");
        getOnePeople().setLoginProvider("");
        getOnePeople().setDateCreated("");
        getOnePeople().setDateSignedIn("");
        getOnePeople().setFacebookUserUID("");
    }
    
    private void resetParticipantValues() {
        setSelectedParticipant(null);
        setSelectedParticipant(new Participant());

        getSelectedParticipant().setId(0);
        getSelectedParticipant().setParticipantPushId("");
        getSelectedParticipant().setUserPushId("");
        getSelectedParticipant().setFirstName("");
        getSelectedParticipant().setLastName("");
        getSelectedParticipant().seteMail("");
        getSelectedParticipant().setGender("");
        getSelectedParticipant().setBirthday("");
        getSelectedParticipant().setCategory("");
        getSelectedParticipant().setParticipantType("");
    }

    /**
     * @return the peopleManagementService
     */
    public PeopleManagementService getPeopleManagementService() {
        return peopleManagementService;
    }

    /**
     * @param peopleManagementService the peopleManagementService to set
     */
    public void setPeopleManagementService(PeopleManagementService peopleManagementService) {
        this.peopleManagementService = peopleManagementService;
    }

    /**
     * @return the peopleList
     */
    public LazyDataModel<People> getPeopleList() {
        return peopleList;
    }

    /**
     * @param peopleList the peopleList to set
     */
    public void setPeopleList(LazyDataModel<People> peopleList) {
        this.peopleList = peopleList;
    }

    /**
     * @return the onePeople
     */
    public People getOnePeople() {
        return onePeople;
    }

    /**
     * @param onePeople the onePeople to set
     */
    public void setOnePeople(People onePeople) {
        this.onePeople = onePeople;
    }

    /**
     * @return the selectedPeople
     */
    public People getSelectedPeople() {
        return selectedPeople;
    }

    /**
     * @param selectedPeople the selectedPeople to set
     */
    public void setSelectedPeople(People selectedPeople) {
        this.selectedPeople = selectedPeople;
    }

    /**
     * @return the unsavedPeople
     */
    public List<People> getUnsavedPeople() {
        return unsavedPeople;
    }

    /**
     * @param unsavedPeople the unsavedPeople to set
     */
    public void setUnsavedPeople(List<People> unsavedPeople) {
        this.unsavedPeople = unsavedPeople;
    }
    
    /**
     * @return the participantManagementService
     */
    public ParticipantManagementService getParticipantManagementService() {
        return participantManagementService;
    }

    /**
     * @param participantManagementService the participantManagementService to
     * set
     */
    public void setParticipantManagementService(ParticipantManagementService participantManagementService) {
        this.participantManagementService = participantManagementService;
    }

    /**
     * @return the participantList
     */
    public LazyDataModel<Participant> getParticipantList() {
        return participantList;
    }

    /**
     * @param participantList the participantList to set
     */
    public void setParticipantList(LazyDataModel<Participant> participantList) {
        this.participantList = participantList;
    }

    /**
     * @return the selectedParticipant
     */
    public Participant getSelectedParticipant() {
        return selectedParticipant;
    }

    /**
     * @param selectedParticipant the selectedParticipant to set
     */
    public void setSelectedParticipant(Participant selectedParticipant) {
        this.selectedParticipant = selectedParticipant;
    }

    /**
     * @return the invoiceList
     */
    public LazyDataModel<Invoice> getInvoiceList() {
        return invoiceList;
    }

    /**
     * @param invoiceList the invoiceList to set
     */
    public void setInvoiceList(LazyDataModel<Invoice> invoiceList) {
        this.invoiceList = invoiceList;
    }

    /**
     * @return the selectedInvoice
     */
    public Invoice getSelectedInvoice() {
        return selectedInvoice;
    }

    /**
     * @param selectedInvoice the selectedInvoice to set
     */
    public void setSelectedInvoice(Invoice selectedInvoice) {
        this.selectedInvoice = selectedInvoice;
    }

    /**
     * @return the invoiceManagementService
     */
    public InvoiceManagementService getInvoiceManagementService() {
        return invoiceManagementService;
    }

    /**
     * @param invoiceManagementService the invoiceManagementService to set
     */
    public void setInvoiceManagementService(InvoiceManagementService invoiceManagementService) {
        this.invoiceManagementService = invoiceManagementService;
    }

    /**
     * @return the paymentList
     */
    public LazyDataModel<Payment> getPaymentList() {
        return paymentList;
    }

    /**
     * @param paymentList the paymentList to set
     */
    public void setPaymentList(LazyDataModel<Payment> paymentList) {
        this.paymentList = paymentList;
    }

    /**
     * @return the selectedPayment
     */
    public Payment getSelectedPayment() {
        return selectedPayment;
    }

    /**
     * @param selectedPayment the selectedPayment to set
     */
    public void setSelectedPayment(Payment selectedPayment) {
        this.selectedPayment = selectedPayment;
    }

    /**
     * @return the newPayment
     */
    public Payment getNewPayment() {
        return newPayment;
    }

    /**
     * @param newPayment the newPayment to set
     */
    public void setNewPayment(Payment newPayment) {
        this.newPayment = newPayment;
    }
    
    
    /**
     * @return the paymentManagementService
     */
    public PaymentManagementService getPaymentManagementService() {
        return paymentManagementService;
    }

    /**
     * @param paymentManagementService the paymentManagementService to set
     */
    public void setPaymentManagementService(PaymentManagementService paymentManagementService) {
        this.paymentManagementService = paymentManagementService;
    }

}
