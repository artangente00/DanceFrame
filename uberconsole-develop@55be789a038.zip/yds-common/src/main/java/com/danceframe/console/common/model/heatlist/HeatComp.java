/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.heatlist;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class HeatComp implements Serializable {
    
    private static final long serialVersionUID = 1L;
     
    private int id;
    private String compMgrId;
    private String heatType;
    private String dance;
    private String level;
    private String age;
    private int heatInfoId;
    private int heatListId;
    
    public HeatComp() {}
    
    public HeatComp(int i, String ci, String ht, String da, String lvl, String ag, int hfi, int hid) {
        this.id = i;
        this.compMgrId = ci;
        this.heatType = ht;
        this.dance = da;
        this.level = lvl;
        this.age = ag;
        this.heatInfoId = hfi;
        this.heatListId = hid;
    }
    
    public HeatComp(String ci, String ht, String da, String lvl, String ag, int hfi, int hid) {
        this.compMgrId = ci;
        this.heatType = ht;
        this.dance = da;
        this.level = lvl;
        this.age = ag; 
         this.heatInfoId = hfi;
        this.heatListId = hid;
    }
    

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the compMgrId
     */
    public String getCompMgrId() {
        return compMgrId;
    }

    /**
     * @param compMgrId the compMgrId to set
     */
    public void setCompMgrId(String compMgrId) {
        this.compMgrId = compMgrId;
    }

    /**
     * @return the heatType
     */
    public String getHeatType() {
        return heatType;
    }

    /**
     * @param heatType the heatType to set
     */
    public void setHeatType(String heatType) {
        this.heatType = heatType;
    }

    /**
     * @return the dance
     */
    public String getDance() {
        return dance;
    }

    /**
     * @param dance the dance to set
     */
    public void setDance(String dance) {
        this.dance = dance;
    }

    /**
     * @return the level
     */
    public String getLevel() {
        return level;
    }

    /**
     * @param level the level to set
     */
    public void setLevel(String level) {
        this.level = level;
    }

    /**
     * @return the age
     */
    public String getAge() {
        return age;
    }

    /**
     * @param age the age to set
     */
    public void setAge(String age) {
        this.age = age;
    }


    /**
     * @return the heatListId
     */
    public int getHeatListId() {
        return heatListId;
    }

    /**
     * @param heatListId the heatListId to set
     */
    public void setHeatListId(int heatListId) {
        this.heatListId = heatListId;
    }

    /**
     * @return the heatInfoId
     */
    public int getHeatInfoId() {
        return heatInfoId;
    }

    /**
     * @param heatInfoId the heatInfoId to set
     */
    public void setHeatInfoId(int heatInfoId) {
        this.heatInfoId = heatInfoId;
    }

    @Override
    public String toString() {
        return "HeatComp{" + "id=" + id + ", compMgrId=" + compMgrId + ", heatType=" + heatType + ", dance=" + dance + ", level=" + level + ", age=" + age + ", heatInfoId=" + heatInfoId + ", heatListId=" + heatListId + '}';
    }

    
    
}
