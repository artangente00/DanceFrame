/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.heatlist;

import com.danceframe.console.common.util.Utility;
import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author lmorallos
 */
public class HeatListEvent implements Serializable {
   
    private static final long serialVersionUID = 1L;
     
    private int     id;
    private String  description;
    private Date    asof;
    private String  filename;
    private Date    compDate;
    private int     eventId;
    private String  eventName;
    private int     eventYear;
    private Date    dateStart;
    private Date    dateStop;
    private int     pubstatus;
    private String  euid;
    private String  competitionName;
    private String  publishedStatus;
    private String  stuFileName;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the asof
     */
    public Date getAsof() {
        return asof;
    }

    /**
     * @param asof the asof to set
     */
    public void setAsof(Date asof) {
        this.asof = asof;
    }

    /**
     * @return the filename
     */
    public String getFilename() {
        return filename;
    }

    /**
     * @param filename the filename to set
     */
    public void setFilename(String filename) {
        this.filename = filename;
    }

    /**
     * @return the compDate
     */
    public Date getCompDate() {
        return compDate;
    }

    /**
     * @param compDate the compDate to set
     */
    public void setCompDate(Date compDate) {
        this.compDate = compDate;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the eventName
     */
    public String getEventName() {
        return eventName;
    }

    /**
     * @param eventName the eventName to set
     */
    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    /**
     * @return the eventYear
     */
    public int getEventYear() {
        return eventYear;
    }

    /**
     * @param eventYear the eventYear to set
     */
    public void setEventYear(int eventYear) {
        this.eventYear = eventYear;
    }

    /**
     * @return the dateStart
     */
    public Date getDateStart() {
        return dateStart;
    }

    /**
     * @param dateStart the dateStart to set
     */
    public void setDateStart(Date dateStart) {
        this.dateStart = dateStart;
    }

    /**
     * @return the dateStop
     */
    public Date getDateStop() {
        return dateStop;
    }

    /**
     * @param dateStop the dateStop to set
     */
    public void setDateStop(Date dateStop) {
        this.dateStop = dateStop;
    }

    /**
     * @return the pubstatus
     */
    public int getPubstatus() {
        return pubstatus;
    }

    /**
     * @param pubstatus the pubstatus to set
     */
    public void setPubstatus(int pubstatus) {
        this.pubstatus = pubstatus;
    }

    /**
     * @return the publishedStatus
     */
    public String getPublishedStatus() {
        return publishedStatus;
    }

    /**
     * @param publishedStatus the publishedStatus to set
     */
    public void setPublishedStatus(String publishedStatus) {
        this.publishedStatus = publishedStatus;
    }
    
     public String getStrAsof() {
        return Utility.date2String(asof);
    }

       /**
     * @return the stuFileName
     */
    public String getStuFileName() {
        return stuFileName;
    }

    /**
     * @param stuFileName the stuFileName to set
     */
    public void setStuFileName(String stuFileName) {
        this.stuFileName = stuFileName;
    }

    /**
     * @return the euid
     */
    public String getEuid() {
        return euid;
    }

    /**
     * @param euid the euid to set
     */
    public void setEuid(String euid) {
        this.euid = euid;
    }

    /**
     * @return the competitionName
     */
    public String getCompetitionName() {
        return competitionName;
    }

    /**
     * @param competitionName the competitionName to set
     */
    public void setCompetitionName(String competitionName) {
        this.competitionName = competitionName;
    }

    @Override
    public String toString() {
        return "HeatListEvent{" + "id=" + id + ", description=" + description + ", asof=" + asof + ", filename=" + filename + ", compDate=" + compDate + ", eventId=" + eventId + ", eventName=" + eventName + ", eventYear=" + eventYear + ", dateStart=" + dateStart + ", dateStop=" + dateStop + ", pubstatus=" + pubstatus + ", euid=" + euid + ", competitionName=" + competitionName + ", publishedStatus=" + publishedStatus + ", stuFileName=" + stuFileName + '}';
    }
    
    

}
