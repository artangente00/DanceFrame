/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.firebase.competition;

import com.danceframe.console.common.model.competition.Contact;
import com.danceframe.console.common.model.competition.Event;
import com.danceframe.console.common.model.competition.Finance;
import com.danceframe.console.common.model.competition.Organizer;
import com.danceframe.console.common.model.competition.Venue;
import java.io.Serializable;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public class EventInfo implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private Event   info;
    private Venue   venue;
    private Contact contact;
    private List<Organizer> organizers;
    private ScheduleInfo schedule;
    private List<GenericFormData> hotels;
    private List<GenericFormData> sponsors;
    private List<GenericFormData> informations;
    private Finance finance;

    /**
     * @return the venue
     */
    public Venue getVenue() {
        return venue;
    }

    /**
     * @param venue the venue to set
     */
    public void setVenue(Venue venue) {
        this.venue = venue;
    }

    /**
     * @return the contact
     */
    public Contact getContact() {
        return contact;
    }

    /**
     * @param contact the contact to set
     */
    public void setContact(Contact contact) {
        this.contact = contact;
    }

    /**
     * @return the organizers
     */
    public List<Organizer> getOrganizers() {
        return organizers;
    }

    /**
     * @param organizers the organizers to set
     */
    public void setOrganizers(List<Organizer> organizers) {
        this.organizers = organizers;
    }

    /**
     * @return the info
     */
    public Event getInfo() {
        return info;
    }

    /**
     * @param info the info to set
     */
    public void setInfo(Event info) {
        this.info = info;
    }

    /**
     * @return the schedule
     */
    public ScheduleInfo getSchedule() {
        return schedule;
    }

    /**
     * @param schedule the schedule to set
     */
    public void setSchedule(ScheduleInfo schedule) {
        this.schedule = schedule;
    }

    /**
     * @return the hotels
     */
    public List<GenericFormData> getHotels() {
        return hotels;
    }

    /**
     * @param hotels the hotels to set
     */
    public void setHotels(List<GenericFormData> hotels) {
        this.hotels = hotels;
    }

    /**
     * @return the sponsors
     */
    public List<GenericFormData> getSponsors() {
        return sponsors;
    }

    /**
     * @param sponsors the sponsors to set
     */
    public void setSponsors(List<GenericFormData> sponsors) {
        this.sponsors = sponsors;
    }

    /**
     * @return the informations
     */
    public List<GenericFormData> getInformations() {
        return informations;
    }

    /**
     * @param informations the informations to set
     */
    public void setInformations(List<GenericFormData> informations) {
        this.informations = informations;
    }

    /**
     * @return the finance
     */
    public Finance getFinance() {
        return finance;
    }

    /**
     * @param finance the finance to set
     */
    public void setFinance(Finance finance) {
        this.finance = finance;
    }

    @Override
    public String toString() {
        return "EventInfo{" + "info=" + info + ", venue=" + venue + ", contact=" + contact + ", organizers=" + organizers + ", schedule=" + schedule + ", hotels=" + hotels + ", sponsors=" + sponsors + ", informations=" + informations + ", finance=" + finance + '}';
    }

      
    
}
