/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.competition;

import com.danceframe.console.common.util.Utility;
import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author lmorallos
 */
public class Event implements Serializable {

    private static final long serialVersionUID = 1L;
    private int     id;
    private String  name;
    private Date    dateStart;
    private Date    dateStop;
    private Date    deadline;
    private int     eventyear;
    private String  website;
    private int     competitionId; 
    private String  competitionName;
    private int     status;
    private String  statusname;
    private int     pubstatus;
    private String  publishedStatus;
    private int     imageid;
    private String  mimeType;
    private String  imgFilename;   
    private long    timeCommit;
    private String  timeInterval;
    private Date    lastupdate;
    private Date    lastpublish;
    private boolean useManual;
    private boolean uberRegister;
    private String  pushId;
    private String shortLink;
    private boolean testEvent;
    private boolean websiteEnabled;
    private boolean hideEvent;
    private String  paymentMethods;
    private String  defaultDisplay;
    private String  uid;
    
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the dateStart
     */
    public Date getDateStart() {
        return dateStart;
    }

    /**
     * @param dateStart the dateStart to set
     */
    public void setDateStart(Date dateStart) {
        this.dateStart = dateStart;
    }

    /**
     * @return the dateStop
     */
    public Date getDateStop() {
        return dateStop;
    }

    /**
     * @param dateStop the dateStop to set
     */
    public void setDateStop(Date dateStop) {
        this.dateStop = dateStop;
    }

    /**
     * @return the deadline
     */
    public Date getDeadline() {
        return deadline;
    }

    /**
     * @param deadline the deadline to set
     */
    public void setDeadline(Date deadline) {
        this.deadline = deadline;
    }

    /**
     * @return the website
     */
    public String getWebsite() {
        return website;
    }

    /**
     * @param website the website to set
     */
    public void setWebsite(String website) {
        this.website = website;
    }

    /**
     * @return the competitionId
     */
    public int getCompetitionId() {
        return competitionId;
    }

    /**
     * @param competitionId the competitionId to set
     */
    public void setCompetitionId(int competitionId) {
        this.competitionId = competitionId;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }
   
    /**
     * @return the eventyear
     */
    public int getEventyear() {
        return eventyear;
    }

    /**
     * @param eventyear the eventyear to set
     */
    public void setEventyear(int eventyear) {
        this.eventyear = eventyear;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

        /**
     * @return the statusname
     */
    public String getStatusname() {
        return statusname;
    }

    /**
     * @param statusname the statusname to set
     */
    public void setStatusname(String statusname) {
        this.statusname = statusname;
    }

    /**
     * @return the imgFilename
     */
    public String getImgFilename() {
        return imgFilename;
    }

    /**
     * @param imgFilename the imgFilename to set
     */
    public void setImgFilename(String imgFilename) {
        this.imgFilename = imgFilename;
    }

    /**
     * @return the imageid
     */
    public int getImageid() {
        return imageid;
    }

    /**
     * @param imageid the imageid to set
     */
    public void setImageid(int imageid) {
        this.imageid = imageid;
    }

    /**
     * @return the mimeType
     */
    public String getMimeType() {
        return mimeType;
    }

    /**
     * @param mimeType the mimeType to set
     */
    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    /**
     * @return the pubstatus
     */
    public int getPubstatus() {
        return pubstatus;
    }

    /**
     * @param pubstatus the pubstatus to set
     */
    public void setPubstatus(int pubstatus) {
        this.pubstatus = pubstatus;
    }

    /**
     * @return the competitionName
     */
    public String getCompetitionName() {
        return competitionName;
    }

    /**
     * @param competitionName the competitionName to set
     */
    public void setCompetitionName(String competitionName) {
        this.competitionName = competitionName;
    }
   
    /**
     * @return the publishedStatus
     */
    public String getPublishedStatus() {
        return publishedStatus;
    }

    /**
     * @param publishedStatus the publishedStatus to set
     */
    public void setPublishedStatus(String publishedStatus) {
        this.publishedStatus = publishedStatus;
    }

 
    /**
     * @return the timeCommit
     */
    public long getTimeCommit() {
        return timeCommit;
    }

    /**
     * @param timeCommit the timeCommit to set
     */
    public void setTimeCommit(long timeCommit) {
        this.timeCommit = timeCommit;
    }

    /**
     * @return the timeInterval
     */
    public String getTimeInterval() {
        String retstr = new String();
        if (timeCommit > 0) {
            retstr = Utility.computerInterval( this.timeCommit);
        }
        return retstr;
    }

    /**
     * @param timeInterval the timeInterval to set
     */
    public void setTimeInterval(String timeInterval) {
        this.timeInterval = timeInterval;
    }

    /**
     * @return the lastupdate
     */
    public Date getLastupdate() {
        return lastupdate;
    }

    /**
     * @param lastupdated the lastupdate to set
     */
    public void setLastupdate(Date lastupdate) {
        this.lastupdate = lastupdate;
    }

    public String getStrLastUpdate() {
        return (Utility.date2String(lastupdate));
    }
    
    public String getIsXMLManual() {
        return (useManual)?"YES":"NO";
    }
    
       /**
     * @return the useManual
     */
    public boolean isUseManual() {
        return useManual;
    }

    /**
     * @param useManual the useManual to set
     */
    public void setUseManual(boolean useManual) {
        this.useManual = useManual;
    }

    /**
     * @return the uberRegister
     */
    public boolean isUberRegister() {
        return uberRegister;
    }

    /**
     * @param uberRegister the uberRegister to set
     */
    public void setUberRegister(boolean uberRegister) {
        this.uberRegister = uberRegister;
    }

    /**
     * @return the pushId
     */
    public String getPushId() {
        return pushId;
    }

    /**
     * @param pushId the pushId to set
     */
    public void setPushId(String pushId) {
        this.pushId = pushId;
    }

    /**
     * @return the lastpublish
     */
    public Date getLastpublish() {
        return lastpublish;
    }
    
    
     public String getStrLastPublish() {
         String retstr = new String();
         if (null == lastpublish) {
             retstr = "NEVER BEEN (UN)PUBLISHED.";
         } else {
             retstr = Utility.date2String(lastpublish);
         }
        return (retstr);
    }

    /**
     * @param lastpublish the lastpublish to set
     */
    public void setLastpublish(Date lastpublish) {
        this.lastpublish = lastpublish;
    }

    /**
     * @return the shortLink
     */
    public String getShortLink() {
        return shortLink;
    }

    /**
     * @param shortLink the shortLink to set
     */
    public void setShortLink(String shortLink) {
        this.shortLink = shortLink;
    }

    /**
     * @return the testEvent
     */
    public boolean isTestEvent() {
        return testEvent;
    }

    /**
     * @param testEvent the testEvent to set
     */
    public void setTestEvent(boolean testEvent) {
        this.testEvent = testEvent;
    }

    /**
     * @return the websiteEnabled
     */
    public boolean isWebsiteEnabled() {
        return websiteEnabled;
    }

    /**
     * @param websiteEnabled the websiteEnabled to set
     */
    public void setWebsiteEnabled(boolean websiteEnabled) {
        this.websiteEnabled = websiteEnabled;
    }

    /**
     * @return the hideEvent
     */
    public boolean isHideEvent() {
        return hideEvent;
    }

    /**
     * @param hideEvent the hideEvent to set
     */
    public void setHideEvent(boolean hideEvent) {
        this.hideEvent = hideEvent;
    }

    /**
     * @return the paymentMethods
     */
    public String getPaymentMethods() {
        return paymentMethods;
    }

    /**
     * @param paymentMethods the paymentMethods to set
     */
    public void setPaymentMethods(String paymentMethods) {
        this.paymentMethods = paymentMethods;
    }

    /**
     * @return the defaultDisplay
     */
    public String getDefaultDisplay() {
        return defaultDisplay;
    }

    /**
     * @param defaultDisplay the defaultDisplay to set
     */
    public void setDefaultDisplay(String defaultDisplay) {
        this.defaultDisplay = defaultDisplay;
    }

    /**
     * @return the uid
     */
    public String getUid() {
        return uid;
    }

    /**
     * @param uid the uid to set
     */
    public void setUid(String uid) {
        this.uid = uid;
    }

    @Override
    public String toString() {
        return "Event{" + "id=" + id + ", name=" + name + ", dateStart=" + dateStart + ", dateStop=" + dateStop + ", deadline=" + deadline + ", eventyear=" + eventyear + ", website=" + website + ", competitionId=" + competitionId + ", competitionName=" + competitionName + ", status=" + status + ", statusname=" + statusname + ", pubstatus=" + pubstatus + ", publishedStatus=" + publishedStatus + ", imageid=" + imageid + ", mimeType=" + mimeType + ", imgFilename=" + imgFilename + ", timeCommit=" + timeCommit + ", timeInterval=" + timeInterval + ", lastupdate=" + lastupdate + ", lastpublish=" + lastpublish + ", useManual=" + useManual + ", uberRegister=" + uberRegister + ", pushId=" + pushId + ", shortLink=" + shortLink + ", testEvent=" + testEvent + ", websiteEnabled=" + websiteEnabled + ", hideEvent=" + hideEvent + ", paymentMethods=" + paymentMethods + ", defaultDisplay=" + defaultDisplay + ", uid=" + uid + '}';
    }

    
}
