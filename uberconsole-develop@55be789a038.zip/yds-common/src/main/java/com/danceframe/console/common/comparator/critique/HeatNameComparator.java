/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.comparator.critique;

import com.danceframe.console.common.model.critique.xml.HeatResultHeat;
import java.util.Comparator;

/**
 *
 * @author lmorallos
 */
public class HeatNameComparator implements Comparator<HeatResultHeat>{

    @Override
    public int compare(HeatResultHeat o1, HeatResultHeat o2) {
        String heat1 = o1.getName();
        String heat2 = o2.getName();
        
        return (extractInt(heat1) - extractInt(heat2));
    }
    
    
     int extractInt(String s) {
        String num = s.replaceAll("\\D", "");
        // return 0 if no digits found
        return num.isEmpty() ? 0 : Integer.parseInt(num);
    }
}
