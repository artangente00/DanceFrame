/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.people;

import com.danceframe.console.common.util.Utility;
import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author nbonita
 */
public class People implements Serializable {
    
    private static final long serialVersionUID = 1L;
    private int     id;
    private String firstName;
    private String lastName;
    private String studioName;
    private String eMail;
    private String gender;
    private String birthday;
    private String category;
    private String invoiceAddress;
    private String firebaseAuthenticationID;
    private String loginProvider;
    private String dateCreated;
    private String dateSignedIn;
    private String facebookUserUID;
     


    public boolean isEmpty() {
        if (getId() > 0) return false;
        if ((null != getFirstName()) || (!firstName.isEmpty()) || (getFirstName().length() > 0))  return false;
        if ((null != getLastName()) || (!lastName.isEmpty()) || (getLastName().length() > 0))  return false;
        if ((null != geteMail()) || (!eMail.isEmpty()) || (geteMail().length() > 0))  return false;
        if ((null != getFirebaseAuthenticationID()) || (!firebaseAuthenticationID.isEmpty()) || (getFirebaseAuthenticationID().length() > 0))  return false;
        if ((null != getLoginProvider()) || (!loginProvider.isEmpty()) || (getLoginProvider().length() > 0))  return false;
        return true;
    }


    @Override
    public String toString() {
        return "User{" + "id=" + getId() + ", firstName=" + getFirstName() + ", lastName=" + getLastName() + ", studioName=" + getStudioName() + ", eMail=" + geteMail() 
                + ", gender=" + getGender() + ", birthday=" + getBirthday() + ", category=" + getCategory() + ", invoiceAddress=" + getInvoiceAddress()
                + ", firebaseAuthenticationID=" + getFirebaseAuthenticationID() + ", loginProvider=" + getLoginProvider()
                + ", dateCreated=" + getDateCreated() + ", dateSignedIn=" + getDateSignedIn() + ", facebookUserUID=" + getFacebookUserUID() + '}';
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * @return the studioName
     */
    public String getStudioName() {
        return studioName;
    }

    /**
     * @param studioName the studioName to set
     */
    public void setStudioName(String studioName) {
        this.studioName = studioName;
    }

    /**
     * @return the eMail
     */
    public String geteMail() {
        return eMail;
    }

    /**
     * @param eMail the eMail to set
     */
    public void seteMail(String eMail) {
        this.eMail = eMail;
    }

    /**
     * @return the gender
     */
    public String getGender() {
        return gender;
    }

    /**
     * @param gender the gender to set
     */
    public void setGender(String gender) {
        this.gender = gender;
    }

    /**
     * @return the birthday
     */
    public String getBirthday() {
        return birthday;
    }

    /**
     * @param birthday the birthday to set
     */
    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    /**
     * @return the category
     */
    public String getCategory() {
        return category;
    }

    /**
     * @param category the category to set
     */
    public void setCategory(String category) {
        this.category = category;
    }

    /**
     * @return the invoiceAddress
     */
    public String getInvoiceAddress() {
        return invoiceAddress;
    }

    /**
     * @param invoiceAddress the invoiceAddress to set
     */
    public void setInvoiceAddress(String invoiceAddress) {
        this.invoiceAddress = invoiceAddress;
    }

    /**
     * @return the firebaseAuthenticationID
     */
    public String getFirebaseAuthenticationID() {
        return firebaseAuthenticationID;
    }

    /**
     * @param firebaseAuthenticationID the firebaseAuthenticationID to set
     */
    public void setFirebaseAuthenticationID(String firebaseAuthenticationID) {
        this.firebaseAuthenticationID = firebaseAuthenticationID;
    }

    /**
     * @return the loginProvider
     */
    public String getLoginProvider() {
        return loginProvider;
    }

    /**
     * @param loginProvider the loginProvider to set
     */
    public void setLoginProvider(String loginProvider) {
        this.loginProvider = loginProvider;
    }

    /**
     * @return the dateCreated
     */
    public String getDateCreated() {
        return dateCreated;
    }

    /**
     * @param dateCreated the dateCreated to set
     */
    public void setDateCreated(String dateCreated) {
        this.dateCreated = dateCreated;
    }

    /**
     * @return the dateSignedIn
     */
    public String getDateSignedIn() {
        return dateSignedIn;
    }

    /**
     * @param dateSignedIn the dateSignedIn to set
     */
    public void setDateSignedIn(String dateSignedIn) {
        this.dateSignedIn = dateSignedIn;
    }

    /**
     * @return the facebookUserUID
     */
    public String getFacebookUserUID() {
        return facebookUserUID;
    }

    /**
     * @param facebookUserUID the facebookUserUID to set
     */
    public void setFacebookUserUID(String facebookUserUID) {
        this.facebookUserUID = facebookUserUID;
    }

    
}
