/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.basic;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class LookUp implements Serializable {
    
    private static final long serialVersionUID = 1L;
    private int     id;
    private String  code;
    private int     index;
    private String  description;

    public LookUp() {}
    
    public LookUp(int id, String code, int index, String desc) {
        this.id = id;
        this.code = code;
        this.index = index;
        this.description = desc;
    }
    
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * @param code the code to set
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * @return the index
     */
    public int getIndex() {
        return index;
    }

    /**
     * @param index the index to set
     */
    public void setIndex(int index) {
        this.index = index;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "EventStatus{" + "id=" + id + ", code=" + code + ", index=" + index + ", description=" + description + '}';
    }

    
}
