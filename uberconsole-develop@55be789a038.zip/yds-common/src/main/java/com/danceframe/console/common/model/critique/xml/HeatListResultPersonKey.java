/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.critique.xml;

import java.io.Serializable;
import org.simpleframework.xml.Root;
import org.simpleframework.xml.Text ;

/**
 *
 * @author lmorallos
 */
@Root(name="personKey")
public class HeatListResultPersonKey implements Serializable {
 
    @Text
    private String personKey;
    
    public HeatListResultPersonKey() {}
    
    public HeatListResultPersonKey(String pk) {
        personKey = pk;
    }

    /**
     * @return the personKey
     */
    public String getPersonKey() {
        return personKey;
    }

    /**
     * @param personKey the personKey to set
     */
    public void setPersonKey(String personKey) {
        this.personKey = personKey;
    }

    @Override
    public String toString() {
        return "HeatListResultPersonKey{" + "personKey=" + personKey + '}';
    }
    
    
}
