/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.basic;

import java.io.ByteArrayInputStream;
import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class Image implements Serializable {
    
    private static final long serialVersionUID = 1L;
    private int     imageId;
    private String  code;
    private int     codeId;
    private String  filname;
    private String  mimeType;
    private byte[]  image;

    /**
     * @return the imageId
     */
    public int getImageId() {
        return imageId;
    }

    /**
     * @param imageId the imageId to set
     */
    public void setImageId(int imageId) {
        this.imageId = imageId;
    }

    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * @param code the code to set
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * @return the codeId
     */
    public int getCodeId() {
        return codeId;
    }

    /**
     * @param codeId the codeId to set
     */
    public void setCodeId(int codeId) {
        this.codeId = codeId;
    }

    /**
     * @return the mimeType
     */
    public String getMimeType() {
        return mimeType;
    }

    /**
     * @param mimeType the mimeType to set
     */
    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    /**
     * @return the image
     */
    public byte[] getImage() {
        return image;
    }

    /**
     * @param image the image to set
     */
    public void setImage(byte[] image) {
        this.image = image;
    }

    public ByteArrayInputStream imageByInputStream() {
        return new ByteArrayInputStream(image);
    }
    

    /**
     * @return the filname
     */
    public String getFilname() {
        return filname;
    }

    /**
     * @param filname the filname to set
     */
    public void setFilname(String filname) {
        this.filname = filname;
    }

    @Override
    public String toString() {
        return "Image{" + "imageId=" + imageId + ", code=" + code + ", codeId=" + codeId + ", filname=" + filname + ", mimeType=" + mimeType + ", image=" + image.length + '}';
    }

   
    
    
    
}
