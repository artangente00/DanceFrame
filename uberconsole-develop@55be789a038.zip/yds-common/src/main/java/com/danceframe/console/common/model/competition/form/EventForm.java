/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.competition.form;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class EventForm implements  Serializable  {
    
    private static final long serialVersionUID = 1L;
    private int     id;
    private int     eventId;
    private String  eventName;
    private int     formId;
    private String  formName;
    private int     formType;
    private String  formTypeName;
    private int     headerType; 
    private String  headerTypeName;
    private int     entryType;
    private String  entryTypeName;
    

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the formId
     */
    public int getFormId() {
        return formId;
    }

    /**
     * @param formId the formId to set
     */
    public void setFormId(int formId) {
        this.formId = formId;
    }

    /**
     * @return the formName
     */
    public String getFormName() {
        return formName;
    }

    /**
     * @param formName the formName to set
     */
    public void setFormName(String formName) {
        this.formName = formName;
    }

    /**
     * @return the formType
     */
    public int getFormType() {
        return formType;
    }

    /**
     * @param formType the formType to set
     */
    public void setFormType(int formType) {
        this.formType = formType;
    }

    /**
     * @return the formTypeName
     */
    public String getFormTypeName() {
        return formTypeName;
    }

    /**
     * @param formTypeName the formTypeName to set
     */
    public void setFormTypeName(String formTypeName) {
        this.formTypeName = formTypeName;
    }

    /**
     * @return the headerType
     */
    public int getHeaderType() {
        return headerType;
    }

    /**
     * @param headerType the headerType to set
     */
    public void setHeaderType(int headerType) {
        this.headerType = headerType;
    }

    /**
     * @return the headerTypeName
     */
    public String getHeaderTypeName() {
        return headerTypeName;
    }

    /**
     * @param headerTypeName the headerTypeName to set
     */
    public void setHeaderTypeName(String headerTypeName) {
        this.headerTypeName = headerTypeName;
    }

    /**
     * @return the entryType
     */
    public int getEntryType() {
        return entryType;
    }

    /**
     * @param entryType the entryType to set
     */
    public void setEntryType(int entryType) {
        this.entryType = entryType;
    }

    /**
     * @return the entryTypeName
     */
    public String getEntryTypeName() {
        return entryTypeName;
    }

    /**
     * @param entryTypeName the entryTypeName to set
     */
    public void setEntryTypeName(String entryTypeName) {
        this.entryTypeName = entryTypeName;
    }

    @Override
    public String toString() {
        return "EventForm{" + "id=" + id + ", eventId=" + eventId + ", formId=" + formId +
                ", formName=" + formName + ", formType=" + formType + ", formTypeName=" + formTypeName + ", headerType=" + headerType + 
                ", headerTypeName=" + headerTypeName + ", entryType=" + entryType + ", entryTypeName=" + entryTypeName + '}';
    }

    /**
     * @return the eventName
     */
    public String getEventName() {
        return eventName;
    }

    /**
     * @param eventName the eventName to set
     */
    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    
    
}
