/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.registry;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class Account implements Serializable {

    private static final long serialVersionUID = 1L;
    private int     id;
    private String  userName;
    private String  firstName;
    private String  lastName;
    private String  midName;
    private String  email;
    private String  address;
    private String  city;
    private String  province;
    private String  state;
    private String  country;
    private String  telePhone;
    private String  mobilePhone;
    private int     accType;
    private String  accDescription;
    private int     active;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the userName
     */
    public String getUserName() {
        return userName;
    }

    /**
     * @param userName the userName to set
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * @return the midName
     */
    public String getMidName() {
        return midName;
    }

    /**
     * @param midName the midName to set
     */
    public void setMidName(String midName) {
        this.midName = midName;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * @return the city
     */
    public String getCity() {
        return city;
    }

    /**
     * @param city the city to set
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * @return the province
     */
    public String getProvince() {
        return province;
    }

    /**
     * @param province the province to set
     */
    public void setProvince(String province) {
        this.province = province;
    }

    /**
     * @return the state
     */
    public String getState() {
        return state;
    }

    /**
     * @param state the state to set
     */
    public void setState(String state) {
        this.state = state;
    }

    /**
     * @return the country
     */
    public String getCountry() {
        return country;
    }

    /**
     * @param country the country to set
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * @return the telePhone
     */
    public String getTelePhone() {
        return telePhone;
    }

    /**
     * @param telePhone the telePhone to set
     */
    public void setTelePhone(String telePhone) {
        this.telePhone = telePhone;
    }

    /**
     * @return the mobilePhone
     */
    public String getMobilePhone() {
        return mobilePhone;
    }

    /**
     * @param mobilePhone the mobilePhone to set
     */
    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    /**
     * @return the accType
     */
    public int getAccType() {
        return accType;
    }

    /**
     * @param accType the accType to set
     */
    public void setAccType(int accType) {
        this.accType = accType;
    }

    /**
     * @return the accDescription
     */
    public String getAccDescription() {
        return accDescription;
    }

    /**
     * @param accDescription the accDescription to set
     */
    public void setAccDescription(String accDescription) {
        this.accDescription = accDescription;
    }

    /**
     * @return the active
     */
    public int getActive() {
        return active;
    }

    /**
     * @param active the active to set
     */
    public void setActive(int active) {
        this.active = active;
    }

    @Override
    public String toString() {
        return "Account{" + "id=" + id + ", userName=" + userName + ", firstName=" + firstName + ", lastName=" + lastName + ", midName=" + midName + ", email=" + email + ", address=" + address + ", city=" + city + ", province=" + province + ", state=" + state + ", country=" + country + ", telePhone=" + telePhone + ", mobilePhone=" + mobilePhone + ", accType=" + accType + ", accDescription=" + accDescription + ", active=" + active + '}';
    }
  
    
}
