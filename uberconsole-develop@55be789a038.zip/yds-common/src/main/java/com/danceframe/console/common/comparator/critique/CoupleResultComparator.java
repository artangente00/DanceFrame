/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.comparator.critique;

import com.danceframe.console.common.model.critique.xml.HeatResultCouple;
import java.util.Comparator;

/**
 *
 * @author lmorallos
 */
public class CoupleResultComparator implements Comparator<HeatResultCouple>{

    @Override
    public int compare(HeatResultCouple o1, HeatResultCouple o2) {
        
        String couple1 = o1.getCoupleKey();
        String couple2 = o2.getCoupleKey();
        
        String person1 = o1.getPersonKeys().get(0).getPersonKey();
        String person2 = o2.getPersonKeys().get(0).getPersonKey();
        
        String partner1 = o1.getPersonKeys().get(1).getPersonKey();
        String partner2 = o2.getPersonKeys().get(1).getPersonKey();
        
        int coup = extractInt(couple1) - extractInt(couple2);
        int res1 = extractInt(person1) - extractInt(person2);
        int res2 = extractInt(partner1) - extractInt(partner2);
        
        if (coup == 0) {
            if (res1 == 0) {
                return res2; 
            } else {
                return res1;
            } 
        } else {
            return coup;
        }
    }
    
    int extractInt(String s) {
        String num = s.replaceAll("\\D", "");
        // return 0 if no digits found
        return num.isEmpty() ? 0 : Integer.parseInt(num);
    }
}
