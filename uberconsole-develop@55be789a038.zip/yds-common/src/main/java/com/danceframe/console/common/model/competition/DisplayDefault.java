/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.competition;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class DisplayDefault implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private int id;
    private int eventId;
    private boolean eventDisplay;
    private boolean venueDisplay;
    private boolean contactDisplay;
    private boolean organizerDisplay;
    private boolean scheduleDisplay;
    private boolean hotelDisplay;
    private boolean sponsorDisplay;
    private boolean informationDisplay;
    private boolean financeDisplay;

    public boolean isAllFalse() {
        return ((!eventDisplay) && (!venueDisplay) && (!contactDisplay) && (!organizerDisplay) && 
                (!scheduleDisplay) && (!hotelDisplay) && (!sponsorDisplay) && (!informationDisplay) && (!financeDisplay))?true:false;
    }
    
    public void setAllFalse() {
        eventDisplay = false;
        venueDisplay = false;
        contactDisplay = false;
        organizerDisplay = false;
        scheduleDisplay = false;
        hotelDisplay = false;
        sponsorDisplay = false;
        informationDisplay = false;
        financeDisplay = false;
    }
    
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the eventDisplay
     */
    public boolean isEventDisplay() {
        return eventDisplay;
    }

    /**
     * @param eventDisplay the eventDisplay to set
     */
    public void setEventDisplay(boolean eventDisplay) {
        this.eventDisplay = eventDisplay;
    }

    /**
     * @return the venueDisplay
     */
    public boolean isVenueDisplay() {
        return venueDisplay;
    }

    /**
     * @param venueDisplay the venueDisplay to set
     */
    public void setVenueDisplay(boolean venueDisplay) {
        this.venueDisplay = venueDisplay;
    }

    /**
     * @return the contactDisplay
     */
    public boolean isContactDisplay() {
        return contactDisplay;
    }

    /**
     * @param contactDisplay the contactDisplay to set
     */
    public void setContactDisplay(boolean contactDisplay) {
        this.contactDisplay = contactDisplay;
    }

    /**
     * @return the organizerDisplay
     */
    public boolean isOrganizerDisplay() {
        return organizerDisplay;
    }

    /**
     * @param organizerDisplay the organizerDisplay to set
     */
    public void setOrganizerDisplay(boolean organizerDisplay) {
        this.organizerDisplay = organizerDisplay;
    }

    /**
     * @return the scheduleDisplay
     */
    public boolean isScheduleDisplay() {
        return scheduleDisplay;
    }

    /**
     * @param scheduleDisplay the scheduleDisplay to set
     */
    public void setScheduleDisplay(boolean scheduleDisplay) {
        this.scheduleDisplay = scheduleDisplay;
    }

    /**
     * @return the hotelDisplay
     */
    public boolean isHotelDisplay() {
        return hotelDisplay;
    }

    /**
     * @param hotelDisplay the hotelDisplay to set
     */
    public void setHotelDisplay(boolean hotelDisplay) {
        this.hotelDisplay = hotelDisplay;
    }

    /**
     * @return the sponsoDisplay
     */
    public boolean isSponsorDisplay() {
        return sponsorDisplay;
    }

    /**
     * @param sponsoDisplay the sponsoDisplay to set
     */
    public void setSponsorDisplay(boolean sponsorDisplay) {
        this.sponsorDisplay = sponsorDisplay;
    }

    /**
     * @return the informationDisplay
     */
    public boolean isInformationDisplay() {
        return informationDisplay;
    }

    /**
     * @param informationDisplay the informationDisplay to set
     */
    public void setInformationDisplay(boolean informationDisplay) {
        this.informationDisplay = informationDisplay;
    }

    /**
     * @return the financeDisplay
     */
    public boolean isFinanceDisplay() {
        return financeDisplay;
    }

    /**
     * @param financeDisplay the financeDisplay to set
     */
    public void setFinanceDisplay(boolean financeDisplay) {
        this.financeDisplay = financeDisplay;
    }

    @Override
    public String toString() {
        return "DisplayDefault{" + "id=" + id + ", eventId=" + eventId + ", eventDisplay=" + eventDisplay + ", venueDisplay=" + venueDisplay + ", contactDisplay=" + contactDisplay + ", organizerDisplay=" + organizerDisplay + ", scheduleDisplay=" + scheduleDisplay + ", hotelDisplay=" + hotelDisplay + ", sponsoDisplay=" + sponsorDisplay + ", informationDisplay=" + informationDisplay + ", financeDisplay=" + financeDisplay + '}';
    }
    
    
    
}
