/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.competition;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class Finance implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private int id;
    private double surcharge;
    private String description;
    private int eventId;
    
    
    public boolean isEmpty() {
        if (surcharge > 0)  return false;
        if ((null != description) || (!description.isEmpty()) || (description.length() > 0))  return false;
        return true;   
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the surcharge
     */
    public double getSurcharge() {
        return surcharge;
    }

    /**
     * @param surcharge the surcharge to set
     */
    public void setSurcharge(double surcharge) {
        this.surcharge = surcharge;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    @Override
    public String toString() {
        return "Finance{" + "id=" + id + ", surcharge=" + surcharge + ", description=" + description + ", eventId=" + eventId + '}';
    }
    
    
    
}
