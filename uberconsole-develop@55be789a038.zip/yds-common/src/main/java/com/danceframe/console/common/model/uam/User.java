/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.uam;

import com.danceframe.console.common.util.Utility;
import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author lmorallos
 */
public class User implements Serializable {
    
     private static final long serialVersionUID = 1L;
     private int     id;
     private String username;
     private String firstname;
     private String lastname;
     private boolean active;
     private Date    datecreated;
     private Date    lastupdated;
     private int     sysuid;
     

   /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return the firstname
     */
    public String getFirstname() {
        return firstname;
    }

    /**
     * @param firstname the firstname to set
     */
    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    /**
     * @return the lastname
     */
    public String getLastname() {
        return lastname;
    }

    /**
     * @param lastname the lastname to set
     */
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }


    /**
     * @return the datecreated
     */
    public Date getDatecreated() {
        return datecreated;
    }

    /**
     * @param datecreated the datecreated to set
     */
    public void setDatecreated(Date datecreated) {
        this.datecreated = datecreated;
    }

    /**
     * @return the lastupdated
     */
    public Date getLastupdated() {
        return lastupdated;
    }

    /**
     * @param lastupdated the lastupdated to set
     */
    public void setLastupdated(Date lastupdated) {
        this.lastupdated = lastupdated;
    }

    /**
     * @return the active
     */
    public boolean isActive() {
        return active;
    }

    /**
     * @param active the active to set
     */
    public void setActive(boolean active) {
        this.active = active;
    }


    /**
     * @return the strActive
     */
    public String getStrActive() {
        return ((active)?"YES":"NO");
    }

    /**
     * @return the strDatecreated
     */
    public String getStrDatecreated() {
        return Utility.date2String(datecreated);
    }



    /**
     * @return the strLastUpdated
     */
    public String getStrLastUpdated() {
        return Utility.date2String(lastupdated);
    }

    public boolean isEmpty() {
        if (id > 0) return false;
        if ((null != username) || (!username.isEmpty()) || (username.length() > 0))  return false;
        if ((null != firstname) || (!firstname.isEmpty()) || (firstname.length() > 0))  return false;
        if ((null != lastname) || (!lastname.isEmpty()) || (lastname.length() > 0))  return false;
        if (null != datecreated) return false;
        if (null != lastupdated) return false;
        return true;
    }

    /**
     * @return the sysuid
     */
    public int getSysuid() {
        return sysuid;
    }

    /**
     * @param sysuid the sysuid to set
     */
    public void setSysuid(int sysuid) {
        this.sysuid = sysuid;
    }

    @Override
    public String toString() {
        return "User{" + "id=" + id + ", username=" + username + ", firstname=" + firstname + ", lastname=" + lastname + ", active=" + active + ", datecreated=" + datecreated + ", lastupdated=" + lastupdated + ", sysuid=" + sysuid + '}';
    }

    
}
