/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.heatlist.result;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

/**
 *
 * @author lmorallos
 */
@Root(name="program")
public class HeatResultProgram implements Serializable {
    
    @ElementList(required=false)
    private ArrayList<HeatResultStudio> studios;
    
    @ElementList(required=false)
    private ArrayList<HeatResultJudge> judges;
    
    @ElementList(required=false)
    private ArrayList<HeatResultPerson> persons;
    
    @ElementList(required=false)
    private ArrayList<HeatResultCompetitor> competitors;
    
    @ElementList(required=false)
    private ArrayList<HeatResultHeat> heats;
    
    private int eventId;
    private int xmlId;
    
    /**
     * @return the studios
     */
    public List<HeatResultStudio> getStudios() {
        return studios;
    }

    /**
     * @param studios the studios to set
     */
    public void setStudios(ArrayList<HeatResultStudio> studios) {
        this.studios = studios;
    }

    /**
     * @return the judges
     */
    public List<HeatResultJudge> getJudges() {
        return judges;
    }

    /**
     * @param judges the judges to set
     */
    public void setJudges(ArrayList<HeatResultJudge> judges) {
        this.judges = judges;
    }

    /**
     * @return the persons
     */
    public List<HeatResultPerson> getPersons() {
        return persons;
    }

    /**
     * @param persons the persons to set
     */
    public void setPersons(ArrayList<HeatResultPerson> persons) {
        this.persons = persons;
    }

    /**
     * @return the heats
     */
    public List<HeatResultHeat> getHeats() {
        return heats;
    }

    /**
     * @param heats the heats to set
     */
    public void setHeats(ArrayList<HeatResultHeat> heats) {
        this.heats = heats;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the xmlId
     */
    public int getXmlId() {
        return xmlId;
    }

    /**
     * @param xmlId the xmlId to set
     */
    public void setXmlId(int xmlId) {
        this.xmlId = xmlId;
    }

    /**
     * @return the competitors
     */
    public ArrayList<HeatResultCompetitor> getCompetitors() {
        return competitors;
    }

    /**
     * @param competitors the competitors to set
     */
    public void setCompetitors(ArrayList<HeatResultCompetitor> competitors) {
        this.competitors = competitors;
    }
    
    
}
