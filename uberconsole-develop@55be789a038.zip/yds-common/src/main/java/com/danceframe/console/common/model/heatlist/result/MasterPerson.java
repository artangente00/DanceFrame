/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.heatlist.result;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class MasterPerson implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private int     id;
    private String  firstname;
    private String  lastname;
    private String  strFirstname;
    private String  strLastname;
    private String  uid;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the firstname
     */
    public String getFirstname() {
        return firstname;
    }

    /**
     * @param firstname the firstname to set
     */
    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    /**
     * @return the lastname
     */
    public String getLastname() {
        return lastname;
    }

    /**
     * @param lastname the lastname to set
     */
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    /**
     * @return the strFirstname
     */
    public String getStrFirstname() {
        if (firstname != null) {
            if (firstname.length() > 0) {
                return firstname;
            } else {
                return "NOFIRSTNAME";
            }
        }
        return "NOFIRSTNAME";
    }

    /**
     * @param strFirstname the strFirstname to set
     */
    public void setStrFirstname(String strFirstname) {
        this.strFirstname = strFirstname;
    }

    /**
     * @return the strLastname
     */
    public String getStrLastname() {
        if (lastname != null) {
            if (lastname.length() > 0) {
                return lastname;
            } else {
                return "NOLASTNAME";
            }
        }
        return "NOLASTNAME";
    }

    /**
     * @param strLastname the strLastname to set
     */
    public void setStrLastname(String strLastname) {
        this.strLastname = strLastname;
    }

    /**
     * @return the uid
     */
    public String getUid() {
        return uid;
    }

    /**
     * @param uid the uid to set
     */
    public void setUid(String uid) {
        this.uid = uid;
    }

    @Override
    public String toString() {
        return "MasterPerson{" + "id=" + id + ", firstname=" + firstname + ", lastname=" + lastname + ", strFirstname=" + strFirstname + ", strLastname=" + strLastname + ", uid=" + uid + '}';
    }
    
    
    
    
    
}
