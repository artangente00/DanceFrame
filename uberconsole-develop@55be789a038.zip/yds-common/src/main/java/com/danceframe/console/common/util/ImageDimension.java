/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.util;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class ImageDimension implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private int width;
    private int height;

    public ImageDimension() {  }
    
    public ImageDimension(int w, int h) {
        width = w;
        height = h;
    };
    
    /**
     * @return the width
     */
    public int getWidth() {
        return width;
    }

    /**
     * @param width the width to set
     */
    public void setWidth(int width) {
        this.width = width;
    }

    /**
     * @return the height
     */
    public int getHeight() {
        return height;
    }

    /**
     * @param height the height to set
     */
    public void setHeight(int height) {
        this.height = height;
    }

    @Override
    public String toString() {
        return "ImageDimension{" + "width=" + width + ", height=" + height + '}';
    }
    
    public String getWidthPix() {
        return Integer.toString(width) + "px";
    }
    
    public String getHeightPix() {
        return Integer.toString(height) + "px";
    }
}
