/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.xml.competition.form;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class Form implements Serializable {
    
    private static final long serialVersionUID = 1L;
     
    private int id;
    private String name;
    private String type;
    private String headerType;
    private String entryType;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the headerType
     */
    public String getHeaderType() {
        return headerType;
    }

    /**
     * @param headerType the headerType to set
     */
    public void setHeaderType(String headerType) {
        this.headerType = headerType;
    }

    /**
     * @return the entryType
     */
    public String getEntryType() {
        return entryType;
    }

    /**
     * @param entryType the entryType to set
     */
    public void setEntryType(String entryType) {
        this.entryType = entryType;
    }
    
}
