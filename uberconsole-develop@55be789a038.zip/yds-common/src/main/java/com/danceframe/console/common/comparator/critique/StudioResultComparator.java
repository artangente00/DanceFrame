/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.comparator.critique;

import com.danceframe.console.common.model.critique.xml.HeatResultStudio;
import java.util.Comparator;

/**
 *
 * @author lmorallos
 */
public class StudioResultComparator implements Comparator<HeatResultStudio>{

    @Override
    public int compare(HeatResultStudio o1, HeatResultStudio o2) {
        String name1 = o1.getName().toUpperCase();
        String name2 = o2.getName().toUpperCase();
        
        String inv1 = o1.getIndependentInvoice().toUpperCase();
        String inv2 = o2.getIndependentInvoice().toUpperCase();
        
         if (name1.compareTo(name2) == 0) {
            return (inv1.compareTo(inv2));
        } else {
            return name1.compareTo(name2);
        }
    }
    
}
