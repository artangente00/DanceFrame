/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.payment;

import java.io.Serializable;

/**
 *
 * @author NDB
 */
public class Payment  implements Serializable {
    
    private static final long serialVersionUID = 1L;
    private int     id;
    private int     invoiceId;
    private String amountPaid;
    private String typeOfPayment;
    private String paymentTimestamp;
    private String uberConsoleUserId;

    public boolean isEmpty() {
        if (getId() > 0) return false;
        if (getInvoiceId() >0)  return false;
        if ((null != getAmountPaid()) || (!getAmountPaid().isEmpty()) || (getAmountPaid().length() > 0))  return false;
        return true;
    }


    @Override
    public String toString() {
        return "Invoice{" + "id=" + getId() + ", invoiceId=" + getInvoiceId() + ", amountPaid=" + getAmountPaid() 
                + ", typeOfPayment=" + getTypeOfPayment() + ", paymentTimestamp=" + getPaymentTimestamp() 
                + ", uberConsoleUserId=" + getUberConsoleUserId()
                + '}';
    }
    
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the invoiceId
     */
    public int getInvoiceId() {
        return invoiceId;
    }

    /**
     * @param invoiceId the invoiceId to set
     */
    public void setInvoiceId(int invoiceId) {
        this.invoiceId = invoiceId;
    }

    /**
     * @return the amountPaid
     */
    public String getAmountPaid() {
        return amountPaid;
    }

    /**
     * @param amountPaid the amountPaid to set
     */
    public void setAmountPaid(String amountPaid) {
        this.amountPaid = amountPaid;
    }

    /**
     * @return the typeOfPayment
     */
    public String getTypeOfPayment() {
        return typeOfPayment;
    }

    /**
     * @param typeOfPayment the typeOfPayment to set
     */
    public void setTypeOfPayment(String typeOfPayment) {
        this.typeOfPayment = typeOfPayment;
    }

    /**
     * @return the paymentTimestamp
     */
    public String getPaymentTimestamp() {
        return paymentTimestamp;
    }

    /**
     * @param paymentTimestamp the paymentTimestamp to set
     */
    public void setPaymentTimestamp(String paymentTimestamp) {
        this.paymentTimestamp = paymentTimestamp;
    }

    /**
     * @return the uberConsoleUserId
     */
    public String getUberConsoleUserId() {
        return uberConsoleUserId;
    }

    /**
     * @param uberConsoleUserId the uberConsoleUserId to set
     */
    public void setUberConsoleUserId(String uberConsoleUserId) {
        this.uberConsoleUserId = uberConsoleUserId;
    }

    

}
