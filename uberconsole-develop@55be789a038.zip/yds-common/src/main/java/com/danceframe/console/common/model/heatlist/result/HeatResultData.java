/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.heatlist.result;

import java.io.Serializable;


/**
 *
 * @author lmorallos
 */
public class HeatResultData implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private int id;
    private String  coupleKey;
    private String  coupleValue;
    private String  judgingPanel;
    private String  scoreHeaders;
    private String  personKey1;
    private String  personKey2;
    private String  subHeatType;
    private String  subHeatDance;
    private String  subHeatLevel;    
    private String  subHeatAge;
    private String  heatName;
    private String  heatSession;
    private String  heatTime;
    private String  heatDate;
    private String  heatDesc;
    private String  heatType;
    private String  category;
    private int coupleId;
    private int resultId;
    private int subHeatId;
    private int heatId;
    private int eventId;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the coupleKey
     */
    public String getCoupleKey() {
        return coupleKey;
    }

    /**
     * @param coupleKey the coupleKey to set
     */
    public void setCoupleKey(String coupleKey) {
        this.coupleKey = coupleKey;
    }

    /**
     * @return the coupleValue
     */
    public String getCoupleValue() {
        return coupleValue;
    }

    /**
     * @param coupleValue the coupleValue to set
     */
    public void setCoupleValue(String coupleValue) {
        this.coupleValue = coupleValue;
    }

    /**
     * @return the judgingPanel
     */
    public String getJudgingPanel() {
        return judgingPanel;
    }

    /**
     * @param judgingPanel the judgingPanel to set
     */
    public void setJudgingPanel(String judgingPanel) {
        this.judgingPanel = judgingPanel;
    }

    /**
     * @return the scoreHeaders
     */
    public String getScoreHeaders() {
        return scoreHeaders;
    }

    /**
     * @param scoreHeaders the scoreHeaders to set
     */
    public void setScoreHeaders(String scoreHeaders) {
        this.scoreHeaders = scoreHeaders;
    }

    /**
     * @return the personKey1
     */
    public String getPersonKey1() {
        return personKey1;
    }

    /**
     * @param personKey1 the personKey1 to set
     */
    public void setPersonKey1(String personKey1) {
        this.personKey1 = personKey1;
    }

    /**
     * @return the personKey2
     */
    public String getPersonKey2() {
        return personKey2;
    }

    /**
     * @param personKey2 the personKey2 to set
     */
    public void setPersonKey2(String personKey2) {
        this.personKey2 = personKey2;
    }

    /**
     * @return the subHeatType
     */
    public String getSubHeatType() {
        return subHeatType;
    }

    /**
     * @param subHeatType the subHeatType to set
     */
    public void setSubHeatType(String subHeatType) {
        this.subHeatType = subHeatType;
    }

    /**
     * @return the subHeatDance
     */
    public String getSubHeatDance() {
        return subHeatDance;
    }

    /**
     * @param subHeatDance the subHeatDance to set
     */
    public void setSubHeatDance(String subHeatDance) {
        this.subHeatDance = subHeatDance;
    }

    /**
     * @return the subHeatLevel
     */
    public String getSubHeatLevel() {
        return subHeatLevel;
    }

    /**
     * @param subHeatLevel the subHeatLevel to set
     */
    public void setSubHeatLevel(String subHeatLevel) {
        this.subHeatLevel = subHeatLevel;
    }

    /**
     * @return the subHeatAge
     */
    public String getSubHeatAge() {
        return subHeatAge;
    }

    /**
     * @param subHeatAge the subHeatAge to set
     */
    public void setSubHeatAge(String subHeatAge) {
        this.subHeatAge = subHeatAge;
    }

    /**
     * @return the heatName
     */
    public String getHeatName() {
        return heatName;
    }

    /**
     * @param heatName the heatName to set
     */
    public void setHeatName(String heatName) {
        this.heatName = heatName;
    }

    /**
     * @return the heatSession
     */
    public String getHeatSession() {
        return heatSession;
    }

    /**
     * @param heatSession the heatSession to set
     */
    public void setHeatSession(String heatSession) {
        this.heatSession = heatSession;
    }

    /**
     * @return the heatTime
     */
    public String getHeatTime() {
        return heatTime;
    }

    /**
     * @param heatTime the heatTime to set
     */
    public void setHeatTime(String heatTime) {
        this.heatTime = heatTime;
    }

    /**
     * @return the heatDate
     */
    public String getHeatDate() {
        return heatDate;
    }

    /**
     * @param heatDate the heatDate to set
     */
    public void setHeatDate(String heatDate) {
        this.heatDate = heatDate;
    }

    /**
     * @return the heatDesc
     */
    public String getHeatDesc() {
        return heatDesc;
    }

    /**
     * @param heatDesc the heatDesc to set
     */
    public void setHeatDesc(String heatDesc) {
        this.heatDesc = heatDesc;
    }

    /**
     * @return the heatType
     */
    public String getHeatType() {
        return heatType;
    }

    /**
     * @param heatType the heatType to set
     */
    public void setHeatType(String heatType) {
        this.heatType = heatType;
    }

    /**
     * @return the coupleId
     */
    public int getCoupleId() {
        return coupleId;
    }

    /**
     * @param coupleId the coupleId to set
     */
    public void setCoupleId(int coupleId) {
        this.coupleId = coupleId;
    }

    /**
     * @return the resultId
     */
    public int getResultId() {
        return resultId;
    }

    /**
     * @param resultId the resultId to set
     */
    public void setResultId(int resultId) {
        this.resultId = resultId;
    }

    /**
     * @return the subHeatId
     */
    public int getSubHeatId() {
        return subHeatId;
    }

    /**
     * @param subHeatId the subHeatId to set
     */
    public void setSubHeatId(int subHeatId) {
        this.subHeatId = subHeatId;
    }

    /**
     * @return the heatId
     */
    public int getHeatId() {
        return heatId;
    }

    /**
     * @param heatId the heatId to set
     */
    public void setHeatId(int heatId) {
        this.heatId = heatId;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the category
     */
    public String getCategory() {
        return category;
    }

    /**
     * @param category the category to set
     */
    public void setCategory(String category) {
        this.category = category;
    }

    @Override
    public String toString() {
        return "HeatResultData{" + "id=" + id + ", coupleKey=" + coupleKey + ", coupleValue=" + coupleValue + ", judgingPanel=" + judgingPanel + ", scoreHeaders=" + scoreHeaders + ", personKey1=" + personKey1 + ", personKey2=" + personKey2 + ", subHeatType=" + subHeatType + ", subHeatDance=" + subHeatDance + ", subHeatLevel=" + subHeatLevel + ", subHeatAge=" + subHeatAge + ", heatName=" + heatName + ", heatSession=" + heatSession + ", heatTime=" + heatTime + ", heatDate=" + heatDate + ", heatDesc=" + heatDesc + ", heatType=" + heatType + ", category=" + category + ", coupleId=" + coupleId + ", resultId=" + resultId + ", subHeatId=" + subHeatId + ", heatId=" + heatId + ", eventId=" + eventId + '}';
    }
    
    

    
}
