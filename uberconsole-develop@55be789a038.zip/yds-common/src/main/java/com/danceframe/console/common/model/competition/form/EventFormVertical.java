/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.competition.form;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class EventFormVertical implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private int id;
    private int fieldId;
    private int eventformId;
    private String code;
    private String description;
    private boolean allowall;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the eventformId
     */
    public int getEventformId() {
        return eventformId;
    }

    /**
     * @param eventformId the eventformId to set
     */
    public void setEventformId(int eventformId) {
        this.eventformId = eventformId;
    }

    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * @param code the code to set
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the allowall
     */
    public boolean isAllowall() {
        return allowall;
    }

    /**
     * @param allowall the allowall to set
     */
    public void setAllowall(boolean allowall) {
        this.allowall = allowall;
    }
    
    
    public String getAllowStr() {
        return ((allowall)? "YES": "NO");
    }
   
    /**
     * @return the fieldId
     */
    public int getFieldId() {
        return fieldId;
    }

    /**
     * @param fieldId the fieldId to set
     */
    public void setFieldId(int fieldId) {
        this.fieldId = fieldId;
    }

    @Override
    public String toString() {
        return "EventFormVertical{" + "id=" + id + ", fieldId=" + fieldId + ", eventformId=" + eventformId + 
                ", code=" + code + ", description=" + description + ", allowall=" + allowall + '}';
    }
    
            
    
}
