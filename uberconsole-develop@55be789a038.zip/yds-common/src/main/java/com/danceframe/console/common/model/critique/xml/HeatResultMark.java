/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.critique.xml;

import java.io.Serializable;
import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.Root;
import org.simpleframework.xml.Text;

/**
 *
 * @author lmorallos
 */
@Root(name="mark")
public class HeatResultMark implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private int id;
    @Attribute
    private String coupleKey;
    @Text
    private String coupleValue;
    private int coupleId;
    private int resultId;
    private int subHeatId;
    private int eventId;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the coupleKey
     */
    public String getCoupleKey() {
        return coupleKey;
    }

    /**
     * @param coupleKey the coupleKey to set
     */
    public void setCoupleKey(String coupleKey) {
        this.coupleKey = coupleKey;
    }

    /**
     * @return the coupleValue
     */
    public String getCoupleValue() {
        return coupleValue;
    }

    /**
     * @param coupleValue the coupleValue to set
     */
    public void setCoupleValue(String coupleValue) {
        this.coupleValue = coupleValue;
    }

    /**
     * @return the coupleId
     */
    public int getCoupleId() {
        return coupleId;
    }

    /**
     * @param coupleId the coupleId to set
     */
    public void setCoupleId(int coupleId) {
        this.coupleId = coupleId;
    }

    /**
     * @return the resultId
     */
    public int getResultId() {
        return resultId;
    }

    /**
     * @param resultId the resultId to set
     */
    public void setResultId(int resultId) {
        this.resultId = resultId;
    }

    /**
     * @return the subHeatId
     */
    public int getSubHeatId() {
        return subHeatId;
    }

    /**
     * @param subHeatId the subHeatId to set
     */
    public void setSubHeatId(int subHeatId) {
        this.subHeatId = subHeatId;
    }


    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    @Override
    public String toString() {
        return "HeatResultMark{" + "id=" + id + ", coupleKey=" + coupleKey + ", coupleValue=" + coupleValue + ", coupleId=" + coupleId + ", resultId=" + resultId + ", subHeatId=" + subHeatId + ", eventId=" + eventId + '}';
    }

    
}
