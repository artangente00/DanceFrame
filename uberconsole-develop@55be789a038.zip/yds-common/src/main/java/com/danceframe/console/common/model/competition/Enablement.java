/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.competition;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class Enablement implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private int id;
    private int eventId;
    private boolean venueEnable;
    private boolean contactEnable;
    private boolean organizerEnable;
    private boolean scheduleEnable;
    private boolean hotelEnable;
    private boolean sponsorEnable;
    private boolean informationEnable;
    private boolean financeEnable;

    public boolean isAllFalse() {
        return ((!venueEnable) && (!contactEnable) && (!organizerEnable) && (!scheduleEnable) && 
                (!hotelEnable) && (!sponsorEnable) && (!informationEnable) && (!financeEnable))?true:false;
    }
    
    public void setFalseAll() {
        venueEnable = false;
        contactEnable = false;
        organizerEnable = false;
        scheduleEnable = false;
        hotelEnable = false;
        sponsorEnable = false;
        informationEnable = false; 
        financeEnable = false;
    }
    
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the venueEnable
     */
    public boolean isVenueEnable() {
        return venueEnable;
    }

    /**
     * @param venueEnable the venueEnable to set
     */
    public void setVenueEnable(boolean venueEnable) {
        this.venueEnable = venueEnable;
    }

    /**
     * @return the contactEnable
     */
    public boolean isContactEnable() {
        return contactEnable;
    }

    /**
     * @param contactEnable the contactEnable to set
     */
    public void setContactEnable(boolean contactEnable) {
        this.contactEnable = contactEnable;
    }

    /**
     * @return the organizerEnable
     */
    public boolean isOrganizerEnable() {
        return organizerEnable;
    }

    /**
     * @param organizerEnable the organizerEnable to set
     */
    public void setOrganizerEnable(boolean organizerEnable) {
        this.organizerEnable = organizerEnable;
    }

    /**
     * @return the scheduleEnable
     */
    public boolean isScheduleEnable() {
        return scheduleEnable;
    }

    /**
     * @param scheduleEnable the scheduleEnable to set
     */
    public void setScheduleEnable(boolean scheduleEnable) {
        this.scheduleEnable = scheduleEnable;
    }

    /**
     * @return the hotelEnable
     */
    public boolean isHotelEnable() {
        return hotelEnable;
    }

    /**
     * @param hotelEnable the hotelEnable to set
     */
    public void setHotelEnable(boolean hotelEnable) {
        this.hotelEnable = hotelEnable;
    }

    /**
     * @return the sponsorEnable
     */
    public boolean isSponsorEnable() {
        return sponsorEnable;
    }

    /**
     * @param sponsorEnable the sponsorEnable to set
     */
    public void setSponsorEnable(boolean sponsorEnable) {
        this.sponsorEnable = sponsorEnable;
    }

    /**
     * @return the informationEnable
     */
    public boolean isInformationEnable() {
        return informationEnable;
    }

    /**
     * @param informationEnable the informationEnable to set
     */
    public void setInformationEnable(boolean informationEnable) {
        this.informationEnable = informationEnable;
    }

    /**
     * @return the financeEnable
     */
    public boolean isFinanceEnable() {
        return financeEnable;
    }

    /**
     * @param financeEnable the financeEnable to set
     */
    public void setFinanceEnable(boolean financeEnable) {
        this.financeEnable = financeEnable;
    }

    @Override
    public String toString() {
        return "Enablement{" + "id=" + id + ", eventId=" + eventId + ", venueEnable=" + venueEnable + ", contactEnable=" + contactEnable + ", organizerEnable=" + organizerEnable + ", scheduleEnable=" + scheduleEnable + ", hotelEnable=" + hotelEnable + ", sponsorEnable=" + sponsorEnable + ", informationEnable=" + informationEnable + ", financeEnable=" + financeEnable + '}';
    }
    
    
    
    
}
