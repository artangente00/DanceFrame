/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.competition.form;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class EventFormCellAllow implements Serializable {
    
    private static final long serialVersionUID = 1L;
     
    private int     id;
    private int     eventFormId;
    private int     eventVertitcalId;
    private int     eventDanceId;
    private String  vertCode;
    private String  vertDescription;
    private String  danceCode;
    private String  danceDescription;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }
    /**
     * @return the eventVertitcalId
     */
    public int getEventVertitcalId() {
        return eventVertitcalId;
    }

    /**
     * @param eventVertitcalId the eventVertitcalId to set
     */
    public void setEventVertitcalId(int eventVertitcalId) {
        this.eventVertitcalId = eventVertitcalId;
    }

    /**
     * @return the eventDanceId
     */
    public int getEventDanceId() {
        return eventDanceId;
    }

    /**
     * @param eventDanceId the eventDanceId to set
     */
    public void setEventDanceId(int eventDanceId) {
        this.eventDanceId = eventDanceId;
    }

    /**
     * @return the eventFormId
     */
    public int getEventFormId() {
        return eventFormId;
    }

    /**
     * @param eventFormId the eventFormId to set
     */
    public void setEventFormId(int eventFormId) {
        this.eventFormId = eventFormId;
    }


    /**
     * @return the vertCode
     */
    public String getVertCode() {
        return vertCode;
    }

    /**
     * @param vertCode the vertCode to set
     */
    public void setVertCode(String vertCode) {
        this.vertCode = vertCode;
    }

    /**
     * @return the vertDescription
     */
    public String getVertDescription() {
        return vertDescription;
    }

    /**
     * @param vertDescription the vertDescription to set
     */
    public void setVertDescription(String vertDescription) {
        this.vertDescription = vertDescription;
    }

    /**
     * @return the danceCode
     */
    public String getDanceCode() {
        return danceCode;
    }

    /**
     * @param danceCode the danceCode to set
     */
    public void setDanceCode(String danceCode) {
        this.danceCode = danceCode;
    }

    /**
     * @return the danceDescription
     */
    public String getDanceDescription() {
        return danceDescription;
    }

    /**
     * @param danceDescription the danceDescription to set
     */
    public void setDanceDescription(String danceDescription) {
        this.danceDescription = danceDescription;
    }
    
    
    
}
