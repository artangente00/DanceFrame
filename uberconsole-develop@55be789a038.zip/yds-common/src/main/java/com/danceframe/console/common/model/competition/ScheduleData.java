/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.competition;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class ScheduleData implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private int id;
    private int eventId;
    private String headerName;
    private String timeValue;
    private String description;
    private int    hdrOrder;
    private int    tvalOrder;
    
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the headerName
     */
    public String getHeaderName() {
        return headerName;
    }

    /**
     * @param headerName the headerName to set
     */
    public void setHeaderName(String headerName) {
        this.headerName = headerName;
    }

    /**
     * @return the timeValue
     */
    public String getTimeValue() {
        return timeValue;
    }

    /**
     * @param timeValue the timeValue to set
     */
    public void setTimeValue(String timeValue) {
        this.timeValue = timeValue;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the hdrOrder
     */
    public int getHdrOrder() {
        return hdrOrder;
    }

    /**
     * @param hdrOrder the hdrOrder to set
     */
    public void setHdrOrder(int hdrOrder) {
        this.hdrOrder = hdrOrder;
    }

    /**
     * @return the tvalOrder
     */
    public int getTvalOrder() {
        return tvalOrder;
    }

    /**
     * @param tvalOrder the tvalOrder to set
     */
    public void setTvalOrder(int tvalOrder) {
        this.tvalOrder = tvalOrder;
    }

    @Override
    public String toString() {
        return "ScheduleData{" + "id=" + id + ", eventId=" + eventId + ", headerName=" + headerName + ", timeValue=" + timeValue + ", description=" + description + ", hdrOrder=" + hdrOrder + ", tvalOrder=" + tvalOrder + '}';
    }

    
}
