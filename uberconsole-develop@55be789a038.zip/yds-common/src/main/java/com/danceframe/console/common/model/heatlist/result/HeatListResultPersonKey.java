/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.heatlist.result;

import java.io.Serializable;
import org.simpleframework.xml.Root;
import org.simpleframework.xml.Text ;

/**
 *
 * @author lmorallos
 */
@Root(name="personKey")
public class HeatListResultPersonKey implements Serializable {

    private int id;
    
    @Text
    private String personKey;
    
    private int     competitorId;
    private int     eventId;
    private int     xmlId;
    
    public HeatListResultPersonKey() {}
    
    public HeatListResultPersonKey(String pk) {
        personKey = pk;
    }

     /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }
 
    /**
     * @return the personKey
     */
    public String getPersonKey() {
        return personKey;
    }

    /**
     * @param personKey the personKey to set
     */
    public void setPersonKey(String personKey) {
        this.personKey = personKey;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the xmlId
     */
    public int getXmlId() {
        return xmlId;
    }

    /**
     * @param xmlId the xmlId to set
     */
    public void setXmlId(int xmlId) {
        this.xmlId = xmlId;
    }

    /**
     * @return the competitorId
     */
    public int getCompetitorId() {
        return competitorId;
    }

    /**
     * @param competitorId the competitorId to set
     */
    public void setCompetitorId(int competitorId) {
        this.competitorId = competitorId;
    }

    @Override
    public String toString() {
        return "HeatListResultPersonKey{" + "id=" + id + ", personKey=" + personKey + ", competitorId=" + competitorId + ", eventId=" + eventId + ", xmlId=" + xmlId + '}';
    }

}
