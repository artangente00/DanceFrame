/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.heatlist.result;

import java.io.Serializable;
import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

/**
 *
 * @author lmorallos
 */
@Root(name="studio")
public class HeatResultStudio implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private int     id;
    @Attribute
    private String  studioKey;
    @Element(required=false)
    private String  name;
    @Element(required=false)
    private String  independentInvoice;
    private int     eventId;
    private int     xmlId;
    
    public HeatResultStudio() {}
    
    public HeatResultStudio(String sk, String nm, String ind) {
        studioKey = sk;
        name = nm;
        independentInvoice = ind;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the studioKey
     */
    public String getStudioKey() {
        return studioKey;
    }

    /**
     * @param studioKey the studioKey to set
     */
    public void setStudioKey(String studioKey) {
        this.studioKey = studioKey;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the independentInvoice
     */
    public String getIndependentInvoice() {
        return independentInvoice;
    }

    /**
     * @param independentInvoice the independentInvoice to set
     */
    public void setIndependentInvoice(String independentInvoice) {
        this.independentInvoice = independentInvoice;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the xmlId
     */
    public int getXmlId() {
        return xmlId;
    }

    /**
     * @param xmlId the xmlId to set
     */
    public void setXmlId(int xmlId) {
        this.xmlId = xmlId;
    }

    @Override
    public String toString() {
        return "HeatResultStudio{" + "id=" + id + ", studioKey=" + studioKey + ", name=" + name + ", independentInvoice=" + independentInvoice + ", eventId=" + eventId + ", xmlId=" + xmlId + '}';
    }
    
    
    
}
