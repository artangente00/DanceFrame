/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.registration;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author lmorallos
 */
public class RegEntry implements Serializable {
    
    private static final long serialVersionUID = 1L;

    private int     id;
    private String  formId;
    private String  ageId;
    private String  levelId;
    private String  danceId;
    private String  danceCatId;
    private int     userId;
    private String  buid;
    private int     eventId;
    private String  euid;
    private String  competitorId;
    private String  cuid;
    private String  iuid;
    private Date    creationDate;
    private Date    lastModified;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the formId
     */
    public String getFormId() {
        return formId;
    }

    /**
     * @param formId the formId to set
     */
    public void setFormId(String formId) {
        this.formId = formId;
    }

    /**
     * @return the ageId
     */
    public String getAgeId() {
        return ageId;
    }

    /**
     * @param ageId the ageId to set
     */
    public void setAgeId(String ageId) {
        this.ageId = ageId;
    }

    /**
     * @return the levelId
     */
    public String getLevelId() {
        return levelId;
    }

    /**
     * @param levelId the levelId to set
     */
    public void setLevelId(String levelId) {
        this.levelId = levelId;
    }

    /**
     * @return the danceId
     */
    public String getDanceId() {
        return danceId;
    }

    /**
     * @param danceId the danceId to set
     */
    public void setDanceId(String danceId) {
        this.danceId = danceId;
    }

    /**
     * @return the danceCatId
     */
    public String getDanceCatId() {
        return danceCatId;
    }

    /**
     * @param danceCatId the danceCatId to set
     */
    public void setDanceCatId(String danceCatId) {
        this.danceCatId = danceCatId;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the euid
     */
    public String getEuid() {
        return euid;
    }

    /**
     * @param euid the euid to set
     */
    public void setEuid(String euid) {
        this.euid = euid;
    }

    /**
     * @return the competitorId
     */
    public String getCompetitorId() {
        return competitorId;
    }

    /**
     * @param competitorId the competitorId to set
     */
    public void setCompetitorId(String competitorId) {
        this.competitorId = competitorId;
    }

    /**
     * @return the cuid
     */
    public String getCuid() {
        return cuid;
    }

    /**
     * @param cuid the cuid to set
     */
    public void setCuid(String cuid) {
        this.cuid = cuid;
    }

    /**
     * @return the creationDate
     */
    public Date getCreationDate() {
        return creationDate;
    }

    /**
     * @param creationDate the creationDate to set
     */
    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    /**
     * @return the lastModified
     */
    public Date getLastModified() {
        return lastModified;
    }

    /**
     * @param lastModified the lastModified to set
     */
    public void setLastModified(Date lastModified) {
        this.lastModified = lastModified;
    }

    /**
     * @return the iuid
     */
    public String getIuid() {
        return iuid;
    }

    /**
     * @param iuid the iuid to set
     */
    public void setIuid(String iuid) {
        this.iuid = iuid;
    }

    /**
     * @return the userId
     */
    public int getUserId() {
        return userId;
    }

    /**
     * @param userId the userId to set
     */
    public void setUserId(int userId) {
        this.userId = userId;
    }

    /**
     * @return the buid
     */
    public String getBuid() {
        return buid;
    }

    /**
     * @param buid the buid to set
     */
    public void setBuid(String buid) {
        this.buid = buid;
    }

    @Override
    public String toString() {
        return "RegEntry{" + "id=" + id + ", formId=" + formId + ", ageId=" + ageId + ", levelId=" + levelId + ", danceId=" + danceId + ", danceCatId=" + danceCatId + ", userId=" + userId + ", buid=" + buid + ", eventId=" + eventId + ", euid=" + euid + ", competitorId=" + competitorId + ", cuid=" + cuid + ", iuid=" + iuid + ", creationDate=" + creationDate + ", lastModified=" + lastModified + '}';
    }
    
}
