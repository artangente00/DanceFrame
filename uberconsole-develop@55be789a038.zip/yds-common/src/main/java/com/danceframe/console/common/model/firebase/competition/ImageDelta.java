/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.firebase.competition;

import java.io.Serializable;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public class ImageDelta implements Serializable {
    
    private static long serialVersionUID = 1L;
    
    private List<ImageBlob> imageList;

    /**
     * @return the imageList
     */
    public List<ImageBlob> getImageList() {
        return imageList;
    }

    /**
     * @param imageList the imageList to set
     */
    public void setImageList(List<ImageBlob> imageList) {
        this.imageList = imageList;
    }

    
}
