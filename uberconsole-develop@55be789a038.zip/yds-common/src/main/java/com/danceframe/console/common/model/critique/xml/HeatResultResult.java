/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.critique.xml;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

/**
 *
 * @author lmorallos
 */
@Root(name="result")
public class HeatResultResult implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private int id;
    @Element (required=false)
    private String judgingPanel;
    @Element (required=false)
    private String scoreHeaders;
    private int subHeatId;
    private int eventId;
     
    @ElementList
    private ArrayList<HeatResultMark> marks;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the judgingPanel
     */
    public String getJudgingPanel() {
        return judgingPanel;
    }

    /**
     * @param judgingPanel the judgingPanel to set
     */
    public void setJudgingPanel(String judgingPanel) {
        this.judgingPanel = judgingPanel;
    }

    /**
     * @return the scoreHeaders
     */
    public String getScoreHeaders() {
        return scoreHeaders;
    }

    /**
     * @param scoreHeaders the scoreHeaders to set
     */
    public void setScoreHeaders(String scoreHeaders) {
        this.scoreHeaders = scoreHeaders;
    }

    /**
     * @return the subHeatId
     */
    public int getSubHeatId() {
        return subHeatId;
    }

    /**
     * @param subHeatId the subHeatId to set
     */
    public void setSubHeatId(int subHeatId) {
        this.subHeatId = subHeatId;
    }

    /**
     * @return the marks
     */
    public List<HeatResultMark> getMarks() {
        return marks;
    }

    /**
     * @param marks the marks to set
     */
    public void setMarks(ArrayList<HeatResultMark> marks) {
        this.marks = marks;
    }

    @Override
    public String toString() {
        return "HeatResultResult{" + "id=" + id + ", judgingPanel=" + judgingPanel + ", scoreHeaders=" + scoreHeaders + ", subHeatId=" + subHeatId + ", marks=" + marks + '}';
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    
}
