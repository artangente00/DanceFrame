/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.heatlist.result;

import java.io.Serializable;
import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.Root;
import org.simpleframework.xml.Text;

/**
 *
 * @author lmorallos
 */
@Root(name="mark")
public class HeatResultMark implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private int id;
    @Attribute
    private String key;
    
    @Attribute (required=false)
    private String studioKey;
    
    @Attribute (required=false)
    private String studioName;   
     
    @Text
    private String value;
    private int competitorId;
    private int resultId;
    private int subHeatId;
    private int eventId;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the resultId
     */
    public int getResultId() {
        return resultId;
    }

    /**
     * @param resultId the resultId to set
     */
    public void setResultId(int resultId) {
        this.resultId = resultId;
    }

    /**
     * @return the subHeatId
     */
    public int getSubHeatId() {
        return subHeatId;
    }

    /**
     * @param subHeatId the subHeatId to set
     */
    public void setSubHeatId(int subHeatId) {
        this.subHeatId = subHeatId;
    }


    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the key
     */
    public String getKey() {
        return key;
    }

    /**
     * @param key the key to set
     */
    public void setKey(String key) {
        this.key = key;
    }

    /**
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * @param value the value to set
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * @return the competitorId
     */
    public int getCompetitorId() {
        return competitorId;
    }

    /**
     * @param competitorId the competitorId to set
     */
    public void setCompetitorId(int competitorId) {
        this.competitorId = competitorId;
    }

    /**
     * @return the studioKey
     */
    public String getStudioKey() {
        return studioKey;
    }

    /**
     * @param studioKey the studioKey to set
     */
    public void setStudioKey(String studioKey) {
        this.studioKey = studioKey;
    }

    /**
     * @return the studioName
     */
    public String getStudioName() {
        return studioName;
    }

    /**
     * @param studioName the studioName to set
     */
    public void setStudioName(String studioName) {
        this.studioName = studioName;
    }

    @Override
    public String toString() {
        return "HeatResultMark{" + "id=" + id + ", key=" + key + ", studioKey=" + studioKey + ", studioName=" + studioName + ", value=" + value + ", competitorId=" + competitorId + ", resultId=" + resultId + ", subHeatId=" + subHeatId + ", eventId=" + eventId + '}';
    }
    
    
    
}
