/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.firebase.competition;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class ImageBlob implements Serializable {
    
    private static long serialVersionUID = 1L;
    
    private int     imageId;
    private int     eventId;
    private String  onDBFilename;
    private String  onDBMd5sum;
    private String  storageFolder;
    private String  storageMd5sum;
    private String  storageMediaLink;
    private long    storageSize;
    

    /**
     * @return the imageId
     */
    public int getImageId() {
        return imageId;
    }

    /**
     * @param imageId the imageId to set
     */
    public void setImageId(int imageId) {
        this.imageId = imageId;
    }

    /**
     * @return the onDBFilename
     */
    public String getOnDBFilename() {
        return onDBFilename;
    }

    /**
     * @param onDBFilename the onDBFilename to set
     */
    public void setOnDBFilename(String onDBFilename) {
        this.onDBFilename = onDBFilename;
    }

    /**
     * @return the onDBMd5sum
     */
    public String getOnDBMd5sum() {
        return onDBMd5sum;
    }

    /**
     * @param onDBMd5sum the onDBMd5sum to set
     */
    public void setOnDBMd5sum(String onDBMd5sum) {
        this.onDBMd5sum = onDBMd5sum;
    }

    /**
     * @return the storageFolder
     */
    public String getStorageFolder() {
        return storageFolder;
    }

    /**
     * @param storageFolder the storageFolder to set
     */
    public void setStorageFolder(String storageFolder) {
        this.storageFolder = storageFolder;
    }

    /**
     * @return the storageMd5sum
     */
    public String getStorageMd5sum() {
        return storageMd5sum;
    }

    /**
     * @param storageMd5sum the storageMd5sum to set
     */
    public void setStorageMd5sum(String storageMd5sum) {
        this.storageMd5sum = storageMd5sum;
    }

    /**
     * @return the storageSize
     */
    public long getStorageSize() {
        return storageSize;
    }

    /**
     * @param storageSize the storageSize to set
     */
    public void setStorageSize(long storageSize) {
        this.storageSize = storageSize;
    }

    /**
     * @return the storageMediaLink
     */
    public String getStorageMediaLink() {
        return storageMediaLink;
    }

    /**
     * @param storageMediaLink the storageMediaLink to set
     */
    public void setStorageMediaLink(String storageMediaLink) {
        this.storageMediaLink = storageMediaLink;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }
    
    public boolean isMd5SumEquals() {
        return (onDBMd5sum.equalsIgnoreCase(storageMd5sum));
    }

    @Override
    public String toString() {
        return "ImageBlob{" + "imageId=" + imageId + ", md5sum-bool:" + isMd5SumEquals() + ", eventId=" + eventId + ", onDBFilename=" + onDBFilename + 
                ", onDBMd5sum=" + onDBMd5sum + ", storageFolder=" + storageFolder + ", storageMd5sum=" + storageMd5sum + 
                ", storageMediaLink=" + storageMediaLink + ", storageSize=" + storageSize + '}';
    }

}
