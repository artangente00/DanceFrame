/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.competition;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class EventSummary implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private int futurePublished;
    private int futureUnPublished;
    private int remainLastYear;
    private int uniqueEvents;

    /**
     * @return the futurePublished
     */
    public int getFuturePublished() {
        return futurePublished;
    }

    /**
     * @param futurePublished the futurePublished to set
     */
    public void setFuturePublished(int futurePublished) {
        this.futurePublished = futurePublished;
    }

    /**
     * @return the futureUnPublished
     */
    public int getFutureUnPublished() {
        return futureUnPublished;
    }

    /**
     * @param futureUnPublished the futureUnPublished to set
     */
    public void setFutureUnPublished(int futureUnPublished) {
        this.futureUnPublished = futureUnPublished;
    }

    /**
     * @return the remainLastYear
     */
    public int getRemainLastYear() {
        return remainLastYear;
    }

    /**
     * @param remainLastYear the remainLastYear to set
     */
    public void setRemainLastYear(int remainLastYear) {
        this.remainLastYear = remainLastYear;
    }

    /**
     * @return the uniqueEvents
     */
    public int getUniqueEvents() {
        return uniqueEvents;
    }

    /**
     * @param uniqueEvents the uniqueEvents to set
     */
    public void setUniqueEvents(int uniqueEvents) {
        this.uniqueEvents = uniqueEvents;
    }

    @Override
    public String toString() {
        return "EventSummary{" + "futurePublished=" + futurePublished + ", futureUnPublished=" + futureUnPublished + ", remainLastYear=" + remainLastYear + ", uniqueEvents=" + uniqueEvents + '}';
    }
    
    
}
