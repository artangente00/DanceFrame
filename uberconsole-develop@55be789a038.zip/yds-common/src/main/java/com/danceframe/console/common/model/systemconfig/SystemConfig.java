/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.systemconfig;


import java.io.Serializable;

/**
 *
 * @author nbonita
 */
public class SystemConfig implements Serializable {
    
    private static final long serialVersionUID = 1L;
    private int     id;
    private String name;
    private String value;
    private String type;
    private String category;
    private String pushid;
    private String enabled;
     
    public SystemConfig() {
    }
    
    public SystemConfig(int i, String n, String v) {
        id = i;
        name = n;
        value = v;
    }
   /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    

    public boolean isEmpty() {
        if (id > 0) return false;
        if ((null != getName()) || (!name.isEmpty()) || (getName().length() > 0))  return false;
        if ((null != getValue()) || (!value.isEmpty()) || (getValue().length() > 0))  return false;
        return true;
    }

    @Override
    public String toString() {
        return "SystemConfig{" + "id=" + id + ", name=" + name + ", value=" + value + ", type=" + type + ", category=" + category + ", pushid=" + pushid + ", enabled=" + enabled + '}';
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * @param value the value to set
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the category
     */
    public String getCategory() {
        return category;
    }

    /**
     * @param category the category to set
     */
    public void setCategory(String category) {
        this.category = category;
    }

    /**
     * @return the pushid
     */
    public String getPushid() {
        return pushid;
    }

    /**
     * @param pushid the pushid to set
     */
    public void setPushid(String pushid) {
        this.pushid = pushid;
    }

    /**
     * @return the enabled
     */
    public String getEnabled() {
        return enabled;
    }

    /**
     * @param enabled the enabled to set
     */
    public void setEnabled(String enabled) {
        this.enabled = enabled;
    }
    
}
