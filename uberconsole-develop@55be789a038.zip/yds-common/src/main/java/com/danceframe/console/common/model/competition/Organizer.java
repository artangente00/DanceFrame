/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.competition;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class Organizer implements Serializable {
    
    private static long serialVersionUID = 1L;
    private int     id;
    private String  name;   
    private int     eventid;

    

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Organizer{" + "id=" + id + ", name=" + name + ", eventid=" + eventid + '}';
    }

    /**
     * @return the eventid
     */
    public int getEventid() {
        return eventid;
    }

    /**
     * @param eventid the eventid to set
     */
    public void setEventid(int eventid) {
        this.eventid = eventid;
    }

        
    
}
