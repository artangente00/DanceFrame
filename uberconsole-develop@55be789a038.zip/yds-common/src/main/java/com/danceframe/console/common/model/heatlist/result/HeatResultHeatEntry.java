/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.heatlist.result;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class HeatResultHeatEntry implements Serializable {
    

    private int     eventId;
    private String  personKey1;
    private String  personKey2;
    private String  coupleKey;
    private String  heatName;
    private String  heatDesc;
    private String  firstName1;
    private String  lastName1;
    private String  competitorNumber;
    private String  firstName2;
    private String  lastName2;
    private int     heatId;
    

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the personKey1
     */
    public String getPersonKey1() {
        return personKey1;
    }

    /**
     * @param personKey1 the personKey1 to set
     */
    public void setPersonKey1(String personKey1) {
        this.personKey1 = personKey1;
    }

    /**
     * @return the personKey2
     */
    public String getPersonKey2() {
        return personKey2;
    }

    /**
     * @param personKey2 the personKey2 to set
     */
    public void setPersonKey2(String personKey2) {
        this.personKey2 = personKey2;
    }

    /**
     * @return the coupleKey
     */
    public String getCoupleKey() {
        return coupleKey;
    }

    /**
     * @param coupleKey the coupleKey to set
     */
    public void setCoupleKey(String coupleKey) {
        this.coupleKey = coupleKey;
    }

    /**
     * @return the heatName
     */
    public String getHeatName() {
        return heatName;
    }

    /**
     * @param heatName the heatName to set
     */
    public void setHeatName(String heatName) {
        this.heatName = heatName;
    }

    /**
     * @return the heatDesc
     */
    public String getHeatDesc() {
        return heatDesc;
    }

    /**
     * @param heatDesc the heatDesc to set
     */
    public void setHeatDesc(String heatDesc) {
        this.heatDesc = heatDesc;
    }

    /**
     * @return the firstName1
     */
    public String getFirstName1() {
        return firstName1;
    }

    /**
     * @param firstName1 the firstName1 to set
     */
    public void setFirstName1(String firstName1) {
        this.firstName1 = firstName1;
    }

    /**
     * @return the lastName1
     */
    public String getLastName1() {
        return lastName1;
    }

    /**
     * @param lastName1 the lastName1 to set
     */
    public void setLastName1(String lastName1) {
        this.lastName1 = lastName1;
    }


    /**
     * @return the firstName2
     */
    public String getFirstName2() {
        return firstName2;
    }

    /**
     * @param firstName2 the firstName2 to set
     */
    public void setFirstName2(String firstName2) {
        this.firstName2 = firstName2;
    }

    /**
     * @return the lastName2
     */
    public String getLastName2() {
        return lastName2;
    }

    /**
     * @param lastName2 the lastName2 to set
     */
    public void setLastName2(String lastName2) {
        this.lastName2 = lastName2;
    }


    /**
     * @return the heatId
     */
    public int getHeatId() {
        return heatId;
    }

    /**
     * @param heatId the heatId to set
     */
    public void setHeatId(int heatId) {
        this.heatId = heatId;
    }


    /**
     * @return the competitorNumber
     */
    public String getCompetitorNumber() {
        return competitorNumber;
    }

    /**
     * @param competitorNumber the competitorNumber to set
     */
    public void setCompetitorNumber(String competitorNumber) {
        this.competitorNumber = competitorNumber;
    }

    @Override
    public String toString() {
        return "HeatResultHeatEntry{" + "eventId=" + eventId + ", personKey1=" + personKey1 + ", personKey2=" + personKey2 + ", coupleKey=" + coupleKey + ", heatName=" + heatName + ", heatDesc=" + heatDesc + ", firstName1=" + firstName1 + ", lastName1=" + lastName1 + ", competitorNumber=" + competitorNumber + ", firstName2=" + firstName2 + ", lastName2=" + lastName2 + ", heatId=" + heatId + '}';
    }

    
    
}
