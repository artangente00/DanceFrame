/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.participant;

import com.danceframe.console.common.util.Utility;
import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author nbonita
 */
public class Participant implements Serializable {
    
    private static final long serialVersionUID = 1L;
    private int     id;
    private String participantPushId;
    private String userPushId;
    private String firstName;
    private String lastName;
    private String eMail;
    private String gender;
    private String birthday;
    private String category;
    private String participantType;
    private String coupleId;
    private String coupleName;
     


    public boolean isEmpty() {
        if (getId() > 0) return false;
        if ((null != getFirstName()) || (!firstName.isEmpty()) || (getFirstName().length() > 0))  return false;
        if ((null != getLastName()) || (!lastName.isEmpty()) || (getLastName().length() > 0))  return false;
        if ((null != geteMail()) || (!eMail.isEmpty()) || (geteMail().length() > 0))  return false;
        if ((null != getParticipantPushId()) || (!participantPushId.isEmpty()) || (getParticipantPushId().length() > 0))  return false;
        return true;
    }


    @Override
    public String toString() {
        return "Participant{" + "id=" + getId() + ", participantPushId=" + getParticipantPushId() + ", userPushId=" + getUserPushId() 
                + ", firstName=" + getFirstName() + ", lastName=" + getLastName()  + ", eMail=" + geteMail() 
                + ", gender=" + getGender() + ", birthday=" + getBirthday() + ", category=" + getCategory() + ", participantType=" + getParticipantType() + '}';
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the participantPushId
     */
    public String getParticipantPushId() {
        return participantPushId;
    }

    /**
     * @param participantPushId the participantPushId to set
     */
    public void setParticipantPushId(String participantPushId) {
        this.participantPushId = participantPushId;
    }

    /**
     * @return the userPushId
     */
    public String getUserPushId() {
        return userPushId;
    }

    /**
     * @param userPushId the userPushId to set
     */
    public void setUserPushId(String userPushId) {
        this.userPushId = userPushId;
    }

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * @return the eMail
     */
    public String geteMail() {
        return eMail;
    }

    /**
     * @param eMail the eMail to set
     */
    public void seteMail(String eMail) {
        this.eMail = eMail;
    }

    /**
     * @return the gender
     */
    public String getGender() {
        return gender;
    }

    /**
     * @param gender the gender to set
     */
    public void setGender(String gender) {
        this.gender = gender;
    }

    /**
     * @return the birthday
     */
    public String getBirthday() {
        return birthday;
    }

    /**
     * @param birthday the birthday to set
     */
    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    /**
     * @return the category
     */
    public String getCategory() {
        return category;
    }

    /**
     * @param category the category to set
     */
    public void setCategory(String category) {
        this.category = category;
    }

    /**
     * @return the participantType
     */
    public String getParticipantType() {
        return participantType;
    }

    /**
     * @param participantType the participantType to set
     */
    public void setParticipantType(String participantType) {
        this.participantType = participantType;
    }

    /**
     * @return the coupleId
     */
    public String getCoupleId() {
        return coupleId;
    }

    /**
     * @param coupleId the coupleId to set
     */
    public void setCoupleId(String coupleId) {
        this.coupleId = coupleId;
    }

    /**
     * @return the coupleName
     */
    public String getCoupleName() {
        return coupleName;
    }

    /**
     * @param coupleName the coupleName to set
     */
    public void setCoupleName(String coupleName) {
        this.coupleName = coupleName;
    }

    

    
}
