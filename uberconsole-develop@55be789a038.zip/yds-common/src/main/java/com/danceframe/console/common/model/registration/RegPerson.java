/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.registration;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author lmorallos
 */
public class RegPerson implements Serializable {
    
    private static long serialVersionUID = 1L;
    
    private int     id;
    private String  lastname;
    private String  firstname;
    private String  type;
    private String  gender;
    private int     eventId;
    private String  euid;
    private int     userId;
    private String  buid;
    private int     studioId;
    private String  suid;
    private String  puid;
    private Date    creationDate;
    private Date    lastModified;

    /**
     * @return the serialVersionUID
     */
    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    /**
     * @param aSerialVersionUID the serialVersionUID to set
     */
    public static void setSerialVersionUID(long aSerialVersionUID) {
        serialVersionUID = aSerialVersionUID;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the lastname
     */
    public String getLastname() {
        return lastname;
    }

    /**
     * @param lastname the lastname to set
     */
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    /**
     * @return the firstname
     */
    public String getFirstname() {
        return firstname;
    }

    /**
     * @param firstname the firstname to set
     */
    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the gender
     */
    public String getGender() {
        return gender;
    }

    /**
     * @param gender the gender to set
     */
    public void setGender(String gender) {
        this.gender = gender;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the euid
     */
    public String getEuid() {
        return euid;
    }

    /**
     * @param euid the euid to set
     */
    public void setEuid(String euid) {
        this.euid = euid;
    }

    /**
     * @return the puid
     */
    public String getPuid() {
        return puid;
    }

    /**
     * @param puid the puid to set
     */
    public void setPuid(String puid) {
        this.puid = puid;
    }

    /**
     * @return the studioId
     */
    public int getStudioId() {
        return studioId;
    }

    /**
     * @param studioId the studioId to set
     */
    public void setStudioId(int studioId) {
        this.studioId = studioId;
    }

    /**
     * @return the suid
     */
    public String getSuid() {
        return suid;
    }

    /**
     * @param suid the suid to set
     */
    public void setSuid(String suid) {
        this.suid = suid;
    }

    /**
     * @return the creationDate
     */
    public Date getCreationDate() {
        return creationDate;
    }

    /**
     * @param creationDate the creationDate to set
     */
    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    /**
     * @return the lastModified
     */
    public Date getLastModified() {
        return lastModified;
    }

    /**
     * @param lastModified the lastModified to set
     */
    public void setLastModified(Date lastModified) {
        this.lastModified = lastModified;
    }

    /**
     * @return the userId
     */
    public int getUserId() {
        return userId;
    }

    /**
     * @param userId the userId to set
     */
    public void setUserId(int userId) {
        this.userId = userId;
    }

    /**
     * @return the buid
     */
    public String getBuid() {
        return buid;
    }

    /**
     * @param buid the buid to set
     */
    public void setBuid(String buid) {
        this.buid = buid;
    }

    @Override
    public String toString() {
        return "RegPerson{" + "id=" + id + ", lastname=" + lastname + ", firstname=" + firstname + ", type=" + type + ", gender=" + gender + ", eventId=" + eventId + ", euid=" + euid + ", userId=" + userId + ", buid=" + buid + ", studioId=" + studioId + ", suid=" + suid + ", puid=" + puid + ", creationDate=" + creationDate + ", lastModified=" + lastModified + '}';
    }
    
    
}
