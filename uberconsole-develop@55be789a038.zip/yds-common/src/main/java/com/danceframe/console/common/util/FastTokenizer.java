/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.util;

/**
 * Copyright 2008
 * @author Leonardo A. Morallos
 * @version 1.2
 * The author still reserve the right for this code and allows for UserAdd and 
 * Dance Frame to use it for uberconsole.
 * This code should not be modified in any case.
 * FastTokenizer which uses StringBuffer in breaking strings into token
 * 
 */
public final class FastTokenizer {
        
    private StringBuffer strbuffer;    
    private char delim;
    private int count;       
    private int firstpos;
    private int currpos;
    private int render;    
    
    public FastTokenizer(String str, char delimiter) {
        strbuffer = new StringBuffer(str);
        delim = delimiter;                
        currpos = 0;
        render = 0;        
        count = ctoken();
    }
    
    public boolean hasMoreTokens() {                        
        return ((render < count)?true:false);
    }
    
    public String nextToken() {
        StringBuffer sret = new StringBuffer();                
        boolean tloop = true;        
        while (tloop) {                
          if (currpos < strbuffer.length()) {
               char ch = strbuffer.charAt(currpos);
               if (ch != delim) {
                   sret.append(ch);
               } else {
                   tloop = false;
               }
          } else {
                tloop = false;
          }
          currpos++;
        }                
        render++;       
        return sret.toString();
    }
    
    public int countTokens() {             
        return(this.count);
    }
    
    // Private. ----------------------------------------------------------------
    private int ctoken() {
        int cnt = 0;                                        
        firstpos = strbuffer.indexOf(Character.toString(delim));        
        if (this.firstpos != -1) {
            for (int i=firstpos; i < strbuffer.length(); i++ ) {
                if (strbuffer.charAt(i) == delim) cnt++;
            }
            cnt++;            
        }
        return cnt;
    }
}