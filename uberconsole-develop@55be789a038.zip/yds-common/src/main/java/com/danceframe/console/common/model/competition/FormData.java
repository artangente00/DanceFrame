/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.competition;

import com.danceframe.console.common.model.basic.GenericFormObject;
import java.io.ByteArrayInputStream;
import java.io.Serializable;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;

/**
 *
 * @author lmorallos
 */
public class FormData extends GenericFormObject implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private int id;
    private String code;
    private String filename;
    private String displayFilename;
    private String mimeType;
    private byte[]  image;
    private int     codeType;
   
    public ByteArrayInputStream getImageByInputStream() {
        return new ByteArrayInputStream(image);
    }
    
    public StreamedContent getImageByStreamContent() {
        StreamedContent img = null;
        if (null != image) {
            if (image.length > 0) {
                img = new DefaultStreamedContent(new ByteArrayInputStream(image),
                mimeType, filename);
            }
        }
        return (img);
    }
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * @param code the code to set
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * @return the filename
     */
    public String getFilename() {
        return filename;
    }

    /**
     * @param filename the filename to set
     */
    public void setFilename(String filename) {
        this.filename = filename;
    }

    /**
     * @return the mimeType
     */
    public String getMimeType() {
        return mimeType;
    }

    /**
     * @param mimeType the mimeType to set
     */
    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    /**
     * @return the image
     */
    public byte[] getImage() {
        return image;
    }

    /**
     * @param image the image to set
     */
    public void setImage(byte[] image) {
        this.image = image;
    }

    /**
     * @return the codeType
     */
    public int getCodeType() {
        return codeType;
    }

    /**
     * @param codeType the codeType to set
     */
    public void setCodeType(int codeType) {
        this.codeType = codeType;
    }

    /**
     * @return the displayFilename
     */
    public String getDisplayFilename() {
        return displayFilename;
    }

    /**
     * @param displayFilename the displayFilename to set
     */
    public void setDisplayFilename(String displayFilename) {
        this.displayFilename = displayFilename;
    }
    
    
}
