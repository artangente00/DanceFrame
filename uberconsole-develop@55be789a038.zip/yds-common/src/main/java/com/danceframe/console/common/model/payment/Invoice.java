/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.payment;

import java.io.Serializable;

/**
 *
 * @author NDB
 */
public class Invoice  implements Serializable {
    
    private static final long serialVersionUID = 1L;
    private int     id;
    private String userPushId;
    private String eventPushId;
    private String billingName;
    private String billingAddress;
    private String eventTitle;
    private String totalAmount;
    private String recievedAmount;
    private String createdTimestamp;
    private String modifiedTimestamp;
    private String rtdbEtransferPaymentJson;

    public boolean isEmpty() {
        if (getId() > 0) return false;
        if ((null != getUserPushId()) || (!userPushId.isEmpty()) || (getUserPushId().length() > 0))  return false;
        if ((null != getEventPushId()) || (!eventPushId.isEmpty()) || (getEventPushId().length() > 0))  return false;
        return true;
    }


    @Override
    public String toString() {
        return "Invoice{" + "id=" + getId() + ", userPushId=" + getUserPushId() + ", eventPushId=" + getEventPushId() 
                + ", billingName=" + getBillingName() + ", billingAddress=" + getBillingAddress() 
                + ", eventTitle=" + getEventTitle() + ", totalAmount=" + getTotalAmount() + ", recievedAmount=" + getRecievedAmount() 
                + ", createdTimestamp=" + getCreatedTimestamp() + ", modifiedTimestamp=" + getModifiedTimestamp() 
                + ", rtdbEtransferPaymentJson=" + getRtdbEtransferPaymentJson() 
                + '}';
    }
    
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the userPushId
     */
    public String getUserPushId() {
        return userPushId;
    }

    /**
     * @param userPushId the userPushId to set
     */
    public void setUserPushId(String userPushId) {
        this.userPushId = userPushId;
    }

    /**
     * @return the eventPushId
     */
    public String getEventPushId() {
        return eventPushId;
    }

    /**
     * @param eventPushId the eventPushId to set
     */
    public void setEventPushId(String eventPushId) {
        this.eventPushId = eventPushId;
    }

    /**
     * @return the billingName
     */
    public String getBillingName() {
        return billingName;
    }

    /**
     * @param billingName the billingName to set
     */
    public void setBillingName(String billingName) {
        this.billingName = billingName;
    }

    /**
     * @return the billingAddress
     */
    public String getBillingAddress() {
        return billingAddress;
    }

    /**
     * @param billingAddress the billingAddress to set
     */
    public void setBillingAddress(String billingAddress) {
        this.billingAddress = billingAddress;
    }

    /**
     * @return the eventTitle
     */
    public String getEventTitle() {
        return eventTitle;
    }

    /**
     * @param eventTitle the eventTitle to set
     */
    public void setEventTitle(String eventTitle) {
        this.eventTitle = eventTitle;
    }

    /**
     * @return the totalAmount
     */
    public String getTotalAmount() {
        return totalAmount;
    }

    /**
     * @param totalAmount the totalAmount to set
     */
    public void setTotalAmount(String totalAmount) {
        this.totalAmount = totalAmount;
    }

    /**
     * @return the recievedAmount
     */
    public String getRecievedAmount() {
        return recievedAmount;
    }

    /**
     * @param recievedAmount the recievedAmount to set
     */
    public void setRecievedAmount(String recievedAmount) {
        this.recievedAmount = recievedAmount;
    }

    /**
     * @return the createdTimestamp
     */
    public String getCreatedTimestamp() {
        return createdTimestamp;
    }

    /**
     * @param createdTimestamp the createdTimestamp to set
     */
    public void setCreatedTimestamp(String createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    /**
     * @return the modifiedTimestamp
     */
    public String getModifiedTimestamp() {
        return modifiedTimestamp;
    }

    /**
     * @param modifiedTimestamp the modifiedTimestamp to set
     */
    public void setModifiedTimestamp(String modifiedTimestamp) {
        this.modifiedTimestamp = modifiedTimestamp;
    }

    /**
     * @return the rtdbEtransferPaymentJson
     */
    public String getRtdbEtransferPaymentJson() {
        return rtdbEtransferPaymentJson;
    }

    /**
     * @param rtdbEtransferPaymentJson the rtdbEtransferPaymentJson to set
     */
    public void setRtdbEtransferPaymentJson(String rtdbEtransferPaymentJson) {
        this.rtdbEtransferPaymentJson = rtdbEtransferPaymentJson;
    }

}
