/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.heatlist.result;

import java.io.Serializable;
import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

/**
 *
 * @author lmorallos
 */
@Root(name="judge")
public class HeatResultJudge implements Serializable {
    
    private static final long serialVersionUID = 1L;
     
    private int     id;
    @Attribute
    private String  judgeKey;
    @Element(required=false)
    private String  firstName;
    @Element(required=false)
    private String  lastName;
    @Element(required=false)
    private String  judgeNumber;
    private int  masterjudge_id;
    private int     eventId;
    private int     xmlId;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * @return the judgeNumber
     */
    public String getJudgeNumber() {
        return judgeNumber;
    }

    /**
     * @param judgeNumber the judgeNumber to set
     */
    public void setJudgeNumber(String judgeNumber) {
        this.judgeNumber = judgeNumber;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the xmlId
     */
    public int getXmlId() {
        return xmlId;
    }

    /**
     * @param xmlId the xmlId to set
     */
    public void setXmlId(int xmlId) {
        this.xmlId = xmlId;
    }

    /**
     * @return the judgeKey
     */
    public String getJudgeKey() {
        return judgeKey;
    }

    /**
     * @param judgeKey the judgeKey to set
     */
    public void setJudgeKey(String judgeKey) {
        this.judgeKey = judgeKey;
    }
    /**
     * @return the masterjudge_id
     */
    public int getMasterjudge_id() {
        return masterjudge_id;
    }

    /**
     * @param masterjudge_id the masterjudge_id to set
     */
    public void setMasterjudge_id(int masterjudge_id) {
        this.masterjudge_id = masterjudge_id;
    }

    @Override
    public String toString() {
        return "HeatResultJudge{" + "id=" + id + ", judgeKey=" + judgeKey + ", firstName=" + firstName + ", lastName=" + lastName + ", judgeNumber=" + judgeNumber + ", masterjudge_id=" + masterjudge_id + ", eventId=" + eventId + ", xmlId=" + xmlId + '}';
    }
}
