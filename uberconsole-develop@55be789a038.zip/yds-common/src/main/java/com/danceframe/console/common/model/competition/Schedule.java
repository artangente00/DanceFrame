/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.competition;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class Schedule implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private int id;
    private int eventId;
    private String schedName;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the schedName
     */
    public String getSchedName() {
        return schedName;
    }

    /**
     * @param schedName the schedName to set
     */
    public void setSchedName(String schedName) {
        this.schedName = schedName;
    }

    @Override
    public String toString() {
        return "Schedule{" + "id=" + id + ", eventId=" + eventId + ", schedName=" + schedName + '}';
    }

    
}
