/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.heatlist;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class HeatSession implements Serializable {
    
    private static final long serialVersionUID = 1L;
     
    private int sessionId;
    private int sessionCount;
    private String sessionDay;
    private String sessionDate;
    private String sessionTime;
    private int heatlistId;

    /**
     * @return the sessionId
     */
    public int getSessionId() {
        return sessionId;
    }

    /**
     * @param sessionId the sessionId to set
     */
    public void setSessionId(int sessionId) {
        this.sessionId = sessionId;
    }

    /**
     * @return the sessionCount
     */
    public int getSessionCount() {
        return sessionCount;
    }

    /**
     * @param sessionCount the sessionCount to set
     */
    public void setSessionCount(int sessionCount) {
        this.sessionCount = sessionCount;
    }

    /**
     * @return the sessionDay
     */
    public String getSessionDay() {
        return sessionDay;
    }

    /**
     * @param sessionDay the sessionDay to set
     */
    public void setSessionDay(String sessionDay) {
        this.sessionDay = sessionDay;
    }

    /**
     * @return the sessionDate
     */
    public String getSessionDate() {
        return sessionDate;
    }

    /**
     * @param sessionDate the sessionDate to set
     */
    public void setSessionDate(String sessionDate) {
        this.sessionDate = sessionDate;
    }

    /**
     * @return the sessionTime
     */
    public String getSessionTime() {
        return sessionTime;
    }

    /**
     * @param sessionTime the sessionTime to set
     */
    public void setSessionTime(String sessionTime) {
        this.sessionTime = sessionTime;
    }

    /**
     * @return the heatlistId
     */
    public int getHeatlistId() {
        return heatlistId;
    }

    /**
     * @param heatlistId the heatlistId to set
     */
    public void setHeatlistId(int heatlistId) {
        this.heatlistId = heatlistId;
    }

    @Override
    public String toString() {
        return "HeatSession{" + "sessionId=" + sessionId + ", sessionCount=" + sessionCount + ", sessionDay=" + sessionDay + ", sessionDate=" + sessionDate + ", sessionTime=" + sessionTime + ", heatlistId=" + heatlistId + '}';
    }
    
    
    
}
