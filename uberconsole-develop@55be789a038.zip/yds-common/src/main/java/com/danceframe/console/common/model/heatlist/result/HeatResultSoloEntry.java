/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.heatlist.result;

import java.io.Serializable;
import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.Root;

/**
 *
 * @author lmorallos
 */
@Root(name="soloEntry")
public class HeatResultSoloEntry implements Serializable {
    
    private int     id;
    @Attribute
    private String  personKey;
    private int     subHeatId;
    private int     eventId;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the personKey
     */
    public String getPersonKey() {
        return personKey;
    }

    /**
     * @param personKey the personKey to set
     */
    public void setPersonKey(String personKey) {
        this.personKey = personKey;
    }


    /**
     * @return the subHeatId
     */
    public int getSubHeatId() {
        return subHeatId;
    }

    /**
     * @param subHeatId the subHeatId to set
     */
    public void setSubHeatId(int subHeatId) {
        this.subHeatId = subHeatId;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    @Override
    public String toString() {
        return "HeatResultSoloEntry{" + "id=" + id + ", personKey=" + personKey + ", subHeatId=" + subHeatId + ", eventId=" + eventId + '}';
    }

    
    
    
}
