/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.heatlist;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class HeatFullData implements Serializable {
 
    private static final long serialVersionUID = 1L;
    
    private int heatListId;
    private int personId;
    private String personCpmId;
    private String mainName;
    private String mainSex;
    private int partnerId;
    private String partnerCpmId;
    private String partnerName;
    private String partnerSex;
    private String seqNo;
    private int compId;
    private String compCpmId;
    private String otherInfo;
    private String heatType;
    private String dance;
    private String level;
    private String age;
    private int heatId;
    private String value;
    private String schedule;
    private String description;

    /**
     * @return the heatListId
     */
    public int getHeatListId() {
        return heatListId;
    }

    /**
     * @param heatListId the heatListId to set
     */
    public void setHeatListId(int heatListId) {
        this.heatListId = heatListId;
    }

    /**
     * @return the personId
     */
    public int getPersonId() {
        return personId;
    }

    /**
     * @param personId the personId to set
     */
    public void setPersonId(int personId) {
        this.personId = personId;
    }

    /**
     * @return the personCpmId
     */
    public String getPersonCpmId() {
        return personCpmId;
    }

    /**
     * @param personCpmId the personCpmId to set
     */
    public void setPersonCpmId(String personCpmId) {
        this.personCpmId = personCpmId;
    }

    /**
     * @return the mainName
     */
    public String getMainName() {
        return mainName;
    }

    /**
     * @param mainName the mainName to set
     */
    public void setMainName(String mainName) {
        this.mainName = mainName;
    }

    /**
     * @return the mainSex
     */
    public String getMainSex() {
        return mainSex;
    }

    /**
     * @param mainSex the mainSex to set
     */
    public void setMainSex(String mainSex) {
        this.mainSex = mainSex;
    }

    /**
     * @return the partnerId
     */
    public int getPartnerId() {
        return partnerId;
    }

    /**
     * @param partnerId the partnerId to set
     */
    public void setPartnerId(int partnerId) {
        this.partnerId = partnerId;
    }

    /**
     * @return the partnerCpmId
     */
    public String getPartnerCpmId() {
        return partnerCpmId;
    }

    /**
     * @param partnerCpmId the partnerCpmId to set
     */
    public void setPartnerCpmId(String partnerCpmId) {
        this.partnerCpmId = partnerCpmId;
    }

    /**
     * @return the partnerName
     */
    public String getPartnerName() {
        return partnerName;
    }

    /**
     * @param partnerName the partnerName to set
     */
    public void setPartnerName(String partnerName) {
        this.partnerName = partnerName;
    }

    /**
     * @return the partnerSex
     */
    public String getPartnerSex() {
        return partnerSex;
    }

    /**
     * @param partnerSex the partnerSex to set
     */
    public void setPartnerSex(String partnerSex) {
        this.partnerSex = partnerSex;
    }

    /**
     * @return the seqNo
     */
    public String getSeqNo() {
        return seqNo;
    }

    /**
     * @param seqNo the seqNo to set
     */
    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo;
    }

    /**
     * @return the compId
     */
    public int getCompId() {
        return compId;
    }

    /**
     * @param compId the compId to set
     */
    public void setCompId(int compId) {
        this.compId = compId;
    }

    /**
     * @return the compCpmId
     */
    public String getCompCpmId() {
        return compCpmId;
    }

    /**
     * @param compCpmId the compCpmId to set
     */
    public void setCompCpmId(String compCpmId) {
        this.compCpmId = compCpmId;
    }

    /**
     * @return the otherInfo
     */
    public String getOtherInfo() {
        return otherInfo;
    }

    /**
     * @param otherInfo the otherInfo to set
     */
    public void setOtherInfo(String otherInfo) {
        this.otherInfo = otherInfo;
    }

    /**
     * @return the heatType
     */
    public String getHeatType() {
        return heatType;
    }

    /**
     * @param heatType the heatType to set
     */
    public void setHeatType(String heatType) {
        this.heatType = heatType;
    }

    /**
     * @return the dance
     */
    public String getDance() {
        return dance;
    }

    /**
     * @param dance the dance to set
     */
    public void setDance(String dance) {
        this.dance = dance;
    }

    /**
     * @return the level
     */
    public String getLevel() {
        return level;
    }

    /**
     * @param level the level to set
     */
    public void setLevel(String level) {
        this.level = level;
    }

    /**
     * @return the heatId
     */
    public int getHeatId() {
        return heatId;
    }

    /**
     * @param heatId the heatId to set
     */
    public void setHeatId(int heatId) {
        this.heatId = heatId;
    }

    /**
     * @return the schedule
     */
    public String getSchedule() {
        return schedule;
    }

    /**
     * @param schedule the schedule to set
     */
    public void setSchedule(String schedule) {
        this.schedule = schedule;
    }

    /**
     * @return the age
     */
    public String getAge() {
        return age;
    }

    /**
     * @param age the age to set
     */
    public void setAge(String age) {
        this.age = age;
    }

    /**
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * @param value the value to set
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "HeatFullData{" + "heatListId=" + heatListId + ", personId=" + personId + ", personCpmId=" + personCpmId + ", mainName=" + mainName + ", mainSex=" + mainSex + ", partnerId=" + partnerId + ", partnerCpmId=" + partnerCpmId + ", partnerName=" + partnerName + ", partnerSex=" + partnerSex + ", seqNo=" + seqNo + ", compId=" + compId + ", compCpmId=" + compCpmId + ", otherInfo=" + otherInfo + ", heatType=" + heatType + ", dance=" + dance + ", level=" + level + ", age=" + age + ", heatId=" + heatId + ", value=" + value + ", schedule=" + schedule + ", description=" + description + '}';
    }
    
    
}
