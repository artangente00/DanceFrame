/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.heatlist.result;

import java.io.Serializable;
import java.util.ArrayList;
import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

/**
 *
 * @author lmorallos
 */
@Root(name="subHeats")
public class HeatResultSubHeats implements Serializable {
    
    private static long serialVersionUID = 1L;
    
    private int id;
    
    @Attribute (required=false)
    private String level;
    @Attribute (required=false)
    private String danceType;
    @Attribute (required=false)
    private String age;
    @Attribute (required=false)
    private String type; 
    @Attribute (required=false)
    private String order; 
    
    private int heatId;
    private int eventId;
    
    private ArrayList<HeatResultSubHeat> subHeat;

    /**
     * @return the level
     */
    public String getLevel() {
        return level;
    }

    /**
     * @param level the level to set
     */
    public void setLevel(String level) {
        this.level = level;
    }

    /**
     * @return the age
     */
    public String getAge() {
        return age;
    }

    /**
     * @param age the age to set
     */
    public void setAge(String age) {
        this.age = age;
    }

    /**
     * @return the subHeat
     */
    @ElementList(inline=true, required=false)
    public ArrayList<HeatResultSubHeat> getSubHeat() {
        return subHeat;
    }

    /**
     * @param subHeat the subHeat to set
     */
    @ElementList(inline=true, required=false) 
    public void setSubHeat(ArrayList<HeatResultSubHeat> subHeat) {
        this.subHeat = subHeat;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the order
     */
    public String getOrder() {
        return order;
    }

    /**
     * @param order the order to set
     */
    public void setOrder(String order) {
        this.order = order;
    }

    /**
     * @return the danceType
     */
    public String getDanceType() {
        return danceType;
    }

    /**
     * @param danceType the danceType to set
     */
    public void setDanceType(String danceType) {
        this.danceType = danceType;
    }

    /**
     * @return the heatId
     */
    public int getHeatId() {
        return heatId;
    }

    /**
     * @param heatId the heatId to set
     */
    public void setHeatId(int heatId) {
        this.heatId = heatId;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "HeatResultSubHeats{" + "id=" + id + ", level=" + level + ", danceType=" + danceType + ", age=" + age + ", type=" + type + ", order=" + order + ", heatId=" + heatId + ", eventId=" + eventId + ", subHeat=" + subHeat + '}';
    }

    
    
    
}
