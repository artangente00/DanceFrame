/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.competition.form;

import java.io.ByteArrayInputStream;
import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class EventFormXML implements Serializable{
    
    private static final long serialVersionUID = 1L;
    
    private int id;
    private int eventId;
    private String eventName;
    private String pushId;
    private boolean useManual;
    private byte[] xmlGenerated;
    private byte[] jsonGenerated;
    private byte[] xmlManual;
    private byte[] jsonManual;
    private byte[] stuManual;
    private byte[] xmlAllManual;
    
     
     
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the xmlGenerated
     */
    public byte[] getXmlGenerated() {
        return xmlGenerated;
    }

    /**
     * @param xmlGenerated the xmlGenerated to set
     */
    public void setXmlGenerated(byte[] xmlGenerated) {
        this.xmlGenerated = xmlGenerated;
    }

    /**
     * @return the jsonGenerated
     */
    public byte[] getJsonGenerated() {
        return jsonGenerated;
    }

    /**
     * @param jsonGenerated the jsonGenerated to set
     */
    public void setJsonGenerated(byte[] jsonGenerated) {
        this.jsonGenerated = jsonGenerated;
    }

    /**
     * @return the xmlManual
     */
    public byte[] getXmlManual() {
        return xmlManual;
    }

    /**
     * @param xmlManual the xmlManual to set
     */
    public void setXmlManual(byte[] xmlManual) {
        this.xmlManual = xmlManual;
    }

    /**
     * @return the jsonManual
     */
    public byte[] getJsonManual() {
        return jsonManual;
    }

    /**
     * @param jsonManual the jsonManual to set
     */
    public void setJsonManual(byte[] jsonManual) {
        this.jsonManual = jsonManual;
    }

    /**
     * @return the eventName
     */
    public String getEventName() {
        return eventName;
    }

    /**
     * @param eventName the eventName to set
     */
    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    /**
     * @return the useManual
     */
    public boolean isUseManual() {
        return useManual;
    }

    /**
     * @param useManual the useManual to set
     */
    public void setUseManual(boolean useManual) {
        this.useManual = useManual;
    }
    
    
    public String getJsonGenPresent() {
        String retstr = "NO";
        if (null != jsonGenerated) {
            retstr =  (jsonGenerated.length > 0)? "YES":"NO";
        }
        return retstr;
    }
    
    public String getXMLGenPresent() {
        String retstr = "NO";
        if (null != xmlGenerated) {
            retstr =  (xmlGenerated.length > 0)? "YES":"NO";
        }
        return retstr;
    }
    
    public String getJsonManPresent() {
        String retstr = "NO";
        if (null != jsonManual) {
            retstr =  (jsonManual.length > 0)? "YES":"NO";
        }
        return retstr;
    }
    
    public String getXMLManPresent() {
        String retstr = "NO";
        if (null != xmlManual) {
            retstr =  (xmlManual.length > 0)? "YES":"NO";
        }
        return retstr;

    }
    
    public boolean isJsonGenDisable() {
        boolean retbool = true;
        if (null != jsonGenerated) {
            retbool =  (jsonGenerated.length > 0)? false: true;
        }
        return retbool;
    }
    
    public boolean isXMLGenDisable() {
       boolean retbool = true;
        if (null != xmlGenerated) {
            retbool =  (xmlGenerated.length > 0)? false: true;;
        }
       return retbool;
    }
    
    public boolean isJsonManDisable() {
        boolean retbool = true;
        if (null != jsonManual) {
            retbool =  (jsonManual.length > 0)? false: true;;
        }
        return retbool;
    }
    
    public boolean isXMLManDisable() {
        boolean retbool = true;
        if (null != xmlManual) {
            retbool =  (xmlManual.length > 0)? false: true;
        }
        return retbool;

    }
    
    public ByteArrayInputStream xmlGeneratedInputStream() {
        return new ByteArrayInputStream(xmlGenerated);
    }
    
    public ByteArrayInputStream jsonGeneratedInputStream() {
        return new ByteArrayInputStream(jsonGenerated);
    }
     
    public ByteArrayInputStream xmlManualInputStream() {
        return new ByteArrayInputStream(xmlManual);
    }
     
    public ByteArrayInputStream jsonManualInputStream() {
        return new ByteArrayInputStream(jsonManual);
    }

    /**
     * @return the stuManual
     */
    public byte[] getStuManual() {
        return stuManual;
    }

    /**
     * @param stuManual the stuManual to set
     */
    public void setStuManual(byte[] stuManual) {
        this.stuManual = stuManual;
    }

    /**
     * @return the xmlAllManual
     */
    public byte[] getXmlAllManual() {
        return xmlAllManual;
    }

    /**
     * @param xmlAllManual the xmlAllManual to set
     */
    public void setXmlAllManual(byte[] xmlAllManual) {
        this.xmlAllManual = xmlAllManual;
    }

    /**
     * @return the pushId
     */
    public String getPushId() {
        return pushId;
    }

    /**
     * @param pushId the pushId to set
     */
    public void setPushId(String pushId) {
        this.pushId = pushId;
    }
     
}
