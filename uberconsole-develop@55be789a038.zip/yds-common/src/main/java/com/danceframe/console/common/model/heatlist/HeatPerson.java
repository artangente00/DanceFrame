/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.heatlist;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class HeatPerson implements Serializable {
    
    private static final long serialVersionUID = 1L;
     
    private int     id;
    private String  compMgrId;
    private String  lastName;
    private String  firstName;
    private String  sex;
    private String  profType;
    private int     studioId;
    private String  studioCmpId;
    private int     heatListId;
    
    public HeatPerson() {}
    
     public HeatPerson(int i, String ci, String ln, String fn, String sx, String pf, int si, String sci, int hid) {
        this.id = i;
        this.compMgrId = ci;
        this.lastName = ln;
        this.firstName = fn;
        this.sex = sx;
        this.profType = pf;
        this.studioId = si;
        this.studioCmpId = sci;
        this.heatListId = hid;
     }
     
     public HeatPerson(String ci, String ln, String fn, String sx, String pf, String sci, int hid) {
        this.compMgrId = ci;
        this.lastName = ln;
        this.firstName = fn;
        this.sex = sx;
        this.profType = pf;
        this.studioCmpId = sci;
        this.heatListId = hid;
     }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the compMgrId
     */
    public String getCompMgrId() {
        return compMgrId;
    }

    /**
     * @param compMgrId the compMgrId to set
     */
    public void setCompMgrId(String compMgrId) {
        this.compMgrId = compMgrId;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return the sex
     */
    public String getSex() {
        return sex;
    }

    /**
     * @param sex the sex to set
     */
    public void setSex(String sex) {
        this.sex = sex;
    }

    /**
     * @return the profType
     */
    public String getProfType() {
        return profType;
    }

    /**
     * @param profType the profType to set
     */
    public void setProfType(String profType) {
        this.profType = profType;
    }

    /**
     * @return the studioId
     */
    public int getStudioId() {
        return studioId;
    }

    /**
     * @param studioId the studioId to set
     */
    public void setStudioId(int studioId) {
        this.studioId = studioId;
    }

    /**
     * @return the studioCmpId
     */
    public String getStudioCmpId() {
        return studioCmpId;
    }

    /**
     * @param studioCmpId the studioCmpId to set
     */
    public void setStudioCmpId(String studioCmpId) {
        this.studioCmpId = studioCmpId;
    }


    /**
     * @return the heatListId
     */
    public int getHeatListId() {
        return heatListId;
    }

    /**
     * @param heatListId the heatListId to set
     */
    public void setHeatListId(int heatListId) {
        this.heatListId = heatListId;
    }

    @Override
    public String toString() {
        return "HeatPerson{" + "id=" + id + ", compMgrId=" + compMgrId + ", lastName=" + lastName + ", firstName=" + firstName + ", sex=" + sex + ", profType=" + profType + ", studioId=" + studioId + ", studioCmpId=" + studioCmpId + ", heatListId=" + heatListId + '}';
    }
   
    
    
}
