/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.registration;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author lmorallos
 */
public class RegUser  implements Serializable {
    
     
    private static final long serialVersionUID = 1L;
    
    private int     id;
    private String  bgoId;
    private String  buid;
    private String  lastName;
    private String  firstName;
    private String  middleName;
    private String  email;
    private String  gender;
    private String  birthday;
    private String  category;
    private String  loginProvider;
    private Date    creationDate;
    private Date    lastModified;
    private Date    signInDate;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the bgoId
     */
    public String getBgoId() {
        return bgoId;
    }

    /**
     * @param bgoId the bgoId to set
     */
    public void setBgoId(String bgoId) {
        this.bgoId = bgoId;
    }

    /**
     * @return the buid
     */
    public String getBuid() {
        return buid;
    }

    /**
     * @param buid the buid to set
     */
    public void setBuid(String buid) {
        this.buid = buid;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return the middleName
     */
    public String getMiddleName() {
        return middleName;
    }

    /**
     * @param middleName the middleName to set
     */
    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the gender
     */
    public String getGender() {
        return gender;
    }

    /**
     * @param gender the gender to set
     */
    public void setGender(String gender) {
        this.gender = gender;
    }

    /**
     * @return the birthday
     */
    public String getBirthday() {
        return birthday;
    }

    /**
     * @param birthday the birthday to set
     */
    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    /**
     * @return the category
     */
    public String getCategory() {
        return category;
    }

    /**
     * @param category the category to set
     */
    public void setCategory(String category) {
        this.category = category;
    }

    /**
     * @return the loginProvider
     */
    public String getLoginProvider() {
        return loginProvider;
    }

    /**
     * @param loginProvider the loginProvider to set
     */
    public void setLoginProvider(String loginProvider) {
        this.loginProvider = loginProvider;
    }

    /**
     * @return the creationDate
     */
    public Date getCreationDate() {
        return creationDate;
    }

    /**
     * @param creationDate the creationDate to set
     */
    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    /**
     * @return the lastModified
     */
    public Date getLastModified() {
        return lastModified;
    }

    /**
     * @param lastModified the lastModified to set
     */
    public void setLastModified(Date lastModified) {
        this.lastModified = lastModified;
    }

    /**
     * @return the signInDate
     */
    public Date getSignInDate() {
        return signInDate;
    }

    /**
     * @param signInDate the signInDate to set
     */
    public void setSignInDate(Date signInDate) {
        this.signInDate = signInDate;
    }

    @Override
    public String toString() {
        return "RegUser{" + "id=" + id + ", bgoId=" + bgoId + ", buid=" + buid + ", lastName=" + lastName + ", firstName=" + firstName + ", middleName=" + middleName + ", email=" + email + ", gender=" + gender + ", birthday=" + birthday + ", category=" + category + ", loginProvider=" + loginProvider + ", creationDate=" + creationDate + ", lastModified=" + lastModified + ", signInDate=" + signInDate + '}';
    }

}
