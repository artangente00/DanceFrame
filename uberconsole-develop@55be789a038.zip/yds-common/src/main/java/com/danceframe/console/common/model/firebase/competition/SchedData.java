/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.firebase.competition;

import java.io.Serializable;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public class SchedData implements Serializable {
    
     private static final long serialVersionUID = 1L;
     
     private String headerName;
     private int    hdrOrder;
     private List<TimeData> timedata;

    /**
     * @return the headerName
     */
    public String getHeaderName() {
        return headerName;
    }

    /**
     * @param headerName the headerName to set
     */
    public void setHeaderName(String headerName) {
        this.headerName = headerName;
    }

    /**
     * @return the hdrOrder
     */
    public int getHdrOrder() {
        return hdrOrder;
    }

    /**
     * @param hdrOrder the hdrOrder to set
     */
    public void setHdrOrder(int hdrOrder) {
        this.hdrOrder = hdrOrder;
    }

    /**
     * @return the timedata
     */
    public List<TimeData> getTimedata() {
        return timedata;
    }

    /**
     * @param timedata the timedata to set
     */
    public void setTimedata(List<TimeData> timedata) {
        this.timedata = timedata;
    }
 
}
