/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.heatlist.result;

import java.io.Serializable;
import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

/**
 *
 * @author lmorallos
 */
@Root(name="person")
public class HeatResultPerson implements Serializable {
    
    private int     id;
    @Attribute
    private String  personKey;
    @Element(required=false)
    private String  firstName;
    @Element(required=false)
    private String  lastName;
    @Element(required=false)
    private String  gender;
    @Element(required=false)
    private String  personType;
    @Element(required=false)
    private String  studioKey;
    @Element(required=false)
    private String  nickName;
    @Element(required=false)
    private String  NdcaUsabdaNumber;
    @Element(required=false)
    private String  competitorNumber;
    private int     masterperson_id;
    private int     eventId;
    private int     xmlId;
    private boolean unified;
    private int newMasterperson_id;
    
    public HeatResultPerson() { }
    
    public HeatResultPerson(String pk, String fn, String ln, String gn , 
            String pt, String sk, String nn, String ncno, String cn) { 
        personKey = pk;
        firstName = fn;
        lastName = ln;
        gender = gn;
        personType = pt;
        studioKey = sk;
        nickName = nn;
        NdcaUsabdaNumber = ncno;
        competitorNumber = cn;
        
    }
    
    
    
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * @return the gender
     */
    public String getGender() {
        return gender;
    }

    /**
     * @param gender the gender to set
     */
    public void setGender(String gender) {
        this.gender = gender;
    }

    /**
     * @return the personType
     */
    public String getPersonType() {
        return personType;
    }

    /**
     * @param personType the personType to set
     */
    public void setPersonType(String personType) {
        this.personType = personType;
    }

    /**
     * @return the studioKey
     */
    public String getStudioKey() {
        return studioKey;
    }

    /**
     * @param studioKey the studioKey to set
     */
    public void setStudioKey(String studioKey) {
        this.studioKey = studioKey;
    }

    /**
     * @return the nickName
     */
    public String getNickName() {
        return nickName;
    }

    /**
     * @param nickName the nickName to set
     */
    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    /**
     * @return the NdcaUsabdaNumber
     */
    public String getNdcaUsabdaNumber() {
        return NdcaUsabdaNumber;
    }

    /**
     * @param NdcaUsabdaNumber the NdcaUsabdaNumber to set
     */
    public void setNdcaUsabdaNumber(String NdcaUsabdaNumber) {
        this.NdcaUsabdaNumber = NdcaUsabdaNumber;
    }

    /**
     * @return the competitorNumber
     */
    public String getCompetitorNumber() {
        return competitorNumber;
    }

    /**
     * @param competitorNumber the competitorNumber to set
     */
    public void setCompetitorNumber(String competitorNumber) {
        this.competitorNumber = competitorNumber;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the xmlId
     */
    public int getXmlId() {
        return xmlId;
    }

    /**
     * @param xmlId the xmlId to set
     */
    public void setXmlId(int xmlId) {
        this.xmlId = xmlId;
    }

    /**
     * @return the personKey
     */
    public String getPersonKey() {
        return personKey;
    }

    /**
     * @param personKey the personKey to set
     */
    public void setPersonKey(String personKey) {
        this.personKey = personKey;
    }


    /**
     * @return the masterperson_id
     */
    public int getMasterperson_id() {
        return masterperson_id;
    }

    /**
     * @param masterperson_id the masterperson_id to set
     */
    public void setMasterperson_id(int masterperson_id) {
        this.masterperson_id = masterperson_id;
    }

    /**
     * @return the unified
     */
    public boolean isUnified() {
        return unified;
    }

    /**
     * @param unified the unified to set
     */
    public void setUnified(boolean unified) {
        this.unified = unified;
    }

    /**
     * @return the newMasterperson_id
     */
    public int isNewMasterperson_id() {
        return newMasterperson_id;
    }

    /**
     * @param newMasterperson_id the newMasterperson_id to set
     */
    public void setNewMasterperson_id(int newMasterperson_id) {
        this.newMasterperson_id = newMasterperson_id;
    }

    @Override
    public String toString() {
        return "HeatResultPerson{" + "id=" + id + ", personKey=" + personKey + ", firstName=" + firstName + ", lastName=" + lastName + ", gender=" + gender + ", personType=" + personType + ", studioKey=" + studioKey + ", nickName=" + nickName + ", NdcaUsabdaNumber=" + NdcaUsabdaNumber + ", competitorNumber=" + competitorNumber + ", masterperson_id=" + masterperson_id + ", eventId=" + eventId + ", xmlId=" + xmlId + ", unified=" + unified + ", newMasterperson_id=" + newMasterperson_id + '}';
    }
       
    
    
}
