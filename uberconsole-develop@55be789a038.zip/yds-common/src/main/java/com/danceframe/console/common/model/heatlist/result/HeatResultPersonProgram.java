/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.heatlist.result;

import java.io.Serializable;
import java.util.ArrayList;
import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

/**
 *
 * @author lmorallos
 */
@Root(name="program")
public class HeatResultPersonProgram implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @Attribute (required=false)
    private int     masterPersonId;
    
    @Attribute (required=false)
    private String     puid;
    
    @ElementList(required=false)
    private ArrayList<HeatResultEvent> events;

    /**
     * @return the events
     */
    public ArrayList<HeatResultEvent> getEvents() {
        return events;
    }

    /**
     * @param events the events to set
     */
    public void setEvents(ArrayList<HeatResultEvent> events) {
        this.events = events;
    }

    /**
     * @return the masterPersonId
     */
    public int getMasterPersonId() {
        return masterPersonId;
    }

    /**
     * @param masterPersonId the masterPersonId to set
     */
    public void setMasterPersonId(int masterPersonId) {
        this.masterPersonId = masterPersonId;
    }

    /**
     * @return the puid
     */
    public String getPuid() {
        return puid;
    }

    /**
     * @param puid the puid to set
     */
    public void setPuid(String puid) {
        this.puid = puid;
    }
    
    
     
    
}
