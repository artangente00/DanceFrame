/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.registration;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author lmorallos
 */
public class RegStudio implements Serializable  {
    
    private static final long serialVersionUID = 1L;
    
    private int     id;
    private String  name;
    private String  contactLastname;
    private String  contactFirstname;
    private String  address1;
    private String  address2;
    private String  city;
    private String  state;
    private String  postal;
    private String  country;
    private String  phone;
    private String  email;
    private int     eventId;
    private String  euid;
    private int     userId;
    private String  buid;
    private String  suid;
    private Date    creationDate;
    private Date    lastModified;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the contactLastname
     */
    public String getContactLastname() {
        return contactLastname;
    }

    /**
     * @param contactLastname the contactLastname to set
     */
    public void setContactLastname(String contactLastname) {
        this.contactLastname = contactLastname;
    }

    /**
     * @return the contactFirstname
     */
    public String getContactFirstname() {
        return contactFirstname;
    }

    /**
     * @param contactFirstname the contactFirstname to set
     */
    public void setContactFirstname(String contactFirstname) {
        this.contactFirstname = contactFirstname;
    }

    /**
     * @return the address1
     */
    public String getAddress1() {
        return address1;
    }

    /**
     * @param address1 the address1 to set
     */
    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    /**
     * @return the address2
     */
    public String getAddress2() {
        return address2;
    }

    /**
     * @param address2 the address2 to set
     */
    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    /**
     * @return the city
     */
    public String getCity() {
        return city;
    }

    /**
     * @param city the city to set
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * @return the state
     */
    public String getState() {
        return state;
    }

    /**
     * @param state the state to set
     */
    public void setState(String state) {
        this.state = state;
    }

    /**
     * @return the postal
     */
    public String getPostal() {
        return postal;
    }

    /**
     * @param postal the postal to set
     */
    public void setPostal(String postal) {
        this.postal = postal;
    }

    /**
     * @return the country
     */
    public String getCountry() {
        return country;
    }

    /**
     * @param country the country to set
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * @return the phone
     */
    public String getPhone() {
        return phone;
    }

    /**
     * @param phone the phone to set
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the euid
     */
    public String getEuid() {
        return euid;
    }

    /**
     * @param euid the euid to set
     */
    public void setEuid(String euid) {
        this.euid = euid;
    }

    /**
     * @return the suid
     */
    public String getSuid() {
        return suid;
    }

    /**
     * @param suid the suid to set
     */
    public void setSuid(String suid) {
        this.suid = suid;
    }

    /**
     * @return the creationDate
     */
    public Date getCreationDate() {
        return creationDate;
    }

    /**
     * @param creationDate the creationDate to set
     */
    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    /**
     * @return the lastModified
     */
    public Date getLastModified() {
        return lastModified;
    }

    /**
     * @param lastModified the lastModified to set
     */
    public void setLastModified(Date lastModified) {
        this.lastModified = lastModified;
    }

    /**
     * @return the userId
     */
    public int getUserId() {
        return userId;
    }

    /**
     * @param userId the userId to set
     */
    public void setUserId(int userId) {
        this.userId = userId;
    }

    /**
     * @return the buid
     */
    public String getBuid() {
        return buid;
    }

    /**
     * @param buid the buid to set
     */
    public void setBuid(String buid) {
        this.buid = buid;
    }

    @Override
    public String toString() {
        return "RegStudio{" + "id=" + id + ", name=" + name + ", contactLastname=" + contactLastname + ", contactFirstname=" + contactFirstname + ", address1=" + address1 + ", address2=" + address2 + ", city=" + city + ", state=" + state + ", postal=" + postal + ", country=" + country + ", phone=" + phone + ", email=" + email + ", eventId=" + eventId + ", euid=" + euid + ", userId=" + userId + ", buid=" + buid + ", suid=" + suid + ", creationDate=" + creationDate + ", lastModified=" + lastModified + '}';
    }
    
}
