/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.competition;

import com.danceframe.console.common.model.basic.GenericFormObject;
import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class Hotel extends GenericFormObject implements Serializable {
    
    private static final long serialVersionUID = 1L;
    private int id;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }
    
}
