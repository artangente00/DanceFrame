/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.competition;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class Contact implements Serializable {
    
    private static final long serialVersionUID = 1L;
    private int     id;
    private String  name;
    private String  address;
    private String  address2;
    private String  city;
    private String  province;    
    private String  country;
    private String  zipcode;
    private String  phone;
    private String  fax;
    private String  email;
    private int     eventid;

     public boolean isEmpty()  {
        if ((null != name) || (!name.isEmpty()) || (name.length() > 0))  return false;
        if ((null != address) || (!address.isEmpty()) || (address.length() > 0))  return false;
        if ((null != address2) || (!address2.isEmpty()) || (address2.length() > 0))  return false;
        if ((null != city) || (!city.isEmpty()) || (city.length() > 0))  return false;
        if ((null != province) || (!province.isEmpty()) || (province.length() > 0))  return false;
        if ((null != country) || (!country.isEmpty()) || (country.length() > 0))  return false;
        if ((null != zipcode) || (!zipcode.isEmpty()) || (zipcode.length() > 0))  return false;
        if ((null != phone) || (!phone.isEmpty()) || (phone.length() > 0))  return false;
        if ((null != fax) || (!fax.isEmpty()) || (fax.length() > 0))  return false;
        if ((null != email) || (!email.isEmpty()) || (email.length() > 0))  return false;
        return true;            
    }
     
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * @return the address2
     */
    public String getAddress2() {
        return address2;
    }

    /**
     * @param address2 the address2 to set
     */
    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    /**
     * @return the city
     */
    public String getCity() {
        return city;
    }

    /**
     * @param city the city to set
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * @return the province
     */
    public String getProvince() {
        return province;
    }

    /**
     * @param province the province to set
     */
    public void setProvince(String province) {
        this.province = province;
    }

    /**
     * @return the country
     */
    public String getCountry() {
        return country;
    }

    /**
     * @param country the country to set
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * @return the zipcode
     */
    public String getZipcode() {
        return zipcode;
    }

    /**
     * @param zipcode the zipcode to set
     */
    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    /**
     * @return the phone
     */
    public String getPhone() {
        return phone;
    }

    /**
     * @param phone the phone to set
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * @return the fax
     */
    public String getFax() {
        return fax;
    }

    /**
     * @param fax the fax to set
     */
    public void setFax(String fax) {
        this.fax = fax;
    }

    /**
     * @return the eventid
     */
    public int getEventid() {
        return eventid;
    }

    /**
     * @param eventid the eventid to set
     */
    public void setEventid(int eventid) {
        this.eventid = eventid;
    }
   

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "Contact{" + "id=" + id + ", name=" + name + ", address=" + address + ", address2=" + address2 + 
                ", city=" + city + ", province=" + province + ", country=" + country + ", zipcode=" + zipcode + 
                ", phone=" + phone + ", fax=" + fax + ", email=" + email + ", eventid=" + eventid + '}';
    }
    
    
    
}
