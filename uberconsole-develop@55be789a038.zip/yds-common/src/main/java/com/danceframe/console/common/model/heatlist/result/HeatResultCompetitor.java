/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.heatlist.result;


import java.io.Serializable;
import java.util.ArrayList;
import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

/**
 *
 * @author lmorallos
 */
@Root(name="competitor")
public class HeatResultCompetitor implements Serializable  {
    
    private static long serialVersionUID = 1L;
    
    private int     id;
    
    @Attribute (name="key", required=false)
    private String  competitorKey;
    
    @Attribute (name="type", required=false)
    private String  competitorType;
    
    @Attribute (required=false)
    private String  nameOverride;
    
    @Attribute (required=false)
    private String  competitorNumber;
    
    @ElementList
    private ArrayList<HeatListResultPersonKey> personKeys;
    
    private int     eventId;
    private int     xmlId;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the compeitorKey
     */
    public String getCompetitorKey() {
        return competitorKey;
    }

    /**
     * @param compeitorKey the compeitorKey to set
     */
    public void setCompetitorKey(String competitorKey) {
        this.competitorKey = competitorKey;
    }

    /**
     * @return the competitorType
     */
    public String getCompetitorType() {
        return competitorType;
    }

    /**
     * @param competitorType the competitorType to set
     */
    public void setCompetitorType(String competitorType) {
        this.competitorType = competitorType;
    }

    /**
     * @return the nameOverride
     */
    public String getNameOverride() {
        return nameOverride;
    }

    /**
     * @param nameOverride the nameOverride to set
     */
    public void setNameOverride(String nameOverride) {
        this.nameOverride = nameOverride;
    }

    /**
     * @return the personKeys
     */
    public ArrayList<HeatListResultPersonKey> getPersonKeys() {
        return personKeys;
    }

    /**
     * @param personKeys the personKeys to set
     */
    public void setPersonKeys(ArrayList<HeatListResultPersonKey> personKeys) {
        this.personKeys = personKeys;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the xmlId
     */
    public int getXmlId() {
        return xmlId;
    }

    /**
     * @param xmlId the xmlId to set
     */
    public void setXmlId(int xmlId) {
        this.xmlId = xmlId;
    }


    /**
     * @return the competitorNumber
     */
    public String getCompetitorNumber() {
        return competitorNumber;
    }

    /**
     * @param competitorNumber the competitorNumber to set
     */
    public void setCompetitorNumber(String competitorNumber) {
        this.competitorNumber = competitorNumber;
    }

    @Override
    public String toString() {
        return "HeatResultCompetitor{" + "id=" + id + ", competitorKey=" + competitorKey + ", competitorType=" + competitorType + ", nameOverride=" + nameOverride + ", competitorNumber=" + competitorNumber + ", personKeys=" + personKeys + ", eventId=" + eventId + ", xmlId=" + xmlId + '}';
    }
    
    
    
}
