/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.registration;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public class RegCompetitor implements Serializable {
    
    private static final long serialVersionUID = 1L;
     
    private int     id;
    private String type;
    private int    eventId;
    private String euid;
    private String cuid;
    private int     userId;
    private String  buid;
    private List<RegCompetitorPerson> personList;
    private Date    creationDate;
    private Date    lastModified;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the euid
     */
    public String getEuid() {
        return euid;
    }

    /**
     * @param euid the euid to set
     */
    public void setEuid(String euid) {
        this.euid = euid;
    }

    /**
     * @return the cuid
     */
    public String getCuid() {
        return cuid;
    }

    /**
     * @param cuid the cuid to set
     */
    public void setCuid(String cuid) {
        this.cuid = cuid;
    }

    /**
     * @return the personList
     */
    public List<RegCompetitorPerson> getPersonList() {
        return personList;
    }

    /**
     * @param personList the personList to set
     */
    public void setPersonList(List<RegCompetitorPerson> personList) {
        this.personList = personList;
    }

    /**
     * @return the creationDate
     */
    public Date getCreationDate() {
        return creationDate;
    }

    /**
     * @param creationDate the creationDate to set
     */
    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    /**
     * @return the lastModified
     */
    public Date getLastModified() {
        return lastModified;
    }

    /**
     * @param lastModified the lastModified to set
     */
    public void setLastModified(Date lastModified) {
        this.lastModified = lastModified;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the userId
     */
    public int getUserId() {
        return userId;
    }

    /**
     * @param userId the userId to set
     */
    public void setUserId(int userId) {
        this.userId = userId;
    }

    /**
     * @return the buid
     */
    public String getBuid() {
        return buid;
    }

    /**
     * @param buid the buid to set
     */
    public void setBuid(String buid) {
        this.buid = buid;
    }

    @Override
    public String toString() {
        return "RegCompetitor{" + "id=" + id + ", type=" + type + ", eventId=" + eventId + ", euid=" + euid + ", cuid=" + cuid + ", userId=" + userId + ", buid=" + buid + ", personList=" + personList + ", creationDate=" + creationDate + ", lastModified=" + lastModified + '}';
    }
   
}
