/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.invoice;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author lmorallos
 */
public class InvoicePayment implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private int     invoicePaymentId;
    private String  firebaseAuthId;
    private String  firebaseEventId;
    private int     eventId;
    private int     peopleId;
    private String  invoiceNo;
    private String  seriesNo;
    private double  invoiceAmount;
    private double  receivedAmount;
    private double  balance;
    private Date    lastPaymentDate;
    private int     mailInvoiceId;
    private boolean sendMail;
    

    /**
     * @return the invoicePaymentId
     */
    public int getInvoicePaymentId() {
        return invoicePaymentId;
    }

    /**
     * @param invoicePaymentId the invoicePaymentId to set
     */
    public void setInvoicePaymentId(int invoicePaymentId) {
        this.invoicePaymentId = invoicePaymentId;
    }

    /**
     * @return the firebaseAuthId
     */
    public String getFirebaseAuthId() {
        return firebaseAuthId;
    }

    /**
     * @param firebaseAuthId the firebaseAuthId to set
     */
    public void setFirebaseAuthId(String firebaseAuthId) {
        this.firebaseAuthId = firebaseAuthId;
    }

    /**
     * @return the firebaseEventId
     */
    public String getFirebaseEventId() {
        return firebaseEventId;
    }

    /**
     * @param firebaseEventId the firebaseEventId to set
     */
    public void setFirebaseEventId(String firebaseEventId) {
        this.firebaseEventId = firebaseEventId;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the peopleId
     */
    public int getPeopleId() {
        return peopleId;
    }

    /**
     * @param peopleId the peopleId to set
     */
    public void setPeopleId(int peopleId) {
        this.peopleId = peopleId;
    }

    /**
     * @return the invoiceNo
     */
    public String getInvoiceNo() {
        return invoiceNo;
    }

    /**
     * @param invoiceNo the invoiceNo to set
     */
    public void setInvoiceNo(String invoiceNo) {
        this.invoiceNo = invoiceNo;
    }

    /**
     * @return the seriesNo
     */
    public String getSeriesNo() {
        return seriesNo;
    }

    /**
     * @param seriesNo the seriesNo to set
     */
    public void setSeriesNo(String seriesNo) {
        this.seriesNo = seriesNo;
    }

    /**
     * @return the invoiceAmount
     */
    public double getInvoiceAmount() {
        return invoiceAmount;
    }

    /**
     * @param invoiceAmount the invoiceAmount to set
     */
    public void setInvoiceAmount(double invoiceAmount) {
        this.invoiceAmount = invoiceAmount;
    }

    /**
     * @return the receivedAmount
     */
    public double getReceivedAmount() {
        return receivedAmount;
    }

    /**
     * @param receivedAmount the receivedAmount to set
     */
    public void setReceivedAmount(double receivedAmount) {
        this.receivedAmount = receivedAmount;
    }

    /**
     * @return the balance
     */
    public double getBalance() {
        return balance;
    }

    /**
     * @param balance the balance to set
     */
    public void setBalance(double balance) {
        this.balance = balance;
    }

    /**
     * @return the lastPaymentDate
     */
    public Date getLastPaymentDate() {
        return lastPaymentDate;
    }

    /**
     * @param lastPaymentDate the lastPaymentDate to set
     */
    public void setLastPaymentDate(Date lastPaymentDate) {
        this.lastPaymentDate = lastPaymentDate;
    }

    /**
     * @return the mailInvoiceId
     */
    public int getMailInvoiceId() {
        return mailInvoiceId;
    }

    /**
     * @param mailInvoiceId the mailInvoiceId to set
     */
    public void setMailInvoiceId(int mailInvoiceId) {
        this.mailInvoiceId = mailInvoiceId;
    }

    /**
     * @return the sendMail
     */
    public boolean isSendMail() {
        return sendMail;
    }

    /**
     * @param sendMail the sendMail to set
     */
    public void setSendMail(boolean sendMail) {
        this.sendMail = sendMail;
    }

    @Override
    public String toString() {
        return "InvoicePayment{" + "invoicePaymentId=" + invoicePaymentId + ", firebaseAuthId=" + firebaseAuthId + ", firebaseEventId=" + firebaseEventId + ", eventId=" + eventId + ", peopleId=" + peopleId + ", invoiceNo=" + invoiceNo + ", seriesNo=" + seriesNo + ", invoiceAmount=" + invoiceAmount + ", receivedAmount=" + receivedAmount + ", balance=" + balance + ", lastPaymentDate=" + lastPaymentDate + ", mailInvoiceId=" + mailInvoiceId + ", sendMail=" + sendMail + '}';
    }
    
    
    
}
