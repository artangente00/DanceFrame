/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.firebase.competition;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class ImageStore implements Serializable {
    
    private static long serialVersionUID = 1L;
    
    private int     imageId;
    private boolean result;

    /**
     * @return the imageId
     */
    public int getImageId() {
        return imageId;
    }

    /**
     * @param imageId the imageId to set
     */
    public void setImageId(int imageId) {
        this.imageId = imageId;
    }

    /**
     * @return the result
     */
    public boolean isResult() {
        return result;
    }

    /**
     * @param result the result to set
     */
    public void setResult(boolean result) {
        this.result = result;
    }

    @Override
    public String toString() {
        return "ImageStore{" + "imageId=" + imageId + ", result=" + result + '}';
    }
    
    
    
}
