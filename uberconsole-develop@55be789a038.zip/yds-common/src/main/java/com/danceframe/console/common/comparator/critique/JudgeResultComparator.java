/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.comparator.critique;

import com.danceframe.console.common.model.critique.xml.HeatResultJudge;
import java.util.Comparator;

/**
 *
 * @author lmorallos
 */
public class JudgeResultComparator implements Comparator<HeatResultJudge>{

    @Override
    public int compare(HeatResultJudge o1, HeatResultJudge o2) {
        
        String lname1 = o1.getLastName().toUpperCase();
        String lname2 = o2.getLastName().toUpperCase();
        
        String fname1 = o1.getFirstName().toUpperCase();
        String fname2 = o2.getFirstName().toUpperCase();
        
        if (lname1.compareTo(lname2) == 0) {
            return (fname1.compareTo(fname2));
        } else {
            return lname1.compareTo(lname2);
        }
    }
    
}
