/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.util;

import static com.danceframe.heatlist.common.util.Utility.isFileExist;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
/**
 *
 * @author lmorallos
 */
public final class Utility {
    
    private static final Logger logger = LogManager.getLogger(Utility.class);
    
    public final static int getYear(Date date) {
        SimpleDateFormat formatyear = new SimpleDateFormat("yyyy");
        int iyear = Integer.parseInt(formatyear.format(date));
        return iyear;
    }
    
    public final static String strDate(Date date) {
        SimpleDateFormat formatyear = new SimpleDateFormat("MM/dd/yyyy");
        String sdate = formatyear.format(date);
        return sdate;
    }
    
    public final static java.sql.Date sqlDate(Date date) {
        if (date==null) return null;
        return(new java.sql.Date(date.getTime()));
    }
    
    public final static java.sql.Timestamp sqlTimestamp(Date date) {
         if (date==null) return null;
        return(new java.sql.Timestamp(date.getTime()));
    }
    
    public final static void isNullDebug(Object obj, String modulename) {
        if (obj == null) {
           logger.info("[*] Debugging =====> (NULL) :" + modulename);            
        } else {
           logger.info("[*] Debugging =====> (NOT NULL) :" + modulename);        
        }
    }
    
    
    public final static String generateUniqueFileName(String prefix) {
        return generateUniqueFileName(prefix, "EVTX");
    } 
    
    public final static String generateUniqueFileName(String prefix, String code) {
        String filename = "";
        long millis = System.currentTimeMillis();
        String datetime = new Date().toString();
        datetime = datetime.replace(" ", "");
        datetime = datetime.replace(":", "");
        filename = prefix + code + datetime + "_" + millis;
        return filename;
    } 
    
    public final static String getExtension(String filename) {
        String retstr = null;
        int idx = filename.lastIndexOf(".");
        if (idx > -1) {
            retstr = filename.substring(idx, filename.length());
            retstr = retstr.replace(".", ""); 
        }
        return retstr;
    }
    
    public final static boolean moveFile(String srcfile, String dstfile) throws IOException {
        boolean retbool = false;
        File srcFile = new File(srcfile);
        File dstFile = new File(dstfile);
        if (dstFile.exists()) dstFile.delete();
        retbool = srcFile.renameTo(dstFile); 
        return retbool;
    }
    
    public final static boolean isFileExist(String filename) throws IOException {
        boolean retbool = false;
        File file = new File(filename);
        retbool = file.exists();
        return retbool;
    }
    
    public final static boolean isFileExist(String directory, String filename) throws IOException {
        boolean retbool = false;
        File file = new File(directory, filename);
        retbool = file.exists();
        return retbool;
    }
    
    public final static String getFilename(String filename) {
        String retstr = null;
        int idx = filename.lastIndexOf(".");
        if (idx > -1) {
            retstr = filename.substring(0, idx);
            retstr = retstr.replace(".", "");   
        }
        return retstr;
    }
    
    public final static String getFilePrefix(String filename) {
        return getFilePrefix(filename, "EVTX");
    }
    
    public final static String getFilePrefix(String filename, String code) {
        String retstr = null;
        int idx = filename.indexOf(code);
        if (idx > -1) {
            retstr = filename.substring(0, idx);
        }
        return retstr;
    }
    
    public final static String getFilenameFromURL(String url) {
        String retstr = null;
        String tmpstr = Utility.getFilename(url);
        int idx = tmpstr.lastIndexOf("/");
        if (idx > -1) {
            retstr = tmpstr.substring(idx + 1,tmpstr.length());
        } 
        return retstr;
    }
    
    public final static boolean deleteFile(String path, String filename) {
        boolean retbool = false;
        String fullpath = path + filename;
        // fullpath = fullpath.replace("\\", "/");
        File file = new File(path, filename);
        logger.info("Attempting to delete:" + fullpath);
        if (file.exists()) {
            file.setWritable(true);
            retbool = file.delete();
             logger.info("Done:" + retbool);
        }
        return retbool;
    }
    
    public final static String computerInterval(long startDate) {
        String retstr = new String();
        long endDate = System.currentTimeMillis();
        long different = endDate - startDate;
        long secondsInMilli = 1000;
        long minutesInMilli = secondsInMilli * 60;
	long hoursInMilli = minutesInMilli * 60;
	long daysInMilli = hoursInMilli * 24;

        long elapsedSeconds = different / secondsInMilli;
        long elapsedMinutes = different / minutesInMilli;
	long elapsedHours = different / hoursInMilli;
	// different = different % hoursInMilli;
        if (elapsedHours > 0) { 
            retstr = String.format("%d hours", elapsedHours);
        } else { 
            if (elapsedSeconds < 60) {
                retstr = String.format("%d secs", elapsedSeconds);
            } else {
               retstr = String.format("%d mins", elapsedMinutes);
            }
        }
        return retstr;
    }
    
    public final static String date2String(Date date) {
        String retstr = new String();
        if (date != null) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd h:mm a");
            String dstr = dateFormat.format(date);
            retstr = dstr.replace(" AM", "am").replace(" PM", "pm");
        }
        return retstr; 
    }
    
    public final static String object2Json(Object object) {
        Gson gson = new GsonBuilder().serializeNulls().setDateFormat("yyyy-MM-dd hh:mm:ss a").create();
        String result = gson.toJson(object);
        return result;
    }
    
    public final static String urlPrefix(String url) {
        String newURL = (url.indexOf("http://") > -1) || 
                (url.indexOf("https://") >  -1) ? url: "http://" + url;
        return newURL;
    }
    
    public final static ImageDimension computeImageScaledValue(ImageDimension imgSize, ImageDimension boundary) {
        ImageDimension retobj = new ImageDimension();
        
        int original_width = imgSize.getWidth();
        int original_height = imgSize.getHeight();
        int bound_width = boundary.getWidth();
        int bound_height = boundary.getHeight();
        int new_width = original_width;
        int new_height = original_height;

        if (original_width > bound_width) {
            new_width = bound_width;
            new_height = (new_width * original_height) / original_width;
        }

        if (new_height > bound_height) {
            new_height = bound_height;
            new_width = (new_height * original_width) / original_height;
        }
        retobj.setWidth(new_width);
        retobj.setHeight(new_height);
        return retobj;
    }
   
    public static final List<String> str2List(String targetstr, char delim) {
        List<String> retlist = new ArrayList<String>();
        FastTokenizer st = new FastTokenizer(targetstr,delim);  
        while (st.hasMoreTokens()) {  
            retlist.add(st.nextToken());  
        }  
        return retlist;
    }
    
    public static final String null2Str(String value) {
        return (value==null)?"":value;
    }
     
    public static String padLeft(String stringToPad, int padToLength){
        String retValue = null;
        if(stringToPad.length() < padToLength) {
            retValue = String.format("%0" + String.valueOf(padToLength - stringToPad.length()) + "d%s",0,stringToPad);
        }
        else{
            retValue = stringToPad;
        }
        return retValue;
    }
    
     public final static String getHeatType(String desc) {
        String retstr = new String();
        String loname = desc.trim().toLowerCase();
       
        if (loname.contains("semi-final")) {
            retstr = "SF";
        } else if (loname.contains("semi final")) {
            retstr = "SF";
        } else if (loname.contains("quarter-final")) {
            retstr = "QF";
        } else if (loname.contains("quarter final")) {
            retstr = "QF";
        } else if (loname.contains("first round")) {
            retstr = "FR";
        } else if (loname.contains("second round")) {
            retstr = "SR";
        } else if (loname.contains("third round")) {
            retstr = "TR";
        } else if (loname.contains("fourth round")) {
            retstr = "OR";
        } else if (loname.contains("proficiency")) {
            retstr = "Proficiency";
        } else  if (loname.contains("final")) {
            retstr = "F";  
        }
        return retstr;
    }
     
    public final static boolean showPerson(String fn, String ln) {
        boolean retbool = true;
        String first = fn.trim().replace(".", "");
        first = first.trim().replace(",", "");
        String last = ln.trim().replace(".", "");
        last = last.trim().replace(",", "");
        if (first.trim().length() == 0 && last.trim().length() == 0) retbool = false;
        return retbool;
    }
    
    public static boolean writeBytesToFile(String filePath, byte[] bytes) {
        boolean retbool = true;
        File outputFile = new File(filePath);
        try (FileOutputStream outputStream = new FileOutputStream(outputFile)) {
            outputStream.write(bytes);
            outputStream.flush();
            outputStream.close(); 
            
            if (!isFileExist(filePath)) {
                retbool = false;
            }
        } catch (IOException ex) {
            retbool = false;
        }
        return retbool;
    }
    
    public static byte[] readFileToBytes(String directory, String filename) throws IOException {
        File file = new File(directory, filename);
        byte[] bytes = Files.readAllBytes(file.toPath());
        return bytes;
    }
    
    
    
     public static boolean isValidURL(String url)
    {
        try {
            new URL(url).toURI();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
     
     public static byte[] digest(byte[] input) {
        MessageDigest md;
        try {
            md = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalArgumentException(e);
        }
        byte[] result = md.digest(input);
        return result;
    }

    public static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
    
    public static String md5HexString(byte[] input) {
        return bytesToHex(digest(input));
    }
}
