/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.invoice;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author lmorallos
 */
public class InvoicePaymentDetail implements Serializable {
    
    private static final long serialVersionUID = 1L;
     
    private int     invoicePaymnetDetailId;
    private int     invoicePaymentId; 
    private double  invoiceAmount;
    private double  receivedAmount;
    private double  balance;
    private String  notes;
    private int     payType;
    private Date    paymentDate;
    private String  payTypeDesc;
    
    /**
     * @return the invoicePaymnetDetailId
     */
    public int getInvoicePaymnetDetailId() {
        return invoicePaymnetDetailId;
    }

    /**
     * @param invoicePaymnetDetailId the invoicePaymnetDetailId to set
     */
    public void setInvoicePaymnetDetailId(int invoicePaymnetDetailId) {
        this.invoicePaymnetDetailId = invoicePaymnetDetailId;
    }

    /**
     * @return the invoicePaymentId
     */
    public int getInvoicePaymentId() {
        return invoicePaymentId;
    }

    /**
     * @param invoicePaymentId the invoicePaymentId to set
     */
    public void setInvoicePaymentId(int invoicePaymentId) {
        this.invoicePaymentId = invoicePaymentId;
    }

    /**
     * @return the invoiceAmount
     */
    public double getInvoiceAmount() {
        return invoiceAmount;
    }

    /**
     * @param invoiceAmount the invoiceAmount to set
     */
    public void setInvoiceAmount(double invoiceAmount) {
        this.invoiceAmount = invoiceAmount;
    }

    /**
     * @return the receivedAmount
     */
    public double getReceivedAmount() {
        return receivedAmount;
    }

    /**
     * @param receivedAmount the receivedAmount to set
     */
    public void setReceivedAmount(double receivedAmount) {
        this.receivedAmount = receivedAmount;
    }

    /**
     * @return the balance
     */
    public double getBalance() {
        return balance;
    }

    /**
     * @param balance the balance to set
     */
    public void setBalance(double balance) {
        this.balance = balance;
    }

    /**
     * @return the notes
     */
    public String getNotes() {
        return notes;
    }

    /**
     * @param notes the notes to set
     */
    public void setNotes(String notes) {
        this.notes = notes;
    }

    /**
     * @return the paymentDate
     */
    public Date getPaymentDate() {
        return paymentDate;
    }

    /**
     * @param paymentDate the paymentDate to set
     */
    public void setPaymentDate(Date paymentDate) {
        this.paymentDate = paymentDate;
    }

    /**
     * @return the payType
     */
    public int getPayType() {
        return payType;
    }

    /**
     * @param payType the payType to set
     */
    public void setPayType(int payType) {
        this.payType = payType;
    }

    /**
     * @return the payTypeDesc
     */
    public String getPayTypeDesc() {
        if (payType == 0) payTypeDesc = "NONE";
        if (payType == 1) payTypeDesc = "CASH";
        if (payType == 2) payTypeDesc = "DEBIT";
        if (payType == 3) payTypeDesc = "CREDIT";
        return payTypeDesc;
    }
    
    @Override
    public String toString() {
        return "InvoicePaymentDetail{" + "invoicePaymnetDetailId=" + invoicePaymnetDetailId + ", invoicePaymentId=" + invoicePaymentId + ", invoiceAmount=" + invoiceAmount + ", receivedAmount=" + receivedAmount + ", balance=" + balance + ", notes=" + notes + ", payType=" + payType + ", paymentDate=" + paymentDate + '}';
    }
  
}
