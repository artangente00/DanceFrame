/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.competition.config;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class Level extends ConfigBase implements Serializable {
    
     private static final long serialVersionUID = 1L;
     
}
