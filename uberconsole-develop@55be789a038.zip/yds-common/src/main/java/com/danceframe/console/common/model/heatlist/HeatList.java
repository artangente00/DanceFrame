/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.heatlist;

import com.danceframe.console.common.util.Utility;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author lmorallos
 */
public class HeatList implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private int     id;
    private String  description;
    private Date    asof;
    private String  filename;
    private String  setupFile;
    private Date    compDate;
    private int     eventId;
    private byte[]  progData;
    private byte[]  setupData; 
    
    
    public HeatList() {}
    
    public HeatList(int i, String desc, Date af, String fname, int eid) {
        this.id = i;
        this.description = desc;
        this.asof = af;
        this.filename = fname;
        this.eventId = eid;
    }
    
    public HeatList(String desc, Date af, String fname, int eid) {
        this.description = desc;
        this.asof = af;
        this.filename = fname;
        this.eventId = eid;
    }
    
    public InputStream getProgDataAsInputStream() {
      return new ByteArrayInputStream(progData);  
    }
    
    public InputStream getSetupDataAsInputStream() {
      return new ByteArrayInputStream(setupData);  
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the asof
     */
    public Date getAsof() {
        return asof;
    }

    /**
     * @param asof the asof to set
     */
    public void setAsof(Date asof) {
        this.asof = asof;
    }

    /**
     * @return the filename
     */
    public String getFilename() {
        return filename;
    }

    /**
     * @param filename the filename to set
     */
    public void setFilename(String filename) {
        this.filename = filename;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    
    public String getStrAsof() {
        return Utility.date2String(asof);
    }

    /**
     * @return the compDate
     */
    public Date getCompDate() {
        return compDate;
    }

    /**
     * @param compDate the compDate to set
     */
    public void setCompDate(Date compDate) {
        this.compDate = compDate;
    }

    /**
     * @return the setupFile
     */
    public String getSetupFile() {
        return setupFile;
    }

    /**
     * @param setupFile the setupFile to set
     */
    public void setSetupFile(String setupFile) {
        this.setupFile = setupFile;
    }

    @Override
    public String toString() {
        return "HeatList{" + "id=" + id + ", description=" + description + ", asof=" + asof + ", filename=" + filename + ", setupFile=" + setupFile + ", compDate=" + compDate + ", eventId=" + eventId + '}';
    } 

    /**
     * @return the progData
     */
    public byte[] getProgData() {
        return progData;
    }

    /**
     * @param progData the progData to set
     */
    public void setProgData(byte[] progData) {
        this.progData = progData;
    }

    /**
     * @return the setupData
     */
    public byte[] getSetupData() {
        return setupData;
    }

    /**
     * @param setupData the setupData to set
     */
    public void setSetupData(byte[] setupData) {
        this.setupData = setupData;
    }
    
}
