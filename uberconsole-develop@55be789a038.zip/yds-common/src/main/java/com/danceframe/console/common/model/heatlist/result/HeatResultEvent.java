/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.heatlist.result;

import java.io.Serializable;
import java.util.ArrayList;
import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

/**
 *
 * @author lmorallos
 */
@Root(name="event")
public class HeatResultEvent implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @Attribute
    private String  personKey;
    
    @Attribute(required=false)
    private int     id;
    
    @Attribute(required=false)
    private String  euid;
    
    @Attribute
    private String  name;
    
    @Attribute
    private String   dateStart;
    
    @Attribute
    private String  dateStop;
    
    @Attribute
    private int     year;
    
    @ElementList(required=false)
    private ArrayList<HeatResultStudio> studios;
    
    @ElementList(required=false)
    private ArrayList<HeatResultJudge> judges;
    
    @ElementList(required=false)
    private ArrayList<HeatResultPerson> persons;
    
    @ElementList(required=false)
    private ArrayList<HeatResultCompetitor> competitors;
    
    @ElementList(required=false)
    private ArrayList<HeatResultHeat> heats;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the dateStart
     */
    public String getDateStart() {
        return dateStart;
    }

    /**
     * @param dateStart the dateStart to set
     */
    public void setDateStart(String dateStart) {
        this.dateStart = dateStart;
    }

    /**
     * @return the dateStop
     */
    public String getDateStop() {
        return dateStop;
    }

    /**
     * @param dateStop the dateStop to set
     */
    public void setDateStop(String dateStop) {
        this.dateStop = dateStop;
    }


    /**
     * @return the year
     */
    public int getYear() {
        return year;
    }

    /**
     * @param year the year to set
     */
    public void setYear(int year) {
        this.year = year;
    }
    
    
    
    /**
     * @return the studios
     */
    public ArrayList<HeatResultStudio> getStudios() {
        return studios;
    }

    /**
     * @param studios the studios to set
     */
    public void setStudios(ArrayList<HeatResultStudio> studios) {
        this.studios = studios;
    }

    /**
     * @return the judges
     */
    public ArrayList<HeatResultJudge> getJudges() {
        return judges;
    }

    /**
     * @param judges the judges to set
     */
    public void setJudges(ArrayList<HeatResultJudge> judges) {
        this.judges = judges;
    }

    /**
     * @return the persons
     */
    public ArrayList<HeatResultPerson> getPersons() {
        return persons;
    }

    /**
     * @param persons the persons to set
     */
    public void setPersons(ArrayList<HeatResultPerson> persons) {
        this.persons = persons;
    }

    /**
     * @return the competitors
     */
    public ArrayList<HeatResultCompetitor> getCompetitors() {
        return competitors;
    }

    /**
     * @param competitors the competitors to set
     */
    public void setCompetitors(ArrayList<HeatResultCompetitor> competitors) {
        this.competitors = competitors;
    }

    /**
     * @return the heats
     */
    public ArrayList<HeatResultHeat> getHeats() {
        return heats;
    }

    /**
     * @param heats the heats to set
     */
    public void setHeats(ArrayList<HeatResultHeat> heats) {
        this.heats = heats;
    }

    /**
     * @return the personKey
     */
    public String getPersonKey() {
        return personKey;
    }

    /**
     * @param personKey the personKey to set
     */
    public void setPersonKey(String personKey) {
        this.personKey = personKey;
    }

    /**
     * @return the euid
     */
    public String getEuid() {
        return euid;
    }

    /**
     * @param euid the euid to set
     */
    public void setEuid(String euid) {
        this.euid = euid;
    }
    
}
