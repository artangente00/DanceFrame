/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.competition;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class PublishSummary implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private int items;
    private int pubpending;
    private int pubcommit;
    private int unpubpending;
    private int unpubcommit;
    private int repubpending;
    private int repubcommit;
    private int allpending;
    private int allcommit;  
    private int totpubpending;

    /**
     * @return the items
     */
    public int getItems() {
        return items;
    }

    /**
     * @param items the items to set
     */
    public void setItems(int items) {
        this.items = items;
    }

    /**
     * @return the pubpending
     */
    public int getPubpending() {
        return pubpending;
    }

    /**
     * @param pubpending the pubpending to set
     */
    public void setPubpending(int pubpending) {
        this.pubpending = pubpending;
    }

    /**
     * @return the pubcommit
     */
    public int getPubcommit() {
        return pubcommit;
    }

    /**
     * @param pubcommit the pubcommit to set
     */
    public void setPubcommit(int pubcommit) {
        this.pubcommit = pubcommit;
    }

    /**
     * @return the unpubpending
     */
    public int getUnpubpending() {
        return unpubpending;
    }

    /**
     * @param unpubpending the unpubpending to set
     */
    public void setUnpubpending(int unpubpending) {
        this.unpubpending = unpubpending;
    }

    /**
     * @return the unpubcommit
     */
    public int getUnpubcommit() {
        return unpubcommit;
    }

    /**
     * @param unpubcommit the unpubcommit to set
     */
    public void setUnpubcommit(int unpubcommit) {
        this.unpubcommit = unpubcommit;
    }

    /**
     * @return the allpending
     */
    public int getAllpending() {
        return allpending;
    }

    /**
     * @param allpending the allpending to set
     */
    public void setAllpending(int allpending) {
        this.allpending = allpending;
    }

    /**
     * @return the allcommit
     */
    public int getAllcommit() {
        return allcommit;
    }

    /**
     * @param allcommit the allcommit to set
     */
    public void setAllcommit(int allcommit) {
        this.allcommit = allcommit;
    }


    /**
     * @return the repubpending
     */
    public int getRepubpending() {
        return repubpending;
    }

    /**
     * @param repubpending the repubpending to set
     */
    public void setRepubpending(int repubpending) {
        this.repubpending = repubpending;
    }

    /**
     * @return the repubcommit
     */
    public int getRepubcommit() {
        return repubcommit;
    }

    /**
     * @param repubcommit the repubcommit to set
     */
    public void setRepubcommit(int repubcommit) {
        this.repubcommit = repubcommit;
    }

    /**
     * @return the totpubpending
     */
    public int getTotpubpending() {
        return pubpending + repubpending;
    }

    /**
     * @param totpubpending the totpubpending to set
     */
    public void setTotpubpending(int totpubpending) {
        this.totpubpending = totpubpending;
    }

    @Override
    public String toString() {
        return "PublishSummary{" + "items=" + items + ", pubpending=" + pubpending +
                ", pubcommit=" + pubcommit + ", unpubpending=" + unpubpending + ", unpubcommit=" + 
                unpubcommit + ", repubpending=" + repubpending + ", repubcommit=" + repubcommit + ", allpending=" + 
                allpending + ", allcommit=" + allcommit + ", totpubpending=" + totpubpending + '}';
    }
    
    
    
}
