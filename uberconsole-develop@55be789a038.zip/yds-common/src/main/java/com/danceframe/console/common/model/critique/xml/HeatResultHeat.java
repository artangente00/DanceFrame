/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.critique.xml;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

/**
 *
 * @author lmorallos
 */
@Root(name="heat")
public class HeatResultHeat implements Serializable {

    private int    id;
    @Attribute (required=false)
    private String name;
    @Attribute (required=false)
    private String session;
    @Attribute (required=false)
    private String time;
    @Attribute (required=false)
    private String date;
    @Attribute (required=false)
    private String desc;
    @Attribute (required=false)
    private String type;
    
    private int eventId;
    private int xmlId;
    
    @ElementList (required=false)
    private ArrayList<HeatResultSubHeat> subHeats;
    
    public HeatResultHeat() {} 
    
    public HeatResultHeat(String nm, String ss, String tm , String dt, String ds) {
        name = nm;
        session = ss;
        time = tm;
        date = dt;
        desc = ds;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the session
     */
    public String getSession() {
        return session;
    }

    /**
     * @param session the session to set
     */
    public void setSession(String session) {
        this.session = session;
    }

    /**
     * @return the time
     */
    public String getTime() {
        return time;
    }

    /**
     * @param time the time to set
     */
    public void setTime(String time) {
        this.time = time;
    }

    /**
     * @return the date
     */
    public String getDate() {
        return date;
    }

    /**
     * @param date the date to set
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     * @return the desc
     */
    public String getDesc() {
        return desc;
    }

    /**
     * @param desc the desc to set
     */
    public void setDesc(String desc) {
        this.desc = desc;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the xmlId
     */
    public int getXmlId() {
        return xmlId;
    }

    /**
     * @param xmlId the xmlId to set
     */
    public void setXmlId(int xmlId) {
        this.xmlId = xmlId;
    }

    /**
     * @return the subHeat
     */
    public List<HeatResultSubHeat> getSubHeats() {
        return subHeats;
    }

    /**
     * @param subHeats the subHeat to set
     */
    public void setSubHeats(ArrayList<HeatResultSubHeat> subHeats) {
        this.subHeats = subHeats;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "HeatResultHeat{" + "id=" + id + ", name=" + name + ", session=" + session + ", time=" + time + ", date=" + date + ", desc=" + desc + ", type=" + type + ", eventId=" + eventId + ", xmlId=" + xmlId + ", subHeats=" + subHeats + '}';
    }

   
 

}
