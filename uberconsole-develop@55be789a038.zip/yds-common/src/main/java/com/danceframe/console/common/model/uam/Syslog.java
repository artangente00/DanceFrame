/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.uam;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author lmorallos
 */
public class Syslog implements Serializable {
    
    private static final long serialVersionUID = 1L;
    private int     id;
    private String  action;
    private String  moduleName;
    private String  className;
    private int     userid;
    private String  username;
    private Date    logdate;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the action
     */
    public String getAction() {
        return action;
    }

    /**
     * @param action the action to set
     */
    public void setAction(String action) {
        this.action = action;
    }

    /**
     * @return the moduleName
     */
    public String getModuleName() {
        return moduleName;
    }

    /**
     * @param moduleName the moduleName to set
     */
    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    /**
     * @return the className
     */
    public String getClassName() {
        return className;
    }

    /**
     * @param className the className to set
     */
    public void setClassName(String className) {
        this.className = className;
    }

    /**
     * @return the userid
     */
    public int getUserid() {
        return userid;
    }

    /**
     * @param userid the userid to set
     */
    public void setUserid(int userid) {
        this.userid = userid;
    }

    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return the logdate
     */
    public Date getLogdate() {
        return logdate;
    }

    /**
     * @param logdate the logdate to set
     */
    public void setLogdate(Date logdate) {
        this.logdate = logdate;
    }

    @Override
    public String toString() {
        return "Syslog{" + "id=" + id + ", action=" + action + ", moduleName=" + 
                moduleName + ", className=" + className + ", userid=" + userid +
                ", username=" + username + ", logdate=" + logdate + '}';
    }
    
    
     
}
