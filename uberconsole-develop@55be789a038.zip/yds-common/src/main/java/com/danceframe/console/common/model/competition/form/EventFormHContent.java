/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.competition.form;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class EventFormHContent implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private int id;
    private int eventFormId;
    private String horizHeader;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the eventFormId
     */
    public int getEventFormId() {
        return eventFormId;
    }

    /**
     * @param eventFormId the eventFormId to set
     */
    public void setEventFormId(int eventFormId) {
        this.eventFormId = eventFormId;
    }

    /**
     * @return the horizHeader
     */
    public String getHorizHeader() {
        return horizHeader;
    }

    /**
     * @param horizHeader the horizHeader to set
     */
    public void setHorizHeader(String horizHeader) {
        this.horizHeader = horizHeader;
    }

    @Override
    public String toString() {
        return "EventHorizContent{" + "id=" + id + ", eventFormId=" + eventFormId + ", horizHeader=" + horizHeader + '}';
    }
    
    
    
}
