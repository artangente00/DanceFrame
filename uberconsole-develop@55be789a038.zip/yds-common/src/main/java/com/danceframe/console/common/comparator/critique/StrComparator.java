/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.comparator.critique;

import java.util.Comparator;

/**
 *
 * @author lmorallos
 */
public class StrComparator implements Comparator<String>{

    @Override
    public int compare(String o1, String o2) {
        return extractInt(o1) - extractInt(o2);
    }
    
    int extractInt(String s) {
        String num = s.replaceAll("\\D", "");
        // return 0 if no digits found
        return num.isEmpty() ? 0 : Integer.parseInt(num);
    }
}
