/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.critique.xml;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

/**
 *
 * @author lmorallos
 */
@Root(name="subHeat")
public class HeatResultSubHeat implements Serializable {
    
        private static long serialVersionUID = 1L;
        
        private int subheatId;
        
        @Attribute (required=false)
        private String id;
        @Attribute (required=false)
        private String type;
        @Attribute (required=false)
        private String dance;
        @Attribute (required=false)
        private String level;
        @Attribute (required=false)
        private String age;
        private int heatId;
        private int eventId;
        

        @ElementList (required=false)
        private ArrayList<HeatResultSoloEntry> soloEntries;
        @ElementList (required=false)
        private ArrayList<HeatResultCoupleEntry> coupleEntries;
        @Element (required=false)
        private HeatResultResult result;
        
        private List<HeatResultCouple> coupleList;
        
        public HeatResultSubHeat() {}
        
        public HeatResultSubHeat(String id, String type, String dance,
                        String lvl, String age) {
            this.id = id;
            this.type = type;
            this.dance = dance;
            this.level = lvl;
            this.age=age;
        }
    /**
     * @return the subheatId
     */
    public int getSubheatId() {
        return subheatId;
    }

    /**
     * @param subheatId the subheatId to set
     */
    public void setSubheatId(int subheatId) {
        this.subheatId = subheatId;
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the dance
     */
    public String getDance() {
        return dance;
    }

    /**
     * @param dance the dance to set
     */
    public void setDance(String dance) {
        this.dance = dance;
    }

    /**
     * @return the level
     */
    public String getLevel() {
        return level;
    }

    /**
     * @param level the level to set
     */
    public void setLevel(String level) {
        this.level = level;
    }

    /**
     * @return the age
     */
    public String getAge() {
        return age;
    }

    /**
     * @param age the age to set
     */
    public void setAge(String age) {
        this.age = age;
    }

    /**
     * @return the heatId
     */
    public int getHeatId() {
        return heatId;
    }

    /**
     * @param heatId the heatId to set
     */
    public void setHeatId(int heatId) {
        this.heatId = heatId;
    }

    /**
     * @return the coupleEntries
     */
    public List<HeatResultCoupleEntry> getCoupleEntries() {
        return coupleEntries;
    }

    /**
     * @param coupleEntries the coupleEntries to set
     */
    public void setCoupleEntries(ArrayList<HeatResultCoupleEntry> coupleEntries) {
        this.coupleEntries = coupleEntries;
    }

    /**
     * @return the result
     */
    public HeatResultResult getResult() {
        return result;
    }

    /**
     * @param result the result to set
     */
    public void setResult(HeatResultResult result) {
        this.result = result;
    }

      /**
     * @return the soloEntries
     */
    public List<HeatResultSoloEntry> getSoloEntries() {
        return soloEntries;
    }

    /**
     * @param soloEntries the soloEntries to set
     */
    public void setSoloEntries(ArrayList<HeatResultSoloEntry> soloEntries) {
        this.soloEntries = soloEntries;
    }

    /**
     * @return the coupleList
     */
    public List<HeatResultCouple> getCoupleList() {
        return coupleList;
    }

    /**
     * @param coupleList the coupleList to set
     */
    public void setCoupleList(List<HeatResultCouple> coupleList) {
        this.coupleList = coupleList;
    }

    @Override
    public String toString() {
        return "HeatResultSubHeat{" + "subheatId=" + subheatId + ", id=" + id + ", type=" + type + ", dance=" + dance + ", level=" + level + ", age=" + age + ", heatId=" + heatId + ", soloEntries=" + soloEntries + ", coupleEntries=" + coupleEntries + ", result=" + result + ", coupleList=" + coupleList + '}';
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    
}
