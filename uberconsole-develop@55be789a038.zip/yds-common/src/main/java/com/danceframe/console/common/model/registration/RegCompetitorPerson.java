/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.registration;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class RegCompetitorPerson implements Serializable {
    
    private static final long serialVersionUID = 1L;
     
    private int id;
    private int competitorId;
    private String cuid;
    private int personId;
    private String puid;
    private int eventId;
    private String euid;
    private int    userId;
    private String buid;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the competitorId
     */
    public int getCompetitorId() {
        return competitorId;
    }

    /**
     * @param competitorId the competitorId to set
     */
    public void setCompetitorId(int competitorId) {
        this.competitorId = competitorId;
    }

    /**
     * @return the cuid
     */
    public String getCuid() {
        return cuid;
    }

    /**
     * @param cuid the cuid to set
     */
    public void setCuid(String cuid) {
        this.cuid = cuid;
    }

    /**
     * @return the personId
     */
    public int getPersonId() {
        return personId;
    }

    /**
     * @param personId the personId to set
     */
    public void setPersonId(int personId) {
        this.personId = personId;
    }

    /**
     * @return the puid
     */
    public String getPuid() {
        return puid;
    }

    /**
     * @param puid the puid to set
     */
    public void setPuid(String puid) {
        this.puid = puid;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the euid
     */
    public String getEuid() {
        return euid;
    }

    /**
     * @param euid the euid to set
     */
    public void setEuid(String euid) {
        this.euid = euid;
    }

    /**
     * @return the userId
     */
    public int getUserId() {
        return userId;
    }

    /**
     * @param userId the userId to set
     */
    public void setUserId(int userId) {
        this.userId = userId;
    }

    /**
     * @return the buid
     */
    public String getBuid() {
        return buid;
    }

    /**
     * @param buid the buid to set
     */
    public void setBuid(String buid) {
        this.buid = buid;
    }

    @Override
    public String toString() {
        return "RegCompetitorPerson{" + "id=" + id + ", competitorId=" + competitorId + ", cuid=" + cuid + ", personId=" + personId + ", puid=" + puid + ", eventId=" + eventId + ", euid=" + euid + ", userId=" + userId + ", buid=" + buid + '}';
    }

}
