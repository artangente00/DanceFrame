/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.heatlist;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class HeatInfo implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private int     id;
    private String  heatValue;
    private String  schedule;
    private String  description;
    private int     heatListId;

    public HeatInfo() {}
    
    public HeatInfo(String hv, String sched, String desc, int hid) {
        this.heatValue = hv;
        this.schedule = sched;
        this.description = desc;
        this.heatListId = hid;
    }
    
    public HeatInfo(int i, String hv, String sched, String desc, int hid) {
        this.id  = i;
        this.heatValue = hv;
        this.schedule = sched;
        this.description = desc;
        this.heatListId = hid;
    }
     
     
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }


    /**
     * @return the schedule
     */
    public String getSchedule() {
        return schedule;
    }

    /**
     * @param schedule the schedule to set
     */
    public void setSchedule(String schedule) {
        this.schedule = schedule;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the heatListId
     */
    public int getHeatListId() {
        return heatListId;
    }

    /**
     * @param heatListId the heatListId to set
     */
    public void setHeatListId(int heatListId) {
        this.heatListId = heatListId;
    }

    /**
     * @return the heatValue
     */
    public String getHeatValue() {
        return heatValue;
    }

    /**
     * @param heatValue the heatValue to set
     */
    public void setHeatValue(String heatValue) {
        this.heatValue = heatValue;
    }

    @Override
    public String toString() {
        return "HeatInfo{" + "id=" + id + ", heatValue=" + heatValue + ", schedule=" + schedule + ", description=" + description + ", heatListId=" + heatListId + '}';
    }

   
    
}
