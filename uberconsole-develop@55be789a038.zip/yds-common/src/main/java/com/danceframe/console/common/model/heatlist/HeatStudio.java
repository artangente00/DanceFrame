/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.heatlist;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class HeatStudio implements Serializable {
    
     private static final long serialVersionUID = 1L;
     
     private int    id;
     private String compMgrId;
     private String name;
     private int    heatListId;

     public HeatStudio() {}
     
     public HeatStudio(int i, String ci, String nm, int hid) {
         this.id = i;
         this.compMgrId = ci;
         this.name = nm;
         this.heatListId = hid;
     }
     
      public HeatStudio(String ci, String nm, int hid) {
         this.id = 0;
         this.compMgrId = ci;
         this.name = nm;
         this.heatListId = hid;
     }
     
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the compMgrId
     */
    public String getCompMgrId() {
        return compMgrId;
    }

    /**
     * @param compMgrId the compMgrId to set
     */
    public void setCompMgrId(String compMgrId) {
        this.compMgrId = compMgrId;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

  
    /**
     * @return the heatListId
     */
    public int getHeatListId() {
        return heatListId;
    }

    /**
     * @param heatListId the heatListId to set
     */
    public void setHeatListId(int heatListId) {
        this.heatListId = heatListId;
    }

    @Override
    public String toString() {
        return "HeatStudio{" + "id=" + id + ", compMgrId=" + compMgrId + ", name=" + name + ", heatListId=" + heatListId + '}';
    }
    
     
    
}
