/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.heatlist.result;

import java.io.Serializable;
import java.util.ArrayList;
import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

/**
 *
 * @author lmorallos
 */
@Root(name="heat")
public class HeatResultHeat implements Serializable {

   private int    id;
    @Attribute (required=false)
    private String name;
    @Attribute (required=false)
    private String part;
    @Attribute (required=false)
    private String session;
    @Attribute (required=false)
    private String time;
    @Attribute (required=false)
    private String date;
    @Attribute (required=false)
    private String desc;
    @Attribute (required=false)
    private String type;
    @Attribute (required=false)
    private String category;
    
    private int eventId;
    private int xmlId;
    
   
    private ArrayList<HeatResultSubHeats> subHeats;
    
    public HeatResultHeat() {} 
    
    public HeatResultHeat(String nm, String ss, String tm , String dt, String ds) {
        name = nm;
        session = ss;
        time = tm;
        date = dt;
        desc = ds;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the session
     */
    public String getSession() {
        return session;
    }

    /**
     * @param session the session to set
     */
    public void setSession(String session) {
        this.session = session;
    }

    /**
     * @return the time
     */
    public String getTime() {
        return time;
    }

    /**
     * @param time the time to set
     */
    public void setTime(String time) {
        this.time = time;
    }

    /**
     * @return the date
     */
    public String getDate() {
        return date;
    }

    /**
     * @param date the date to set
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     * @return the desc
     */
    public String getDesc() {
        return desc;
    }

    /**
     * @param desc the desc to set
     */
    public void setDesc(String desc) {
        this.desc = desc;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the xmlId
     */
    public int getXmlId() {
        return xmlId;
    }

    /**
     * @param xmlId the xmlId to set
     */
    public void setXmlId(int xmlId) {
        this.xmlId = xmlId;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the subHeats
     */
    @ElementList(inline=true, required=false)
    public ArrayList<HeatResultSubHeats> getSubHeats() {
        return subHeats;
    }

    /**
     * @param subHeats the subHeats to set
     */
    @ElementList(inline=true, required=false)
    public void setSubHeats(ArrayList<HeatResultSubHeats> subHeats) {
        this.subHeats = subHeats;
    }

    /**
     * @return the part
     */
    public String getPart() {
        return part;
    }

    /**
     * @param part the part to set
     */
    public void setPart(String part) {
        this.part = part;
    }

    /**
     * @return the category
     */
    public String getCategory() {
        return category;
    }

    /**
     * @param category the category to set
     */
    public void setCategory(String category) {
        this.category = category;
    }

    @Override
    public String toString() {
        return "HeatResultHeat{" + "id=" + id + ", name=" + name + ", part=" + part + ", session=" + session + ", time=" + time + ", date=" + date + ", desc=" + desc + ", type=" + type + ", category=" + category + ", eventId=" + eventId + ", xmlId=" + xmlId + ", subHeats=" + subHeats + '}';
    }
   
    

}
