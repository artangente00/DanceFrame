/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.heatlist.result;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

/**
 *
 * @author lmorallos
 */
@Root(name="couple")
public class HeatResultCouple implements Serializable {
    
    private static long serialVersionUID = 1L;
    
    private int     id;
    @Attribute
    private String  coupleKey;
    
    @ElementList
    private ArrayList<HeatListResultPersonKey> personKeys;
    
    private int     eventId;
    private int     xmlId;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the coupleKey
     */
    public String getCoupleKey() {
        return coupleKey;
    }

    /**
     * @param coupleKey the coupleKey to set
     */
    public void setCoupleKey(String coupleKey) {
        this.coupleKey = coupleKey;
    }

    /**
     * @return the personKeys
     */
    public List<HeatListResultPersonKey> getPersonKeys() {
        return personKeys;
    }

    /**
     * @param personKeys the personKeys to set
     */
    public void setPersonKeys(ArrayList<HeatListResultPersonKey> personKeys) {
        this.personKeys = personKeys;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the xmlId
     */
    public int getXmlId() {
        return xmlId;
    }

    /**
     * @param xmlId the xmlId to set
     */
    public void setXmlId(int xmlId) {
        this.xmlId = xmlId;
    }

    @Override
    public String toString() {
        return "HeatResultCouple{" + "id=" + id + ", coupleKey=" + coupleKey + ", personKeys=" + personKeys + ", eventId=" + eventId + ", xmlId=" + xmlId + '}';
    }

    
    
}
