/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.competition.form;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class EventFormField implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private int     id;
    private int     eventformId;
    private String  fieldName;
    private String  linkTo;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the eventformId
     */
    public int getEventformId() {
        return eventformId;
    }

    /**
     * @param eventformId the eventformId to set
     */
    public void setEventformId(int eventformId) {
        this.eventformId = eventformId;
    }

    /**
     * @return the fieldName
     */
    public String getFieldName() {
        return fieldName;
    }

    /**
     * @param fieldName the fieldName to set
     */
    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    /**
     * @return the linkTo
     */
    public String getLinkTo() {
        return linkTo;
    }

    /**
     * @param linkTo the linkTo to set
     */
    public void setLinkTo(String linkTo) {
        this.linkTo = linkTo;
    }

    @Override
    public String toString() {
        return "EventFormField{" + "id=" + id + ", eventformId=" + 
                eventformId + ", fieldName=" + fieldName + ", linkTo=" + linkTo + '}';
    }
    
    
    
}
