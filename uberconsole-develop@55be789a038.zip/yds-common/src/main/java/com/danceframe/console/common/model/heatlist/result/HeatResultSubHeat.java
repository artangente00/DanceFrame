/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.heatlist.result;

import java.io.Serializable;
import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

/**
 *
 * @author lmorallos
 */
@Root(name="subHeat")
public class HeatResultSubHeat implements Serializable {
    
        private static long serialVersionUID = 1L;
        
        private int subheatId;
        
        @Attribute (required=false)
        private String id; 
        private String type;
        
        @Attribute (required=false)
        private String dance;      
        private String level;
        
        @Attribute (required=false)
        private String age;
        
        @Attribute (required=false)
        private String order;
        
        @Attribute (required=false)
        private String scoring;
        
        private int subheatsId;
        private int eventId;

        @Element (required=false)
        private HeatResultResult result;
        
        public HeatResultSubHeat() {}
        
        public HeatResultSubHeat(String id, String type, String dance,
                        String lvl, String age) {
            this.id = id;
            this.type = type;
            this.dance = dance;
            this.level = lvl;
            this.age=age;
        }
        
         public HeatResultSubHeat(String id, String type, String dance,
                        String lvl, String age, String score) {
            this.id = id;
            this.type = type;
            this.dance = dance;
            this.level = lvl;
            this.age=age;
            this.scoring = score;
        }
         
    /**
     * @return the subheatId
     */
    public int getSubheatId() {
        return subheatId;
    }

    /**
     * @param subheatId the subheatId to set
     */
    public void setSubheatId(int subheatId) {
        this.subheatId = subheatId;
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the dance
     */
    public String getDance() {
        return dance;
    }

    /**
     * @param dance the dance to set
     */
    public void setDance(String dance) {
        this.dance = dance;
    }

    /**
     * @return the level
     */
    public String getLevel() {
        return level;
    }

    /**
     * @param level the level to set
     */
    public void setLevel(String level) {
        this.level = level;
    }

    /**
     * @return the age
     */
    public String getAge() {
        return age;
    }

    /**
     * @param age the age to set
     */
    public void setAge(String age) {
        this.age = age;
    }

    /**
     * @return the result
     */
    public HeatResultResult getResult() {
        return result;
    }

    /**
     * @param result the result to set
     */
    public void setResult(HeatResultResult result) {
        this.result = result;
    }

    /**
     * @return the eventId
     */
    public int getEventId() {
        return eventId;
    }

    /**
     * @param eventId the eventId to set
     */
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the order
     */
    public String getOrder() {
        return order;
    }

    /**
     * @param order the order to set
     */
    public void setOrder(String order) {
        this.order = order;
    }

    /**
     * @return the subheatsId
     */
    public int getSubheatsId() {
        return subheatsId;
    }

    /**
     * @param subheatsId the subheatsId to set
     */
    public void setSubheatsId(int subheatsId) {
        this.subheatsId = subheatsId;
    }

    /**
     * @return the scoring
     */
    public String getScoring() {
        return scoring;
    }

    /**
     * @param scoring the scoring to set
     */
    public void setScoring(String scoring) {
        this.scoring = scoring;
    }

    @Override
    public String toString() {
        return "HeatResultSubHeat{" + "subheatId=" + subheatId + ", id=" + id + ", type=" + type + ", dance=" + dance + ", level=" + level + ", age=" + age + ", order=" + order + ", scoring=" + scoring + ", subheatsId=" + subheatsId + ", eventId=" + eventId + ", result=" + result + '}';
    }

    
    
}
