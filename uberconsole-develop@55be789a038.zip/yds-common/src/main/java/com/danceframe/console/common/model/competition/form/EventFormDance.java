/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.competition.form;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class EventFormDance implements Serializable{
    
    private static final long serialVersionUID = 1L;
    
    private int     id;
    private int     eventformId;
    private int     horizContentId;
    private String  code;
    private String  description;
    private String  horizHeader;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * @param code the code to set
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the eventformId
     */
    public int getEventformId() {
        return eventformId;
    }

    /**
     * @param eventformId the eventformId to set
     */
    public void setEventformId(int eventformId) {
        this.eventformId = eventformId;
    }

    /**
     * @return the horizContentId
     */
    public int getHorizContentId() {
        return horizContentId;
    }

    /**
     * @param horizContentId the horizContentId to set
     */
    public void setHorizContentId(int horizContentId) {
        this.horizContentId = horizContentId;
    }
    /**
     * @return the horizHeader
     */
    public String getHorizHeader() {
        return horizHeader;
    }

    /**
     * @param horizHeader the horizHeader to set
     */
    public void setHorizHeader(String horizHeader) {
        this.horizHeader = horizHeader;
    }

    @Override
    public String toString() {
        return "EventFormDance{" + "id=" + id + ", eventformId=" + eventformId + ", horizContentId=" + horizContentId + ", code=" + code + ", description=" + description + ", horizHeader=" + horizHeader + '}';
    }
    
    
}
