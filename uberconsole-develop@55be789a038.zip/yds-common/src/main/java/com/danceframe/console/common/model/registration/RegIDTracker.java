/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.registration;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author lmorallos
 */
public class RegIDTracker implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private int     id;
    private int     regUserId;
    private String  buid;
    private String  euid;
    private String  bgId;
    private String  uid;
    private int     nodeType;
    private Date    creationDate;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the regUserId
     */
    public int getRegUserId() {
        return regUserId;
    }

    /**
     * @param regUserId the regUserId to set
     */
    public void setRegUserId(int regUserId) {
        this.regUserId = regUserId;
    }

    /**
     * @return the buid
     */
    public String getBuid() {
        return buid;
    }

    /**
     * @param buid the buid to set
     */
    public void setBuid(String buid) {
        this.buid = buid;
    }

    /**
     * @return the euid
     */
    public String getEuid() {
        return euid;
    }

    /**
     * @param euid the euid to set
     */
    public void setEuid(String euid) {
        this.euid = euid;
    }

    /**
     * @return the bgId
     */
    public String getBgId() {
        return bgId;
    }

    /**
     * @param bgId the bgId to set
     */
    public void setBgId(String bgId) {
        this.bgId = bgId;
    }

    /**
     * @return the uid
     */
    public String getUid() {
        return uid;
    }

    /**
     * @param uid the uid to set
     */
    public void setUid(String uid) {
        this.uid = uid;
    }

    /**
     * @return the nodeType
     */
    public int getNodeType() {
        return nodeType;
    }

    /**
     * @param nodeType the nodeType to set
     */
    public void setNodeType(int nodeType) {
        this.nodeType = nodeType;
    }

    /**
     * @return the creationDate
     */
    public Date getCreationDate() {
        return creationDate;
    }

    /**
     * @param creationDate the creationDate to set
     */
    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    @Override
    public String toString() {
        return "RegIDTracker{" + "id=" + id + ", regUserId=" + regUserId + ", buid=" + buid + ", euid=" + euid + ", bgId=" + bgId + ", uid=" + uid + ", nodeType=" + nodeType + ", creationDate=" + creationDate + '}';
    }
    
}
