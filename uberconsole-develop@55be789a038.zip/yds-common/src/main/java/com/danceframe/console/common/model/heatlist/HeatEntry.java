/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.common.model.heatlist;

import java.io.Serializable;

/**
 *
 * @author lmorallos
 */
public class HeatEntry implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private int     id;
    private String  entryCpmId;
    private int     personId;
    private String  personCmpId;
    private String  seqNo;
    private int     partnerId;
    private String  partnerCmpId;
    private int     studioId;
    private String  studioCmpId;
    private int     compId;
    private String  compCmpId;
    private int     heatListId;
    private String  otherinfo;

    public HeatEntry() {}
    
    public HeatEntry(int i, String ci, int pi, String pci, String sn, int pri, 
            String prmi, int si, String sri, String ot, int cmi, String ccmi, int hid) {
        this.id = i;
        this.entryCpmId = ci;
        this.personId = pi;
        this.personCmpId = pci;
        this.seqNo = sn;
        this.partnerId = pri;
        this.partnerCmpId = prmi;
        this.studioId = si;
        this.studioCmpId = sri;
        this.otherinfo = ot;
        this.compId = cmi;
        this.compCmpId = ccmi;
        this.heatListId = hid;
    }
    
    public HeatEntry(String ci,  String sn, String pci,
            String prmi, String sri, String ot, String ccmi, int hid) {
        this.entryCpmId = ci;
        this.seqNo = sn;
        this.personCmpId = pci;
        this.partnerCmpId = prmi;
        this.studioCmpId = sri;
        this.otherinfo = ot;
        this.compCmpId = ccmi;
        this.heatListId = hid;
    }
    
    
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the entryCpmId
     */
    public String getEntryCpmId() {
        return entryCpmId;
    }

    /**
     * @param entryCpmId the entryCpmId to set
     */
    public void setEntryCpmId(String entryCpmId) {
        this.entryCpmId = entryCpmId;
    }

    /**
     * @return the personId
     */
    public int getPersonId() {
        return personId;
    }

    /**
     * @param personId the personId to set
     */
    public void setPersonId(int personId) {
        this.personId = personId;
    }

    /**
     * @return the personCmpId
     */
    public String getPersonCmpId() {
        return personCmpId;
    }

    /**
     * @param personCmpId the personCmpId to set
     */
    public void setPersonCmpId(String personCmpId) {
        this.personCmpId = personCmpId;
    }

    /**
     * @return the seqNo
     */
    public String getSeqNo() {
        return seqNo;
    }

    /**
     * @param seqNo the seqNo to set
     */
    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo;
    }

    /**
     * @return the partnerId
     */
    public int getPartnerId() {
        return partnerId;
    }

    /**
     * @param partnerId the partnerId to set
     */
    public void setPartnerId(int partnerId) {
        this.partnerId = partnerId;
    }

    /**
     * @return the partnerCmpId
     */
    public String getPartnerCmpId() {
        return partnerCmpId;
    }

    /**
     * @param partnerCmpId the partnerCmpId to set
     */
    public void setPartnerCmpId(String partnerCmpId) {
        this.partnerCmpId = partnerCmpId;
    }

    /**
     * @return the studioId
     */
    public int getStudioId() {
        return studioId;
    }

    /**
     * @param studioId the studioId to set
     */
    public void setStudioId(int studioId) {
        this.studioId = studioId;
    }

    /**
     * @return the studioCmpId
     */
    public String getStudioCmpId() {
        return studioCmpId;
    }

    /**
     * @param studioCmpId the studioCmpId to set
     */
    public void setStudioCmpId(String studioCmpId) {
        this.studioCmpId = studioCmpId;
    }

    /**
     * @return the compId
     */
    public int getCompId() {
        return compId;
    }

    /**
     * @param compId the compId to set
     */
    public void setCompId(int compId) {
        this.compId = compId;
    }

    /**
     * @return the compCmpId
     */
    public String getCompCmpId() {
        return compCmpId;
    }

    /**
     * @param compCmpId the compCmpId to set
     */
    public void setCompCmpId(String compCmpId) {
        this.compCmpId = compCmpId;
    }

    /**
     * @return the heatListId
     */
    public int getHeatListId() {
        return heatListId;
    }

    /**
     * @param heatListId the heatListId to set
     */
    public void setHeatListId(int heatListId) {
        this.heatListId = heatListId;
    }

    /**
     * @return the otherinfo
     */
    public String getOtherinfo() {
        return otherinfo;
    }

    /**
     * @param otherinfo the otherinfo to set
     */
    public void setOtherinfo(String otherinfo) {
        this.otherinfo = otherinfo;
    }

    @Override
    public String toString() {
        return "HeatEntry{" + "id=" + id + ", entryCpmId=" + entryCpmId + ", personId=" + personId + ", personCmpId=" + personCmpId + ", seqNo=" + seqNo + ", partnerId=" + partnerId + ", partnerCmpId=" + partnerCmpId + ", studioId=" + studioId + ", studioCmpId=" + studioCmpId + ", compId=" + compId + ", compCmpId=" + compCmpId + ", heatListId=" + heatListId + ", otherinfo=" + otherinfo + '}';
    }
   
    
    
}
