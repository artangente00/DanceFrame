/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query.uam;

/**
 *
 * @author lmorallos
 */
public final class SyslogQuery {
    
    public final static String INSERT_QRY = "SELECT uberconsole.FN_SYSLOG_INSERT(?, ?, ?, ?, ?)";
    
    public final static String SELECT_QRY = "SELECT syslog_id, action, modname, classname, " + 
            "user_id, logdate, username FROM uberConsole.VW_SYSLOG";
    
    public final static String SELECT_COUNT_QRY = "SELECT count(*) FROM uberConsole.VW_SYSLOG";
    
    public final static String UPDATE_SYSLOGID = "SELECT uberconsole.FN_SYSLOG_TBLUPDATE(?, ?, ?, ?)";
}
