/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.file.form.impl;

import com.danceframe.console.service.file.form.SetupFileProcessor;
import com.danceframe.setupfile.service.XMLServiceCreator;

/**
 *
 * @author lmorallos
 */
public class SetupFileProcessorImpl implements SetupFileProcessor {

    private XMLServiceCreator xmlServiceCreator;
    private static final boolean DEBUG_FLAG = false;
    
    @Override
    public boolean createXMLFromSTU(String directory, String stufile, String xmlbasefile) {
        boolean retbool = false;
        xmlServiceCreator.setDebugOn(DEBUG_FLAG);
        retbool = xmlServiceCreator.create(directory, stufile, xmlbasefile);
        return retbool;
    }
    
    /**
     * @return the xmlServiceCreator
     */
    public XMLServiceCreator getXmlServiceCreator() {
        return xmlServiceCreator;
    }

    /**
     * @param xmlServiceCreator the xmlServiceCreator to set
     */
    public void setXmlServiceCreator(XMLServiceCreator xmlServiceCreator) {
        this.xmlServiceCreator = xmlServiceCreator;
    }

}
