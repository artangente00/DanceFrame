/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.critique;

import com.danceframe.console.common.model.critique.xml.HeatResultSoloEntry;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class CritiqueSoloEntryRowMapper implements RowMapper<HeatResultSoloEntry> {

    @Override
    public HeatResultSoloEntry mapRow(ResultSet rs, int i) throws SQLException {
        final HeatResultSoloEntry entry = new HeatResultSoloEntry();
        entry.setId(rs.getInt("sentry_id"));
        entry.setPersonKey(rs.getString("person_key"));
        entry.setSubHeatId(rs.getInt("subheat_id"));
        entry.setEventId(rs.getInt("event_id"));
        return entry;
    }
    
}
