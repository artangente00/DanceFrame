/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.competition.impl;

import com.danceframe.console.common.model.competition.Organizer;
import com.danceframe.console.service.dataprovider.competition.OrganizerProviderDao;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.query.competition.OrganizerQuery;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public class OrganizerProviderDaoImpl extends GenericProviderDaoImpl<Organizer> implements OrganizerProviderDao {

    @Override
    public int search(int id) {
        Object[] obj = new Object[] {id };
        int ret = (Integer)this.genericQryTemplateInteger(OrganizerQuery.SEARCHBYID_QRY, obj);
        return ret;
    }

    @Override
    public int search(String name) {
        Object[] obj = new Object[] {name };
        int ret = (Integer)this.genericQryTemplateInteger(OrganizerQuery.SEARCHBYNAME_QRY, obj);
        return ret;
    }

    @Override
    public int insert(Organizer organizer) {
        Object[] obj = new Object[] {
            organizer.getEventid(),
            organizer.getName()            
        };
        int ret = (Integer)this.genericQryTemplateInteger(OrganizerQuery.INSERT_QRY, obj);
        return ret;
    }

    @Override
    public int update(Organizer organizer) {
        Object[] obj = new Object[] {            
            organizer.getId(),
            organizer.getName()
        };
        int ret = (Integer)this.genericQryTemplateInteger(OrganizerQuery.UPDATE_QRY, obj);
        return ret;
    }

    @Override
    public int delete(int id) {
        Object[] obj = new Object[] {id };
        int ret = (Integer)this.genericQryTemplateInteger(OrganizerQuery.DELETEBYID_QRY, obj);
        return ret;
    }

    @Override
    public int delete(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Organizer get(int id) {
          Object[] obj = new Object[] { id };
        String sqlWhere = " WHERE organizer_id = ?"  ;
        String finalSQL =  OrganizerQuery.SELECT_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);    
    }

    @Override
    public Organizer get(String name) {
          Object[] obj = new Object[] { name };
        String sqlWhere = " WHERE name = ?"  ;
        String finalSQL =  OrganizerQuery.SELECT_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);    
    }

    @Override
    public List<Organizer> getAll(String wherestr) { 
        List<Organizer> orgList = new ArrayList<Organizer>();
        orgList = genericQryAllTemplateRowMapper(OrganizerQuery.SELECT_QRY, wherestr);
        return(orgList);
    }

    @Override
    public List<Organizer> getAllWithPaging(String wherestr, int pagesize, int first) { 
        List<Organizer> orgList = new ArrayList<Organizer>();
        orgList = genericQryAllTemplateRowMapperWithPaging(OrganizerQuery.SELECT_QRY, 
                wherestr,  pagesize,  first);
        return(orgList);
    }  

    @Override
    public List<Organizer> getAllByEventId(int id) {
        List<Organizer> orgList = new ArrayList<Organizer>();
        String sqlWhere = " WHERE event_id="  + Integer.toString(id) ;
        orgList = genericQryAllTemplateRowMapper(OrganizerQuery.SELECT_QRY, sqlWhere);
        return(orgList);
    }

    @Override
    public long getAllCount(String wherestr) {
        return genericQryForInt(OrganizerQuery.SELECT_COUNT_QRY, wherestr);     
    }
    
  
}
