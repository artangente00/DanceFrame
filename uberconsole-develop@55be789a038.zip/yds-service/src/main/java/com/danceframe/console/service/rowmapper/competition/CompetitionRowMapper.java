/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.competition;

import com.danceframe.console.common.model.competition.Competition;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class CompetitionRowMapper implements RowMapper<Competition> {

    @Override
    public Competition mapRow(final ResultSet rs, final int column) throws SQLException {
        final Competition competition = new Competition();
        competition.setId(rs.getInt("competition_id"));
        competition.setName(rs.getString("name"));
        return competition;
    }
    
}
