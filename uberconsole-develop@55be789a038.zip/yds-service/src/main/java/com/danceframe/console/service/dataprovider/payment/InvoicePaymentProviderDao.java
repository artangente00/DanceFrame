/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.payment;

import com.danceframe.console.common.model.invoice.InvoicePayment;
import com.danceframe.console.service.dataprovider.GenericProviderDao;

/**
 *
 * @author lmorallos
 */
public interface InvoicePaymentProviderDao extends GenericProviderDao<InvoicePayment>{
    
    InvoicePayment getInvoicePayment(String invoiceNo, String seriesNo);
    
    int setSendMail(String firebaseauth, String fiberevent, boolean sendmail);
    
}
