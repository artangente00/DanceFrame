/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.impl;

import org.springframework.jdbc.core.support.JdbcDaoSupport;
import com.danceframe.console.service.dataprovider.GenericProviderDao;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public abstract class GenericProviderDaoImpl<T> extends JdbcDaoSupport implements GenericProviderDao<T> {
     
    private static final Logger logger = LogManager.getLogger(GenericProviderDao.class);
    protected RowMapper<T> rowMapper;
    
    protected int genericQryForInt(String sql) {
       return ((int)getJdbcTemplate().queryForObject(sql, Integer.class)); 
    }
    
    protected long genericQryForInt(String sql, String wherestr) {
        String finalSQL = ((wherestr != null) || (wherestr.length() > 0 ) || (!wherestr.isEmpty()))? sql + " "  + wherestr : sql;
        logger.info(finalSQL);
        return (getJdbcTemplate().queryForObject(finalSQL, Long.class));
    }
    
    protected Object genericQryTemplateInteger(Object sql, Object[] obj) {    
        logger.info(sql);
        return( getJdbcTemplate().queryForObject((String)sql, obj, Integer.class));        
    }
    
    protected String genericQryTemplateString(Object sql, Object[] obj) {    
        logger.info(sql);
        return( getJdbcTemplate().queryForObject((String)sql, obj, String.class));        
    }
    
    protected T genericQryTemplateRowMapper(Object sql, Object[] obj) {
        logger.info(sql);
        return((T)getJdbcTemplate().queryForObject((String)sql, obj, rowMapper));        
    }
    
    protected List<T> genericQryAllTemplateRowMapper(Object sql, Object[] obj) {
         logger.info(sql);
        return((List<T>)getJdbcTemplate().query((String)sql, obj, rowMapper));        
    }
    
    protected List<T> genericQryAllTemplateRowMapper(String sql, String wherestr) {    
        String finalSQL = ((wherestr != null) || (wherestr.length() > 0 ) || (!wherestr.isEmpty()))? sql + " "  + wherestr : sql;
        logger.info(finalSQL);
        return((List<T>)getJdbcTemplate().query(finalSQL, rowMapper));        
    }
    
    protected List<T> genericQryAllTemplateRowMapperWithPaging(String sql, String wherestr, int pagesize, int first) {
        // int actpagenum = pagesize * pagenumber; 
        String limit = " LIMIT " + Integer.toString(pagesize);
        String offset = " OFFSET " + Integer.toString(first);       
        String finalSQL = ((wherestr != null) || (wherestr.length() > 0 ) || (!wherestr.isEmpty()))? sql + " "  + wherestr : sql;        
        String strSQL = finalSQL  + limit + offset;
        logger.info(strSQL);
        return((List<T>)getJdbcTemplate().query(strSQL, rowMapper));        
    }
    
    protected List<String> genericQryForList(String sql, Object[] obj) {
       logger.info(sql);
       return ((List<String>)getJdbcTemplate().queryForList(sql, obj, String.class)); 
    }
    
    /**
     * @return the rowMapper
     */
    public RowMapper<T> getRowMapper() {
        return rowMapper;
    }

    /**
     * @param rowMapper the rowMapper to set
     */
    public void setRowMapper(RowMapper<T> rowMapper) {
        this.rowMapper = rowMapper;
    }
    
}
