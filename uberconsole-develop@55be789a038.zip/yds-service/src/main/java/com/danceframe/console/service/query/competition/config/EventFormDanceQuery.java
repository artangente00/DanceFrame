/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query.competition.config;

/**
 *
 * @author lmorallos
 */
public final class EventFormDanceQuery {
    
    public final static String INSERT_QRY = "SELECT uberconsole.FN_EVENTFORM_DANCE_INSERT(?, ?, ?, ?)";
    
    public final static String DELETE_QRY = "SELECT uberconsole.FN_EVENTFORM_DANCE_DELETE(?, ?, ?)";
    
    public final static String DELETEBYID_QRY = "SELECT uberconsole.FN_EVENTFORM_DANCE_DELETEBYID(?)";
    
    public final static String SELECT_QRY = "SELECT eventdance_id, hcontent_id ,eventform_id," +
	"code,description,horizheader FROM uberconsole.VW_EVENT_CONFIGDANCE";
    
    public final static String SELECT_COUNT_QRY = "SELECT COUNT(eventdance_id) FROM uberconsole.tbl_eventform_dance";

}
