/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.payment.impl;

import com.danceframe.console.common.model.invoice.InvoicePayment;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.dataprovider.payment.InvoicePaymentProviderDao;
import com.danceframe.console.service.query.payment.InvoicePaymentQuery;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public class InvoicePaymentProviderDaoImpl extends GenericProviderDaoImpl<InvoicePayment> implements InvoicePaymentProviderDao {
  
    @Override
    public int search(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int search(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int insert(InvoicePayment invpay) {
        Object[] obj = new Object[] {
            invpay.getFirebaseAuthId(),
            invpay.getFirebaseEventId(),
            invpay.getEventId(),
            invpay.getInvoiceNo(),
            invpay.getSeriesNo(),
            BigDecimal.valueOf(invpay.getInvoiceAmount()),
            BigDecimal.valueOf(invpay.getReceivedAmount()),
            BigDecimal.valueOf(invpay.getBalance()),
            invpay.getMailInvoiceId()
         };
        int ret = (Integer)this.genericQryTemplateInteger(InvoicePaymentQuery.INSERT_INVPAYMENT, obj);
        return ret;
    }

    @Override
    public int update(InvoicePayment invpay) {
         Object[] obj = new Object[] {
            invpay.getFirebaseAuthId(),
            invpay.getFirebaseEventId(),
            invpay.getEventId(),
            invpay.getInvoiceNo(),
            invpay.getSeriesNo(),
            BigDecimal.valueOf(invpay.getInvoiceAmount()),
            BigDecimal.valueOf(invpay.getReceivedAmount()),
            BigDecimal.valueOf(invpay.getBalance()),
            invpay.getMailInvoiceId()
         };
         int ret = (Integer)this.genericQryTemplateInteger(InvoicePaymentQuery.UPDATE_INVPAYMENT, obj);
        return ret;
    }

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public InvoicePayment get(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public InvoicePayment get(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<InvoicePayment> getAll(String wherestr) {
        List<InvoicePayment> invPayList = new ArrayList<InvoicePayment>();
        invPayList = genericQryAllTemplateRowMapper(InvoicePaymentQuery.SELECT_INVPAYMENT, wherestr); 
        return(invPayList);
    }

    @Override
    public List<InvoicePayment> getAllWithPaging(String wherestr, int pagesize, int first) {
        List<InvoicePayment> invPayList = new ArrayList<InvoicePayment>();
        invPayList = genericQryAllTemplateRowMapperWithPaging(InvoicePaymentQuery.SELECT_INVPAYMENT, wherestr,  pagesize,  first); 
        return(invPayList);
    }

    @Override
    public long getAllCount(String wherestr) {
        return genericQryForInt(InvoicePaymentQuery.COUNT_INVPAYMENT_COUNT, wherestr);
    }

     
    @Override
    public InvoicePayment getInvoicePayment(String invoiceNo, String seriesNo) {
         Object[] obj = new Object[] {
            invoiceNo,
            seriesNo
         };
        String finSQl = InvoicePaymentQuery.INSERT_INVPAYMENT + " WHERE invoice_no=? AND series_no=?";
        return genericQryTemplateRowMapper(finSQl, obj); 
    }

    @Override
    public int setSendMail(String firebaseauth, String fiberevent, boolean sendmail) {
         Object[] obj = new Object[] {
            firebaseauth,
            fiberevent,
            sendmail
         };
         int ret = (Integer)this.genericQryTemplateInteger(InvoicePaymentQuery.UPDATE_SENDMAIL, obj);
        return ret;
    }

}
