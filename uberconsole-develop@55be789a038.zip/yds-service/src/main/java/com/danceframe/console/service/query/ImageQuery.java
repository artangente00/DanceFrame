/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query;

/**
 *
 * @author lmorallos
 */
public final class ImageQuery {
    
    public static final String INSERT_EVENT_IMAGE_QRY = "INSERT INTO  uberconsole.tbl_imgdata(code, image_id, code_id, filename, mimetype, image) " + 
            "VALUES (?, ?, ?, ?, ?, ?);";
    
    public static final String INSERT_TMPIMAGE_QRY = "INSERT INTO  uberconsole.tbl_tmpimgdata(code, image_id, code_id, filename, mimetype, image) " + 
            "VALUES (?, ?, ?, ?, ?, ?);";
     
     public static final String UPDATE_TMPIMAGE_QRY = "UPDATE uberconsole.tbl_tmpimgdata "
            + "SET filename = ?, mimetype = ?, image = ? WHERE image_id=?";
     
    public static final String UPDATE_IMAGE_QRY = "UPDATE uberconsole.tbl_imgdata "
            + "SET filename = ?, mimetype = ?, image = ? WHERE image_id=?";
    
    public static final String SELECT_IMAGEID_QRY = "SELECT nextval('uberconsole.seq_imgdata')";
    
    public static final String SELECT_IMAGEDATA_QRY = "SELECT image FROM uberconsole.tbl_imgdata WHERE image_id=?";

    public static final String SELECT_IMAGE_QRY = "SELECT image_id, filename, mimetype,code, code_id, image FROM uberconsole.tbl_imgdata WHERE image_id=?";

    public static final String SELECT_IMAGELIST_BYEVENTID  = "SELECT imageid FROM uberconsole.FN_EVENT_GETALL_IMAGEID( ? )";
    
    
}
