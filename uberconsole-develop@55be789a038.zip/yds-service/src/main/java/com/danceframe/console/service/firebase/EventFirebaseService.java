/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.firebase;

import com.danceframe.console.common.model.competition.Event;
import java.util.List;
import java.util.Map;

/**
 *
 * @author lmorallos
 */
public interface EventFirebaseService {
    
    List<Map<String, Object>> getAllEventPublishInProgress();
    
    List<Map<String, Object>> getAllEventUnPublishInProgress();
    
    List<Map<String, Object>> getAllEventRePublishInProgress();
    
    List<Map<String, Object>> getAllEventCommitInProgress();
      
    List<Event> getAllEventPublished();

}
