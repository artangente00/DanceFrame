/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.people;

import com.danceframe.console.common.model.people.People;
import com.danceframe.console.service.dataprovider.GenericProviderDao;

/**
 *
 * @author nbonita
 */
public interface PeopleProviderDao extends GenericProviderDao<People>{   
    
}
