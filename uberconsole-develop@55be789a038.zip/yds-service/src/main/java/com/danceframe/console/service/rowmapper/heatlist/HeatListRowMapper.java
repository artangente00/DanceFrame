/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.heatlist;

import com.danceframe.console.common.model.heatlist.HeatListEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class HeatListRowMapper implements RowMapper<HeatListEvent>{

    @Override
    public HeatListEvent mapRow(ResultSet rs, int columns) throws SQLException {
        final HeatListEvent heatlistEvent = new HeatListEvent();
        heatlistEvent.setId(rs.getInt("heatlist_id"));
        heatlistEvent.setEventId(rs.getInt("event_id"));
        heatlistEvent.setDescription(rs.getString("description"));
        heatlistEvent.setFilename(rs.getString("filename"));
        heatlistEvent.setCompDate(rs.getDate("comp_date"));
        heatlistEvent.setStuFileName(rs.getString("stufilename"));
        heatlistEvent.setAsof(rs.getTimestamp("heatasof"));
        heatlistEvent.setEventName(rs.getString("event_name"));
        heatlistEvent.setEventYear(rs.getInt("event_year"));
        heatlistEvent.setDateStart(rs.getDate("date_start"));
        heatlistEvent.setDateStop(rs.getDate("date_stop"));
        heatlistEvent.setPubstatus(rs.getInt("pubstatus"));
        heatlistEvent.setEuid(rs.getString("uid"));
        heatlistEvent.setCompetitionName(rs.getString("competition_name"));
        heatlistEvent.setPublishedStatus(rs.getString("publish_status"));
        return heatlistEvent;
    }   
}

       