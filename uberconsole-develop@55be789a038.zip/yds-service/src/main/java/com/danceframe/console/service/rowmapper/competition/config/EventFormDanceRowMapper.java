/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.competition.config;

import com.danceframe.console.common.model.competition.form.EventFormDance;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class EventFormDanceRowMapper implements RowMapper<EventFormDance>{

    @Override
    public EventFormDance mapRow(ResultSet rs, int column) throws SQLException {
        EventFormDance formdance = new EventFormDance();
        formdance.setId(rs.getInt("eventdance_id"));
        formdance.setHorizContentId(rs.getInt("hcontent_id"));
        formdance.setEventformId(rs.getInt("eventform_id"));
        formdance.setCode(rs.getString("code"));
        formdance.setDescription(rs.getString("description"));
        formdance.setHorizHeader(rs.getString("horizheader"));
        return formdance;
    }
    
}
