/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.heatlist.result;

import com.danceframe.console.common.model.heatlist.result.HeatResultHeatEntry;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class HeatResultHeatEntryRowMapper implements RowMapper<HeatResultHeatEntry> {

    @Override
    public HeatResultHeatEntry mapRow(ResultSet rs, int i) throws SQLException {
        final HeatResultHeatEntry entry = new HeatResultHeatEntry();
        entry.setEventId(rs.getInt("event_id"));
        entry.setHeatId(rs.getInt("heat_id"));
        entry.setPersonKey1(rs.getString("person1_key"));
        entry.setPersonKey2(rs.getString("person2_key"));
        entry.setCoupleKey(rs.getString("couple_key"));
        entry.setHeatName(rs.getString("heat_name"));
        entry.setHeatDesc(rs.getString("description"));
        entry.setFirstName1(rs.getString("firstname1"));
        entry.setLastName1(rs.getString("lastname1"));
        entry.setCompetitorNumber(rs.getString("competitor_num"));
        entry.setFirstName2(rs.getString("firstname2"));
        entry.setLastName2(rs.getString("lastname2"));
        return entry;
    }
    
}
