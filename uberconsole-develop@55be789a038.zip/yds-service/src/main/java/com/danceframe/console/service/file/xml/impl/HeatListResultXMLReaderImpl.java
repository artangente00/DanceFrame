/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.file.xml.impl;

import com.danceframe.console.common.exception.YDSException;
import com.danceframe.console.common.model.heatlist.result.HeatListResultPersonKey;
import com.danceframe.console.common.model.heatlist.result.HeatResultCompetitor;
import com.danceframe.console.common.model.heatlist.result.HeatResultHeat;
import com.danceframe.console.common.model.heatlist.result.HeatResultJudge;
import com.danceframe.console.common.model.heatlist.result.HeatResultMark;
import com.danceframe.console.common.model.heatlist.result.HeatResultPerson;
import com.danceframe.console.common.model.heatlist.result.HeatResultProgram;
import com.danceframe.console.common.model.heatlist.result.HeatResultResult;
import com.danceframe.console.common.model.heatlist.result.HeatResultStudio;
import com.danceframe.console.common.model.heatlist.result.HeatResultSubHeat;
import com.danceframe.console.common.model.heatlist.result.HeatResultSubHeats;
import com.danceframe.console.common.model.heatlist.result.HeatlistResultXML;
import com.danceframe.console.service.dataprovider.heatlist.HeatListResultProviderDao;
import com.danceframe.console.service.dataprovider.impl.BaseJdbcDaoImpl;
import com.danceframe.console.service.file.xml.HeatListResultXMLReader;
import com.danceframe.heatlist.common.util.Utility;
import com.danceframe.heatlist.service.compmgr.HeatListBaseReader;
import java.util.ArrayList;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.simpleframework.xml.Serializer;
import org.simpleframework.xml.core.Persister;

/**
 *
 * @author lmorallos
 */
public class HeatListResultXMLReaderImpl extends BaseJdbcDaoImpl implements HeatListResultXMLReader {

    private static final Logger logger = LogManager.getLogger(HeatListResultXMLReaderImpl.class);
    private HeatListResultProviderDao heatListResultProviderDao;
    private HeatListBaseReader heatListBaseReaderType4;
    private HeatListBaseReader heatListBaseReaderType5;
    
    @Override
    public HeatResultProgram xmlToProgramObject(HeatlistResultXML resultXML) throws YDSException{
        HeatResultProgram program = null;
        if (resultXML.getData().length > 0) {
            program = new HeatResultProgram();
            try {
                Serializer serializer = new Persister();
                program = serializer.read(HeatResultProgram.class,
                        resultXML.getByteAsInputStream());

                int eventId = resultXML.getEventId();
                int xmlId = resultXML.getId();
                program.setEventId(eventId);
                program.setXmlId(xmlId);
                
                if (program.getStudios() != null) {
                    for (int i = 0; i < program.getStudios().size(); i++) {
                        program.getStudios().get(i).setEventId(eventId);
                        program.getStudios().get(i).setXmlId(xmlId);
//                        logger.info(program.getJudges().get(i).toString());
                    }
                }
                if (program.getJudges() != null) {
                    for (int i = 0; i < program.getJudges().size(); i++) {
                        program.getJudges().get(i).setEventId(eventId);
                        program.getJudges().get(i).setXmlId(xmlId);
//                        logger.info(program.getJudges().get(i).toString());
                    }
                }
                
                if (program.getPersons() != null) {
                    for (int i = 0; i < program.getPersons().size(); i++) {
                        program.getPersons().get(i).setEventId(eventId);
                        program.getPersons().get(i).setXmlId(xmlId);
//                        logger.info(program.getPersons().get(i).toString());
                    }
                }
                
                 if (program.getCompetitors() != null) {
                    for (int i = 0; i < program.getCompetitors().size(); i++) {
                        program.getCompetitors().get(i).setEventId(eventId);
                        program.getCompetitors().get(i).setXmlId(xmlId);
//                        logger.info(program.getPersons().get(i).toString());
                    }
                }
                
                if (program.getHeats() != null) {
                    for (int i = 0; i < program.getHeats().size(); i++) {
                        program.getHeats().get(i).setEventId(eventId);
                        program.getHeats().get(i).setXmlId(xmlId);
//                        logger.info(program.getHeats().get(i).toString());
                    }
                  }
            } catch (Exception ex) {
                logger.warn(ex.getMessage());
                throw new YDSException(ex);
            }
        }
        return program;
    }

    @Override
    public boolean objectToDatabase(HeatResultProgram program) throws YDSException {
        boolean retbool = true;
        int eventId = program.getEventId();
        int xmlId = program.getXmlId();
        try {
            boolean cleared = (heatListResultProviderDao.clearByEventId(eventId) > 0)?true:false;
            int i = 0;
            if (cleared) {
                heatListResultProviderDao.insertProgram(program);
                if (program.getStudios() != null) {
                    i = 0;
                    for (HeatResultStudio studio:program.getStudios()) {
                        heatListResultProviderDao.insertStudio(studio);
                        i++;
                    }
                    logger.info("Studios: event Id:" + eventId + " record inserted:"  + i);
                }
                if (program.getJudges() != null) {
                    i = 0;
                    for (HeatResultJudge judge:program.getJudges()) {
                        heatListResultProviderDao.insertJudge(judge);
                        i++;
                    }
                    logger.info("Judges: event Id:" + eventId + " record inserted:"  + i);
                }
                if (program.getPersons() != null) {
                    i = 0;
                    for (HeatResultPerson person:program.getPersons()) {
                        heatListResultProviderDao.insertPerson(person);
                        i++;
                    }
                    logger.info("Persons: event Id:" + eventId + " record inserted:"  + i);
                }
                
                if (program.getCompetitors() != null) {
                    i = 0;
                    for (HeatResultCompetitor competitor:program.getCompetitors()) {
                        int comp_id = heatListResultProviderDao.insertCompetitor(competitor);
                        if (comp_id > 0) {
                            List<HeatListResultPersonKey> personKeys = competitor.getPersonKeys();
                            if (personKeys != null) {
                                if (personKeys.size() > 0) {
                                    for (HeatListResultPersonKey personKey:personKeys) {
                                        personKey.setXmlId(xmlId);
                                        personKey.setEventId(eventId);
                                        personKey.setCompetitorId(comp_id);
                                        int id = heatListResultProviderDao.insertPersonKey(personKey);
                                    }
                                }
                            }        
                        }
                        i++;
                    }
                    logger.info("Competitors: event Id:" + eventId + " record inserted:"  + i);
                }
          
                if (program.getHeats() != null) {
                    i = 0;
                    for (HeatResultHeat heat:program.getHeats()) {
                        int heatId = heatListResultProviderDao.insertHeat(heat);  
//                        logger.info("Heat ID:" + heatId);
                        i++;                    
                        if (heatId > 0) {
                           if (heat.getSubHeats() != null) {
                                for (HeatResultSubHeats subheats:heat.getSubHeats()) {
                                    subheats.setHeatId(heatId);
                                    subheats.setEventId(eventId);
                                    int subheatsId = heatListResultProviderDao.insertSubHeats(subheats);
//                                    logger.info("SubHeats ID:" + subheatsId);
                                    if (subheatsId > 0) {
                                        for (HeatResultSubHeat subheat:subheats.getSubHeat()) {
                                            subheat.setEventId(eventId);
                                            subheat.setSubheatsId(subheatsId);
                                            int subHeatId = heatListResultProviderDao.insertSubHeat(subheat); 
//                                            logger.info("SubHeat ID:" + subHeatId);
                                            if (subHeatId > 0) {
                                                HeatResultResult result = subheat.getResult();
                                                if (result != null) {
                                                   result.setSubHeatId(subHeatId);
                                                   result.setEventId(eventId);
                                                   int resultId = heatListResultProviderDao.insertResult(result);
                                                   if (result.getMarks() != null)  {
                                                       for (HeatResultMark mark:result.getMarks()) {
                                                           mark.setResultId(resultId);
                                                           mark.setSubHeatId(subHeatId);
                                                           mark.setEventId(eventId);
                                                           mark.setKey(mark.getKey());
                                                           mark.setValue(mark.getValue());
                                                           heatListResultProviderDao.insertMark(mark);
                                                       }
                                                   }                               
                                                }
                                            }
                                        }
                                    }
                                } 
                           }
                        }                                      
                    }
                    logger.info("Heats: event Id:" + eventId + " record inserted:"  + i);
                 }
            } else {
                retbool = false;
            }
        } catch (Exception ex) {
            retbool = false;
            logger.warn(ex.getMessage());
            throw new YDSException(ex);
        }
        return retbool;
    }

    @Override
    public boolean createXMLonUberHeatT4(String tmpLocation, String htmFilename, String datFilename, String xmlFilename) {
        boolean retbool = false;
        logger.info("tmp:" + tmpLocation + " HTML File: " + htmFilename + " DAT File: " + datFilename +  "XML File: " + xmlFilename);
        String logFile = tmpLocation + Utility.getFilename(htmFilename) + ".log";
        String errFile = tmpLocation + "HeatresultError.log";
        logger.info("Log File: " + logFile + "Error File: " + errFile);
        
        String htmFullpath = tmpLocation + htmFilename;
        String datFullpath = tmpLocation + datFilename;
        String xmlFullpath = tmpLocation + xmlFilename;
        logger.info("HTML Fullpath: " + htmFullpath + " DAT Fullpath: " + datFullpath +  "XML Fullpath: " + xmlFullpath);
        
        List<String> fileList = new ArrayList<String>();
        fileList.add(htmFullpath);
        fileList.add(datFullpath);
        fileList.add(logFile);
        fileList.add(errFile);
        logger.info("Using Parser Type (4): CompMgr HTML and DAT Files");
        heatListBaseReaderType4.setFileList(fileList);
        heatListBaseReaderType4.setNoStatistics(false);
        heatListBaseReaderType4.setQuite(true);
        heatListBaseReaderType4.setDebug(false);
        int errcnt = heatListBaseReaderType4.fileToXML(htmFullpath, xmlFullpath, false);
        if (errcnt > 0) {
            logger.info("Error found, please check error log.");
        } else {
            retbool = true;
        }
        return retbool;
    }
    
    @Override
    public boolean createXMLonUberHeatT5(String tmpLocation, String htlFilename, String scrFilename, String xmlFilename) {
        boolean retbool = false;
        logger.info("tmp:" + tmpLocation + " HTL File: " + htlFilename + " SCR File: " + scrFilename +  "XML File: " + xmlFilename);
        String logFile = tmpLocation + Utility.getFilename(htlFilename) + ".log";
        String errFile = tmpLocation + "HeatresultError.log";
        logger.info("Log File: " + logFile + "Error File: " + errFile);
        
        String htlFullpath = tmpLocation + htlFilename;
        String scrFullpath = tmpLocation + scrFilename;
        String xmlFullpath = tmpLocation + xmlFilename;
        logger.info("HTL Fullpath: " + htlFullpath + " SCR Fullpath: " + scrFullpath +  "XML Fullpath: " + xmlFullpath);
        
        List<String> fileList = new ArrayList<String>();
        fileList.add(htlFullpath);
        fileList.add(scrFullpath);
        fileList.add(logFile);
        fileList.add(errFile);
        logger.info("Using Parser Type (5): CompMgr HTL and SCR Files");
        heatListBaseReaderType5.setFileList(fileList);
        heatListBaseReaderType5.setNoStatistics(false);
        heatListBaseReaderType5.setQuite(true);
        heatListBaseReaderType5.setDebug(false);
        int errcnt = heatListBaseReaderType5.fileToXML(htlFullpath, xmlFullpath, false);
        if (errcnt > 0) {
            logger.info("Error found, please check error log.");
        } else {
            retbool = true;
        }
        return retbool;
    }
    
    /**
     * @return the heatListResultProviderDao
     */
    public HeatListResultProviderDao getHeatListResultProviderDao() {
        return heatListResultProviderDao;
    }

    /**
     * @param heatListResultProviderDao the heatListResultProviderDao to set
     */
    public void setHeatListResultProviderDao(HeatListResultProviderDao heatListResultProviderDao) {
        this.heatListResultProviderDao = heatListResultProviderDao;
    }

    /**
     * @return the heatListBaseReaderType4
     */
    public HeatListBaseReader getHeatListBaseReaderType4() {
        return heatListBaseReaderType4;
    }

    /**
     * @param heatListBaseReaderType4 the heatListBaseReaderType4 to set
     */
    public void setHeatListBaseReaderType4(HeatListBaseReader heatListBaseReaderType4) {
        this.heatListBaseReaderType4 = heatListBaseReaderType4;
    }

    /**
     * @return the heatListBaseReaderType5
     */
    public HeatListBaseReader getHeatListBaseReaderType5() {
        return heatListBaseReaderType5;
    }

    /**
     * @param heatListBaseReaderType5 the heatListBaseReaderType5 to set
     */
    public void setHeatListBaseReaderType5(HeatListBaseReader heatListBaseReaderType5) {
        this.heatListBaseReaderType5 = heatListBaseReaderType5;
    }
    
    
    
}
