/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query.competition;

/**
 *
 * @author lmorallos
 */
public final class DisplayDefaultQuery {
    
     public static final String SELECT_DISPLAYDEFAULT_QRY = "SELECT uregdisplay_id,event_display,venue_display,contact_display," +
"                        organizer_display,schedule_display,hotel_display,sponsor_display,info_display,finance_display,event_id FROM uberconsole.tbl_displayureg";
    
    public static final String INSERT_DISPLAYDEFAULT_QRY = "SELECT uberconsole.FN_UREGDISPLAY_INSERT(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    public static final String UPDATE_DISPLAYDEFAULT_QRY = "SELECT uberconsole.FN_UREGDISPLAY_UPDATE(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
}
