/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.competition;

import com.danceframe.console.common.model.competition.ScheduleData;
import com.danceframe.console.service.dataprovider.GenericProviderDao;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public interface ScheduleDataProviderDao extends GenericProviderDao<ScheduleData> {
    
    int getTmpEventId();
    
    int deleteTmpDataByID(int eventId);
       
    List<String> getHeaderNames(int eventId);
    
    int getLastHeaderOrder(int eventId);
    
    int getLastTimeValueOrder(String headerName, int eventId);
    
    int getHeaderOrder(String headerName, int eventId);
    
    int movetoTemporary(int eventId);
    
    List<ScheduleData> getAllData(String wherestr);
       
}
