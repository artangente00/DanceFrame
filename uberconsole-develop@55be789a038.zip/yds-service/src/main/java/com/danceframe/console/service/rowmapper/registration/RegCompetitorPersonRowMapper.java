/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.registration;

import com.danceframe.console.common.model.registration.RegCompetitorPerson;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class RegCompetitorPersonRowMapper implements RowMapper<RegCompetitorPerson> {

    @Override
    public RegCompetitorPerson mapRow(ResultSet rs, int i) throws SQLException {
        final RegCompetitorPerson compPerson = new RegCompetitorPerson();
        compPerson.setId(rs.getInt("regcompperson_id"));
        compPerson.setCompetitorId(rs.getInt("regcompetitor_id"));
        compPerson.setCuid(rs.getString("cuid"));
        compPerson.setPersonId(rs.getInt("regperson_id"));
        compPerson.setPuid(rs.getString("puid"));
        compPerson.setEventId(rs.getInt("event_id"));
        compPerson.setEuid(rs.getString("euid"));
        compPerson.setUserId(rs.getInt("reguser_id"));
        compPerson.setBuid(rs.getString("buid"));
        return compPerson;
    }
    
}
