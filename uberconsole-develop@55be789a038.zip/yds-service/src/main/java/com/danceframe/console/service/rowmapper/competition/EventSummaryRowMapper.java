/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.competition;

import com.danceframe.console.common.model.competition.EventSummary;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class EventSummaryRowMapper implements RowMapper<EventSummary> {

    @Override
    public EventSummary mapRow(ResultSet rs, int columns) throws SQLException {
        EventSummary eventsum = new EventSummary();
        eventsum.setFuturePublished(rs.getInt("futurepubcnt"));
        eventsum.setFutureUnPublished(rs.getInt("futureunpubcnt"));
        eventsum.setRemainLastYear(rs.getInt("remlastyrcnt"));
        eventsum.setUniqueEvents(rs.getInt("uniqeventcnt"));
        return eventsum;
    }
    
}
