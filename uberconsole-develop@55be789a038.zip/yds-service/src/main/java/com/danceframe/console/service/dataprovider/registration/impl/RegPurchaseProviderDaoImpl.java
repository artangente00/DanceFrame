/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.registration.impl;

import com.danceframe.console.common.model.registration.RegPurchase;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.dataprovider.registration.RegPurchaseProviderDao;
import com.danceframe.console.service.query.RegistrationQuery;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public class RegPurchaseProviderDaoImpl extends GenericProviderDaoImpl<RegPurchase> implements RegPurchaseProviderDao {

    @Override
    public int search(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int search(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int insert(RegPurchase purchase) {
        Object[] obj = new Object[] { 
            purchase.getBuid(),
            purchase.getEuid(),
            purchase.getCode(),
            purchase.getType(),
            purchase.getItemCode(),
            purchase.getItemCount()           
        };
        int ret = (Integer)this.genericQryTemplateInteger(RegistrationQuery.INSERT_REGPURCHASE_QRY, obj);
        return ret;
    }

    @Override
    public int update(RegPurchase purchase) {
          Object[] obj = new Object[] { 
            purchase.getId(),
            purchase.getCode(),
            purchase.getType(),
            purchase.getItemCode(),
            purchase.getItemCount()
        };
        int ret = (Integer)this.genericQryTemplateInteger(RegistrationQuery.UPDATE_REGPURCHASE_QRY, obj);
        return ret;
    }

    @Override
    public int delete(int id) {
        Object[] obj = new Object[] { id };
        int ret = (Integer)this.genericQryTemplateInteger(RegistrationQuery.DELETE_REGPURCHASE_QRY, obj);
        return ret;
    }

    @Override
    public int delete(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public RegPurchase get(int id) {
        Object[] obj = new Object[] { id };
        String sqlWhere = " WHERE purchase_id = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGPURCHASE_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);  
    }

    @Override
    public RegPurchase get(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RegPurchase> getAll(String wherestr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RegPurchase> getAllWithPaging(String wherestr, int pagesize, int pagenumber) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public long getAllCount(String wherestr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public RegPurchase get(int purchaseId, String euid) {
        Object[] obj = new Object[] { purchaseId, euid };
        String sqlWhere = " WHERE purchase_id = ? AND euid = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGPURCHASE_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);   
    }

    @Override
    public List<RegPurchase> getPurchaseByEventUID(String euid) {
        List<RegPurchase> purchaseList = new ArrayList<>();
        Object[] obj = new Object[] { euid };
        String sqlWhere = " WHERE euid = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGPURCHASE_QRY + sqlWhere;
        purchaseList =  genericQryAllTemplateRowMapper(finalSQL, obj);
        return purchaseList;  
    }

    @Override
    public List<RegPurchase> getPurchaseByEvent(String buid, String euid) {
        List<RegPurchase> purchaseList = new ArrayList<>();
        Object[] obj = new Object[] { euid };
        String sqlWhere = " WHERE buid=? AND euid = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGPURCHASE_QRY + sqlWhere;
        purchaseList =  genericQryAllTemplateRowMapper(finalSQL, obj);
        return purchaseList; 
    }
    
}
