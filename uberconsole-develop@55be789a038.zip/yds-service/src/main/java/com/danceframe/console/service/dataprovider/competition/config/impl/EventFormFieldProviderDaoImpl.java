/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.competition.config.impl;

import com.danceframe.console.common.model.competition.form.EventFormField;
import com.danceframe.console.service.dataprovider.competition.config.EventFormFieldProviderDao;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.query.competition.config.EventFormFieldQuery;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public class EventFormFieldProviderDaoImpl extends GenericProviderDaoImpl<EventFormField> 
                implements EventFormFieldProviderDao {

    @Override
    public int insert(EventFormField eventfield) {
        Object[] obj = new Object[] {
            eventfield.getEventformId(),
            eventfield.getFieldName(),
            eventfield.getLinkTo()
        };
        int ret = (Integer)this.genericQryTemplateInteger(EventFormFieldQuery.INSERT_QRY, obj);
        return ret;
    }
    
    @Override
    public int search(int id) {
        Object[] obj = new Object[] { id };
        int ret = (Integer)this.genericQryTemplateInteger(EventFormFieldQuery.SEARCH_QRY, obj);
        return ret;
    }

    @Override
    public List<EventFormField> getAll(String wherestr) {
        List<EventFormField> eventfieldList = new ArrayList<EventFormField>();
        eventfieldList = genericQryAllTemplateRowMapper(EventFormFieldQuery.SELECT_QRY, wherestr); 
        return(eventfieldList);
    }

    @Override
    public List<EventFormField> getAllWithPaging(String wherestr, int pagesize, int first) {
         List<EventFormField> eventfieldList = new ArrayList<EventFormField>();
        eventfieldList = genericQryAllTemplateRowMapperWithPaging(EventFormFieldQuery.SELECT_QRY, wherestr, pagesize,  first); 
        return(eventfieldList);
    }

    @Override
    public long getAllCount(String wherestr) {
       return genericQryForInt(EventFormFieldQuery.SELECT_COUNT_QRY, wherestr);  
    }
    
    @Override
    public int search(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int update(EventFormField t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public EventFormField get(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public EventFormField get(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    
}
