/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.critique;

import com.danceframe.console.common.model.critique.xml.HeatResultMark;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class CritiqueMarkRowMapper implements RowMapper<HeatResultMark> {

    @Override
    public HeatResultMark mapRow(ResultSet rs, int i) throws SQLException {
        final HeatResultMark mark = new HeatResultMark();
        mark.setId(rs.getInt("mark_id"));
        mark.setCoupleKey(rs.getString("couple_key"));
        mark.setCoupleValue(rs.getString("couple_value"));
        mark.setCoupleId(rs.getInt("couple_id"));
        mark.setResultId(rs.getInt("result_id"));
        mark.setSubHeatId(rs.getInt("subheat_id"));
        return mark;
    }
    
}
