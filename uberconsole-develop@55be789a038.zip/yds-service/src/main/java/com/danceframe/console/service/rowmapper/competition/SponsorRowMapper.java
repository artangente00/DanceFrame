/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.competition;

import com.danceframe.console.common.model.competition.Sponsor;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class SponsorRowMapper implements RowMapper<Sponsor> {

    @Override
    public Sponsor mapRow(ResultSet rs, int column) throws SQLException {
        Sponsor sponsor = new Sponsor();
        sponsor.setId(rs.getInt("information_id"));
        sponsor.setUrl(rs.getString("url"));
        sponsor.setDescription(rs.getString("description"));
        sponsor.setOrderValue(rs.getInt("ordervalue"));
        sponsor.setImageId(rs.getInt("image_id"));
        sponsor.setEventId(rs.getInt("event_id"));
        return sponsor;   
    }
    
}
