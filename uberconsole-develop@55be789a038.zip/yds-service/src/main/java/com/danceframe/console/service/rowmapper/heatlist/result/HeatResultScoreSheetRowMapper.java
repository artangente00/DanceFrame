/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.heatlist.result;

import com.danceframe.console.common.model.heatlist.result.HeatResultScoreSheet;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class HeatResultScoreSheetRowMapper implements RowMapper<HeatResultScoreSheet>{

    @Override
    public HeatResultScoreSheet mapRow(ResultSet rs, int i) throws SQLException {
        final HeatResultScoreSheet score = new HeatResultScoreSheet();
        score.setEventId(rs.getInt("event_id"));
        score.setHeatId(rs.getInt("heat_id"));
        score.setSubHeatId(rs.getInt("subheat_id"));
        score.setPersonKey1(rs.getString("person1_key"));
        score.setPersonKey2(rs.getString("person2_key"));
        score.setCoupleKey(rs.getString("couple_key"));
        score.setCoupleValue(rs.getString("couple_value"));
        score.setJudgingPanel(rs.getString("judgepanel"));
        score.setScoreHeaders(rs.getString("scoreheaders"));
        score.setHeatName(rs.getString("heat_name"));
        score.setHeatDesc(rs.getString("description"));
        score.setSubHeatType(rs.getString("subheat_type"));
        score.setSubHeatDance(rs.getString("subheat_dance"));
        score.setSubHeatLevel(rs.getString("subheat_level"));
        score.setSubHeatAge(rs.getString("subheat_age"));
        score.setFirstName1(rs.getString("firstname1"));
        score.setLastName1(rs.getString("lastname1"));
        score.setCompetitorNumber(rs.getString("competitor_num"));
        score.setFirstName2(rs.getString("firstname2"));
        score.setLastName2(rs.getString("lastname2"));
        return score;
    }
    
}
