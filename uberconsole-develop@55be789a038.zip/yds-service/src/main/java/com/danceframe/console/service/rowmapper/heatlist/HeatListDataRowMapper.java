/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.heatlist;

import com.danceframe.console.common.model.heatlist.HeatFullData;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class HeatListDataRowMapper implements RowMapper<HeatFullData>{

    @Override
    public HeatFullData mapRow(ResultSet rs, int column) throws SQLException {
        final HeatFullData fulldata = new HeatFullData();
        fulldata.setHeatListId(rs.getInt("heatlist_id"));
        fulldata.setPersonId(rs.getInt("person_id"));
        fulldata.setPersonCpmId(rs.getString("personcpm_id"));
	fulldata.setMainName(rs.getString("mainname"));
        fulldata.setMainSex(rs.getString("mainsex"));
        fulldata.setPartnerId(rs.getInt("partner_id"));
        fulldata.setPartnerCpmId(rs.getString("partnercpm_id"));
        fulldata.setPartnerName(rs.getString("partname"));
        fulldata.setPartnerSex(rs.getString("partsex"));
        fulldata.setSeqNo(rs.getString("seqno"));
        fulldata.setCompId(rs.getInt("comp_id"));
        fulldata.setCompCpmId(rs.getString("compcpm_id"));
        fulldata.setOtherInfo(rs.getString("otherinfo"));
        fulldata.setHeatType(rs.getString("heattype"));
        fulldata.setDance(rs.getString("dance"));
        fulldata.setLevel(rs.getString("heatlevel"));
        fulldata.setAge(rs.getString("age"));
        fulldata.setHeatId(rs.getInt("heat_id"));
        fulldata.setValue(rs.getString("heat_val"));
        fulldata.setSchedule(rs.getString("schedule")); 
        fulldata.setDescription(rs.getString("description"));
        return fulldata;
    }
    
}
