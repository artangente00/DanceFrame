/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.impl;

import com.danceframe.console.common.model.basic.LookUp;
import com.danceframe.console.service.constant.Lookup;
import com.danceframe.console.service.query.UtilityQuery;
import java.util.List;
import org.springframework.jdbc.core.RowMapper;
import com.danceframe.console.service.dataprovider.LookUpProviderDao;

/**
 *
 * @author lmorallos
 */
public class LookUpProviderDaoImpl extends BaseJdbcDaoImpl implements LookUpProviderDao {

    private RowMapper<LookUp> rowMapper;
    
    @Override
    public List<LookUp> getEventStatus() {
       return getLookUp(Lookup.EVENT_STATUS); 
    }
    
   
    @Override
    public List<LookUp> getNoYes() {
       return getLookUp(Lookup.NOYES); 
    }

    @Override
    public List<LookUp> getPublishStatus() {
        return getLookUp(Lookup.PUBLISH_STATUS); 
    }
    
    @Override
    public List<LookUp> getFormTypes() {
         return getLookUp(Lookup.FORM_TYPE); 
    }
    
    @Override
    public List<LookUp> getFormHeaderTypes() {
        return getLookUp(Lookup.FORM_HEADER_TYPE); 
    }

    @Override
    public List<LookUp> getFormEntryTypes() {
         return getLookUp(Lookup.FORM_ENTRY_TYPE); 
    }

    @Override
    public List<LookUp> getFormFields() {
         return getLookUp(Lookup.FORM_FIELD); 
     }
	
	@Override
    public List<LookUp> getCountry() {
         return getLookUp(Lookup.VENUE_COUNTRY); 
     }
	
    @Override
    public List<LookUp> getLookUp(String code) {
        String finalSQL = UtilityQuery.LOOKUP_QRY + " WHERE code='" + code + "'";
        List<LookUp> eventStatusList  = getJdbcTemplate().query(finalSQL,rowMapper);
        return eventStatusList;    
    }


     /**
     * @return the rowMapper
     */
    public RowMapper<LookUp> getRowMapper() {
        return rowMapper;
    }

    /**
     * @param rowMapper the rowMapper to set
     */
    public void setRowMapper(RowMapper<LookUp> rowMapper) {
        this.rowMapper = rowMapper;
    }

    
    
}
