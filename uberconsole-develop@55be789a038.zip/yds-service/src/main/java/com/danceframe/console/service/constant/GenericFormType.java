/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.constant;

/**
 *
 * @author lmorallos
 */
public final class GenericFormType {
    
    public static final int HOTEL = 1;
    
    public static final int SPONSOR = 2;
     
    public static final int INFO = 3;
    
    public static final String EVENT_CODE= "EVENT";
    
    public static final String HOTEL_CODE= "HOTEL";
    
    public static final String SPONSOR_CODE= "SPONSOR";
    
    public static final String INFO_CODE= "INFO";
    
    
    public static final String IMG_HOTEL_CODE= "HTLX";
    
    public static final String IMG_SPONSOR_CODE= "SPNX";
    
    public static final String IMG_INFO_CODE= "INFX";
    
}
