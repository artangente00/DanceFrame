/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.constant;

/**
 *
 * @author lmorallos
 */
public final class HeatListTag {
    
    public final static String STUDIO_START_TAG = "START_STUDIO_TABLE";
    public final static String STUDIO_END_TAG = "END_STUDIO_TABLE";

    public final static String PERSON_START_TAG = "START_PERSON_TABLE";
    public final static String PERSON_END_TAG = "END_PERSON_TABLE";

    public final static String PROGRAM_START_TAG = "START_PROGRAM_TABLE";
    public final static String PROGRAM_END_TAG = "END_PROGRAM_TABLE";
    
    public final static String HEAT_START_TAG = "START_HEAT";
    public final static String HEAT_END_TAG = "END_HEAT";

    public final static String COMP_START_TAG = "START_COMP";
    public final static String COMP_END_TAG = "END_COMP";

}
