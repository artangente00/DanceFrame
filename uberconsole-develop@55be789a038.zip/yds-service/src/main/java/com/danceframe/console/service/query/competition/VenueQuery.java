/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query.competition;

/**
 *
 * @author lmorallos
 */
public final class VenueQuery {

    public static final String INSERT_QRY = "SELECT uberconsole.FN_VENUE_INSERT_WITH_EVENTID(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    public static final String UPDATEBYEVENTID_QRY = "SELECT uberconsole.FN_VENUE_UPDATEBY_EVENTID(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    public static final String DELETEBYID_QRY = "SELECT uberconsole.FN_VENUE_DELETEBYID(?)";
	
    public static final String SEARCHBYID_QRY = "SELECT uberconsole.FN_VENUE_SEARCHBYID(?)";
	
    public static final String SEARCHBYNAME_QRY = "SELECT uberconsole.FN_VENUE_SEARCHBYNAME(?)";
    
    public static final String SELECT_QRY = "SELECT venue_id, name, address, address2, city, province, country, zipcode, phone,"
            + " resvphone, fax, website, longtitude, latitude, event_id FROM uberconsole.tbl_venue";

    public static final String SELECT_COUNT_QRY = "SELECT COUNT(venue_id) FROM uberconsole.tbl_venue";

}
