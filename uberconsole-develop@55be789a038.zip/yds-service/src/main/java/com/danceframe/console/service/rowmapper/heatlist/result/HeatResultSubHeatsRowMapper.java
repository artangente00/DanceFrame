/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.heatlist.result;

import com.danceframe.console.common.model.heatlist.result.HeatResultSubHeat;
import com.danceframe.console.common.model.heatlist.result.HeatResultSubHeats;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class HeatResultSubHeatsRowMapper implements RowMapper<HeatResultSubHeats>{

    @Override
    public HeatResultSubHeats mapRow(ResultSet rs, int i) throws SQLException {
        final HeatResultSubHeats subheats = new HeatResultSubHeats();
        subheats.setId(rs.getInt("subheats_id"));
        subheats.setDanceType(rs.getString("subheats_dancetype"));
        subheats.setLevel(rs.getString("subheats_level"));
        subheats.setAge(rs.getString("subheats_age"));
        subheats.setType(rs.getString("subheats_type"));
        subheats.setOrder(rs.getString("subheats_order"));
        subheats.setHeatId(rs.getInt("heat_id"));
        subheats.setEventId(rs.getInt("event_id"));
        return subheats;
    }
    
}
