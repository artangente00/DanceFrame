/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.payment;


import com.danceframe.console.common.model.payment.Payment;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author NDB
 */
public class PaymentRowMapper implements RowMapper<Payment> {
    
    @Override
    public Payment mapRow(final ResultSet rs, final int column) throws SQLException {
        final Payment onePayment = new Payment();
        onePayment.setId(rs.getInt("payment_id"));
        onePayment.setInvoiceId(rs.getInt("invoice_id"));
        onePayment.setAmountPaid(rs.getString("amount_paid"));
        onePayment.setTypeOfPayment(rs.getString("type_of_payment"));
        onePayment.setPaymentTimestamp(rs.getString("payment_timestamp"));
        onePayment.setUberConsoleUserId(rs.getString("uberconsole_user_id"));
        return onePayment;
    }
    
}
