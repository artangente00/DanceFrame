/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.competition;

import com.danceframe.console.common.model.competition.Finance;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class FinanceRowMapper implements RowMapper<Finance>{

    @Override
    public Finance mapRow(ResultSet rs, int column) throws SQLException {
        Finance finance = new Finance();
        finance.setId(rs.getInt("finance_id"));
        finance.setSurcharge(rs.getDouble("surcharge"));
        finance.setDescription(rs.getString("description"));
        finance.setEventId(rs.getInt("event_id"));
        return finance;
    }
    
}
