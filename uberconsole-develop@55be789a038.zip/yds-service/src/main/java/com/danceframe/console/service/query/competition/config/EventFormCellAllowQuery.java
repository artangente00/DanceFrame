/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query.competition.config;

/**
 *
 * @author lmorallos
 */
public final class EventFormCellAllowQuery {
    
    public final static String INSERT_QRY = "SELECT uberconsole.FN_EVENTFORM_VERTICAL_ALLOW_INSERT(?, ?, ?)";
    
    public final static String DELETE_QRY = "SELECT uberconsole.FN_EVENTFORM_VERTICAL_ALLOW_DELETEBYID(?)";
        
    // public final static String SELECT_QRY = "SELECT eventallow_id, eventform_id, eventvertical_id, eventdance_id FROM tbl_eventform_vertical_allow";
    
    // public final static String SELECT_COUNT_QRY = "SELECT count(eventallow_id) FROM tbl_eventform_vertical_allow";
    
    public final static String SELECT_QRY = "SELECT eventallow_id, eventform_id, eventvertical_id, eventdance_id,verticalcode," +
            "verticaldesc, dancecode, dancedesc FROM uberConsole.VW_EVENT_CONFIGALLOW";
    
    public final static String SELECT_COUNT_QRY = "SELECT count(eventallow_id) FROM uberConsole.VW_EVENT_CONFIGALLOW";
    
}
