/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query;

/**
 *
 * @author lmorallos
 */
public class RegistrationQuery {
    
    public static final String INSERT_REGUSER_QRY = "SELECT uberconsole.FN_REGUSER_INSERT(?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    public static final String UPDATE_REGUSER_QRY = "SELECT uberconsole.FN_REGUSER_UPDATE(?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    public static final String UPDATE_REGUSER_BYBUID_QRY = "SELECT uberconsole.FN_REGUSER_UPDATE_BYBUID(?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    public static final String DELETE_REGUSER_QRY = "SELECT uberconsole.FN_REGUSER_DELETE(?)";
   
    public static final String SIGNIN_REGUSER_QRY = "SELECT uberconsole.FN_REGUSER_SIGNIN(?, ?)";
    
    public static final String INSERT_REGSTUDIO_QRY = "SELECT uberconsole.FN_REGSTUDIO_INSERT(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    public static final String UPDATE_REGSTUDIO_QRY = "SELECT uberconsole.FN_REGSTUDIO_UPDATE(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    public static final String INSERT_REGPERSON_QRY = "SELECT uberconsole.FN_REGPERSON_INSERT(?, ?, ?, ?, ?, ?, ?, ?)";

    public static final String UPDATE_REGPERSON_QRY = "SELECT uberconsole.FN_REGPERSON_UPDATE(?, ?, ?, ?, ?, ?, ?)";
    
    public static final String INSERT_REGPURCHASE_QRY = "SELECT uberconsole.FN_REGPURCHASE_INSERT(?, ?, ?, ?, ?, ?)";

    public static final String UPDATE_REGPURCHASE_QRY = "SELECT uberconsole.FN_REGPURCHASE_UPDATE(?, ?, ?, ?, ?)";
    
    public static final String DELETE_REGPURCHASE_QRY = "SELECT uberconsole.FN_REGPURCHASE_DELETE(?)";
    
    public static final String INSERT_REGCOMPETITOR_QRY = "SELECT uberconsole.FN_REGCOMPETITOR_INSERT(?, ?, ?)";
    
    public static final String INSERT_REGCOMP_PERSON_QRY = "SELECT uberconsole.FN_REGCOMPETITOR_PERSON_INSERT(?, ?, ?, ?)";
    
    public static final String DELETE_REGCOMP_PERSON_QRY = "SELECT uberconsole.FN_REGCOMPETITOR_PERSON_DELETE(?)";
    
    public static final String DELETE_REGCOMP_PERSON_BYCUID_QRY = "SELECT uberconsole.FN_REGCOMPETITOR_PERSON_DELETEBYCUID(?, ?, ?)";
      
    public static final String INSERT_REGENTRY_QRY = "SELECT uberconsole.FN_REGENTRY_INSERT(?, ?, ?, ?, ?, ?, ?, ?)";
    
    public static final String UPDATE_REGENTRY_QRY = "SELECT uberconsole.FN_REGENTRY_UPDATE(?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    public static final String DELETE_REGENTRY_QRY = "SELECT uberconsole.FN_REGENTRY_DELETE(?)";
    
    public static final String INSERT_REGIDTRACKER_QRY = "SELECT uberconsole.FN_REGTRACKID_INSERT(?, ?, ?, ?, ?, ?)";
    
    
    public static final String SELECT_REGUSER_QRY = "SELECT * FROM uberconsole.tbl_reguser";
    
    public static final String SELECT_REGSTUDIO_QRY = "SELECT * FROM uberconsole.tbl_regstudio";
    
    public static final String SELECT_REGPERSON_QRY = "SELECT * FROM uberconsole.tbl_regperson";
    
    public static final String SELECT_REGCOMPETITOR_QRY = "SELECT * FROM uberconsole.tbl_regcompetitor";
    
    public static final String SELECT_REGCOMP_PERSON_QRY = "SELECT * FROM uberconsole.tbl_regcomp_person";
    
    public static final String SELECT_REGPURCHASE_QRY = "SELECT * FROM uberconsole.tbl_regpurchase";
    
    public static final String SELECT_REGENTRY_QRY = "SELECT * FROM uberconsole.tbl_regentry";
        
    public static final String SELECT_REGIDTRACKER_QRY = "SELECT * FROM uberconsole.tbl_regtrackid";
    
    
    
}
