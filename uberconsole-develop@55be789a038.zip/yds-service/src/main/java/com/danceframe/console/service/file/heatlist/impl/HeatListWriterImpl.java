/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.file.heatlist.impl;

import com.danceframe.console.common.model.heatlist.HeatFullData;
import com.danceframe.console.common.model.heatlist.HeatListEvent;
import com.danceframe.console.common.model.heatlist.HeatPerson;
import com.danceframe.console.common.model.heatlist.HeatSession;
import com.danceframe.console.common.util.Utility;
import com.danceframe.console.service.dataprovider.heatlist.HeatListProviderDao;
import com.danceframe.console.service.file.heatlist.HeatListWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import liquibase.util.StringUtils;
import org.springframework.dao.EmptyResultDataAccessException;

/**
 *
 * @author lmorallos
 */
public class HeatListWriterImpl implements HeatListWriter {
    
    private static final Logger logger = LogManager.getLogger(HeatListWriter.class);
    private final static String TEMPLATE_FILE = "heat_template.htl";
    private final static String TMP_PERSON_FILE = "personlist.out";
    private final static String TMP_DATA_FILE = "datalist.out";
    
    private final static String MARKER_EVENT_UID = "$HEATLIST_EVENT_EUID$";
    private final static String MARKER_COMPETITION = "$HEATLIST_COMPETITION$";
    private final static String MARKER_EVENT_NAME = "$HEATLIST_EVENT$";
    private final static String MARKER_ASOF = "$HEATLIST_ASOF$";
    private final static String MARKER_PERSON_BLOCK = "$HEATLIST_PERSON_BLOCK$";    
    private final static String MARKER_DATA_BLOCK = "$HEATLIST_DATA_BLOCK$";
    
    private final static String MARKER_PERSON_NAME = "$HEATLIST_PERSON_NAME$";
    private final static String MARKER_PARTNER_NAME = "$HEATLIST_PARTNER_NAME$";
    private final static String MARKER_PERSON_ID = "$HEAT_PERSON_ID$";
    
    private final static String MARKER_SCHED = "$HEAT_ENTRY_SCHED$";
    private final static String MARKER_SEQNO = "$HEAT_ENTRY_SEQNO$";
    private final static String MARKER_VALUE = "$HEAT_ENTRY_VAL$";
    private final static String MARKER_EVENT = "$HEAT_ENTRY_EVENT$";
    
    private final static String PERSON_BLOCK = 
            "<tr><td>$HEATLIST_PERSON_NAME$</td><td><input type=\"button\" value=\"Show entries\" onclick=\"ShowPersonData('TABLE_CODE_$HEAT_PERSON_ID$')\"></td></tr>";
    private final static String DATA_BLOCK = 
            "<tr><td>$HEAT_ENTRY_SCHED$</td><td>$HEAT_ENTRY_SEQNO$</td><td>$HEAT_ENTRY_VAL$</td><td>$HEAT_ENTRY_EVENT$</td></tr>";
    
  
    private final static String HEAT_BLOCK_START= 
        "<div id=\"TABLE_CODE_$HEAT_PERSON_ID$\" style=\"visibility:hidden; Position:Absolute; left:5%; top:10%\">" ;
    
    private final static String HEAT_PERSON_BLOCK = 
            "<strong>$HEATLIST_PERSON_NAME$</strong><br/>";
    private final static String HEAT_PARTNER_BLOCK = "<br/><strong>With $HEATLIST_PARTNER_NAME$</strong>";
    
    private final static String HEAT_TABLE_START =        
        "<table border=\"2\" cellspacing=\"0\" bordercolor=\"#000000\">\n" +
        "<tr><td>Session@Time</td><td>Number</td><td>Heat</td><td>Event</td></tr>";
    private final static String HEAT_TABLE_END = "</table>"; 
    
    private final static String HEAT_BLOCK_END = "</div>";    
    private HeatListProviderDao heatListProviderDao;

    
    @Override
    public boolean writeToFile(String tmppath, String outputfile, int eid) throws FileNotFoundException, IOException {
        boolean retbool = false;
//        System.out.println("Event ID:" + eid);
        HeatListEvent heatlist = null;
        try {
            heatlist = heatListProviderDao.getHeatListByEventId(eid);
            if (heatlist == null) {
                return false;
            }
        } catch (EmptyResultDataAccessException ex) {
            return false;
        }
//        System.out.println(heatlist.toString());
        long icnt = 0;
        long iperson = 0;
        int hid = heatlist.getId();
        String personfile = tmppath + TMP_PERSON_FILE;
        String datafile =  tmppath + TMP_DATA_FILE;
        BufferedWriter personout = new BufferedWriter(new FileWriter(personfile));
        BufferedWriter dataout = new BufferedWriter(new FileWriter(datafile));
        String persondata = new String();
        List<HeatSession> sessions = heatListProviderDao.getHeatSessions(hid);
        List<HeatPerson> lstPerson = heatListProviderDao.getAllHeatPerson(hid);
        for (HeatPerson person:lstPerson) {
            String tmpLastname = person.getLastName();
            String  tmpFirstname = person.getFirstName();
            if (Utility.showPerson(tmpFirstname, tmpLastname)) {
              	String personLastName = new String(person.getLastName().getBytes("UTF-8"), "ISO-8859-1");
            	String personFirstName = new String(person.getFirstName().getBytes("UTF-8"), "ISO-8859-1");
            	String fullname = personLastName + ", " + personFirstName;
                String personId = Integer.toString(person.getId());
                String personCompId = person.getCompMgrId();
                int datacnt = heatListProviderDao.getCountDataByPerson(personCompId,hid);
                String blockstr = new String();
                if (datacnt > 0) {
                    persondata = PERSON_BLOCK.replace(MARKER_PERSON_NAME, StringUtils.escapeHtml(fullname));
                    persondata = persondata.replace(MARKER_PERSON_ID, personId);
                    personout.write(persondata);personout.newLine();
                    iperson++;
                    blockstr = HEAT_BLOCK_START.replace(MARKER_PERSON_ID, personId);
                    dataout.write(blockstr);dataout.newLine();

                    List<HeatFullData> fulldata = heatListProviderDao.
                            getHeatFullDataByPerson(personCompId,hid);
                    String heatdata = new String();

                    int block = 0;
                    String tablestr = new String();
                    int partid = -1; 
                    int persid = -1;
                    int pcnt = 0;
//                    System.out.println("-----------------------------------------------");
                    for (HeatFullData hdata:fulldata) {
//                        System.out.println(hdata.toString());
                        if ((partid != hdata.getPartnerId()) || (persid != hdata.getPersonId())) {
                            if (block > 0) {
                                dataout.write(HEAT_TABLE_END);dataout.newLine();
                            }
                            String mainPerson = new String();
                            String partPerson = new String();
                            if (person.getId() == hdata.getPersonId()) {
                                mainPerson = hdata.getMainName();
                                partPerson = hdata.getPartnerName();
                            } else if (person.getId() == hdata.getPartnerId()) {
                                mainPerson = hdata.getPartnerName(); 
                                partPerson = hdata.getMainName();
                            }
                            blockstr = HEAT_PERSON_BLOCK.replace(MARKER_PERSON_NAME, StringUtils.escapeHtml(mainPerson));
                            if (pcnt == 0) {
                                dataout.write(blockstr);dataout.newLine();
                                pcnt++;
                            }
                            if (null != partPerson) {
                                tablestr = HEAT_PARTNER_BLOCK.replace(MARKER_PARTNER_NAME, StringUtils.escapeHtml(partPerson));
                                dataout.write(tablestr);dataout.newLine();
                            }


                            dataout.write(HEAT_TABLE_START);dataout.newLine();
                            block++;
                        }
//                        String schedule = schedAddDay(hdata.getSchedule(), heatlist.getCompDate());
                        String schedule = schedAddSession(hdata.getSchedule(), sessions);
                        heatdata = DATA_BLOCK.replace(MARKER_SCHED,schedule);
                        heatdata = heatdata.replace(MARKER_SEQNO,hdata.getSeqNo());
                        heatdata = heatdata.replace(MARKER_VALUE,hdata.getValue());
                        String desc = new String();

                        if (hdata.getValue().indexOf("Solo") > -1) {
                             desc = desc + " " + hdata.getDescription();
                        } else {
                            String age = (hdata.getAge().length() > 0)?hdata.getAge():"";
                            String lvl = (hdata.getLevel().length() > 0)?hdata.getLevel():"";
                            String dance = (hdata.getDance().length() > 0)?hdata.getDance():"";
                           
                            String sfx = new String();
                            if ((lvl.length() > 0)  && (age.length() > 0)){
                                sfx = " - L-" + age  + " " +  lvl ;
                            } else if ((lvl.length() == 0)  && (age.length() > 0)){
                                sfx = " - L-" + age ; 
                            } else if ((lvl.length() > 0)  && (age.length() == 0)){
                                 sfx = " - " + lvl ;
                            }
                            //desc =  hdata.getDescription() + " " + sfx;
                            desc =  dance + " " + sfx;
//                            if (hdata.getAge().length() > 0)  
//                                    desc = desc +  hdata.getAge();
//                                    //desc = desc + "(" + hdata.getAge() + ")";
//                            if (hdata.getLevel().length() > 0) 
//                                    desc = desc + " " + hdata.getLevel();
//                             if (hdata.getDance().length() > 0) 
//                                    desc = desc + " " + hdata.getDance();
                        }
                        heatdata = heatdata.replace(MARKER_EVENT, desc);
                        dataout.write(heatdata);dataout.newLine();
                        partid =  hdata.getPartnerId();
                        persid = hdata.getPersonId();
                        icnt++;
                    }
                    dataout.write(HEAT_TABLE_END);dataout.newLine();
                    dataout.write(HEAT_BLOCK_END);dataout.newLine();
                }
            }
        }
        personout.close();
        dataout.close();
        logger.info("HEATLIST - No of person data written:" + iperson);
        logger.info("HEATLIST - No of heat data written:" + icnt);
        // fill out the data
        String outfullpath = tmppath + outputfile;
        BufferedWriter htmfile = new BufferedWriter(new FileWriter(outfullpath));
       
        Resource resource = new ClassPathResource(TEMPLATE_FILE);
        InputStream resourceInputStream = resource.getInputStream();
        InputStreamReader isrfile = new InputStreamReader(resourceInputStream);
        BufferedReader templateFile = new BufferedReader(isrfile);
        String strline = new String();
        while ((strline = templateFile.readLine()) != null) {            
            if (strline.equalsIgnoreCase(MARKER_PERSON_BLOCK)) {
                BufferedReader partFile = new BufferedReader(new FileReader(personfile));
                String tmpstr = new String();
                while ((tmpstr = partFile.readLine()) != null) {
                    htmfile.write(tmpstr);htmfile.newLine();
                }
                if (partFile != null)  partFile.close();
            } else if (strline.equalsIgnoreCase(MARKER_DATA_BLOCK)) {
                BufferedReader partFile = new BufferedReader(new FileReader(datafile));
                String tmpstr = new String();
                while ((tmpstr = partFile.readLine()) != null) {
                    htmfile.write(tmpstr);htmfile.newLine();
                }
                if (partFile != null)  partFile.close();
            } else {
                if (strline.indexOf(MARKER_EVENT_UID) > -1) 
                    strline = strline.replace(MARKER_EVENT_UID, heatlist.getEuid());
                 if (strline.indexOf(MARKER_COMPETITION) > -1) 
                    strline = strline.replace(MARKER_COMPETITION, heatlist.getDescription());
                if (strline.indexOf(MARKER_EVENT_NAME) > -1) 
                    strline = strline.replace(MARKER_EVENT_NAME, heatlist.getDescription());
                if (strline.indexOf(MARKER_ASOF) > -1) 
                    strline = strline.replace(MARKER_ASOF, heatlist.getStrAsof());
                htmfile.write(strline);htmfile.newLine();
            }
            
        }
        if (templateFile != null) templateFile.close();
        if (htmfile != null) {
            htmfile.flush();htmfile.close();
        }
        logger.info("HEATLIST - Finished wirting output" + outfullpath);
        retbool = true;
        return retbool;
    }

    private String schedAddDay(String sched, Date cdate) {
        String retstr = new String();
        Calendar cal = Calendar.getInstance();
        cal.setTime(cdate);
        int year = cal.get(Calendar.YEAR);
        int mon = cal.get(Calendar.MONTH) + 1;
        int day = cal.get(Calendar.DAY_OF_MONTH);
        
        String[] split = sched.split("@");
        int iday = Integer.parseInt(split[0]) - 1;
        String strday = DateTimeFormatter.ofPattern("EEEE")
            .format(LocalDate.of(year, mon, day + iday));
        retstr = sched + " " + strday;
        return retstr;
    }
    
    private String schedAddSession(String sched, List<HeatSession> sessions) {
        String retstr = new String();
        String[] split = sched.split("@");
        int iday = Integer.parseInt(split[0]);
        String day = new String();
        for (HeatSession session:sessions) {
            if (session.getSessionCount() == iday) {
                day  = session.getSessionDay();
                break;
            }
        }
        retstr = day + "@" + split[1];
        return retstr;
    }
    
    
    
    /**
     * @return the heatListProviderDao
     */
    public HeatListProviderDao getHeatListProviderDao() {
        return heatListProviderDao;
    }

    /**
     * @param heatListProviderDao the heatListProviderDao to set
     */
    public void setHeatListProviderDao(HeatListProviderDao heatListProviderDao) {
        this.heatListProviderDao = heatListProviderDao;
    }
    
}
