/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.uam.impl;

import com.danceframe.console.common.model.uam.Syslog;
import com.danceframe.console.service.dataprovider.impl.BaseJdbcDaoImpl;
import com.danceframe.console.service.dataprovider.uam.SyslogProviderDao;
import com.danceframe.console.service.query.uam.SyslogQuery;
import java.util.ArrayList;
import java.util.List;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class SyslogProviderDaoImpl extends BaseJdbcDaoImpl implements SyslogProviderDao {

    private RowMapper<Syslog> rowMapper;
    
    @Override
    public int insert(Syslog syslog) {
         Object[] obj = new Object[] {
            syslog.getAction(),
            syslog.getModuleName(),
            syslog.getClassName(),
            syslog.getUserid(),
            new java.sql.Timestamp(System.currentTimeMillis())           
            };
        int iret = getJdbcTemplate().queryForObject(SyslogQuery.INSERT_QRY, 
                   obj, Integer.class);
        return iret;
      }

    
    @Override
    public int updateSyslogId(String tblname, int syslogid, String idvar, int id) {
         Object[] obj = new Object[] {
            tblname,
            syslogid,
            idvar,
            id };
        int iret = getJdbcTemplate().queryForObject(SyslogQuery.UPDATE_SYSLOGID, 
                   obj, Integer.class);
        return iret;
     }
    
    @Override
    public List<Syslog> getAll(String wherestr) {
        List<Syslog> syslogList = new ArrayList<Syslog>();
        String sql = SyslogQuery.SELECT_QRY;
        String finalSQL = ((wherestr != null) || (wherestr.length() > 0 ) || (!wherestr.isEmpty()))? sql + " "  + wherestr : sql;
        syslogList = getJdbcTemplate().query(finalSQL, rowMapper);
        return(syslogList);        
    }

    @Override
    public List<Syslog> getAllWithPaging(String wherestr, int pagesize, int first) {
        List<Syslog> syslogList = new ArrayList<Syslog>();
        String sql = SyslogQuery.SELECT_QRY;
        String limit = " LIMIT " + Integer.toString(pagesize);
        String offset = " OFFSET " + Integer.toString(first);       
        String finalSQL = ((wherestr != null) || (wherestr.length() > 0 ) || (!wherestr.isEmpty()))? sql + " "  + wherestr : sql;        
        String strSQL = finalSQL  + limit + offset;
        logger.info(strSQL);
        syslogList = getJdbcTemplate().query(strSQL, rowMapper);
        return(syslogList); 
      }

    @Override
    public long getAllCount(String wherestr) {
        String sql = SyslogQuery.SELECT_COUNT_QRY;
        String finalSQL = ((wherestr != null) || (wherestr.length() > 0 ) || (!wherestr.isEmpty()))? sql + " "  + wherestr : sql;
        return (getJdbcTemplate().queryForObject(finalSQL, Long.class));
    }

    /**
     * @return the rowMapper
     */
    public RowMapper<Syslog> getRowMapper() {
        return rowMapper;
    }

    /**
     * @param rowMapper the rowMapper to set
     */
    public void setRowMapper(RowMapper<Syslog> rowMapper) {
        this.rowMapper = rowMapper;
    }

}
