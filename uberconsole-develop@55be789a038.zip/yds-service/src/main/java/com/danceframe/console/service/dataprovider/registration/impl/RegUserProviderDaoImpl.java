/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.registration.impl;

import com.danceframe.console.common.model.registration.RegUser;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.dataprovider.registration.RegUserProviderDao;
import com.danceframe.console.service.query.RegistrationQuery;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public class RegUserProviderDaoImpl extends GenericProviderDaoImpl<RegUser> implements RegUserProviderDao{

    @Override
    public int search(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int search(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int insert(RegUser reguser) {
         Object[] obj = new Object[] { 
            reguser.getBgoId(),
            reguser.getLastName(),
            reguser.getFirstName(),
            reguser.getMiddleName(),
            reguser.getEmail(),
            reguser.getGender(),
            reguser.getBirthday(),
            reguser.getCategory(),
            reguser.getLoginProvider()
        };
        int ret = (Integer)this.genericQryTemplateInteger(RegistrationQuery.INSERT_REGUSER_QRY, obj);
        return ret;
    }

    @Override
    public int update(RegUser reguser) {
         Object[] obj = new Object[] { 
            reguser.getBgoId(),
            reguser.getLastName(),
            reguser.getFirstName(),
            reguser.getMiddleName(),
            reguser.getEmail(),
            reguser.getGender(),
            reguser.getBirthday(),
            reguser.getCategory(),
            reguser.getLoginProvider()
        };
        int ret = (Integer)this.genericQryTemplateInteger(RegistrationQuery.UPDATE_REGUSER_QRY, obj);
        return ret;
    }
    
    @Override
    public int updateByBuid(RegUser reguser) {
         Object[] obj = new Object[] { 
            reguser.getBuid(),
            reguser.getLastName(),
            reguser.getFirstName(),
            reguser.getMiddleName(),
            reguser.getEmail(),
            reguser.getGender(),
            reguser.getBirthday(),
            reguser.getCategory(),
            reguser.getLoginProvider()
        };
        int ret = (Integer)this.genericQryTemplateInteger(RegistrationQuery.UPDATE_REGUSER_BYBUID_QRY, obj);
        return ret;
    }

    @Override
    public int delete(int id) {
        Object[] obj = new Object[] { id };
        int ret = (Integer)this.genericQryTemplateInteger(RegistrationQuery.DELETE_REGUSER_QRY, obj);
        return ret;
    }

    @Override
    public int delete(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public RegUser get(int id) {
        Object[] obj = new Object[] { id };
        String sqlWhere = " WHERE reguser_id = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGUSER_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);   
    }

    @Override
    public RegUser get(String buid) {
        Object[] obj = new Object[] { buid };
        String sqlWhere = " WHERE buid = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGUSER_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);   
    }
    
    @Override
    public RegUser getByBgoId(String bgoid) {
        Object[] obj = new Object[] { bgoid };
        String sqlWhere = " WHERE bgoid = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGUSER_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);   
    }
    
     @Override
    public RegUser get(String bgoid, String buid) {
        Object[] obj = new Object[] { bgoid, buid };
        String sqlWhere = " WHERE bgoid=? AND buid = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGUSER_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);   
    }
    

    @Override
    public List<RegUser> getAll(String wherestr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RegUser> getAllWithPaging(String wherestr, int pagesize, int pagenumber) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public long getAllCount(String wherestr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RegUser> getAll() {
        List<RegUser> userList = new ArrayList<>();
        String finalSQL =  RegistrationQuery.SELECT_REGUSER_QRY;
        userList =  genericQryAllTemplateRowMapper(finalSQL, "");
        return userList;   
    }

    @Override
    public int signin(String bgoid, String buid) {
         Object[] obj = new Object[] { 
           bgoid, buid
        };
        int ret = (Integer)this.genericQryTemplateInteger(RegistrationQuery.SIGNIN_REGUSER_QRY, obj);
        return ret;

    }


   
}
