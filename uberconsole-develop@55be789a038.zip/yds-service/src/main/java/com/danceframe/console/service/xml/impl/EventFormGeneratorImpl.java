/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.xml.impl;

import com.danceframe.console.common.model.competition.form.EventForm;
import com.danceframe.console.service.dataprovider.competition.config.EventFormCellAllowProviderDao;
import com.danceframe.console.service.dataprovider.competition.config.EventFormDanceProviderDao;
import com.danceframe.console.service.dataprovider.competition.config.EventFormFieldProviderDao;
import com.danceframe.console.service.dataprovider.competition.config.EventFormHContentProviderDao;
import com.danceframe.console.service.dataprovider.competition.config.EventFormProviderDao;
import com.danceframe.console.service.xml.EventFormGenerator;
import java.util.List;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import org.json.JSONException;
import org.json.XML;

/**
 *
 * @author lmorallos
 */
public class EventFormGeneratorImpl implements EventFormGenerator {

    private EventFormProviderDao eventFormProviderDao;
    private EventFormFieldProviderDao eventFormFieldProviderDao;
    private EventFormHContentProviderDao eventFormHContentProviderDao;
    private EventFormDanceProviderDao eventFormDanceProviderDao;
    private EventFormCellAllowProviderDao eventFormCellAllowProviderDao;
            
            
    @Override
    public String generate(int eventId) {
        String retstr = new String();
        List<EventForm> eventFormList = eventFormProviderDao.getAll("WHERE event_id=" + eventId);
        return retstr;
    }
    
    @Override
    public boolean xmlToJson(byte[] xmldata, String tmpLocation, String jsonfilename) throws IOException {
       boolean retbool = true;      
       try {
        String json = XML.toJSONObject(new String(xmldata)).toString();
        BufferedOutputStream stream = new BufferedOutputStream(
                        new FileOutputStream(new File(tmpLocation,jsonfilename)));
        stream.write(json.getBytes());
        stream.flush();
        stream.close();
        stream = null;
        File f = new File(tmpLocation,jsonfilename);
        if (!f.exists()) retbool = false;
       } catch (JSONException ex) {
           ex.printStackTrace();
       }
       return retbool;
    }
    

    /**
     * @return the eventFormProviderDao
     */
    public EventFormProviderDao getEventFormProviderDao() {
        return eventFormProviderDao;
    }

    /**
     * @param eventFormProviderDao the eventFormProviderDao to set
     */
    public void setEventFormProviderDao(EventFormProviderDao eventFormProviderDao) {
        this.eventFormProviderDao = eventFormProviderDao;
    }

    /**
     * @return the eventFormFieldProviderDao
     */
    public EventFormFieldProviderDao getEventFormFieldProviderDao() {
        return eventFormFieldProviderDao;
    }

    /**
     * @param eventFormFieldProviderDao the eventFormFieldProviderDao to set
     */
    public void setEventFormFieldProviderDao(EventFormFieldProviderDao eventFormFieldProviderDao) {
        this.eventFormFieldProviderDao = eventFormFieldProviderDao;
    }

    /**
     * @return the eventFormDanceProviderDao
     */
    public EventFormDanceProviderDao getEventFormDanceProviderDao() {
        return eventFormDanceProviderDao;
    }

    /**
     * @param eventFormDanceProviderDao the eventFormDanceProviderDao to set
     */
    public void setEventFormDanceProviderDao(EventFormDanceProviderDao eventFormDanceProviderDao) {
        this.eventFormDanceProviderDao = eventFormDanceProviderDao;
    }

    /**
     * @return the eventFormCellAllowProviderDao
     */
    public EventFormCellAllowProviderDao getEventFormCellAllowProviderDao() {
        return eventFormCellAllowProviderDao;
    }

    /**
     * @param eventFormCellAllowProviderDao the eventFormCellAllowProviderDao to set
     */
    public void setEventFormCellAllowProviderDao(EventFormCellAllowProviderDao eventFormCellAllowProviderDao) {
        this.eventFormCellAllowProviderDao = eventFormCellAllowProviderDao;
    }

    /**
     * @return the eventFormHContentProviderDao
     */
    public EventFormHContentProviderDao getEventFormHContentProviderDao() {
        return eventFormHContentProviderDao;
    }

    /**
     * @param eventFormHContentProviderDao the eventFormHContentProviderDao to set
     */
    public void setEventFormHContentProviderDao(EventFormHContentProviderDao eventFormHContentProviderDao) {
        this.eventFormHContentProviderDao = eventFormHContentProviderDao;
    }

}
