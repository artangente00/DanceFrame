/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.heatlist.result;

import com.danceframe.console.common.model.heatlist.result.HeatResultCoupleEntry;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class HeatResultCoupleEntryRowMapper implements RowMapper<HeatResultCoupleEntry> {

    @Override
    public HeatResultCoupleEntry mapRow(ResultSet rs, int i) throws SQLException {
        final HeatResultCoupleEntry entry = new HeatResultCoupleEntry();
        entry.setId(rs.getInt("entry_id"));
        entry.setCoupleKey(rs.getString("couple_key"));
        entry.setCoupleId(rs.getInt("couple_id"));
        entry.setSubHeatId(rs.getInt("subheat_id"));
        return entry;
    }

}
