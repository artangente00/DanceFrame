/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.competition;

import com.danceframe.console.common.model.competition.Enablement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class EnablementRowMapper implements RowMapper<Enablement> {

    @Override
    public Enablement mapRow(ResultSet rs, int column) throws SQLException {
        Enablement enable = new Enablement();
        enable.setId(rs.getInt("enable_id"));
        enable.setEventId(rs.getInt("event_id"));
        enable.setVenueEnable(rs.getBoolean("venue_enable"));
        enable.setContactEnable(rs.getBoolean("contact_enable"));
        enable.setOrganizerEnable(rs.getBoolean("organizer_enable"));
        enable.setScheduleEnable(rs.getBoolean("schedule_enable"));
        enable.setHotelEnable(rs.getBoolean("hotel_enable"));
        enable.setSponsorEnable(rs.getBoolean("sponsor_enable"));
        enable.setInformationEnable(rs.getBoolean("information_enable"));
        enable.setFinanceEnable(rs.getBoolean("finance_enable"));
        return enable;
    }
    
}
