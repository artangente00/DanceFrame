/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider;

import com.danceframe.console.common.model.registry.AccountType;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public interface AccountTypeProviderDao {
    
    int insertAccountType(String description);
    
    int updateAccountType(int id, String description);
    
    int updateAccountTypeByDesc(String description, String newdescription);
    
    int deleteAccountType(String description);
    
    AccountType getAccountTypeInfo(String description);
    
    List<AccountType> getAllAccounType();
    
}
