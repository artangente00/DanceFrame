/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.competition;

import com.danceframe.console.common.model.competition.Information;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class InfoRowMapper implements RowMapper<Information> {

    @Override
    public Information mapRow(ResultSet rs, int column) throws SQLException {
        Information info = new Information();
        info.setId(rs.getInt("information_id"));
        info.setUrl(rs.getString("url"));
        info.setDescription(rs.getString("description"));
        info.setOrderValue(rs.getInt("ordervalue"));
        info.setImageId(rs.getInt("image_id"));
        info.setEventId(rs.getInt("event_id"));
        return info;     
    }
    
}
