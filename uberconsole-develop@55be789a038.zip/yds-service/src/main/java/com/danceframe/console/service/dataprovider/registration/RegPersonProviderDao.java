/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.registration;

import com.danceframe.console.common.model.registration.RegPerson;
import com.danceframe.console.service.dataprovider.GenericProviderDao;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public interface RegPersonProviderDao extends GenericProviderDao<RegPerson>{
    
    RegPerson get(int personId, String euid);
    
    RegPerson get(String puid, String euid);
    
    List<RegPerson> getPersonsByEventUID(String euid);
    
    RegPerson get(String buid, String euid, String puid);
    
    List<RegPerson> getPersonsByEvent(String buid, String euid);
}
