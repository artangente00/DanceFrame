/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query.critique;

/**
 *
 * @author lmorallos
 */
public final class CritiqueQuery {
    
    
    public final static String EVENT_CLEAR_QRY = "SELECT uberconsole.FN_CRITIQUE_EVENT_CLEAR( ? )";

    public final static String PROGRAM_INSERT_QRY = "SELECT uberconsole.FN_CRITIQUE_PROGRAM_INSERT(?, ?, ?, ?, ?, ? )";
    
    public final static String STUDIO_INSERT_QRY = "SELECT uberconsole.FN_CRITIQUE_STUDIO_INSERT(?, ?, ?, ?, ? )";

    public final static String JUDGE_INSERT_QRY = "SELECT uberconsole.FN_CRITIQUE_JUDGE_INSERT( ?, ?, ?, ?, ?, ? )";

    public final static String PERSON_INSERT_QRY = "SELECT uberconsole.FN_CRITIQUE_PERSON_INSERT( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )";

    public final static String COUPLES_SEARCH_QRY = "SELECT uberconsole.FN_CRITIQUE_COUPLES_SEARCH( ?, ? )";
    
    public final static String COUPLES_INSERT_QRY = "SELECT uberconsole.FN_CRITIQUE_COUPLES_INSERT( ?, ?, ?, ?, ? )";

    public final static String HEATS_INSERT_QRY = "SELECT uberconsole.FN_CRITIQUE_HEATS_INSERT( ?, ?, ?, ?, ?, ?, ?, ? )";

    public final static String SUBHEATS_INSERT_QRY = "SELECT uberconsole.FN_CRITIQUE_SUBHEATS_INSERT( ?, ?, ?, ?, ?, ?, ? )";

    public final static String ENTRIES_INSERT_QRY = "SELECT uberconsole.FN_CRITIQUE_COUPLE_ENTRIES_INSERT( ?, ?, ? )";

    public final static String SOLO_INSERT_QRY = "SELECT uberconsole.FN_CRITIQUE_SOLO_ENTRIES_INSERT( ?, ?, ? )";
    
    public final static String RESULT_INSERT_QRY = "SELECT uberconsole.FN_CRITIQUE_RESULT_INSERT( ?, ?, ?, ?)";

    public final static String MARKS_INSERT_QRY = "SELECT uberconsole.FN_CRITIQUE_MARKS_INSERT( ?, ?, ?, ?, ?)";

    public final static String SELECT_STUDIO_QRY = "SELECT studio_id,studio_key,name,invoice,event_id,xml_id " + 
						"FROM uberconsole.tbl_hrstudios";

    public final static String SELECT_JUDGE_QRY = "SELECT judge_id,judge_key,firstname,lastname,judge_num," + 
						"event_id,xml_id FROM uberconsole.tbl_hrjudges";

    public final static String SELECT_PERSON_QRY = "SELECT person_id,person_key,firstname,lastname,gender," + 
						"persontype,studio_key,nickname,ndcaus_num,competitor_num,event_id," + 
						"xml_id FROM uberconsole.tbl_hrpersons";

    public final static String SELECT_COUPLE_QRY = "SELECT couple_id,couple_key,person1_key,person2_key," + 
						"event_id,xml_id FROM uberconsole.tbl_hrcouples";

    public final static String SELECT_HEAT_QRY = "SELECT heat_id,heat_name,heat_session,heat_time,heat_date," + 
						"description,event_id,xml_id FROM uberconsole.tbl_hrheats";

    public final static String SELECT_SUBHEAT_QRY = "SELECT subheat_id,subheat_key,subheat_type,subheat_dance," + 
                                                    "subheat_level,subheat_age,heat_id,event_id,xml_id FROM uberconsole.tbl_hrsubheats";

    public final static String SELECT_ENTRIES_QRY = "SELECT entry_id,couple_key,couple_id,subheat_id,event_id,xml_id" + 
                                                    " FROM uberconsole.tbl_hrcoupleentries";
    
     public final static String SELECT_SOLO_QRY = "SELECT sentry_id,person_key,subheat_id,event_id" + 
                                                    " FROM uberconsole.tbl_hrsoloentries";

    public final static String SELECT_RESULT_QRY = "SELECT result_id,judgepanel,scoreheaders,subheat_id,event_id," + 
                                                    "xml_id FROM uberconsole.tbl_hrresult";

    public final static String SELECT_MARK_QRY = "SELECT mark_id,couple_key,couple_value,couple_id,result_id,subheat_id," + 
						"event_id,xml_id FROM uberconsole.tbl_hrmarks";
	
}
