/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.competition.impl;

import com.danceframe.console.common.model.competition.Event;
import com.danceframe.console.common.model.competition.EventSummary;
import com.danceframe.console.common.model.competition.PublishSummary;
import com.danceframe.console.common.util.Utility;
import com.danceframe.console.service.dataprovider.competition.EventProviderDao;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.query.competition.EventQuery;
import com.danceframe.console.service.rowmapper.competition.EventSummaryRowMapper;
import com.danceframe.console.service.rowmapper.competition.PublishSummaryRowMapper;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;



/**
 *
 * @author lmorallos
 */
public class EventProviderDaoImpl extends GenericProviderDaoImpl<Event> implements EventProviderDao {

    private PublishSummaryRowMapper publishSummaryRowMapper;
    private EventSummaryRowMapper eventSummaryRowMapper;
    
    @Override
    public int searchByEventAndDate(int id, Date start, Date stop) {
        Object[] obj = new Object[] {id, start, stop };
        int ret = (Integer)this.genericQryTemplateInteger(EventQuery.SEARCH_BYEVENTANDDATE_QRY, obj);
        return ret;
    }
    
     @Override
    public int searchByCompetitionAndDate(int compid, Date start, Date stop) {
        Object[] obj = new Object[] {compid, start, stop };
        int ret = (Integer)this.genericQryTemplateInteger(EventQuery.SEARCH_BYCOMPIDANDDATE_QRY, obj);
        return ret;
    }

    @Override
    public int setStatus(int id, int status) {
        Object[] obj = new Object[] {id, status };
        int ret = (Integer)this.genericQryTemplateInteger(EventQuery.SETSTATUS_QRY, obj);
        return ret;
    }
    
    @Override
    public int setPushId(int id, String pushid) {
        Object[] obj = new Object[] {id, pushid };
        int ret = (Integer)this.genericQryTemplateInteger(EventQuery.SETPUSHID_QRY, obj);
        return ret;
    }
    
    
    @Override
    public int setPublishStatus(int id, int pubstatus, long commitTime) {
        Object[] obj = new Object[] {id, pubstatus, commitTime };
        int ret = (Integer)this.genericQryTemplateInteger(EventQuery.SETPUBSTATUS_QRY, obj);
        return ret;
    }

    @Override
    public int insert(Event event) {
        Object[] obj = new Object[] {
            event.getCompetitionId(),
            Utility.sqlDate(event.getDateStart()),
            Utility.sqlDate(event.getDateStop()),
            Utility.sqlTimestamp(event.getDeadline()),
            Utility.getYear(event.getDateStart()),
            event.getWebsite(),
            event.getStatus(),
            event.getPubstatus(),
            event.getName(),
            event.isUberRegister(),
            event.isTestEvent(),
            event.isWebsiteEnabled(),
            event.isHideEvent(),
            event.getPaymentMethods()
            };
        int ret = (Integer)this.genericQryTemplateInteger(EventQuery.INSERT_QRY, obj);
        return ret;
    }

    @Override
    public int update(Event event) {
        Object[] obj = new Object[] {
            event.getId(),
            Utility.sqlDate(event.getDateStart()),
            Utility.sqlDate(event.getDateStop()),
            Utility.sqlTimestamp(event.getDeadline()),
            Utility.getYear(event.getDateStart()),
            event.getWebsite(),
            event.getStatus(),
            event.getName(),
            event.getPubstatus(),
            event.getImageid(),
            event.isUberRegister(),
            event.getShortLink(),
            event.isTestEvent(),
            event.isWebsiteEnabled(),
            event.isHideEvent(),
            event.getPaymentMethods()
            };
        int ret = (Integer)this.genericQryTemplateInteger(EventQuery.UPDATE_BYEVENTID_QRY, obj);
        return ret;
    }

    
    @Override
    public int search(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int search(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    @Override
    public int delete(int id) {
        Object[] obj = new Object[] {id };
        int ret = (Integer)this.genericQryTemplateInteger(EventQuery.DELETE_QRY, obj);
        return ret;
    }

    @Override
    public int delete(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Event get(int id) {
        Object[] obj = new Object[] { id };
        String sqlWhere = " WHERE event_id = ?"  ;
        String finalSQL = EventQuery.SELECT_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);        
    }
    
    
    @Override
    public Event getEventByEuid(String euid) {
        Object[] obj = new Object[] { euid };
        String sqlWhere = " WHERE uid = ?"  ;
        String finalSQL = EventQuery.SELECT_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);        
    }


    @Override
    public Event get(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

     @Override
    public List<Event> getAll(String wherestr) {  
        List<Event> eventList = new ArrayList<Event>();
        eventList = genericQryAllTemplateRowMapper(EventQuery.SELECT_QRY, wherestr); 
        return(eventList);
    }

    @Override
    public List<Event> getAllWithPaging(String wherestr, int pagesize, int first) {
        List<Event> eventList = new ArrayList<Event>();
        eventList = genericQryAllTemplateRowMapperWithPaging(EventQuery.SELECT_QRY, wherestr,  pagesize,  first);
        return(eventList);
    } 

    @Override
    public long getAllCount(String wherestr) {
         return genericQryForInt(EventQuery.SELECT_COUNT_QRY, wherestr);  
    }

    @Override
    public int updateImageFile(int id, int imgId) {
        Object[] obj = new Object[] {id, imgId };
        int ret = (Integer)this.genericQryTemplateInteger(EventQuery.UPDATE_IMG_BYEVENTID_QRY, obj);
        return ret;    }

    @Override
    public int copy(int id, String name) {
        Object[] obj = new Object[] {id, name };
        int ret = (Integer)this.genericQryTemplateInteger(EventQuery.COPY_QRY, obj);
        return ret;
    } 

    @Override
    public PublishSummary getPublishReport() {
        return getJdbcTemplate().queryForObject(EventQuery.SELECT_PUBSTAT_QRY, publishSummaryRowMapper ); 
    }
    
     @Override
    public EventSummary getEventStatusReport() {
        return getJdbcTemplate().queryForObject(EventQuery.SELECT_EVENT_SUMMARY, eventSummaryRowMapper ); 
    }
    
     @Override
    public List<Integer> getAllYear() {
        return ((List<Integer>)getJdbcTemplate().queryForList(EventQuery.SELECT_EVENT_YEAR_QRY,Integer.class));
    }


    /**
     * @return the publishSummaryRowMapper
     */
    public PublishSummaryRowMapper getPublishSummaryRowMapper() {
        return publishSummaryRowMapper;
    }

    /**
     * @param publishSummaryRowMapper the publishSummaryRowMapper to set
     */
    public void setPublishSummaryRowMapper(PublishSummaryRowMapper publishSummaryRowMapper) {
        this.publishSummaryRowMapper = publishSummaryRowMapper;
    }

    /**
     * @return the eventSummaryRowMapper
     */
    public EventSummaryRowMapper getEventSummaryRowMapper() {
        return eventSummaryRowMapper;
    }

    /**
     * @param eventSummaryRowMapper the eventSummaryRowMapper to set
     */
    public void setEventSummaryRowMapper(EventSummaryRowMapper eventSummaryRowMapper) {
        this.eventSummaryRowMapper = eventSummaryRowMapper;
    }

       
    
}
