/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.uam;

import com.danceframe.console.common.model.uam.Syslog;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class SyslogRowMapper implements RowMapper<Syslog> {

    @Override
    public Syslog mapRow(ResultSet rs, int column) throws SQLException {
        final Syslog syslog = new Syslog();
        syslog.setId(rs.getInt("syslog_id"));
        syslog.setAction(rs.getString("action"));
        syslog.setModuleName(rs.getString("modname"));
        syslog.setClassName(rs.getString("classname"));
        syslog.setUserid(rs.getInt("user_id"));
        syslog.setUsername(rs.getString("username"));
        syslog.setLogdate(rs.getTimestamp("logdate"));
        return syslog;
    }
    
}
