/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.payment.impl;

import com.danceframe.console.common.model.payment.Invoice;
import com.danceframe.console.common.model.payment.Payment;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.dataprovider.payment.PaymentProviderDao;
import com.danceframe.console.service.query.payment.InvoiceQuery;
import com.danceframe.console.service.query.payment.PaymentQuery;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author NDB
 */
public class PaymentProviderDaoImpl  extends GenericProviderDaoImpl<Payment> implements PaymentProviderDao {
    @Override
    public int search(int id) {
        Object[] obj = new Object[] {id };
        int ret = (Integer)this.genericQryTemplateInteger(PaymentQuery.SEARCH_BYID_QRY, obj);
        return ret;
    }

    @Override
    public int search(String invoiceId) {
        Object[] obj = new Object[] {Integer.parseInt(invoiceId) };
        int ret = (Integer)this.genericQryTemplateInteger(PaymentQuery.SEARCH_BYINVOICEID_QRY, obj);
        return ret;
    }

    @Override
    public int insert(Payment onePayment) {
        Object[] obj = new Object[] {
            onePayment.getInvoiceId(),
            onePayment.getAmountPaid(),
            onePayment.getTypeOfPayment(),
            onePayment.getPaymentTimestamp(),
            onePayment.getUberConsoleUserId()
            };
         int ret = (Integer)this.genericQryTemplateInteger(PaymentQuery.INSERT_QRY, obj);
        return ret;
    }

    @Override
    public int update(Payment onePayment) {
        Object[] obj = new Object[] {
            onePayment.getId(),
            onePayment.getInvoiceId(),
            onePayment.getAmountPaid(),
            onePayment.getTypeOfPayment(),
            onePayment.getPaymentTimestamp(),
            onePayment.getUberConsoleUserId()
            };
        int ret = (Integer)this.genericQryTemplateInteger(PaymentQuery.UPDATE_QRY, obj);
        return ret;    }

    @Override
    public int delete(int id) {
        Object[] obj = new Object[] { id };
        int ret = (Integer)this.genericQryTemplateInteger(PaymentQuery.DELETE_QRY, obj);
        return ret;
    }
    
    

    @Override
    public int delete(String name) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Payment get(int id) {
        Object[] obj = new Object[] { id };
        String sqlWhere = " WHERE payment_id = ?"  ;
        String finalSQL = PaymentQuery.SELECT_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj); 
    }

    @Override
    public Payment get(String invoiceId) {
        Object[] obj = new Object[] { Integer.parseInt(invoiceId) };
        String sqlWhere = " WHERE UPPER(invoice_id) = UPPER(?)"  ;
        String finalSQL = PaymentQuery.SELECT_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj); 
    }

    @Override
    public List<Payment> getAll(String wherestr) {
        List<Payment> paymentList = new ArrayList<Payment>();
        paymentList = genericQryAllTemplateRowMapper(PaymentQuery.SELECT_QRY, wherestr); 
        return(paymentList);
    }

    @Override
    public List<Payment> getAllWithPaging(String wherestr, int pagesize, int first) {
        List<Payment> paymentList = new ArrayList<Payment>();
        paymentList = genericQryAllTemplateRowMapperWithPaging(PaymentQuery.SELECT_QRY, wherestr,  pagesize,  first);
        return(paymentList);
    }

    @Override
    public long getAllCount(String wherestr) {
         return genericQryForInt(PaymentQuery.SELECT_COUNT_QRY, wherestr);  
    }
}
