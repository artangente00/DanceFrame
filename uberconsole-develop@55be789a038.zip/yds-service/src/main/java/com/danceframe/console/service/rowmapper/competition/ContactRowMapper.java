/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.competition;

import com.danceframe.console.common.model.competition.Contact;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class ContactRowMapper implements RowMapper<Contact>{

    @Override
    public Contact mapRow(ResultSet rs, int column) throws SQLException {
       final Contact contact = new Contact();        
        contact.setId(rs.getInt("contact_id"));        
        contact.setName(rs.getString("name"));
        contact.setAddress(rs.getString("address"));
        contact.setAddress2(rs.getString("address2"));
        contact.setCity(rs.getString("city"));
        contact.setProvince(rs.getString("province"));
        contact.setCountry(rs.getString("country"));
        contact.setZipcode(rs.getString("zipcode"));
        contact.setPhone(rs.getString("phone"));
        contact.setFax(rs.getString("fax"));	
        contact.setEmail(rs.getString("email"));
        contact.setEventid(rs.getInt("event_id"));
        return contact;
    }
    
}
