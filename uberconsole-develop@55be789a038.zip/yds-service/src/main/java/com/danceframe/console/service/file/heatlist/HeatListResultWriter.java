/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.file.heatlist;

import java.io.FileNotFoundException;
import java.io.IOException;

/**
 *
 * @author lmorallos
 */
public interface HeatListResultWriter {
    
    boolean writeToFile(String tmppath, String outputfile, int eventId) throws FileNotFoundException, IOException;

}
