/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.registration.impl;

import com.danceframe.console.common.model.registration.RegEntry;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.query.RegistrationQuery;
import java.util.ArrayList;
import java.util.List;
import com.danceframe.console.service.dataprovider.registration.RegEntryProviderDao;

/**
 *
 * @author lmorallos
 */
public class RegEntryProviderDaoImpl extends GenericProviderDaoImpl<RegEntry> implements RegEntryProviderDao{

    @Override
    public int search(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int search(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

            
    @Override
    public int insert(RegEntry dance) {
        Object[] obj = new Object[] { 
            dance.getBuid(),
            dance.getEuid(),
            dance.getCuid(),
            dance.getFormId(),
            dance.getAgeId(),
            dance.getLevelId(),
            dance.getDanceId(),
            dance.getDanceCatId()            
        };
        int ret = (Integer)this.genericQryTemplateInteger(RegistrationQuery.INSERT_REGENTRY_QRY, obj);
        return ret;
    }

    @Override
    public int update(RegEntry dance) {
         Object[] obj = new Object[] { 
            dance.getBuid(),
            dance.getEuid(),
            dance.getCuid(),
            dance.getIuid(),
            dance.getFormId(),
            dance.getAgeId(),
            dance.getLevelId(),
            dance.getDanceId(),
            dance.getDanceCatId()            
        };
        int ret = (Integer)this.genericQryTemplateInteger(RegistrationQuery.UPDATE_REGENTRY_QRY, obj);
        return ret;
    }

    @Override
    public int delete(int id) {
        Object[] obj = new Object[] { id };
        int ret = (Integer)this.genericQryTemplateInteger(RegistrationQuery.DELETE_REGENTRY_QRY, obj);
        return ret;
    }

    @Override
    public int delete(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public RegEntry get(int id) {
        Object[] obj = new Object[] { id };
        String sqlWhere = " WHERE regentry_id = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGENTRY_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);   
    }

    @Override
    public RegEntry get(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RegEntry> getAll(String wherestr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RegEntry> getAllWithPaging(String wherestr, int pagesize, int pagenumber) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public long getAllCount(String wherestr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public RegEntry get(int regentryId, String euid) {
         Object[] obj = new Object[] { regentryId, euid };
        String sqlWhere = " WHERE regentry_id = ? AND euid = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGENTRY_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);   
    }

    @Override
    public List<RegEntry> getEntryByEventUID(String euid) {
        List<RegEntry> entryList = new ArrayList<>();
        Object[] obj = new Object[] { euid };
        String sqlWhere = " WHERE euid = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGENTRY_QRY + sqlWhere;
        entryList =  genericQryAllTemplateRowMapper(finalSQL, obj);
        return entryList;    
    }

    @Override
    public List<RegEntry> getEntryByCompetitorAndEUID(String cuid, String euid) {
        List<RegEntry> entryList = new ArrayList<>();
        Object[] obj = new Object[] { euid };
        String sqlWhere = " WHERE cuid = ? AND euid = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGENTRY_QRY + sqlWhere;
        entryList =  genericQryAllTemplateRowMapper(finalSQL, obj);
        return entryList;
    }

    @Override
    public List<RegEntry> getEntriesByEvent(String buid, String euid) {
        List<RegEntry> entryList = new ArrayList<>();
        Object[] obj = new Object[] { euid };
        String sqlWhere = " WHERE buid = ? AND euid = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGENTRY_QRY + sqlWhere;
        entryList =  genericQryAllTemplateRowMapper(finalSQL, obj);
        return entryList;
    }

    @Override
    public List<RegEntry> getEntryByCompetitors(String buid, String euid, String cuid) {
         List<RegEntry> entryList = new ArrayList<>();
        Object[] obj = new Object[] { euid };
        String sqlWhere = " WHERE buid = ? AND euid = ? AND cuid = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGENTRY_QRY + sqlWhere;
        entryList =  genericQryAllTemplateRowMapper(finalSQL, obj);
        return entryList;
    }

   
    
}
