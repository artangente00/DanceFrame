/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.constant;

/**
 *
 * @author lmorallos
 */
public final class Lookup {
    
    public final static String EVENT_STATUS = "EVTSTAT";
    
    public final static String NOYES = "NOYES";
    
    public final static String PUBLISH_STATUS = "PUBSTAT";
    
    public final static String FORM_TYPE = "CF-FORMTYPE";
    
    public final static String FORM_HEADER_TYPE = "CF-HEADTYPE";

    public final static String FORM_ENTRY_TYPE = "CF-ENTRYTYPE";
    
    public final static String FORM_FIELD = "CF-FIELD";
    
	public final static String VENUE_COUNTRY = "COUNTRY";
}
