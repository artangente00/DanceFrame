/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.competition;

import com.danceframe.console.common.model.competition.FormData;
import com.danceframe.console.common.model.firebase.competition.GenericFormData;
import com.danceframe.console.service.dataprovider.GenericProviderDao;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public interface GenericFormProviderDao extends GenericProviderDao<FormData> {
    
    int insertToEvent(int eventId, int code, int oldEventId);
    
    int updateToEvent(int eventId, int code);
    
    int moveEventToTemp(int eventId, int code);
    
    int cleanupTemp(int eventId);
    
    int updateImageId(int id, int imgId);
    
    int lastOrder(int eventId, String code);
    
    long countData(int eventId, String code);
    
    List<GenericFormData> getFormData(int eventId, String code);

}
