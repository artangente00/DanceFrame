/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query.competition.config;

/**
 *
 * @author lmorallos
 */
public final class EventFormQuery {
    
    public static final String SELECT_QRY =  "SELECT eventform_id,event_id,form_id,"
            + "formtype,headertype,entrytype,event_name,form_name,formtype_name,headertype_name, entrytype_name "
            + "FROM uberconsole.VW_EVENT_CONFIGFORM";
    
     public static final String SELECT_COUNT_QRY =  "SELECT COUNT(eventform_id)"
            + " FROM uberconsole.VW_EVENT_CONFIGFORM";
     
    public static final String INSERT_QRY = "SELECT uberconsole.FN_EVENTFORM_INSERT( ?, ?, ?, ?, ?)";
    
    public static final String DELETE_QRY = "SELECT uberconsole.FN_EVENTFORM_DELETE( ? )";
    
   
    
}
