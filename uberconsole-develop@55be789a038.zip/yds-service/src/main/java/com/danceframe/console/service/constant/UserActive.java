/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.constant;

/**
 *
 * @author lmorallos
 */
public final class UserActive {
    
    public static final boolean ACTIVE = true;
    
    public static final boolean INACTIVE = false;
    
}
