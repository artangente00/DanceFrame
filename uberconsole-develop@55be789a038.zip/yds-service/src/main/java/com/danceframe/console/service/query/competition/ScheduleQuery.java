/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query.competition;

/**
 *
 * @author lmorallos
 */
public final class ScheduleQuery {
    
    public static final String SELECT_SCHEDULE_QRY = "SELECT schedule_id, event_id, sched_name FROM uberconsole.tbl_schedule";
        
    public static final String SELECT_SCHEDULEDATA_QRY = "SELECT schedlist_id,header_name, hdrorder, timevalue, tvalorder, description, event_id FROM  uberconsole.tbl_tmpschedlist";
    
    public static final String SELECT_SCHEDFINALDATA_QRY = "SELECT schedlist_id,header_name, hdrorder, timevalue, tvalorder, description, event_id FROM  uberconsole.tbl_schedlist";
    
    public static final String INSERT_SCHEDULE_QRY = "SELECT uberconsole.FN_SCHEDULE_INSERT_WITH_EVENTID(?, ?, ?)";
    
    public static final String UPDATE_SCHEDULE_QRY = "SELECT uberconsole.FN_SCHEDULE_UPDATE_BYEVENTID(?, ?)";
    
    public static final String INSERT_SCHEDULEDATA_QRY = "SELECT uberconsole.FN_SCHEDULE_LIST_INSERT_WITH_EVENTID(?, ?, ?, ?, ?, ?)";
    
    public static final String UPDATE_SCHEDULEDATA_QRY = "SELECT uberconsole.FN_SCHEDULE_LIST_UPDATE_WITH_EVENTID(?, ?, ?, ?, ?, ?, ?)";
    
    public static final String DELETE_SCHEDULEDATA_QRY  = "SELECT uberconsole.FN_SCHEDULE_LIST_DELETEBYID(?)";
    
    public static final String SELECT_SCHEDULEDATA_TMPIDQRY = "SELECT nextval('uberconsole.seqtmpevent')";
        
    public static final String SELECT_SCHEDULEDATA_COUNTQRY = "SELECT count(event_id) FROM  uberconsole.tbl_tmpschedlist";

    public static final String DELETE_SCHEDULEDTMPATA_QRY = "SELECT uberconsole.FN_SCHEDULE_LIST_CLEANTMPBYID( ? );";

    public static final String SELECT_SCHEDULEDATA_HEADER_QRY = "SELECT DISTINCT header_name FROM uberconsole.tbl_tmpschedlist WHERE event_id=?";
    
    public static final String SELECT_SCHEDULEDATA_HDRORDERLAST_QRY = "SELECT DISTINCT hdrorder FROM uberconsole.tbl_tmpschedlist WHERE event_id=? ORDER BY hdrorder desc limit 1";
    
    public static final String SELECT_SCHEDULEDATA_TVALORDERLAST_QRY = "SELECT DISTINCT tvalorder FROM uberconsole.tbl_tmpschedlist WHERE header_name=? AND event_id=? ORDER BY tvalorder desc limit 1";
    
    public static final String SELECT_SCHEDULEDATA_HDRORDER_QRY = "SELECT DISTINCT hdrorder FROM uberconsole.tbl_tmpschedlist WHERE header_name=? AND event_id=?";

    public static final String MOVE_SCHEDULEDATA_QRY  = "SELECT uberconsole.FN_SCHEDULE_LIST_MOVETO_TMP(?)";
    
}
