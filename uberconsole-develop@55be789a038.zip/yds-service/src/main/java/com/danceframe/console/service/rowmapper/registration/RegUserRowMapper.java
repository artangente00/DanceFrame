/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.registration;

import com.danceframe.console.common.model.registration.RegUser;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class RegUserRowMapper implements RowMapper<RegUser> {

    @Override
    public RegUser mapRow(ResultSet rs, int i) throws SQLException {
        final RegUser retuser = new RegUser();
        retuser.setId(rs.getInt("reguser_id"));
        retuser.setBgoId(rs.getString("bgoid"));
        retuser.setBuid(rs.getString("buid"));
        retuser.setLastName(rs.getString("lastname"));
        retuser.setFirstName(rs.getString("firstname"));
        retuser.setMiddleName(rs.getString("midname"));
        retuser.setEmail(rs.getString("email"));
        retuser.setGender(rs.getString("gender"));
        retuser.setCategory(rs.getString("category"));
        retuser.setLoginProvider(rs.getString("loginprovider"));
        retuser.setLastModified(rs.getTimestamp("last_modified"));
        retuser.setSignInDate(rs.getTimestamp("signin_date"));
        retuser.setCreationDate(rs.getTimestamp("create_date"));
        return retuser;
    }
    
}
