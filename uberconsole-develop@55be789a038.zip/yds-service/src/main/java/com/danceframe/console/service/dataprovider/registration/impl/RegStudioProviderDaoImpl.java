/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.registration.impl;

import com.danceframe.console.common.model.registration.RegStudio;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.dataprovider.registration.RegStudioProviderDao;
import com.danceframe.console.service.query.RegistrationQuery;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public class RegStudioProviderDaoImpl extends GenericProviderDaoImpl<RegStudio> implements RegStudioProviderDao{

    @Override
    public int search(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int search(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

            
    @Override
    public int insert(RegStudio studio) {
        Object[] obj = new Object[] { 
            studio.getBuid(),
            studio.getEuid(),
            studio.getName(),
            studio.getContactLastname(),
            studio.getContactFirstname(),
            studio.getAddress1(),
            studio.getAddress2(),
            studio.getCity(),
            studio.getState(),
            studio.getPostal(),
            studio.getCountry(),
            studio.getPhone(),
            studio.getEmail()
        };
        int ret = (Integer)this.genericQryTemplateInteger(RegistrationQuery.INSERT_REGSTUDIO_QRY, obj);
        return ret;
    }
        
    @Override
    public int update(RegStudio studio) {
         Object[] obj = new Object[] { 
            studio.getBuid(),
            studio.getEuid(),
            studio.getSuid(), 
            studio.getName(),
            studio.getContactLastname(),
            studio.getContactFirstname(),
            studio.getAddress1(),
            studio.getAddress2(),
            studio.getCity(),
            studio.getState(),
            studio.getPostal(),
            studio.getCountry(),
            studio.getPhone(),
            studio.getEmail()
        };
        int ret = (Integer)this.genericQryTemplateInteger(RegistrationQuery.UPDATE_REGSTUDIO_QRY, obj);
        return ret;
    }

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public RegStudio get(int id) {
        Object[] obj = new Object[] { id };
        String sqlWhere = " WHERE regstudio_id = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGSTUDIO_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);    
    }

    @Override
    public RegStudio get(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RegStudio> getAll(String wherestr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RegStudio> getAllWithPaging(String wherestr, int pagesize, int pagenumber) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public long getAllCount(String wherestr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public RegStudio get(int studioId, String euid) {
        Object[] obj = new Object[] { studioId, euid };
        String sqlWhere = " WHERE studio_id = ? AND euid = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGSTUDIO_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);    
    }
    
    @Override
    public List<RegStudio> getStudiosByEventUID(String euid) {
        List<RegStudio> studioList = new ArrayList<>();
        Object[] obj = new Object[] { euid };
        String sqlWhere = " WHERE euid = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGSTUDIO_QRY + sqlWhere;
        studioList =  genericQryAllTemplateRowMapper(finalSQL, obj);
        return studioList;    
    }

    @Override
    public RegStudio get(String suid, String euid) {
        Object[] obj = new Object[] { suid, euid };
        String sqlWhere = " WHERE suid = ? AND euid = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGSTUDIO_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);    
    }

    @Override
    public RegStudio get(String buid, String euid, String suid) {
        Object[] obj = new Object[] { buid, euid, suid};
        String sqlWhere = " WHERE buid = ? AND euid = ? AND suid = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGSTUDIO_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);    
    }

    @Override
    public List<RegStudio> getStudiosByEvent(String buid, String euid) {
        List<RegStudio> studioList = new ArrayList<>();
        Object[] obj = new Object[] { euid };
        String sqlWhere = " WHERE buid = ? AND euid = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGSTUDIO_QRY + sqlWhere;
        studioList =  genericQryAllTemplateRowMapper(finalSQL, obj);
        return studioList;   
    }
    
}
