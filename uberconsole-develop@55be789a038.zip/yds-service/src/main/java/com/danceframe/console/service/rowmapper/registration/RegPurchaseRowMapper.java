/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.registration;

import com.danceframe.console.common.model.registration.RegPurchase;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class RegPurchaseRowMapper implements RowMapper<RegPurchase>{

    @Override
    public RegPurchase mapRow(ResultSet rs, int i) throws SQLException {
        final RegPurchase purchase = new RegPurchase();
        purchase.setId(rs.getInt("purchase_id"));
        purchase.setCode(rs.getString("purchaser_code"));
        purchase.setType(rs.getString("purchaser_type"));
        purchase.setItemCode(rs.getString("item_code"));
        purchase.setItemCount(rs.getString("item_count"));
        purchase.setCreationDate(rs.getTimestamp("create_date"));
        purchase.setLastModified(rs.getTimestamp("last_modified"));
        purchase.setEventId(rs.getInt("event_id"));
        purchase.setEuid(rs.getString("euid"));    
        purchase.setUserId(rs.getInt("reguser_id"));
        purchase.setBuid(rs.getString("buid"));
        return purchase;
    }
    
}
