/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.heatlist;

import com.danceframe.console.common.model.heatlist.HeatPerson;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class HeatListPersonRowMapper implements RowMapper<HeatPerson> {

    @Override
    public HeatPerson mapRow(ResultSet rs, int column) throws SQLException {
        final HeatPerson person = new HeatPerson();
        person.setId(rs.getInt("person_id"));
        person.setCompMgrId(rs.getString("personcpm_id"));
        person.setLastName(rs.getString("lastname"));
        person.setFirstName(rs.getString("firstname"));
        person.setSex(rs.getString("sex"));
        person.setProfType(rs.getString("profile_type"));
        person.setStudioId(rs.getInt("studio_id"));
        person.setStudioCmpId(rs.getString("studiocpm_id"));
        person.setHeatListId(rs.getInt("heatlist_id"));
        return person;
    }

}
