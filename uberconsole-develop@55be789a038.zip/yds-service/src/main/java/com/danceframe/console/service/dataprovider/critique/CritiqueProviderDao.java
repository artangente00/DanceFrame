/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.critique;

import com.danceframe.console.common.model.critique.xml.HeatResultCouple;
import com.danceframe.console.common.model.critique.xml.HeatResultCoupleEntry;
import com.danceframe.console.common.model.critique.xml.HeatResultHeat;
import com.danceframe.console.common.model.critique.xml.HeatResultJudge;
import com.danceframe.console.common.model.critique.xml.HeatResultMark;
import com.danceframe.console.common.model.critique.xml.HeatResultPerson;
import com.danceframe.console.common.model.critique.xml.HeatResultProgram;
import com.danceframe.console.common.model.critique.xml.HeatResultResult;
import com.danceframe.console.common.model.critique.xml.HeatResultSoloEntry;
import com.danceframe.console.common.model.critique.xml.HeatResultStudio;
import com.danceframe.console.common.model.critique.xml.HeatResultSubHeat;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public interface CritiqueProviderDao {
    
    int clearByEventId(int eventId);
    
    int insertProgram(HeatResultProgram program);
    
    int insertStudio(HeatResultStudio studio);
    
    int insertPerson(HeatResultPerson person);
    
    int insertJudge(HeatResultJudge judge);
    
    int insertCouple(HeatResultCouple couple);
    
    int coupleSearch(int coupleId, int eventId);
    
    int insertHeat(HeatResultHeat heat);
    
    int insertSubHeat(HeatResultSubHeat subheat);
    
    int insertEntry(HeatResultCoupleEntry entry);
    
    int insertSoloEntry(HeatResultSoloEntry solo);
    
    int insertResult(HeatResultResult result);
    
    int insertMark(HeatResultMark mark);
    
    List<HeatResultStudio> getStudios(int eventId);
    
    List<HeatResultJudge> getJudges(int eventId);
     
    List<HeatResultPerson> getPersons(int eventId);
      
    List<HeatResultCouple> getCouples(int eventId);
    
    List<HeatResultHeat> getHeats(int eventId);
    
    List<HeatResultSubHeat> getSubHeats(int eventId, int heatId);
    
    List<HeatResultCoupleEntry> getEntries(int eventId, int subHeatId);
    
    List<HeatResultSoloEntry> getSoloEntries(int eventId, int subHeatId);
    
    List<HeatResultResult> getResult(int eventId, int subHeatId);
    
    List<HeatResultMark> getMarks(int eventId, int subHeatId, int resultId);

}
