/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.competition.impl;

import com.danceframe.console.common.model.competition.Schedule;
import com.danceframe.console.service.dataprovider.competition.ScheduleProviderDao;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.query.competition.ScheduleQuery;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public class ScheduleProviderDaoImpl extends GenericProviderDaoImpl<Schedule> implements ScheduleProviderDao {

    @Override
    public int insert(Schedule schedule, int oldeventid) {
         Object[] obj = new Object[] { 
            schedule.getEventId(),
            schedule.getSchedName(),
            oldeventid
        };
        int ret = (Integer)this.genericQryTemplateInteger(ScheduleQuery.INSERT_SCHEDULE_QRY, obj);
        return ret;     
    }

    @Override
    public int update(Schedule schedule) {
        Object[] obj = new Object[] { 
            schedule.getEventId(),
            schedule.getSchedName()
        };
        int ret = (Integer)this.genericQryTemplateInteger(ScheduleQuery.UPDATE_SCHEDULE_QRY, obj);
        return ret;  
    }

    @Override
    public Schedule get(int eventid) {
         Object[] obj = new Object[] { eventid };
        String sqlWhere = " WHERE event_id = ?"  ;
        String finalSQL = ScheduleQuery.SELECT_SCHEDULE_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);   
    }
    
    @Override
    public List<Schedule> getAll(String wherestr) {
        List<Schedule> schedList = new ArrayList<Schedule>();
        schedList = genericQryAllTemplateRowMapper(ScheduleQuery.SELECT_SCHEDULE_QRY, wherestr); 
        return(schedList);
    }

    @Override
    public List<Schedule> getAllWithPaging(String wherestr, int pagesize, int first) {
        List<Schedule> schedList = new ArrayList<Schedule>();
        schedList = genericQryAllTemplateRowMapperWithPaging(ScheduleQuery.SELECT_SCHEDULE_QRY , wherestr,  pagesize,  first); 
        return(schedList);
    }

    @Override
    public long getAllCount(String wherestr) {
        return genericQryForInt(ScheduleQuery.SELECT_SCHEDULE_QRY, wherestr);
    }
    
    @Override
    public int search(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int search(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    

    @Override
    public Schedule get(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int insert(Schedule t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    

    
}
