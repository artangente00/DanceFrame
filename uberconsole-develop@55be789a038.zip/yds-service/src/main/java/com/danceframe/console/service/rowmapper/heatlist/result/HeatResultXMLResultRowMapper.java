/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.heatlist.result;

import com.danceframe.console.common.model.heatlist.result.HeatlistResultXML;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author l;morallos
 */
public class HeatResultXMLResultRowMapper implements RowMapper<HeatlistResultXML> {
    
      @Override
    public HeatlistResultXML mapRow(ResultSet rs, int i) throws SQLException {
        final HeatlistResultXML xmldata = new HeatlistResultXML();
        xmldata.setId(rs.getInt("xml_id"));
        xmldata.setFilename(rs.getString("filename"));
        xmldata.setUploadtime(rs.getDate("uploadtime"));
        xmldata.setCode(rs.getString("code"));
        xmldata.setEventId(rs.getInt("event_id"));
        xmldata.setData(rs.getBytes("xmldata"));     
        return xmldata;
    }

}
