/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.heatlist.result;

import com.danceframe.console.common.model.heatlist.result.HeatResultStudio;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class HeatResultStudioRowMapper implements RowMapper<HeatResultStudio> {

    @Override
    public HeatResultStudio mapRow(ResultSet rs, int i) throws SQLException {
        final  HeatResultStudio studio = new HeatResultStudio();
        studio.setId(rs.getInt("studio_id"));
        studio.setStudioKey(rs.getString("studio_key"));
        studio.setName(rs.getString("name"));
        studio.setIndependentInvoice(rs.getString("invoice"));
        studio.setEventId(rs.getInt("event_id"));
        studio.setXmlId(rs.getInt("xml_id"));
        return studio;
    }
}
