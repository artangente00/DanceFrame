/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.competition.impl;

import com.danceframe.console.common.model.competition.Contact;
import com.danceframe.console.service.dataprovider.competition.ContactProviderDao;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.query.competition.ContactQuery;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public class ContactProviderDaoImpl extends GenericProviderDaoImpl<Contact> implements ContactProviderDao {

    
    @Override
    public int search(int id) {
        Object[] obj = new Object[] {id };
        int ret = (Integer)this.genericQryTemplateInteger(ContactQuery.SEARCHBYID_QRY, obj);
        return ret;
    }

    @Override
    public int search(String name) {
        Object[] obj = new Object[] {name };
        int ret = (Integer)this.genericQryTemplateInteger(ContactQuery.SEARCHBYNAME_QRY, obj);
        return ret;
    }
   
                
    @Override
    public int insert(Contact contact) {
         Object[] obj = new Object[] {
            contact.getEventid(),
            contact.getName(),
            contact.getAddress(),
            contact.getAddress2(),
            contact.getCity(),
            contact.getProvince(),           
            contact.getCountry(),
            contact.getZipcode(),
            contact.getPhone(),            
            contact.getFax(),
            contact.getEmail()
         };
        int ret = (Integer)this.genericQryTemplateInteger(ContactQuery.INSERT_QRY, obj);
        return ret;
    }

    @Override
    public int update(Contact contact) {
         Object[] obj = new Object[] {
            contact.getEventid(),
            contact.getName(),
            contact.getAddress(),
            contact.getAddress2(),
            contact.getCity(),
            contact.getProvince(),           
            contact.getCountry(),
            contact.getZipcode(),
            contact.getPhone(),      
            contact.getFax(),
            contact.getEmail()
         };
        int ret = (Integer)this.genericQryTemplateInteger(ContactQuery.UPDATEBYEVENTID_QRY, obj);
        return ret;
    }

    @Override
    public int delete(int id) {
        Object[] obj = new Object[] {id };
        int ret = (Integer)this.genericQryTemplateInteger(ContactQuery.DELETEBYID_QRY, obj);
        return ret;
    }

    @Override
    public int delete(String name) {
         throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Contact get(int id) {
        Object[] obj = new Object[] { id };
        String sqlWhere = " WHERE contact_id = ?"  ;
        String finalSQL =  ContactQuery.SELECT_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);    
    }

    @Override
    public Contact get(String name) {
       Object[] obj = new Object[] { name };
        String sqlWhere = " WHERE name = ?"  ;
        String finalSQL =  ContactQuery.SELECT_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);    
    }
    
     @Override
    public List<Contact> getAll(String wherestr) {        
        List<Contact> contactList = new ArrayList<Contact>();
        contactList = genericQryAllTemplateRowMapper(ContactQuery.SELECT_QRY, wherestr);
        return(contactList);
    }

    @Override
    public List<Contact> getAllWithPaging(String wherestr, int pagesize, int first) {   
        List<Contact> contactList = new ArrayList<Contact>();
        contactList = genericQryAllTemplateRowMapperWithPaging(ContactQuery.SELECT_QRY, 
                wherestr,  pagesize,  first);
        return(contactList);
    }  

    @Override
    public Contact getByEventId(int id) {
        Object[] obj = new Object[] { id };
        String sqlWhere = " WHERE event_id = ?"  ;
        String finalSQL =  ContactQuery.SELECT_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);    
    }

    @Override
    public long getAllCount(String wherestr) {
        return genericQryForInt(ContactQuery.SELECT_COUNT_QRY, wherestr);  
    }
       
}
