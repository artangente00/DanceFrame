/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query.competition.config;

/**
 *
 * @author lmorallos
 */
public class EventFormFieldQuery {
    
    public final static String INSERT_QRY = "SELECT uberconsole.FN_EVENTFORM_FIELD_INSERT(?, ?, ?)";
    
    public final static String DELETE_QRY = "";
    
    public final static String SEARCH_QRY = "SELECT uberconsole.FN_EVENTFORM_FIELD_SEARCHBYFORMID(?)";
        
    public final static String SELECT_QRY = "SELECT eventfield_id, eventform_id, field_name,linkto FROM uberconsole.tbl_eventform_field";
    
    public final static String SELECT_COUNT_QRY = "SELECT count(eventfield_id) FROM uberconsole.tbl_eventform_field";
}
