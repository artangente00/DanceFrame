/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.heatlist.impl;

import com.danceframe.console.common.model.heatlist.result.MasterPerson;
import com.danceframe.console.service.dataprovider.heatlist.HeatListResultMasterPersonProviderDao;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.query.heatlist.HeatListResultQuery;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public class HeatListResultMasterPersonProviderDaoImpl extends GenericProviderDaoImpl<MasterPerson> implements  HeatListResultMasterPersonProviderDao {

    @Override
    public int search(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int search(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int insert(MasterPerson t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int update(MasterPerson person) {
        Object[] obj = new Object[] {
            person.getId(),
            person.getFirstname(),
            person.getLastname()
        };
        int ret = (Integer)this.genericQryTemplateInteger(HeatListResultQuery.SELECT_MASTERPERSON_EDIT, obj);
        return ret;
    }

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public MasterPerson get(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public MasterPerson get(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<MasterPerson> getAll(String wherestr) {
         List<MasterPerson> mpersonList = new ArrayList<MasterPerson>();
        mpersonList = genericQryAllTemplateRowMapper(HeatListResultQuery.SELECT_MASTERPERSON, wherestr);
        return(mpersonList);
    }

    @Override
    public List<MasterPerson> getAllWithPaging(String wherestr, int pagesize, int first) {
        List<MasterPerson> mpersonList = new ArrayList<MasterPerson>();
        mpersonList = genericQryAllTemplateRowMapperWithPaging(HeatListResultQuery.SELECT_MASTERPERSON, wherestr,  pagesize,  first);
        return(mpersonList);
    }

    @Override
    public long getAllCount(String wherestr) {
        return genericQryForInt(HeatListResultQuery.SELECT_MASTERPERSON_COUNT, wherestr);
    }

    @Override
    public int unifiedMasterPerson(int newid, int oldid) {
        int ret = 0;
    
         Object[] obj = new Object[] {
            newid, oldid
        };
        try {
         ret = (Integer)this.genericQryTemplateInteger(HeatListResultQuery.SELECT_MASTERPERSON_UNIFIED, obj);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return ret;
    }

    @Override
    public int getMasterPersonIdByNames(String firstname, String lastname) {
        Object[] obj = new Object[] { firstname, lastname };
        int ret = (Integer)this.genericQryTemplateInteger(HeatListResultQuery.SELECT_MASTERPERSON_ID_BYNAME, obj);
        return ret;
    }

    @Override
    public String getMasterPersonUIDById(int masterPersonId) {
        String uid = null;
        Object[] obj = new Object[] { masterPersonId };
        uid = (String)this.genericQryTemplateString(HeatListResultQuery.SELECT_MASTERPERSON_UID_BYID, obj);
        return uid;
    }


    @Override
    public String getMasterPersonUIDByNames(String firstname, String lastname) {
        String uid = null;
        Object[] obj = new Object[] { firstname, lastname };
        uid = (String)this.genericQryTemplateString(HeatListResultQuery.SELECT_MASTERPERSON_UID_BYNAME, obj);
        return uid;
    }

    @Override
    public int getMasterPersonUIDById(String uid) {
         Object[] obj = new Object[] { uid };
        int ret = (Integer)this.genericQryTemplateInteger(HeatListResultQuery.SELECT_MASTERPERSON_ID_BYUID, obj);
        return ret;
    }
    
}
