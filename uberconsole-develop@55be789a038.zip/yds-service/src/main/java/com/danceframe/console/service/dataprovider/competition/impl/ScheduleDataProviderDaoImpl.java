/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.competition.impl;

import com.danceframe.console.common.model.competition.ScheduleData;
import com.danceframe.console.service.dataprovider.competition.ScheduleDataProviderDao;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.query.competition.ScheduleQuery;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public class ScheduleDataProviderDaoImpl extends GenericProviderDaoImpl<ScheduleData> implements ScheduleDataProviderDao {

    @Override
    public int insert(ScheduleData scheddata) {
        Object[] obj = new Object[] {
            scheddata.getEventId(),
            scheddata.getHeaderName(),
            scheddata.getHdrOrder(),
            scheddata.getTimeValue(),
            scheddata.getTvalOrder(),
            scheddata.getDescription()
        } ;
        int ret = (Integer)this.genericQryTemplateInteger(ScheduleQuery.INSERT_SCHEDULEDATA_QRY, obj);
        return ret;  
    }

    @Override
    public int update(ScheduleData scheddata) {
         Object[] obj = new Object[] {
            scheddata.getId(),
            scheddata.getHeaderName(),
            scheddata.getHdrOrder(),
            scheddata.getTimeValue(),
            scheddata.getTvalOrder(),
            scheddata.getDescription(),
            scheddata.getEventId()
        } ;
        int ret = (Integer)this.genericQryTemplateInteger(ScheduleQuery.UPDATE_SCHEDULEDATA_QRY, obj);
        return ret;  
    }

    @Override
    public int deleteTmpDataByID(int eventId) {
        Object[] obj = new Object[] { eventId } ;
        int ret = (Integer)this.genericQryTemplateInteger(ScheduleQuery.DELETE_SCHEDULEDTMPATA_QRY, obj);
        return ret;  
    }

     
    @Override
    public int delete(int id) {
        Object[] obj = new Object[] { id } ;
        int ret = (Integer)this.genericQryTemplateInteger(ScheduleQuery.DELETE_SCHEDULEDATA_QRY, obj);
        return ret;  
    }
    
     @Override
    public ScheduleData get(int id) {
        Object[] obj = new Object[] { id };
        String sqlWhere = " WHERE schedlist_id = ?"  ;
        String finalSQL = ScheduleQuery.SELECT_SCHEDULEDATA_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);   
    }
    
    @Override
    public List<ScheduleData> getAll(String wherestr) {
        List<ScheduleData> scheddataList = new ArrayList<ScheduleData>();
        scheddataList = genericQryAllTemplateRowMapper(ScheduleQuery.SELECT_SCHEDULEDATA_QRY, wherestr); 
        return(scheddataList);
    }

    @Override
    public List<ScheduleData> getAllWithPaging(String wherestr, int pagesize, int first) {
        List<ScheduleData> scheddataList = new ArrayList<ScheduleData>();
        scheddataList = genericQryAllTemplateRowMapperWithPaging(ScheduleQuery.SELECT_SCHEDULEDATA_QRY , wherestr,  pagesize,  first); 
        return(scheddataList);
    }

    @Override
    public List<String> getHeaderNames(int eventId) {
        Object[] obj = new Object[] { eventId };
        return genericQryForList(ScheduleQuery.SELECT_SCHEDULEDATA_HEADER_QRY, obj);
    }

    @Override
    public long getAllCount(String wherestr) {
        return genericQryForInt(ScheduleQuery.SELECT_SCHEDULEDATA_COUNTQRY, wherestr);  
    }
    
    @Override
    public int getTmpEventId() {
        return (genericQryForInt(ScheduleQuery.SELECT_SCHEDULEDATA_TMPIDQRY));
    }
    
    @Override
    public int getLastHeaderOrder(int eventId) {
        Object[] obj = new Object[] { eventId } ;
        int ret = (Integer)this.genericQryTemplateInteger(ScheduleQuery.SELECT_SCHEDULEDATA_HDRORDERLAST_QRY, obj);
        return ret;  
    }

    @Override
    public int getLastTimeValueOrder(String headerName, int eventId) {
        Object[] obj = new Object[] { headerName, eventId } ;
        int ret = (Integer)this.genericQryTemplateInteger(ScheduleQuery.SELECT_SCHEDULEDATA_TVALORDERLAST_QRY, obj);
        return ret;
    }

    @Override
    public int getHeaderOrder(String headerName, int eventId) {
         Object[] obj = new Object[] { headerName, eventId } ;
        int ret = (Integer)this.genericQryTemplateInteger(ScheduleQuery.SELECT_SCHEDULEDATA_HDRORDER_QRY, obj);
        return ret;  
    }

    @Override
    public int movetoTemporary(int eventId) {
         Object[] obj = new Object[] { eventId } ;
        int ret = (Integer)this.genericQryTemplateInteger(ScheduleQuery.MOVE_SCHEDULEDATA_QRY, obj);
        return ret;
    }
    
    @Override
    public List<ScheduleData> getAllData(String wherestr) {
        List<ScheduleData> scheddataList = new ArrayList<ScheduleData>();
        scheddataList = genericQryAllTemplateRowMapper(ScheduleQuery.SELECT_SCHEDFINALDATA_QRY, wherestr); 
        return(scheddataList);
     }
    
    @Override
    public int search(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int search(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ScheduleData get(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

       
}
