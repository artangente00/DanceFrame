/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.competition.impl;

import com.danceframe.console.common.model.competition.Enablement;
import com.danceframe.console.service.dataprovider.competition.EnablementProviderDao;
import com.danceframe.console.service.dataprovider.impl.BaseJdbcDaoImpl;
import com.danceframe.console.service.query.competition.EnablementQuery;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class EnablementProviderDaoImpl extends BaseJdbcDaoImpl implements EnablementProviderDao {

    private RowMapper<Enablement> rowMapper;
    
    @Override
    public int insert(Enablement en) {
        Object[] obj = new Object[] {
             en.getEventId(),
             en.isVenueEnable(), 
             en.isContactEnable(), 
             en.isOrganizerEnable(), 
             en.isScheduleEnable(), 
             en.isHotelEnable(), 
             en.isSponsorEnable(),
             en.isInformationEnable(),
             en.isFinanceEnable()
                 };
         return(getJdbcTemplate().queryForObject(EnablementQuery.INSERT_ENABLE_QRY, obj, Integer.class));   
    }

    @Override
    public int update(Enablement en) {
        Object[] obj = new Object[] {
             en.getEventId(),
             en.isVenueEnable(), 
             en.isContactEnable(), 
             en.isOrganizerEnable(), 
             en.isScheduleEnable(), 
             en.isHotelEnable(), 
             en.isSponsorEnable(),
             en.isInformationEnable(),
             en.isFinanceEnable()
                 };
         return( getJdbcTemplate().queryForObject(EnablementQuery.UPDATE_ENABLE_QRY, obj, Integer.class));   
    }

    @Override
    public Enablement get(int eventId) {
        Object[] obj = new Object[] { eventId };
        String sqlWhere = " WHERE event_id=?"  ;
        String finalSQL =  EnablementQuery.SELECT_ENABLE_QRY + sqlWhere;
        return((Enablement)getJdbcTemplate().queryForObject(finalSQL, obj, rowMapper));        
    }

    /**
     * @return the rowMapper
     */
    public RowMapper<Enablement> getRowMapper() {
        return rowMapper;
    }

    /**
     * @param rowMapper the rowMapper to set
     */
    public void setRowMapper(RowMapper<Enablement> rowMapper) {
        this.rowMapper = rowMapper;
    }

  
    
}
