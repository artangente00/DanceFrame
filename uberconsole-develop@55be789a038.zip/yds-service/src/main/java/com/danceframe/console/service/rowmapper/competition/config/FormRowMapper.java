/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.competition.config;

import com.danceframe.console.common.model.competition.config.Form;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class FormRowMapper implements RowMapper<Form>{

    @Override
    public Form mapRow(ResultSet rs, int column) throws SQLException {
        final Form form = new Form();
        form.setId(rs.getInt("form_id"));
        form.setName(rs.getString("name"));
        return form;  
    }
    
}
