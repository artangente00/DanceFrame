/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.file.xml.impl;

import com.danceframe.compmgr.binary.service.file.XMLGenerator;
import com.danceframe.console.common.exception.YDSException;
import com.danceframe.console.service.file.xml.CompManagerXMLWriter;
import com.danceframe.setupfile.util.Utility;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 *
 * @author lmorallos
 */
public class CompManagerXMLWriterImpl implements CompManagerXMLWriter {

    private static final Logger logger = LogManager.getLogger(CompManagerXMLWriterImpl.class);
    private XMLGenerator xmlGenerator;
    
    @Override
    public boolean createXMLOutput(String tmpLocation, String dbcFilename, String xmlfile, boolean debug) throws YDSException {
        boolean retbool = false;
        String xmlfilename = tmpLocation + xmlfile;
        String infile = tmpLocation + dbcFilename;
        String errfile = tmpLocation + "debugerr.log";
        String logfile = tmpLocation + "logger.log";
        boolean quite = true;
        try {
            Utility.deleteFile(errfile);
            Utility.deleteFile(logfile);
            xmlGenerator.setErrorfile(errfile);
            xmlGenerator.setLogfile(logfile);
            xmlGenerator.setNoStatistics(false);
            xmlGenerator.setQuite(quite);
            xmlGenerator.setDebug(debug);
            xmlGenerator.binaryToXML(infile, xmlfilename, true);
            if (Utility.isFileExist(xmlfilename)) {
               retbool = true; 
            }
        } catch (Exception ex) {
            logger.warn(ex.getMessage());
                throw new YDSException(ex);
            
        }
        return retbool;
    }

    /**
     * @return the xmlGenerator
     */
    public XMLGenerator getXmlGenerator() {
        return xmlGenerator;
    }

    /**
     * @param xmlGenerator the xmlGenerator to set
     */
    public void setXmlGenerator(XMLGenerator xmlGenerator) {
        this.xmlGenerator = xmlGenerator;
    }
    
}
