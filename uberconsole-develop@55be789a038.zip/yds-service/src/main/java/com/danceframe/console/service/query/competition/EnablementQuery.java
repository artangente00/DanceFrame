/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query.competition;

/**
 *
 * @author lmorallos
 */
public final class EnablementQuery {
    
    public static final String SELECT_ENABLE_QRY = "SELECT enable_id, event_id,venue_enable,contact_enable,organizer_enable," + 
                            "schedule_enable,hotel_enable,sponsor_enable,information_enable, finance_enable FROM uberconsole.tbl_enablement";
    
    public static final String INSERT_ENABLE_QRY = "SELECT uberconsole.FN_EVENT_ENABLEMENT_INSERT(?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    public static final String UPDATE_ENABLE_QRY = "SELECT uberconsole.FN_EVENT_ENABLEMENT_UPDATE(?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
}

