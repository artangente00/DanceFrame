/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.competition.config;

import com.danceframe.console.common.model.competition.config.Age;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class AgeRowMapper implements RowMapper<Age> {

    @Override
    public Age mapRow(ResultSet rs, int column) throws SQLException {
        final Age dance = new Age();
        dance.setId(rs.getInt("age_id"));
        dance.setName(rs.getString("name"));
        dance.setDescription(rs.getString("description"));
        return dance;    
    }
    
}
