/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.payment;

import com.danceframe.console.common.model.payment.Invoice;
import com.danceframe.console.service.dataprovider.GenericProviderDao;

/**
 *
 * @author NDB
 */
public interface InvoiceProviderDao extends GenericProviderDao<Invoice>{   
    
}
