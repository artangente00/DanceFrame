/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.constant;

/**
 *
 * @author lmorallos
 */
public final class PublishStatus {
    
    public static final int NOT_PUBLISHED = 0;
    
    public static final int PUBLISH_PENDING = 1;
    
    public static final int PUBLISH_IN_PROGRESS = 2;
    
    public static final int UNPUBLISH_IN_PROGRESS = 3;
    
    public static final int UNPUBLISH_PENDING = 4;
    
    public static final int PUBLISHED = 5;
    
    public static final int REPUBLISH_PENDING = 6;
    
    public static final int REPUBLISH_IN_PROGRESS = 7;
    
    public static final int ALL_COMMITED = 8;

}
