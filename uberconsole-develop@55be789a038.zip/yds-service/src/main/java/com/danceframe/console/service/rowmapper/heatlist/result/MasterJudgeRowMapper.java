/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.heatlist.result;

import com.danceframe.console.common.model.heatlist.result.MasterJudge;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class MasterJudgeRowMapper implements RowMapper<MasterJudge> {

    @Override
    public MasterJudge mapRow(ResultSet rs, int i) throws SQLException {
        MasterJudge judge = new MasterJudge();
        judge.setId(rs.getInt("masterjudge_id"));
        judge.setFirstname(rs.getString("firstname"));
        judge.setLastname(rs.getString("lastname"));
        return judge;
    }
    
}
