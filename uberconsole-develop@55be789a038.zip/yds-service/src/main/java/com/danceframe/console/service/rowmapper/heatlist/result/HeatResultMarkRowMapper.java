/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.heatlist.result;

import com.danceframe.console.common.model.heatlist.result.HeatResultMark;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class HeatResultMarkRowMapper implements RowMapper<HeatResultMark> {

    @Override
    public HeatResultMark mapRow(ResultSet rs, int i) throws SQLException {
        final HeatResultMark mark = new HeatResultMark();
        mark.setId(rs.getInt("mark_id"));
        mark.setKey(rs.getString("competitor_key"));
        mark.setValue(rs.getString("competitor_value"));
        mark.setStudioName(rs.getString("studio_name"));
        mark.setCompetitorId(rs.getInt("competitor_id"));
        mark.setResultId(rs.getInt("result_id"));
        mark.setSubHeatId(rs.getInt("subheat_id"));
        mark.setEventId(rs.getInt("event_id"));
        return mark;
    }
    
}
