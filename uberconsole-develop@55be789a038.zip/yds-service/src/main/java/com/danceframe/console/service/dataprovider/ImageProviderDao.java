/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider;

import com.danceframe.console.common.model.basic.Image;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public interface ImageProviderDao {
    
    int insertEventImageFile(int eventid, String path, String filename, String mimetype);
    
    int updateEventImageFile(int imageid, String path, String filename, String mimetype);
    
    int inserGenericFormImageFile(int codeid, String path, String filename, String mimetype, String code);
    
    int updateGenericFormImageFile(int codeid, String path, String filename, String mimetype, String code);

    Image get(int imageid);
    
    List<Integer> getAllImageIds(int eventId);
    
}
