/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.competition;

import com.danceframe.console.common.model.competition.ScheduleData;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class ScheduleDataRowMapper implements RowMapper<ScheduleData>{

    @Override
    public ScheduleData mapRow(ResultSet rs, int column) throws SQLException {
       ScheduleData scheddata = new ScheduleData();
       scheddata.setId(rs.getInt("schedlist_id"));
       scheddata.setEventId(rs.getInt("event_id"));
       scheddata.setHeaderName(rs.getString("header_name"));
       scheddata.setHdrOrder(rs.getInt("hdrorder"));
       scheddata.setTimeValue(rs.getString("timevalue"));
       scheddata.setTvalOrder(rs.getInt("tvalorder"));
       scheddata.setDescription(rs.getString("description"));
       return scheddata;
    }
    
}
