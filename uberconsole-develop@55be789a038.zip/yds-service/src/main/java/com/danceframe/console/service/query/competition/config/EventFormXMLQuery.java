/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query.competition.config;

/**
 *
 * @author lmorallos
 */
public final class EventFormXMLQuery {
    
    public static final String SELECT_XML_SEQ = "SELECT nextval('uberconsole.seq_eventform_xml')";
    
    public static final String SELECT_XML_QRY = "SELECT event_id, push_id, event_name, usemanual, eventxml_id, xmlgenerated, jsongenerated, xmlmanual, jsonmanual, stufile, xmlallfile FROM uberconsole.VW_EVENT_CONFIGXML";
    
    public static final String INSERT_GENERATE_QRY = "INSERT INTO  uberconsole.tbl_eventform_xml(eventxml_id, event_id, xmlgenerated, jsongenerated) " + 
            "VALUES (?, ?, ?, ?);";
    
    public static final String INSERT_MANUAL_QRY = "INSERT INTO  uberconsole.tbl_eventform_xml(eventxml_id, event_id, xmlmanual, jsonmanual) " + 
            "VALUES (?, ?, ?, ?);";
    
    
    public static final String UPDATE_GENERATE_QRY = "UPDATE uberconsole.tbl_eventform_xml SET xmlgenerated=?, jsongenerated=? " + 
            "WHERE event_id = ?;";
    
    public static final String UPDATE_MANUAL_QRY = "UPDATE uberconsole.tbl_eventform_xml SET xmlmanual=?, jsonmanual=? " + 
            "WHERE event_id = ?;";
    
    
    public static final String INSERT_STU_MANUAL_QRY = "INSERT INTO  uberconsole.tbl_eventform_xml(eventxml_id, event_id, stufile, xmlallfile, xmlmanual, jsonmanual) " + 
            "VALUES (?, ?, ?, ?, ?, ? );";
     
     
    public static final String UPDATE_STU_MANUAL_QRY = "UPDATE uberconsole.tbl_eventform_xml SET stufile=?, xmlallfile=?, xmlmanual=?, jsonmanual=? " + 
            "WHERE event_id = ?;"; 
    
    
    public static final String USEMANUAL_QRY = "SELECT uberconsole.FN_EVENT_SETUSEMANUAL(?, ?)";
}
