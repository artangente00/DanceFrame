/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.competition.config.impl;

import com.danceframe.console.common.model.competition.form.EventFormVertical;
import com.danceframe.console.service.dataprovider.competition.config.EventFormVerticalProviderDao;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.query.competition.config.EventFormVerticalQuery;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public class EventFormVerticalProviderDaoImpl extends GenericProviderDaoImpl<EventFormVertical>
                implements EventFormVerticalProviderDao
{

    @Override
    public int insert(EventFormVertical eventvertical) {
         Object[] obj = new Object[] {
             eventvertical.getFieldId(),
            eventvertical.getEventformId(),
            eventvertical.getCode(),
            eventvertical.getDescription(),
            eventvertical.isAllowall()
            };
        int ret = (Integer)this.genericQryTemplateInteger(EventFormVerticalQuery.INSERT_QRY, obj);
        return ret;
    }

    @Override
    public int delete(int id) {
        Object[] obj = new Object[] { id };
        int ret = (Integer)this.genericQryTemplateInteger(EventFormVerticalQuery.DELETE_QRY, obj);
        return ret;
    }


    @Override
    public List<EventFormVertical> getAll(String wherestr) {
        List<EventFormVertical> eventvertList = new ArrayList<EventFormVertical>();
        eventvertList = genericQryAllTemplateRowMapper(EventFormVerticalQuery.SELECT_QRY, wherestr); 
        return(eventvertList);
    }

    @Override
    public List<EventFormVertical> getAllWithPaging(String wherestr, int pagesize, int first) {
        List<EventFormVertical> eventvertList = new ArrayList<EventFormVertical>();
        eventvertList = genericQryAllTemplateRowMapperWithPaging(EventFormVerticalQuery.SELECT_QRY, wherestr, pagesize,  first); 
        return(eventvertList);
    }

    @Override
    public long getAllCount(String wherestr) {
        return genericQryForInt(EventFormVerticalQuery.SELECT_COUNT_QRY, wherestr);  
    }
    
    @Override
    public int update(EventFormVertical t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    @Override
    public int search(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int search(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public EventFormVertical get(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public EventFormVertical get(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

  
    
}
