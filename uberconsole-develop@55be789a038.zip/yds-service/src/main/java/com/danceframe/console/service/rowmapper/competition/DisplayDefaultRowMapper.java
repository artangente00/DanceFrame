/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.competition;

import com.danceframe.console.common.model.competition.DisplayDefault;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class DisplayDefaultRowMapper implements RowMapper<DisplayDefault> {

    @Override
    public DisplayDefault mapRow(ResultSet rs, int i) throws SQLException {
        DisplayDefault display = new DisplayDefault();
        display.setId(rs.getInt("uregdisplay_id"));
        display.setEventId(rs.getInt("event_id"));
        display.setEventDisplay(rs.getBoolean("event_display"));
        display.setVenueDisplay(rs.getBoolean("venue_display"));
        display.setContactDisplay(rs.getBoolean("contact_display"));
        display.setOrganizerDisplay(rs.getBoolean("organizer_display"));
        display.setScheduleDisplay(rs.getBoolean("schedule_display"));
        display.setHotelDisplay(rs.getBoolean("hotel_display"));
        display.setSponsorDisplay(rs.getBoolean("sponsor_display"));
        display.setInformationDisplay(rs.getBoolean("info_display"));
        display.setFinanceDisplay(rs.getBoolean("finance_display"));
        return display;
    }
    
}
