/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.registration;

import com.danceframe.console.common.model.registration.RegEntry;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class RegEntryRowMapper implements RowMapper<RegEntry>{

    @Override
    public RegEntry mapRow(ResultSet rs, int i) throws SQLException {
        final RegEntry entry = new RegEntry();
        entry.setId(rs.getInt("regentry_id"));
        entry.setCreationDate(rs.getTimestamp("create_date"));
        entry.setLastModified(rs.getTimestamp("last_modified"));
        entry.setFormId(rs.getString("form_id"));
        entry.setAgeId(rs.getString("age_id"));
        entry.setLevelId(rs.getString("level_id"));
        entry.setDanceId(rs.getString("dance_id"));
        entry.setDanceCatId(rs.getString("dancecat_id"));
        entry.setUserId(rs.getInt("reguser_id"));
        entry.setBuid(rs.getString("buid"));
        entry.setEventId(rs.getInt("event_id"));
        entry.setEuid(rs.getString("euid")); 
        entry.setIuid(rs.getString("iuid"));
        return entry;
    }
    
}
