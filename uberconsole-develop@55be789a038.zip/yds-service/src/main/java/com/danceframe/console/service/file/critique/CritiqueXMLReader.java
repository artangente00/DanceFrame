/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.file.critique;

import com.danceframe.console.common.exception.YDSException;
import com.danceframe.console.common.model.critique.xml.HeatResultProgram;
import com.danceframe.console.common.model.critique.xml.HeatlistResultXML;

/**
 *
 * @author lmorallos
 */
public interface CritiqueXMLReader {
    
    HeatResultProgram xmlToProgramObject(HeatlistResultXML resultXML) throws YDSException;
    
    boolean objectToDatabase(HeatResultProgram program) throws YDSException;
}
