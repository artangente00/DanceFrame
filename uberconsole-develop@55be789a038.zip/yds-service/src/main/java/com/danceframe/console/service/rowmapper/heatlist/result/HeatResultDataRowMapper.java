/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.heatlist.result;

import com.danceframe.console.common.model.heatlist.result.HeatResultData;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class HeatResultDataRowMapper implements RowMapper<HeatResultData>{

    @Override
    public HeatResultData mapRow(ResultSet rs, int i) throws SQLException {
        final HeatResultData data = new HeatResultData();
        data.setId(rs.getInt("mark_id"));
        data.setCoupleKey(rs.getString("couple_key"));
        data.setCoupleValue(rs.getString("couple_value"));
        data.setJudgingPanel(rs.getString("judgepanel"));
        data.setScoreHeaders(rs.getString("scoreheaders"));
        data.setPersonKey1(rs.getString("person1_key"));
        data.setPersonKey2(rs.getString("person2_key"));
        data.setSubHeatType(rs.getString("subheat_type"));
        data.setSubHeatDance(rs.getString("subheat_dance"));
        data.setSubHeatLevel(rs.getString("subheat_level"));
        data.setSubHeatAge(rs.getString("subheat_age"));
        data.setHeatName(rs.getString("heat_name"));
        data.setHeatSession(rs.getString("heat_session"));
        data.setHeatTime(rs.getString("heat_time"));
        data.setHeatDate(rs.getString("heat_date"));
        data.setHeatDesc(rs.getString("description"));
        data.setCategory(rs.getString("category"));
        data.setHeatId(rs.getInt("heat_id"));
        data.setCoupleId(rs.getInt("couple_id"));
        data.setResultId(rs.getInt("result_id"));
        data.setSubHeatId(rs.getInt("subheat_id"));
        data.setEventId(rs.getInt("event_id"));
        return data;
    }
    
}
