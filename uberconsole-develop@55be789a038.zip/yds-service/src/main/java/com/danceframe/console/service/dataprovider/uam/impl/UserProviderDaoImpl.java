/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.uam.impl;

import com.danceframe.console.common.model.uam.User;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.dataprovider.uam.UserProviderDao;
import com.danceframe.console.service.query.uam.UserQuery;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public class UserProviderDaoImpl extends GenericProviderDaoImpl<User> implements UserProviderDao {

    @Override
    public int search(int id) {
        Object[] obj = new Object[] {id };
        int ret = (Integer)this.genericQryTemplateInteger(UserQuery.SEARCH_BYUSERID_QRY, obj);
        return ret;
    }

    @Override
    public int search(String username) {
        Object[] obj = new Object[] {username };
        int ret = (Integer)this.genericQryTemplateInteger(UserQuery.SEARCH_BYUSERNAME_QRY, obj);
        return ret;
    }

    @Override
    public int insert(User user) {
        Object[] obj = new Object[] {
            user.getUsername(),
            user.getFirstname(),
            user.getLastname(),
            user.isActive(),
            user.getSysuid()
            };
         int ret = (Integer)this.genericQryTemplateInteger(UserQuery.INSERT_QRY, obj);
        return ret;
    }

    @Override
    public int update(User user) {
        Object[] obj = new Object[] {
            user.getId(),
            user.getUsername(),
            user.getFirstname(),
            user.getLastname(),
            user.isActive(),
            user.getSysuid()
            };
        int ret = (Integer)this.genericQryTemplateInteger(UserQuery.UPDATE_QRY, obj);
        return ret;    }

    @Override
    public int delete(int id) {
        Object[] obj = new Object[] { id };
        int ret = (Integer)this.genericQryTemplateInteger(UserQuery.DELETE_QRY, obj);
        return ret;
    }
    
    @Override
    public int delete(int id, int sysid) {
        Object[] obj = new Object[] { id, sysid};
        int ret = (Integer)this.genericQryTemplateInteger(UserQuery.DELETE_QRY, obj);
        return ret;
    }

    @Override
    public int delete(String name) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public User get(int id) {
        Object[] obj = new Object[] { id };
        String sqlWhere = " WHERE user_id = ?"  ;
        String finalSQL = UserQuery.SELECT_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj); 
    }

    @Override
    public User get(String username) {
        Object[] obj = new Object[] { username };
        String sqlWhere = " WHERE UPPER(username) = UPPER(?)"  ;
        String finalSQL = UserQuery.SELECT_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj); 
    }

    @Override
    public List<User> getAll(String wherestr) {
        List<User> userList = new ArrayList<User>();
        userList = genericQryAllTemplateRowMapper(UserQuery.SELECT_QRY, wherestr); 
        return(userList);
    }

    @Override
    public List<User> getAllWithPaging(String wherestr, int pagesize, int first) {
        List<User> userList = new ArrayList<User>();
        userList = genericQryAllTemplateRowMapperWithPaging(UserQuery.SELECT_QRY, wherestr,  pagesize,  first);
        return(userList);
    }

    @Override
    public long getAllCount(String wherestr) {
         return genericQryForInt(UserQuery.SELECT_COUNT_QRY, wherestr);  
    }

    @Override
    public int setDisabled(boolean disabled) {
         Object[] obj = new Object[] {disabled };
        int ret = (Integer)this.genericQryTemplateInteger(UserQuery.USER_SETDISABLE_QRY, obj);
        return ret;
    }
    
}
