/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query.competition.config;

/**
 *
 * @author lmorallos
 */
public class EventFormHContentQuery {
    
    public final static String INSERT_QRY = "SELECT uberconsole.FN_EVENTFORM_HCONTENT_INSERT(?, ?)";
    
    public final static String DELETE_QRY = "SELECT uberconsole.FN_EVENTFORM_HCONTENT_DELETE(?, ?)";
    
     public final static String DELETEBYID_QRY = "SELECT uberconsole.FN_EVENTFORM_HCONTENT_DELETEBYID( ? )";
    
    public final static String DELETEALL_QRY = "SELECT uberconsole.FN_EVENTFORM_HCONTENT_CLEAR(?, ?)";
     
    public final static String SELECT_QRY = "SELECT hcontent_id, eventform_id, horizheader FROM uberconsole.tbl_eventform_hcontent";
    
    public final static String SELECT_COUNT_QRY = "SELECT COUNT(hcontent_id) FROM uberconsole.tbl_eventform_hcontent";
    
}
