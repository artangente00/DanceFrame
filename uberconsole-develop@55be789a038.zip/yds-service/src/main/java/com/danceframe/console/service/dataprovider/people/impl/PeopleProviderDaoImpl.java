/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.people.impl;


import com.danceframe.console.common.model.people.People;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.dataprovider.people.PeopleProviderDao;
import com.danceframe.console.service.query.people.PeopleQuery;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author nbonita
 */
public class PeopleProviderDaoImpl extends GenericProviderDaoImpl<People> implements PeopleProviderDao {

    @Override
    public int search(int id) {
        Object[] obj = new Object[] {id };
        int ret = (Integer)this.genericQryTemplateInteger(PeopleQuery.SEARCH_BYID_QRY, obj);
        return ret;
    }

    @Override
    public int search(String email) {
        Object[] obj = new Object[] {email };
        int ret = (Integer)this.genericQryTemplateInteger(PeopleQuery.SEARCH_BYEMAIL_QRY, obj);
        return ret;
    }

    @Override
    public int insert(People onePeople) {
        Object[] obj = new Object[] {
            onePeople.getFirstName(),
            onePeople.getLastName(),
            onePeople.getStudioName(),
            onePeople.geteMail(),
            onePeople.getGender(),
            onePeople.getBirthday(),
            onePeople.getCategory(),
            onePeople.getInvoiceAddress(),
            onePeople.getFirebaseAuthenticationID(),
            onePeople.getLoginProvider(),
            onePeople.getDateCreated(),
            onePeople.getDateSignedIn(),
            onePeople.getFacebookUserUID()
            };
         int ret = (Integer)this.genericQryTemplateInteger(PeopleQuery.INSERT_QRY, obj);
        return ret;
    }

    @Override
    public int update(People onePeople) {
        Object[] obj = new Object[] {
            onePeople.getId(),
            onePeople.getFirstName(),
            onePeople.getLastName(),
            onePeople.getStudioName(),
            onePeople.geteMail(),
            onePeople.getGender(),
            onePeople.getBirthday(),
            onePeople.getCategory(),
            onePeople.getInvoiceAddress()
            };
        int ret = (Integer)this.genericQryTemplateInteger(PeopleQuery.UPDATE_QRY, obj);
        return ret;    }

    @Override
    public int delete(int id) {
        Object[] obj = new Object[] { id };
        int ret = (Integer)this.genericQryTemplateInteger(PeopleQuery.DELETE_QRY, obj);
        return ret;
    }
    
    

    @Override
    public int delete(String name) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public People get(int id) {
        Object[] obj = new Object[] { id };
        String sqlWhere = " WHERE people_id = ?"  ;
        String finalSQL = PeopleQuery.SELECT_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj); 
    }

    @Override
    public People get(String email) {
        Object[] obj = new Object[] { email };
        String sqlWhere = " WHERE UPPER(email) = UPPER(?)"  ;
        String finalSQL = PeopleQuery.SELECT_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj); 
    }

    @Override
    public List<People> getAll(String wherestr) {
        List<People> peopleList = new ArrayList<People>();
        peopleList = genericQryAllTemplateRowMapper(PeopleQuery.SELECT_QRY, wherestr); 
        return(peopleList);
    }

    @Override
    public List<People> getAllWithPaging(String wherestr, int pagesize, int first) {
        List<People> peopleList = new ArrayList<People>();
        peopleList = genericQryAllTemplateRowMapperWithPaging(PeopleQuery.SELECT_QRY, wherestr,  pagesize,  first);
        return(peopleList);
    }

    @Override
    public long getAllCount(String wherestr) {
         return genericQryForInt(PeopleQuery.SELECT_COUNT_QRY, wherestr);  
    }

   
    
}
