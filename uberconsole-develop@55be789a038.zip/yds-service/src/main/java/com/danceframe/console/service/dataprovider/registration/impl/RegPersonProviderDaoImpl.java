/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.registration.impl;

import com.danceframe.console.common.model.registration.RegPerson;
import com.danceframe.console.common.util.Utility;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.dataprovider.registration.RegPersonProviderDao;
import com.danceframe.console.service.query.RegistrationQuery;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public class RegPersonProviderDaoImpl extends GenericProviderDaoImpl<RegPerson> implements RegPersonProviderDao{

    @Override
    public int search(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int search(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
            
    @Override
    public int insert(RegPerson person) {        
        Object[] obj = new Object[] {
            person.getBuid(),
            person.getEuid(),
            person.getSuid(),
            person.getLastname(),
            person.getFirstname(),
            person.getType(),
            person.getGender(),
            Utility.sqlTimestamp(person.getCreationDate())
           
        };
        int ret = (Integer)this.genericQryTemplateInteger(RegistrationQuery.INSERT_REGPERSON_QRY, obj);
        return ret;
    }
    
    @Override
    public int update(RegPerson person) {
         Object[] obj = new Object[] {
            person.getBuid(),
            person.getEuid(), 
            person.getPuid(),            
            person.getLastname(),
            person.getFirstname(),
            person.getType(),
            person.getGender()
        };
        int ret = (Integer)this.genericQryTemplateInteger(RegistrationQuery.UPDATE_REGPERSON_QRY, obj);
        return ret;
    }

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public RegPerson get(int id) {
        Object[] obj = new Object[] { id };
        String sqlWhere = " WHERE regperson_id = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGPERSON_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);   
    }

    @Override
    public RegPerson get(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RegPerson> getAll(String wherestr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RegPerson> getAllWithPaging(String wherestr, int pagesize, int pagenumber) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public long getAllCount(String wherestr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public RegPerson get(int personId, String euid) {
        Object[] obj = new Object[] { personId, euid };
        String sqlWhere = " WHERE regperson_id = ? AND euid = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGPERSON_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);   
    }

    @Override
    public List<RegPerson> getPersonsByEventUID(String euid) {
        List<RegPerson> personList = new ArrayList<>();
        Object[] obj = new Object[] { euid };
        String sqlWhere = " WHERE euid = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGPERSON_QRY + sqlWhere;
        personList =  genericQryAllTemplateRowMapper(finalSQL, obj);
        return personList;    
    }

    @Override
    public RegPerson get(String puid, String euid) {
        Object[] obj = new Object[] { puid, euid };
        String sqlWhere = " WHERE puid = ? AND euid = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGPERSON_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);   
    }

    @Override
    public RegPerson get(String buid, String euid, String puid) {
        Object[] obj = new Object[] { buid, euid, puid };
        String sqlWhere = " WHERE bguid = ? AND euid = ? AND puid = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGPERSON_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);   
    }

    @Override
    public List<RegPerson> getPersonsByEvent(String buid, String euid) {
        List<RegPerson> personList = new ArrayList<>();
        Object[] obj = new Object[] { euid };
        String sqlWhere = " WHERE bguid = ? AND euid = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGPERSON_QRY + sqlWhere;
        personList =  genericQryAllTemplateRowMapper(finalSQL, obj);
        return personList;    
    }
    
}
