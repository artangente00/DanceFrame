/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query.participant;


/**
 *
 * @author nbonita
 */
public final class ParticipantQuery {
    
    public static final String TBL_NAME = "tbl_participant";
    
    public static final String ID_VARIABLE = "participant_id";
    
    public static final String INSERT_QRY = "SELECT uberconsole.FN_PARTICIPANT_INSERT( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )";
    
    public static final String UPDATE_QRY = "SELECT uberconsole.FN_PARTICIPANT_UPDATE( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )";
    
    public static final String DELETE_QRY = "SELECT uberconsole.FN_PARTICIPANT_DELETE( ? )";
    
    public static final String SEARCH_BYID_QRY = "SELECT uberconsole.FN_PARTICIPANT_BYID( ? )";
    
    public static final String SEARCH_BYPUSHID_QRY = "SELECT uberconsole.FN_PARTICIPANT_BYPUSHID( ? )";
    
    
    public static final String SELECT_QRY = "SELECT participant_id, participant_push_id, user_push_id, " +
                                                "first_name, last_name, " +
                                                "email, gender, birthday, " +
                                                "category, participant_type, " +
                                                "couple_id, couple_name " +
                                                "FROM uberconsole.VW_PARTICIPANTMANAGEMENT";
    
    public static final String SELECT_COUNT_QRY = "SELECT count(participant_id) FROM uberconsole.VW_PARTICIPANTMANAGEMENT";
    
}








