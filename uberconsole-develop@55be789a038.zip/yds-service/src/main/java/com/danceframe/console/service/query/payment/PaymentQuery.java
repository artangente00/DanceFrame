/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query.payment;

/**
 *
 * @author NDB
 */
public class PaymentQuery {

    public static final String TBL_NAME = "tbl_payment";
    
    public static final String ID_VARIABLE = "payment_id";
    
    public static final String INSERT_QRY = "SELECT uberconsole.FN_PAYMENT_INSERT( ?, ?, ?, ?, ?)";
    
    public static final String UPDATE_QRY = "SELECT uberconsole.FN_PAYMENT_UPDATE( ?, ?, ?, ?, ?, ?)";
    
    public static final String DELETE_QRY = "SELECT uberconsole.FN_PAYMENT_DELETE( ? )";
    
    public static final String SEARCH_BYID_QRY = "SELECT uberconsole.FN_PAYMENT_BYID( ? )";
    
    public static final String SEARCH_BYINVOICEID_QRY = "SELECT uberconsole.FN_PAYMENT_BYINVOICEID( ? )";
    
    
    public static final String SELECT_QRY = "SELECT payment_id, invoice_id, amount_paid, " +
                                                "type_of_payment, payment_timestamp, uberconsole_user_id " +
                                                "FROM uberconsole.VW_PAYMENTMANAGEMENT";
    
    public static final String SELECT_COUNT_QRY = "SELECT count(payment_id) FROM uberconsole.VW_PAYMENTMANAGEMENT";

}
