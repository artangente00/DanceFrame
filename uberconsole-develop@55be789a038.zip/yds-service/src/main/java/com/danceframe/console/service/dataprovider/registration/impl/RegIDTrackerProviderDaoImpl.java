/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.registration.impl;

import com.danceframe.console.common.model.registration.RegIDTracker;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.dataprovider.registration.RegIDTrackerProviderDao;
import com.danceframe.console.service.query.RegistrationQuery;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public class RegIDTrackerProviderDaoImpl extends GenericProviderDaoImpl<RegIDTracker> implements RegIDTrackerProviderDao {

    @Override
    public int search(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int search(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int insert(RegIDTracker tracker) {
         Object[] obj = new Object[] { 
            tracker.getBuid(),
            tracker.getRegUserId(),
            tracker.getEuid(),
            tracker.getBgId(),
            tracker.getUid(),
            tracker.getNodeType()       
        };
        int ret = (Integer)this.genericQryTemplateInteger(RegistrationQuery.INSERT_REGIDTRACKER_QRY, obj);
        return ret;
    }

    @Override
    public int update(RegIDTracker t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public RegIDTracker get(int id) {
        Object[] obj = new Object[] { id };
        String sqlWhere = " WHERE regtrack_id = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGIDTRACKER_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);   
    }

    @Override
    public RegIDTracker get(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RegIDTracker> getAll(String wherestr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RegIDTracker> getAllWithPaging(String wherestr, int pagesize, int pagenumber) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public long getAllCount(String wherestr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RegIDTracker> getIDs(String buid, String euid) {
        List<RegIDTracker> trackList = new ArrayList<>();
        Object[] obj = new Object[] { buid, euid };
        String sqlWhere = " WHERE buid = ? AND euid = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGIDTRACKER_QRY + sqlWhere;
        trackList =  genericQryAllTemplateRowMapper(finalSQL, obj);
        return trackList;
    }

    @Override
    public List<RegIDTracker> getIDs(String buid, String euid, int nodeType) {
        List<RegIDTracker> trackList = new ArrayList<>();
        Object[] obj = new Object[] { buid, euid, nodeType};
        String sqlWhere = " WHERE buid = ? AND euid = ? and node_type = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGIDTRACKER_QRY + sqlWhere;
        trackList =  genericQryAllTemplateRowMapper(finalSQL, obj);
        return trackList;
    }
    
}
