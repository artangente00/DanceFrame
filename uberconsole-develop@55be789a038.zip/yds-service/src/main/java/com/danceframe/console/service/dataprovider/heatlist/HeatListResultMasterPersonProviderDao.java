/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.heatlist;

import com.danceframe.console.common.model.heatlist.result.MasterPerson;
import com.danceframe.console.service.dataprovider.GenericProviderDao;

/**
 *
 * @author lmorallos
 */
public interface HeatListResultMasterPersonProviderDao extends GenericProviderDao<MasterPerson> {
    
    int unifiedMasterPerson(int newid, int oldid);
    
    int getMasterPersonIdByNames(String firstname, String lastname);
    
    String getMasterPersonUIDById(int masterPersonId);
    
    String getMasterPersonUIDByNames(String firstname, String lastname);
    
    int getMasterPersonUIDById(String uid);
    
    
}
