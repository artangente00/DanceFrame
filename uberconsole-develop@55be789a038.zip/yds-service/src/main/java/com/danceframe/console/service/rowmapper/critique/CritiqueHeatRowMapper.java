/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.critique;

import com.danceframe.console.common.model.critique.xml.HeatResultHeat;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class CritiqueHeatRowMapper implements RowMapper<HeatResultHeat> {

    @Override
    public HeatResultHeat mapRow(ResultSet rs, int i) throws SQLException {
        final HeatResultHeat heat = new HeatResultHeat();
        heat.setId(rs.getInt("heat_id"));
        heat.setName(rs.getString("heat_name"));
        heat.setSession(rs.getString("heat_session"));
        heat.setTime(rs.getString("heat_time"));
        heat.setDate(rs.getString("heat_date"));
        heat.setDesc(rs.getString("description"));
        heat.setEventId(rs.getInt("event_id"));
        heat.setXmlId(rs.getInt("xml_id"));
        return heat;
    }
    
}

	 	