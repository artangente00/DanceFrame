/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.file.xml;

import com.danceframe.console.common.exception.YDSException;
import com.danceframe.console.common.model.heatlist.result.HeatResultProgram;
import com.danceframe.console.common.model.heatlist.result.HeatlistResultXML;

/**
 *
 * @author lmorallos
 */
public interface HeatListResultXMLReader {
    
    boolean createXMLonUberHeatT4(String tmpLocation, String htmFilename, String datFilename,  String xmlFilename);
    
    boolean createXMLonUberHeatT5(String tmpLocation, String htlFilename, String scrFilename,  String xmlFilename);
    
    HeatResultProgram xmlToProgramObject(HeatlistResultXML resultXML) throws YDSException;
    
    boolean objectToDatabase(HeatResultProgram program) throws YDSException;
}
