/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.registration.impl;

import com.danceframe.console.common.model.registration.RegCompetitorPerson;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.dataprovider.registration.RegCompetitorPersonProviderDao;
import com.danceframe.console.service.query.RegistrationQuery;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public class RegCompetitorPersonProviderDaoImpl extends GenericProviderDaoImpl<RegCompetitorPerson> implements RegCompetitorPersonProviderDao {

    @Override
    public int search(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int search(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int insert(RegCompetitorPerson regcomp) {
        Object[] obj = new Object[] { 
            regcomp.getBuid(),
            regcomp.getEuid(),
            regcomp.getCuid(),            
            regcomp.getPuid()
        };
        int ret = (Integer)this.genericQryTemplateInteger(RegistrationQuery.INSERT_REGCOMP_PERSON_QRY, obj);
        return ret;
    }

    @Override
    public int update(RegCompetitorPerson t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(int id) {
        Object[] obj = new Object[] { id };
        int ret = (Integer)this.genericQryTemplateInteger(RegistrationQuery.DELETE_REGCOMP_PERSON_QRY, obj);
        return ret;
    }

    @Override
    public int delete(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public RegCompetitorPerson get(int id) {
        Object[] obj = new Object[] { id };
        String sqlWhere = " WHERE regcompperson_id = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGCOMP_PERSON_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);   
    }

    @Override
    public RegCompetitorPerson get(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RegCompetitorPerson> getAll(String wherestr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RegCompetitorPerson> getAllWithPaging(String wherestr, int pagesize, int pagenumber) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public long getAllCount(String wherestr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RegCompetitorPerson> getCompetitorPersons(String buid, String euid, String cuid) {
        List<RegCompetitorPerson> compList = new ArrayList<>();
        Object[] obj = new Object[] { euid };
        String sqlWhere = " WHERE buid = ? AND euid = ? AND cuid = ? "  ;
        String finalSQL =  RegistrationQuery.SELECT_REGCOMP_PERSON_QRY + sqlWhere;
        compList =  genericQryAllTemplateRowMapper(finalSQL, obj);
        return compList;    
    }

    @Override
    public int deleteByCUID(String buid, String euid, String cuid) {
         Object[] obj = new Object[] { buid, euid, cuid };
        int ret = (Integer)this.genericQryTemplateInteger(RegistrationQuery.DELETE_REGCOMP_PERSON_BYCUID_QRY, obj);
        return ret;
    }
    
}
