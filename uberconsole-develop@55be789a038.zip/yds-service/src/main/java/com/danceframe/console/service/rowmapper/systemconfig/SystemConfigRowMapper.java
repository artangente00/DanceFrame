/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.systemconfig;


import com.danceframe.console.common.model.systemconfig.SystemConfig;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author nbonita
 */
public class SystemConfigRowMapper implements RowMapper<SystemConfig> {

    @Override
    public SystemConfig mapRow(final ResultSet rs, final int column) throws SQLException {
        final SystemConfig oneSystemConfig = new SystemConfig();
        oneSystemConfig.setId(rs.getInt("systemconfig_id"));
        oneSystemConfig.setName(rs.getString("systemconfig_name"));
        oneSystemConfig.setValue(rs.getString("systemconfig_value"));
        oneSystemConfig.setType(rs.getString("systemconfig_type"));
        oneSystemConfig.setCategory(rs.getString("systemconfig_category"));
        oneSystemConfig.setPushid(rs.getString("systemconfig_pushid"));
        oneSystemConfig.setEnabled(rs.getString("systemconfig_enabled"));
        return oneSystemConfig;
    }
    
}
