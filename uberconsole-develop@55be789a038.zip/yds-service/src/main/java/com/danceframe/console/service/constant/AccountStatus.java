/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.constant;

/**
 *
 * @author lmorallos
 */
public final class AccountStatus {
    
    public static final int  DEACTIVE   = 0;
    
    public static final int ACTIVE      = 1;
}
