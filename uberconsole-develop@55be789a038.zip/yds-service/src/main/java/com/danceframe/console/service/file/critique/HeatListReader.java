/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.file.critique;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public interface HeatListReader  {

    int fileToXML(String filename, String xmlfilename, boolean console) throws FileNotFoundException, IOException;
 
    void setConfigFile(String configFile);
    
    void setFileList(List<String> filelist);
    
    void setQuite(boolean quite);
    
    void setNoStatistics(boolean nostat);
    
    void setDebug(boolean debug);
    
}
