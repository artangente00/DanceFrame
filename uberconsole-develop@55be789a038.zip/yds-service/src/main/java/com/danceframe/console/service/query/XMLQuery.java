/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query;

/**
 *
 * @author lmorallos
 */
public final class XMLQuery {
    
    public static final String SELECT_XMLID_QRY = "SELECT nextval('uberconsole.seq_xmldata')";
    
    public static final String INSERT_XMLFILE_QRY = "INSERT INTO uberconsole.tbl_xmldata (xml_id, filename, uploadtime, code, event_id, xmldata) " + 
            "VALUES (?, ?, ?, ?, ?, ?);";
   
}
