/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.competition.config;

import com.danceframe.console.common.model.competition.form.EventFormDance;
import com.danceframe.console.service.dataprovider.GenericProviderDao;

/**
 *
 * @author lmorallos
 */
public interface EventFormDanceProviderDao extends GenericProviderDao<EventFormDance> {
    
    int deleteDance(int hcontent, int eventformid, String code);
}
