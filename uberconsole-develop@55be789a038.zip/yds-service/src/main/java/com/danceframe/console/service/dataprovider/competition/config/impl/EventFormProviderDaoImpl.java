/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.competition.config.impl;

import com.danceframe.console.common.model.competition.form.EventForm;
import com.danceframe.console.service.dataprovider.competition.config.EventFormProviderDao;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.query.competition.config.EventFormQuery;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public class EventFormProviderDaoImpl extends GenericProviderDaoImpl<EventForm> implements EventFormProviderDao {

    @Override
    public int insert(EventForm eventform) {
        Object[] obj = new Object[] {
            eventform.getEventId(),
            eventform.getFormId(),
            eventform.getFormType(),
            eventform.getHeaderType(),
            eventform.getEntryType()
            };
        int ret = (Integer)this.genericQryTemplateInteger(EventFormQuery.INSERT_QRY, obj);
        return ret;
      }
    
    @Override
    public int delete(int id) {
        Object[] obj = new Object[] { id };
        int ret = (Integer)this.genericQryTemplateInteger(EventFormQuery.DELETE_QRY, obj);
        return ret;
    }
    
     @Override
    public List<EventForm> getAll(String wherestr) {
        List<EventForm> eventformList = new ArrayList<EventForm>();
        eventformList = genericQryAllTemplateRowMapper(EventFormQuery.SELECT_QRY, wherestr); 
        return(eventformList);
    }

    @Override
    public List<EventForm> getAllWithPaging(String wherestr, int pagesize, int first) {
        List<EventForm> eventformList = new ArrayList<EventForm>();
        eventformList = genericQryAllTemplateRowMapperWithPaging(EventFormQuery.SELECT_QRY, wherestr,  pagesize,  first);
        return(eventformList);
    }

    @Override
    public long getAllCount(String wherestr) {
       return genericQryForInt(EventFormQuery.SELECT_COUNT_QRY, wherestr);  
    }
    
    @Override
    public int search(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int search(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int update(EventForm t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public EventForm get(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public EventForm get(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
