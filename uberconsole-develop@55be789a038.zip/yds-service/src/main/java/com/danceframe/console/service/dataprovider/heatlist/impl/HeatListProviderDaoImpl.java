/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.heatlist.impl;

import com.danceframe.console.common.model.heatlist.HeatComp;
import com.danceframe.console.common.model.heatlist.HeatEntry;
import com.danceframe.console.common.model.heatlist.HeatFullData;
import com.danceframe.console.common.model.heatlist.HeatInfo;
import com.danceframe.console.common.model.heatlist.HeatList;
import com.danceframe.console.common.model.heatlist.HeatListEvent;
import com.danceframe.console.common.model.heatlist.HeatPerson;
import com.danceframe.console.common.model.heatlist.HeatSession;
import com.danceframe.console.common.model.heatlist.HeatStudio;
import com.danceframe.console.common.util.Utility;
import com.danceframe.console.service.dataprovider.heatlist.HeatListProviderDao;
import com.danceframe.console.service.dataprovider.impl.BaseJdbcDaoImpl;
import com.danceframe.console.service.query.heatlist.HeatListQuery;
import com.danceframe.console.service.rowmapper.heatlist.HeatListDataRowMapper;
import com.danceframe.console.service.rowmapper.heatlist.HeatListPersonRowMapper;
import com.danceframe.console.service.rowmapper.heatlist.HeatListRowMapper;
import com.danceframe.console.service.rowmapper.heatlist.HeatSessionRowMapper;
import java.util.ArrayList;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


/**
 *
 * @author lmorallos
 */
public class HeatListProviderDaoImpl extends BaseJdbcDaoImpl implements HeatListProviderDao {
    
    private static final Logger logger = LogManager.getLogger(HeatListProviderDao.class);
    private HeatListDataRowMapper heatListDataRowMapper;
    private HeatListPersonRowMapper heatListPersonRowMapper;
    private HeatListRowMapper heatListRowMapper;
    private HeatSessionRowMapper heatSessionRowMapper;
    
    
    
    @Override
    public int insertHeatList(HeatList heatlist) {
        Object[] obj = new Object[] {
                heatlist.getEventId(),
                heatlist.getDescription(),
                heatlist.getFilename(),
                heatlist.getSetupFile(),
                Utility.sqlTimestamp(heatlist.getAsof()),
                Utility.sqlDate(heatlist.getCompDate())
                };
        logger.info(HeatListQuery.INSERT_HEATLIST_QRY);
        int iret = (Integer)getJdbcTemplate().queryForObject(HeatListQuery.INSERT_HEATLIST_QRY, 
                   obj, Integer.class);
        return iret;
    }
    
    @Override
    public int insertStudio(HeatStudio heatstudio) {
         Object[] obj = new Object[] {
                heatstudio.getHeatListId(),
                heatstudio.getCompMgrId(),
                heatstudio.getName()
                };
        logger.info(HeatListQuery.INSERT_HEATSTUDIO_QRY);
        int iret = (Integer)getJdbcTemplate().queryForObject(HeatListQuery.INSERT_HEATSTUDIO_QRY, 
                        obj, 
                        Integer.class);
        return iret;
    }

    @Override
    public int insertPerson(HeatPerson heatperson) {
          Object[] obj = new Object[] { 
              heatperson.getHeatListId(),
              heatperson.getCompMgrId(),
              heatperson.getLastName(),
              heatperson.getFirstName(),
              heatperson.getSex(),
              heatperson.getProfType(),
              heatperson.getStudioCmpId()
          };
        logger.info(HeatListQuery.INSERT_HEATPERSON_QRY);
        int iret = (Integer)getJdbcTemplate().queryForObject(HeatListQuery.INSERT_HEATPERSON_QRY, 
                    obj, 
                    Integer.class);
        return iret;
    }

    @Override
    public int insertHeatInfo(HeatInfo heatinfo) {
         Object[] obj = new Object[] { 
            heatinfo.getHeatListId(),
            heatinfo.getHeatValue(),
            heatinfo.getSchedule(),
            heatinfo.getDescription(),
            };
        logger.info(HeatListQuery.INSERT_HEATINFO_QRY);
        int iret = (Integer)getJdbcTemplate().queryForObject(HeatListQuery.INSERT_HEATINFO_QRY, 
                    obj, Integer.class);
        return iret;
    }

    @Override
    public int insertCompetition(HeatComp heatcomp) {
        Object[] obj = new Object[] {
            heatcomp.getHeatListId(),
            heatcomp.getCompMgrId(),
            heatcomp.getHeatType(),
            heatcomp.getDance(),
            heatcomp.getLevel(),
            heatcomp.getAge(),
            heatcomp.getHeatInfoId()
        };
        logger.info(HeatListQuery.INSERT_HEATCOMP_QRY);
        int iret = (Integer)getJdbcTemplate().queryForObject(HeatListQuery.INSERT_HEATCOMP_QRY, 
                    obj, Integer.class);
        return iret;
    }

    @Override
    public int insertEntry(HeatEntry heatentry) {
         Object[] obj = new Object[] {
                    heatentry.getHeatListId(),
                    heatentry.getEntryCpmId(),
                    heatentry.getPersonCmpId(),
                    heatentry.getSeqNo(),
                    heatentry.getPartnerCmpId(),
                    heatentry.getStudioCmpId(),
                    heatentry.getOtherinfo(),
                    heatentry.getCompCmpId()
                    };
        logger.info(HeatListQuery.INSERT_HEATENTRY_QRY);
        int iret = (Integer)getJdbcTemplate().queryForObject(HeatListQuery.INSERT_HEATENTRY_QRY, 
                    obj, 
                    Integer.class);
       return iret;
    }

    @Override
    public int insertSession(HeatSession heatsession) {
        Object[] obj = new Object[] {
            heatsession.getHeatlistId(),
            heatsession.getSessionCount(),
            heatsession.getSessionDay(),
            heatsession.getSessionDate(),
            heatsession.getSessionTime()
            };
        logger.info(HeatListQuery.INSERT_HEATSESSION_QRY);
        int iret = (Integer)getJdbcTemplate().queryForObject(HeatListQuery.INSERT_HEATSESSION_QRY, 
                    obj, 
                    Integer.class);
        return iret;
    }


    @Override
    public int deleteHeatList(int heatListId) {
        Object[] obj = new Object[] {heatListId };
        int iret = (Integer)getJdbcTemplate().queryForObject(HeatListQuery.DELETE_HEATLIST_QRY, obj, Integer.class);
        return iret;
    }

     @Override
    public List<HeatPerson> getAllHeatPerson(int heatListId) {
        List<HeatPerson> lstPerson = new ArrayList<HeatPerson>();
        Object[] obj = new Object[] {heatListId };
        logger.info(HeatListQuery.SELECT_PERSON_QRY);
        lstPerson = (List<HeatPerson>)getJdbcTemplate().query(HeatListQuery.SELECT_PERSON_QRY, 
                   obj, heatListPersonRowMapper);
        return lstPerson;
    }

    @Override
    public List<HeatFullData> getHeatFullDataByPerson(String personCmdId, int heatListId) {
        List<HeatFullData> lstData = new ArrayList<HeatFullData>();
        Object[] obj = new Object[] {heatListId, personCmdId, personCmdId, };
        logger.info(HeatListQuery.SELECT_HEATDATA_QRY);
        lstData = (List<HeatFullData>)getJdbcTemplate().query(HeatListQuery.SELECT_HEATDATA_QRY, 
                   obj, heatListDataRowMapper);
        return lstData;
    }

    @Override
    public int getCountDataByPerson(String personCmdId, int heatListId) {
        Object[] obj = new Object[] {heatListId, personCmdId, personCmdId, };
        logger.info(HeatListQuery.COUNT_DATA_QRY);
        int iret = (Integer)getJdbcTemplate().queryForObject(HeatListQuery.COUNT_DATA_QRY, 
                   obj, Integer.class);
        return iret;
    }

    @Override
    public HeatListEvent getHeatListById(int heatListId) {
        Object[] obj = new Object[] {heatListId };
        String sql = HeatListQuery.SELECT_HEATLIST_QRY + " WHERE heatlist_id=?";
        logger.info(sql);
        return (HeatListEvent)getJdbcTemplate().queryForObject(sql, obj, heatListRowMapper);
    }
    
    @Override
    public HeatListEvent getHeatListByEventId(int eventId) {
        Object[] obj = new Object[] {eventId };
        String sql = HeatListQuery.SELECT_HEATLIST_QRY + " WHERE event_id=?";
        logger.info(sql);
        return (HeatListEvent)getJdbcTemplate().queryForObject(sql, obj, heatListRowMapper);
    }

     @Override
    public List<HeatListEvent> getAll(String wherestr) {
        String sql = HeatListQuery.SELECT_HEATLIST_QRY;
        String finalSQL = ((wherestr != null) || (wherestr.length() > 0 ) || (!wherestr.isEmpty()))? sql + " "  + wherestr : sql;    
        logger.info(finalSQL);
        return((List<HeatListEvent>)getJdbcTemplate().query(finalSQL, heatListRowMapper));  
    }

    @Override
    public List<HeatListEvent> getAllWithPaging(String wherestr, int pagesize, int first) {
        String limit = " LIMIT " + Integer.toString(pagesize);
        String offset = " OFFSET " + Integer.toString(first);       
        String sql = HeatListQuery.SELECT_HEATLIST_QRY;
        String finalSQL = ((wherestr != null) || (wherestr.length() > 0 ) || (!wherestr.isEmpty()))? sql + " "  + wherestr : sql;        
        String strSQL = finalSQL  + limit + offset;
        logger.info(strSQL);
        return((List<HeatListEvent>)getJdbcTemplate().query(strSQL, heatListRowMapper));    
    }

    @Override
    public long getAllCount(String wherestr) {
        String sql = HeatListQuery.COUNT_HEATLIST_QRY;
        String finalSQL = ((wherestr != null) || (wherestr.length() > 0 ) || (!wherestr.isEmpty()))? sql + " "  + wherestr : sql;
        logger.info(finalSQL);
        return (getJdbcTemplate().queryForObject(finalSQL, Long.class));
    }
    
    
      @Override
    public int checkHeatListDataExist(int eventId) {
        Object[] obj = new Object[] {eventId };
        logger.info(HeatListQuery.SELECT_HEATLIST_CHECK_BYEVENTID_QRY);
        return (getJdbcTemplate().queryForObject(HeatListQuery.SELECT_HEATLIST_CHECK_BYEVENTID_QRY, obj, Integer.class));     
    }

    @Override
    public int deleteHeatListByEventId(int eventId) {
        Object[] obj = new Object[] { eventId };
        int iret = getJdbcTemplate().queryForObject(HeatListQuery.DELETE_HEATLIST_BYEVENTID_QRY, obj, Integer.class);
        return iret;
    }
    
     @Override
    public int saveHeatlistData(HeatList heatList, int type) {
        Object[] obj = null;
        int iret = 0;
        if (type == 1) {
            obj = new Object[] {
                heatList.getId(),
                heatList.getProgData()
            };
            logger.info(HeatListQuery.UPDATE_HEATLISTFILE_QRY);
            iret = getJdbcTemplate().queryForObject(HeatListQuery.UPDATE_HEATLISTFILE_QRY,  obj, Integer.class);
        }
         if (type == 2) {
            obj = new Object[] {
                heatList.getId(),
                heatList.getSetupData()
            };
            logger.info(HeatListQuery.UPDATE_HEATSTUFILE_QRY);
            iret = getJdbcTemplate().queryForObject(HeatListQuery.UPDATE_HEATSTUFILE_QRY,  obj, Integer.class);
        }
       return iret;
    }

    @Override
    public List<HeatSession> getHeatSessions(int heatListId) {
        Object[]  obj = new Object[] { heatListId };
        logger.info(HeatListQuery.SELECT_HEATSESSION_QRY);
        return((List<HeatSession>)getJdbcTemplate().query(HeatListQuery.SELECT_HEATSESSION_QRY, obj, heatSessionRowMapper));  
    }
   

   
    /**
     * @return the heatListDataRowMapper
     */
    public HeatListDataRowMapper getHeatListDataRowMapper() {
        return heatListDataRowMapper;
    }

    /**
     * @param heatListDataRowMapper the heatListDataRowMapper to set
     */
    public void setHeatListDataRowMapper(HeatListDataRowMapper heatListDataRowMapper) {
        this.heatListDataRowMapper = heatListDataRowMapper;
    }

    /**
     * @return the heatListPersonRowMapper
     */
    public HeatListPersonRowMapper getHeatListPersonRowMapper() {
        return heatListPersonRowMapper;
    }

    /**
     * @param heatListPersonRowMapper the heatListPersonRowMapper to set
     */
    public void setHeatListPersonRowMapper(HeatListPersonRowMapper heatListPersonRowMapper) {
        this.heatListPersonRowMapper = heatListPersonRowMapper;
    }

    /**
     * @return the heatListRowMapper
     */
    public HeatListRowMapper getHeatListRowMapper() {
        return heatListRowMapper;
    }

    /**
     * @param heatListRowMapper the heatListRowMapper to set
     */
    public void setHeatListRowMapper(HeatListRowMapper heatListRowMapper) {
        this.heatListRowMapper = heatListRowMapper;
    }

    /**
     * @return the heatSessionRowMapper
     */
    public HeatSessionRowMapper getHeatSessionRowMapper() {
        return heatSessionRowMapper;
    }

    /**
     * @param heatSessionRowMapper the heatSessionRowMapper to set
     */
    public void setHeatSessionRowMapper(HeatSessionRowMapper heatSessionRowMapper) {
        this.heatSessionRowMapper = heatSessionRowMapper;
    }

   
   
   
}
