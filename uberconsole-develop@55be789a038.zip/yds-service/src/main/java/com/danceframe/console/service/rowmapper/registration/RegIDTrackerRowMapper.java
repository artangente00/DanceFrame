/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.registration;

import com.danceframe.console.common.model.registration.RegIDTracker;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class RegIDTrackerRowMapper implements RowMapper<RegIDTracker> {

    @Override
    public RegIDTracker mapRow(ResultSet rs, int i) throws SQLException {
        final RegIDTracker regtrack = new RegIDTracker();
        regtrack.setId(rs.getInt("regtrack_id"));
        regtrack.setRegUserId(rs.getInt("reguser_id"));
        regtrack.setBuid(rs.getString("buid"));
        regtrack.setEuid(rs.getString("euid"));
        regtrack.setBgId(rs.getString("bgid"));
        regtrack.setUid(rs.getString("uid"));
        regtrack.setNodeType(rs.getInt("node_type"));
        regtrack.setCreationDate(rs.getTimestamp("create_date"));
        return regtrack;
    }
    
}
