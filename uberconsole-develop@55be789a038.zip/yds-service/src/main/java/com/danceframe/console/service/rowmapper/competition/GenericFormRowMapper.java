/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.competition;

import com.danceframe.console.common.model.firebase.competition.GenericFormData;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class GenericFormRowMapper implements RowMapper<GenericFormData> {

    @Override
    public GenericFormData mapRow(ResultSet rs, int column) throws SQLException {
        GenericFormData genformdata = new GenericFormData();
        genformdata.setId(rs.getInt("code_id"));
        genformdata.setUrl(rs.getString("url"));
        genformdata.setDescription(rs.getString("description"));
        genformdata.setOrderValue(rs.getInt("ordervalue"));
        genformdata.setImageId(rs.getInt("image_id"));
        genformdata.setEventId(rs.getInt("event_id"));
        genformdata.setImgFilename(rs.getString("filename"));
        genformdata.setMimeType(rs.getString("mimetype"));
        return genformdata;        
    }
    
}
