/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query.payment;

/**
 *
 * @author NDB
 */
public class InvoiceQuery {

    public static final String TBL_NAME = "tbl_invoice";
    
    public static final String ID_VARIABLE = "invoice_id";
    
    public static final String INSERT_QRY = "SELECT uberconsole.FN_INVOICE_INSERT( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    public static final String UPDATE_QRY = "SELECT uberconsole.FN_INVOICE_UPDATE( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    public static final String DELETE_QRY = "SELECT uberconsole.FN_INVOICE_DELETE( ? )";
    
    public static final String SEARCH_BYID_QRY = "SELECT uberconsole.FN_INVOICE_BYID( ? )";
    
    public static final String SEARCH_BYUSERPUSHID_QRY = "SELECT uberconsole.FN_INVOICE_BYUSERPUSHID( ? )";
    
    
    public static final String SELECT_QRY = "SELECT invoice_id, user_push_id, event_push_id, " +
                                                "billing_name, billing_address, event_title, " +
                                                "total_amount, received_amount, " +
                                                "created_timestamp, modified_timestamp, rtdb_etransfer_payment_json " +
                                                "FROM uberconsole.VW_INVOICEMANAGEMENT";
    
    public static final String SELECT_COUNT_QRY = "SELECT count(invoice_id) FROM uberconsole.VW_INVOICEMANAGEMENT";

}
