/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.impl;

import com.danceframe.console.common.model.registry.Account;
import com.danceframe.console.service.dataprovider.AccountProviderDao;
import com.danceframe.console.service.query.AccountQuery;
import java.util.ArrayList;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class AccountProviderDaoImpl extends BaseJdbcDaoImpl implements AccountProviderDao {

    private static final Logger logger = LogManager.getLogger(AccountProviderDaoImpl.class);
    
    private RowMapper<Account> rowMapper;
      
    @Override
    public int searchUserAccount(String username, int isactive) {
        int iret = -1;
        try {
            iret = getJdbcTemplate().queryForObject(AccountQuery.SEARCH_QRY, 
                    new Object[] {username, isactive}, Integer.class);
        } catch (EmptyResultDataAccessException ex) {
            logger.warn("account:search:empty" + ex.getMessage());
        } catch (Exception ex) {  
            ex.printStackTrace();
            // logger.warn("account:search:error-" + ex.getMessage());     
        }  
        return iret;
    }

    @Override
    public int insertAccount(Account account) {
        int iret = -1;
        try {
            iret = getJdbcTemplate().queryForObject(AccountQuery.INSERT_QRY, 
                    new Object[] {
                        account.getUserName(),
                        account.getFirstName(),
                        account.getLastName(),
                        account.getMidName(),
                        account.getEmail(),
                        account.getAddress(),
                        account.getCity(),
                        account.getProvince(),
                        account.getState(),
                        account.getCountry(),
                        account.getTelePhone(),
                        account.getMobilePhone(),
                        account.getAccType()       
                    }, 
                    Integer.class);
        } catch (EmptyResultDataAccessException ex) {
            logger.warn("account:insert:empty" + ex.getMessage());
        } catch (Exception ex) {  
            ex.printStackTrace();
            //logger.warn("account:insert:error-" + ex.getMessage());     
        }  
        return iret;
    }

    @Override
    public int updateAccount(Account account) {
          int iret = -1;
        try {
            iret = getJdbcTemplate().queryForObject(AccountQuery.UPDATE_QRY, 
                    new Object[] {
                        account.getUserName(),
                        account.getFirstName(),
                        account.getLastName(),
                        account.getMidName(),
                        account.getEmail(),
                        account.getAddress(),
                        account.getCity(),
                        account.getProvince(),
                        account.getState(),
                        account.getCountry(),
                        account.getTelePhone(),
                        account.getMobilePhone(),
                        account.getAccType()       
                    }, 
                    Integer.class);
        } catch (EmptyResultDataAccessException ex) {
            logger.warn("account:update:empty" + ex.getMessage());
        } catch (Exception ex) {  
            ex.printStackTrace();
            //logger.warn("account:update:error-" + ex.getMessage());     
        }  
        return iret;
    }

    @Override
    public int activateAccount(String username) {
        int iret = -1;
        try {
            iret = getJdbcTemplate().queryForObject(AccountQuery.ACTIVATE_QRY, 
                    new Object[] {username}, Integer.class);
        } catch (EmptyResultDataAccessException ex) {
            logger.warn("account:activate:empty" + ex.getMessage());
        } catch (Exception ex) {  
            //logger.warn("account:activate:error-" + ex.getMessage());  
            ex.printStackTrace();
        }  
        return iret;
    }

    @Override
    public int deactivateAccount(String username) {
          int iret = -1;
        try {
            iret = getJdbcTemplate().queryForObject(AccountQuery.DEACTIVATE_QRY, 
                    new Object[] {username}, Integer.class);
        } catch (EmptyResultDataAccessException ex) {
            logger.warn("account:deactive:empty" + ex.getMessage());
        } catch (Exception ex) {  
           ex.printStackTrace();
            //logger.warn("account:deactive:error-" + ex.getMessage());     
        }  
        return iret;
    }

    @Override
    public Account getUserInformation(String username, int isactive) {
        Account accountret = null;
        try {
            accountret = (Account)getJdbcTemplate().queryForObject(AccountQuery.GETUSERINFO_QRY, 
                    new Object[] {username, isactive}, rowMapper);
        } catch (EmptyResultDataAccessException ex) {
            logger.warn("account:getuser:empty" + ex.getMessage());
        } catch (Exception ex) {  
            ex.printStackTrace();
            //logger.warn("account:getuser:error-" + ex.getMessage());     
        }  
        return accountret;
    }

    @Override
    public List<Account> getAllUserWithPaging(int pagesize, int pagenum, int isactive) {
       List<Account> accountList = new ArrayList<Account>();
       try {
            accountList = getJdbcTemplate().query(AccountQuery.GETALLINFO_WITH_PAGING_QRY, 
                    new Object[] {pagesize, pagenum, isactive}, rowMapper);
        } catch (EmptyResultDataAccessException ex) {
            logger.warn("account:getall:empty" + ex.getMessage());
        } catch (Exception ex) {  
            ex.printStackTrace();
            //logger.warn("account:getall:error-" + ex.getMessage());     
        }  
       return accountList;
    }
    
    @Override
    public int searchAllUser(String username) {
        int iret = -1;
        try {
            iret = getJdbcTemplate().queryForObject(AccountQuery.SEARCH_ALL_QRY, 
                    new Object[] {username}, Integer.class);
        } catch (EmptyResultDataAccessException ex) {
            logger.warn("account:search:empty" + ex.getMessage());
        } catch (Exception ex) {  
            ex.printStackTrace();
        }  
        return iret;
    }

    /**
     * @return the rowMapper
     */
    public RowMapper<Account> getRowMapper() {
        return rowMapper;
    }

    /**
     * @param rowMapper the rowMapper to set
     */
    public void setRowMapper(RowMapper<Account> rowMapper) {
        this.rowMapper = rowMapper;
    }

    
    
}
