/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.file.heatlist.impl;

import com.danceframe.console.common.model.heatlist.result.HeatResultHeatEntry;
import com.danceframe.console.common.model.heatlist.result.HeatResultJudge;
import com.danceframe.console.common.model.heatlist.result.HeatResultPerson;
import com.danceframe.console.common.model.heatlist.result.HeatResultScoreSheet;
import com.danceframe.console.common.util.Utility;
import com.danceframe.console.service.dataprovider.heatlist.HeatListResultProviderDao;
import com.danceframe.console.service.file.heatlist.HeatListResultWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

/**
 *
 * @author lmorallos
 */
public class HeatListResultWriterImpl implements HeatListResultWriter {

    private static final Logger logger = LogManager.getLogger(HeatListResultWriter.class);
    private HeatListResultProviderDao heatListResultProviderDao;
    
    private final static String TEMPLATE_FILE = "heatresult_template.htl";
    private final static String TMP_PERSON_FILE = "personhr.out";
    private final static String TMP_HEAT_FILE = "heathr.out";
    private final static String TMP_SCORE_FILE = "scorehr.out";
    private final static String TMP_JUDGE_FILE = "judgehr.out";
    
    private final static String MARKER_PERSON_FULLNAME = "$HEATLIST_RESULT_PERSON_FULLNAME$";
    private final static String MARKER_PERSON_KEY = "$HEATLIST_RESULT_PERSON_KEY$";
    private final static String MARKER_PERSON1_FULLNAME ="$HEATLIST_RESULT_PERSON1_FULLNAME$";
    private final static String MARKER_PERSON2_FULLNAME = "$HEATLIST_RESULT_PERSON2_FULLNAME$";
    private final static String MARKER_COMPETITORNUM = "$HEATLIST_RESULT_COMPETITORNUM$";
    private final static String MARKER_HEAT_NAME = "$HEATLIST_RESULT_HEATNAME$";
    private final static String MARKER_HEAT_DESC = "$HEATLIST_RESULT_HEATDESC$";
    private final static String MARKER_HEAT_ID = "$HEATLIST_RESULT_HEATID$";
    
    private final static String MARKER_SUBHEAT_DET = "$HEATLIST_RESULT_SUBHEATDET$";
    private final static String MARKER_COMP_PERSON = "$HEATLIST_RESULT_COMP_PERSON$";
    private final static String MARKER_JUDGE_NUM_NAME = "$HEATLIST_RESULT_JUDGE_NUM_NAME$";
    private final static String MARKER_SCORE_TR = "$HEATLIST_SCORE_TRDATA$";
    private final static String MARKER_SCORE_TD = "$HEATLIST_SCORE_TDDATA$";
    
    private final static String MARKER_PERSON_BLOCK = "$HEATLIST_RESULT_PERSON_BLOCK$";
    private final static String MARKER_HEAT_BLOCK = "$HEATLIST_RESULT_HEATENTRY_BLOCK$";
    private final static String MARKER_SCORE_BLOCK = "$HEATLIST_RESULT_SCORESHEET_BLOCK$";
    private final static String MARKER_JUDGE_BLOCK = "$HEATLIST_RESULT_JUDGE_BLOCK$";
    
    
    private final static String PERSON_BLOCK = "<tr><td>$HEATLIST_RESULT_PERSON_FULLNAME$</td><td><input type=\"button\" value=\"Show entries\" onclick=\"ShowBlock('TABLE_CODE_$HEATLIST_RESULT_PERSON_KEY$')\"></td></tr>";
    
    private final static String START_HEAT_ENTRY_BLOCK = "<div id=\"TABLE_CODE_$HEATLIST_RESULT_PERSON_KEY$\" style=\"visibility:hidden; Position:Absolute; color: #000; text-align: center; left:0; right: 0; margin: 0 auto; top: 0\">";
    
    private final static String START_HEAT_SUB_BLOCK = 
                    "<strong>Entries for $HEATLIST_RESULT_PERSON1_FULLNAME$</strong><br>" +
                    "<br><strong>With $HEATLIST_RESULT_PERSON2_FULLNAME$</strong>" +
                    "<table border=\"1\" cellspacing=\"0\" bordercolor=\"white\" style=\"margin: 15px auto;\">" +
                    "<tr><td>Number</td><td>Heat</td><td>Event</td><td>Link</td></tr>";
    
    private final static String END_HEAT_SUB_BLOCK = "</table>";
            
    private final static String END_HEAT_ENTRY_BLOCK = "<input type=\"button\" value=\"Return to menu\" onclick=\"ShowBlock('block_menu')\"></div>";
    
    private final static String HEAT_ENTRY_BLOCK = "<tr><td>$HEATLIST_RESULT_COMPETITORNUM$</td><td>$HEATLIST_RESULT_HEATNAME$</td><td>$HEATLIST_RESULT_HEATDESC$</td><td><input type=\"button\" value=\"Show scoresheet\" onclick=\"ShowBlock('SCORESHEET_CODE_$HEATLIST_RESULT_HEATID$')\"></td></tr>";

    private final static String START_SCORESHEET_BLOCK = "<div id=\"SCORESHEET_CODE_$HEATLIST_RESULT_HEATID$\" style=\"visibility:hidden; Position:Absolute; color: #000; text-align: center; left:0; right: 0; margin: 0 auto; top: 0\">";
         
    private final static String START_SCOREHEAT_BLOCK =  "<p>$HEATLIST_RESULT_HEATNAME$:$HEATLIST_RESULT_HEATDESC$ ($HEATLIST_RESULT_SUBHEATDET$)</p>" +
                    "<table border=\"1\" cellspacing=\"0\" bordercolor=\"white\" style=\"margin: 15px auto;\">";
    
     private final static String END_SCOREHEAT_BLOCK = "</table>";
     
    private final static String END_SCORESHEET_BLOCK = "<input type=\"button\" value=\"Return to menu\" onclick=\"ShowBlock('block_menu')\">" +
                    "<input type=\"button\" value=\"List of judges\" onclick=\"ShowBlock('JUDGE_LIST')\"></div>";
               
    private final static String JUDGE_BLOCK_LIST = "<br>$HEATLIST_RESULT_JUDGE_NUM_NAME$";
    
    private final static String SCORESHEET_TRDATA = "<tr>$HEATLIST_SCORE_TRDATA$</tr>";
    
    private final static String SCORESHEET_TDDATA = "<td>$HEATLIST_SCORE_TDDATA$</td>";
    
    @Override
    public boolean writeToFile(String tmppath, String outputfile, int eventId) throws FileNotFoundException, IOException {
        boolean retbool = false;
        String personfile = tmppath + TMP_PERSON_FILE;
        String heatfile = tmppath + TMP_HEAT_FILE;
        String scorefile = tmppath + TMP_SCORE_FILE;
        String judgefile = tmppath + TMP_JUDGE_FILE;
        BufferedWriter personout = new BufferedWriter(new FileWriter(personfile));      
        BufferedWriter heatout = new BufferedWriter(new FileWriter(heatfile));
        String persondata = new String();
//        List<HeatResultPerson> persons = heatListResultProviderDao.getAllPersons(eventId);
         List<HeatResultPerson> persons = new ArrayList<>();
        int personCnt =0;
        int heatCnt = 0;
        int subCnt = 0;
        int scoreCnt = 0;
        int judgeCnt = 0;
        for (HeatResultPerson person:persons) {
            // System.out.println(person.toString());
            String tmpLastname = person.getLastName();
            String  tmpFirstname = person.getFirstName();
            String heatHeader = new String();
            if (Utility.showPerson(tmpFirstname, tmpLastname)) {
                String fullname = person.getLastName() + ", " + person.getFirstName();
                String personKey = person.getPersonKey();
//                int datacnt = heatListResultProviderDao.countResultDataByPerson(eventId, personKey);
                int datacnt = 0;
                if (datacnt > 0) {
                    persondata = PERSON_BLOCK.replace(MARKER_PERSON_FULLNAME, fullname);
                    persondata = persondata.replace(MARKER_PERSON_KEY, personKey);
                    personout.write(persondata);personout.newLine();
                    personCnt++;
                    
                    heatHeader = START_HEAT_ENTRY_BLOCK.replace(MARKER_PERSON_KEY, personKey);
                    heatout.write(heatHeader);heatout.newLine();
                    
                    String heatPerson1 = new String();
                    String heatPerson2 = new String();
                    String personKey2 = new String();
                    String heatSubHeader = new String();
                    String heatEntry = new String();
                    int tcnt = 0;
                    boolean isheat = false;
//                    List<HeatResultHeatEntry> entries = heatListResultProviderDao.getHeatResultByPerson(eventId, personKey, 1);
                    List<HeatResultHeatEntry> entries  = new ArrayList<>();
                    for (HeatResultHeatEntry entry:entries) {
                        if  (!personKey2.equalsIgnoreCase(entry.getPersonKey2())) {
                            if (tcnt > 0) {
                                heatout.write(END_HEAT_SUB_BLOCK);heatout.newLine();
                            }
                            heatPerson1 = entry.getLastName1() + ", " + entry.getFirstName1();
                            heatPerson2 = entry.getLastName2() + ", " + entry.getFirstName2();
                            
                            heatSubHeader = START_HEAT_SUB_BLOCK.replace(MARKER_PERSON1_FULLNAME, heatPerson1);
                            heatSubHeader = heatSubHeader.replace(MARKER_PERSON2_FULLNAME, heatPerson2);
                            heatout.write(heatSubHeader);heatout.newLine();  
                            // System.out.println("----[*]=" + heatPerson1 + ":" + heatPerson2);
                            isheat = true;
                        }
                        String comp = (entry.getCompetitorNumber() == null)?"":entry.getCompetitorNumber();
                        heatEntry = HEAT_ENTRY_BLOCK.replace(MARKER_COMPETITORNUM, comp);
                        heatEntry = heatEntry.replace(MARKER_HEAT_NAME, entry.getHeatName().toString());
                        heatEntry = heatEntry.replace(MARKER_HEAT_DESC, entry.getHeatDesc().toString());
                        heatEntry = heatEntry.replace(MARKER_HEAT_ID, Integer.toString(entry.getHeatId()));
                        
                        
                        heatout.write(heatEntry);heatout.newLine();                        
//                        System.out.println("----[*-*]=>" + entry.getCompetitorNumber() + ":" +
//                                entry.getHeatName() + ":" + entry.getHeatDesc()  + ":" + entry.getCoupleKey()+":" + entry.getHeatId());
                        personKey2 = entry.getPersonKey2();
                        tcnt++;
                    }  
                    if (isheat) {
                        heatout.write(END_HEAT_SUB_BLOCK);heatout.newLine();
                    }
                    
                    tcnt = 0;
                    String personKey1 = new String();
//                    entries = heatListResultProviderDao.getHeatResultByPerson(eventId, personKey, 2);
                    
                    isheat = false;
                    for (HeatResultHeatEntry entry:entries) {
                        if  (!personKey1.equalsIgnoreCase(entry.getPersonKey1())) {
                            if (tcnt > 0) {
                                heatout.write(END_HEAT_SUB_BLOCK);heatout.newLine();
                            }
                            heatPerson1 = entry.getLastName1() + "," + entry.getFirstName1();
                            heatPerson2 = entry.getLastName2() + "," + entry.getFirstName2();
                            
                            heatSubHeader = START_HEAT_SUB_BLOCK.replace(MARKER_PERSON1_FULLNAME, heatPerson1);
                            heatSubHeader = heatSubHeader.replace(MARKER_PERSON2_FULLNAME, heatPerson2);
                            heatout.write(heatSubHeader);heatout.newLine();
//                            System.out.println("----[*]=" + heatPerson1 + ":" + heatPerson2);
                            isheat = true;
                        }
                        String comp = (entry.getCompetitorNumber() == null)?"":entry.getCompetitorNumber();
                        heatEntry = HEAT_ENTRY_BLOCK.replace(MARKER_COMPETITORNUM, comp);
                        heatEntry = heatEntry.replace(MARKER_HEAT_NAME, entry.getHeatName().toString());
                        heatEntry = heatEntry.replace(MARKER_HEAT_DESC, entry.getHeatDesc().toString());
                        heatEntry = heatEntry.replace(MARKER_HEAT_ID, Integer.toString(entry.getHeatId()));
                        heatout.write(heatEntry);heatout.newLine(); 
                        
//                        System.out.println("----[*-*]=>" + entry.getCompetitorNumber() + ":" +
//                                entry.getHeatName() + ":" + entry.getHeatDesc()  + ":" + entry.getCoupleKey() +":" + entry.getHeatId());
                        personKey1 = entry.getPersonKey1();
                    }
                    if (isheat) {
                        heatout.write(END_HEAT_SUB_BLOCK);heatout.newLine();
                    }
                    heatout.write(END_HEAT_ENTRY_BLOCK);heatout.newLine();
                }
            }
        }
        personout.close();
        heatout.close();
        logger.info("HEATRESULTLIST - No of person data written:" + personCnt);
        logger.info("HEATRESULTLIST - No of heat data written:" + heatCnt);
        
        // scoresheet     
        BufferedWriter scoreout = new BufferedWriter(new FileWriter(scorefile));
        int lcnt = 0;
        int hcnt = 0;
        int scnt = 0;
        int heatid = 0;
        boolean isHeat = false;
        boolean isSub = false;
        String scoreHead =new String();    
        int subheatid = 0;
        int osubheat = 0;
//        List<HeatResultScoreSheet> scores = heatListResultProviderDao.getAllScoreSheetByEvent(eventId);
        List<HeatResultScoreSheet> scores = new ArrayList<>();
        for (HeatResultScoreSheet score:scores) {
            //START_SCORESHEET_BLOCK
            if (heatid != score.getHeatId()) {
                if (isSub) {
                    scoreout.write(END_SCOREHEAT_BLOCK);scoreout.newLine();
                    isSub = false;
                }
                if (hcnt >0) {
                    scoreout.write(END_SCORESHEET_BLOCK);scoreout.newLine();
                }
                scoreHead = START_SCORESHEET_BLOCK.replace(MARKER_HEAT_ID, Integer.toString(score.getHeatId()));
                scoreout.write(scoreHead);scoreout.newLine();
                isHeat = true;
                hcnt++;
                heatCnt++;
            }
            //System.out.println(score.toString());
            if (subheatid != score.getSubHeatId()) {
                 if (isSub) {
                    scoreout.write(END_SCOREHEAT_BLOCK);scoreout.newLine();
                    //isSub = false;
                }
                String tmpSub = new String();
                tmpSub = score.getSubHeatDance() + " " + score.getSubHeatLevel() + " " + score.getSubHeatAge();
                scoreHead = START_SCOREHEAT_BLOCK.replace(MARKER_HEAT_NAME, score.getHeatName());
                scoreHead = scoreHead.replace(MARKER_HEAT_DESC, score.getHeatDesc());
                scoreHead = scoreHead.replace(MARKER_SUBHEAT_DET, tmpSub);
                scoreout.write(scoreHead);scoreout.newLine();
                
                
                String tmpLine = new String();
                String tmpStr = new String();
                String scHeader = new String();
                List<String> headers = Utility.str2List(score.getScoreHeaders(), '|');
                tmpStr = SCORESHEET_TDDATA.replace(MARKER_SCORE_TD, "No.");
                tmpLine = tmpLine + tmpStr;
                for (String header:headers) {
                    tmpStr = SCORESHEET_TDDATA.replace(MARKER_SCORE_TD, header);
                    tmpLine = tmpLine + tmpStr;
                }
                scHeader = SCORESHEET_TRDATA.replace(MARKER_SCORE_TR, tmpLine);
                scoreout.write(scHeader);scoreout.newLine();
                subCnt++;
                isSub = true;
                scnt++;
                osubheat = subheatid;
            }
            // -- data
             String tmpLine = new String();
            String tmpStr = new String();
            String comp = (score.getCompetitorNumber() == null)?"":score.getCompetitorNumber();
            String tmpPersonComp = comp + " " + score.getLastName1() + "/" + score.getLastName2();
            tmpStr = SCORESHEET_TDDATA.replace(MARKER_SCORE_TD, tmpPersonComp);
            tmpLine = tmpLine + tmpStr;
            
            String scValue = new String();
            List<String> scorevals = Utility.str2List(score.getCoupleValue(), '|');
            for (String scoreval:scorevals) {
                tmpStr = SCORESHEET_TDDATA.replace(MARKER_SCORE_TD, scoreval);
                tmpLine = tmpLine + tmpStr;
            }
            scValue = SCORESHEET_TRDATA.replace(MARKER_SCORE_TR, tmpLine);
            scoreout.write(scValue);scoreout.newLine();
            
            scoreCnt++;
            heatid = score.getHeatId();
            subheatid = score.getSubHeatId();
            lcnt++;
        }
        if (isSub) {
             scoreout.write(END_SCOREHEAT_BLOCK);scoreout.newLine();
        }
        if (isHeat) {
            scoreout.write(END_SCORESHEET_BLOCK);scoreout.newLine();
        }
        
        scoreout.close();
        logger.info("HEATRESULTLIST - No of subheat data written:" + subCnt);
        logger.info("HEATRESULTLIST - No of scoresheet data written:" + scoreCnt);  
        // Judge list
        BufferedWriter judgeout = new BufferedWriter(new FileWriter(judgefile));   
//        List<HeatResultJudge> judges = heatListResultProviderDao.getAllJudges(eventId);
        List<HeatResultJudge> judges = new ArrayList<>();
        String judgeStr = new String();
        for (HeatResultJudge judge:judges) {
            String judgeLine = judge.getJudgeNumber() + " " + judge.getFirstName() + " " + judge.getLastName();
            judgeStr = JUDGE_BLOCK_LIST.replace(MARKER_JUDGE_NUM_NAME, judgeLine);
            judgeout.write(judgeStr);judgeout.newLine();
            judgeCnt++;
        }
        judgeout.close();
        logger.info("HEATRESULTLIST - No of judge data written:" + judgeCnt);
        
        // compose
        String outfullpath = tmppath + outputfile;
        BufferedWriter htmfile = new BufferedWriter(new FileWriter(outfullpath));
        Resource resource = new ClassPathResource(TEMPLATE_FILE);
        InputStream resourceInputStream = resource.getInputStream();
        InputStreamReader isrfile = new InputStreamReader(resourceInputStream);
        BufferedReader templateFile = new BufferedReader(isrfile);
        String strline = new String();
        while ((strline = templateFile.readLine()) != null) {
            if (strline.equalsIgnoreCase(MARKER_PERSON_BLOCK)) {
                BufferedReader partFile = new BufferedReader(new FileReader(personfile));
                String tmpstr = new String();
                while ((tmpstr = partFile.readLine()) != null) {
                    htmfile.write(tmpstr);htmfile.newLine();
                }
                if (partFile != null)  partFile.close();
            } else if (strline.equalsIgnoreCase(MARKER_HEAT_BLOCK)) {
                BufferedReader partFile = new BufferedReader(new FileReader(heatfile));
                String tmpstr = new String();
                while ((tmpstr = partFile.readLine()) != null) {
                    htmfile.write(tmpstr);htmfile.newLine();
                }
                if (partFile != null)  partFile.close();
            } else if (strline.equalsIgnoreCase(MARKER_SCORE_BLOCK)) {
                BufferedReader partFile = new BufferedReader(new FileReader(scorefile));
                String tmpstr = new String();
                while ((tmpstr = partFile.readLine()) != null) {
                    htmfile.write(tmpstr);htmfile.newLine();
                }
                if (partFile != null)  partFile.close();
            } else if (strline.equalsIgnoreCase(MARKER_JUDGE_BLOCK)) {
                BufferedReader partFile = new BufferedReader(new FileReader(judgefile));
                String tmpstr = new String();
                while ((tmpstr = partFile.readLine()) != null) {
                    htmfile.write(tmpstr);htmfile.newLine();
                }
                if (partFile != null)  partFile.close();
            } else {
                 htmfile.write(strline);htmfile.newLine();
            }        
        }
        if (templateFile != null) templateFile.close();
        if (htmfile != null) {
            htmfile.flush();htmfile.close();
        }
        logger.info("HEATLIST - Finished wirting output" + outfullpath);
        return retbool;
    }

    /**
     * @return the heatListResultProviderDao
     */
    public HeatListResultProviderDao getHeatListResultProviderDao() {
        return heatListResultProviderDao;
    }

    /**
     * @param heatListResultProviderDao the heatListResultProviderDao to set
     */
    public void setHeatListResultProviderDao(HeatListResultProviderDao heatListResultProviderDao) {
        this.heatListResultProviderDao = heatListResultProviderDao;
    }
    
}
