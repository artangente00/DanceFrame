/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query.competition;

/**
 *
 * @author lmorallos
 */
public final class ContactQuery {
    
     public static final String INSERT_QRY = "SELECT uberconsole.FN_CONTACT_INSERT_WITH_EVENTID(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )";

    public static final String UPDATEBYEVENTID_QRY = "SELECT uberconsole.FN_CONTACT_UPDATEBY_EVENTID(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    public static final String DELETEBYID_QRY = "SELECT uberconsole.FN_CONTACT_DELETEBYID( ? )";
	
    public static final String SEARCHBYID_QRY = "SELECT uberconsole.FN_CONTACT_SEARCHBYID( ? )";
	
    public static final String SEARCHBYNAME_QRY = "SELECT uberconsole.FN_CONTACT_SEARCHBYNAME( ? ) ";
    
    public static final String SELECT_QRY = "SELECT contact_id, name, address, address2, city, province, country, zipcode,"
            + " phone, fax, email, event_id FROM uberconsole.tbl_contact";
    
    public static final String SELECT_COUNT_QRY = "SELECT count(contact_id) FROM uberconsole.tbl_contact"; 
    
}
