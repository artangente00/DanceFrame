/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.competition.config;

import com.danceframe.console.common.model.competition.form.EventFormXML;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class EventFormXMLRowMapper implements RowMapper<EventFormXML> {

    @Override
    public EventFormXML mapRow(ResultSet rs, int column) throws SQLException {
        EventFormXML eventformxml = new EventFormXML();
        eventformxml.setId(rs.getInt("eventxml_id"));
        eventformxml.setEventId(rs.getInt("event_id"));
        eventformxml.setPushId(rs.getString("push_id"));
        eventformxml.setEventName(rs.getString("event_name"));
        eventformxml.setUseManual(rs.getBoolean("usemanual"));
        eventformxml.setJsonGenerated(rs.getBytes("jsongenerated"));
        eventformxml.setXmlGenerated(rs.getBytes("xmlgenerated"));
        eventformxml.setJsonManual(rs.getBytes("jsonmanual"));
        eventformxml.setXmlManual(rs.getBytes("xmlmanual"));
        eventformxml.setStuManual(rs.getBytes("stufile"));
        eventformxml.setXmlAllManual(rs.getBytes("xmlallfile"));
        return eventformxml;
    }
    
}

