/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.competition;

import com.danceframe.console.common.model.competition.Event;
import com.danceframe.console.common.model.competition.EventSummary;
import com.danceframe.console.common.model.competition.PublishSummary;
import com.danceframe.console.service.dataprovider.GenericProviderDao;
import java.util.Date;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public interface EventProviderDao extends GenericProviderDao<Event> {
    
    int searchByEventAndDate(int id, Date start, Date stop);
    
    int searchByCompetitionAndDate(int compid, Date start, Date stop);
 
    int setStatus(int id, int status);
    
    int setPushId(int id, String pushid);
    
    int setPublishStatus(int id, int status, long commitTime);
    
    int updateImageFile(int id, int imgId);
    
    int copy(int id, String name);
    
    PublishSummary getPublishReport();
    
    EventSummary getEventStatusReport();
    
    List<Integer> getAllYear();
    
    Event getEventByEuid(String euid);
       
}
