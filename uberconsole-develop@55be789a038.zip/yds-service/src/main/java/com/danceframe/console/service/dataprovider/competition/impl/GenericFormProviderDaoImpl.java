/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.competition.impl;

import com.danceframe.console.common.model.competition.FormData;
import com.danceframe.console.common.model.firebase.competition.GenericFormData;
import com.danceframe.console.service.constant.GenericFormType;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.query.competition.FormDataQuery;
import java.util.ArrayList;
import java.util.List;
import com.danceframe.console.service.dataprovider.competition.GenericFormProviderDao;
import com.danceframe.console.service.rowmapper.competition.GenericFormRowMapper;

/**
 *
 * @author lmorallos
 */
public class GenericFormProviderDaoImpl extends GenericProviderDaoImpl<FormData> implements GenericFormProviderDao {

    private GenericFormRowMapper genericFormRowMapper;
    
    @Override
    public int insert(FormData formdata) {
        Object[] obj = new Object[] {
            formdata.getEventId(),
            formdata.getUrl(),
            formdata.getDescription(),
            formdata.getOrderValue(),
            formdata.getImageId(),
            formdata.getCodeType()
        };
        int ret = (Integer)this.genericQryTemplateInteger(FormDataQuery.INSERT_QRY, obj);
        return ret;
    }
    
    @Override
    public int update(FormData formdata) {
         Object[] obj = new Object[] {
            formdata.getId(),
            formdata.getEventId(),
            formdata.getUrl(),
            formdata.getDescription(),
            formdata.getOrderValue(),
            formdata.getCodeType()
        };
        int ret = (Integer)this.genericQryTemplateInteger(FormDataQuery.UPDATE_QRY, obj);
        return ret;
    }

    @Override
    public int delete(int id) {
        Object[] obj = new Object[] {  id };
        int ret = (Integer)this.genericQryTemplateInteger(FormDataQuery.DELETE_QRY, obj);
        return ret;
    }

    @Override
    public int cleanupTemp(int eventId) {
         Object[] obj = new Object[] {  eventId };
        int ret = (Integer)this.genericQryTemplateInteger(FormDataQuery.CLEANTMP_QRY, obj);
        return ret;
    }
    
    @Override
    public int insertToEvent(int eventId, int code, int oldEventId) {
         Object[] obj = new Object[] {  eventId, code, oldEventId  };
        int ret = (Integer)this.genericQryTemplateInteger(FormDataQuery.EVENT_INSERT_QRY, obj);
        return ret;
    }

    @Override
    public int updateToEvent(int eventId, int code) {
        Object[] obj = new Object[] {  eventId, code  };
        int ret = (Integer)this.genericQryTemplateInteger(FormDataQuery.EVENT_UPDATE_QRY, obj);
        return ret;
    }

    @Override
    public int moveEventToTemp(int eventId, int code) {
         Object[] obj = new Object[] {  eventId, code  };
        int ret = (Integer)this.genericQryTemplateInteger(FormDataQuery.MOVE2TMP_QRY, obj);
        return ret;
    }
    
    @Override
    public FormData get(int id) {
        Object[] obj = new Object[] { id };
        String sqlWhere = " WHERE event_id = ?"  ;
        String finalSQL = FormDataQuery.SELECT_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);   
    }
    
     @Override
    public List<FormData> getAll(String wherestr) {
        List<FormData> formdataList = new ArrayList<FormData>();
        formdataList = genericQryAllTemplateRowMapper(FormDataQuery.SELECT_QRY, wherestr); 
        return(formdataList);
    }

    @Override
    public List<FormData> getAllWithPaging(String wherestr, int pagesize, int first) {
       List<FormData> formdataList = new ArrayList<FormData>();
        formdataList = genericQryAllTemplateRowMapperWithPaging(FormDataQuery.SELECT_QRY, wherestr,  pagesize,  first);
        return(formdataList);
     }
    
     @Override
    public int updateImageId(int id, int imgId) {
        Object[] obj = new Object[] {id, imgId };
        int ret = (Integer)this.genericQryTemplateInteger(FormDataQuery.UPDATE_IMAGEBYID_QRY, obj);
        return ret;
    }

    @Override
    public long getAllCount(String wherestr) {
        return genericQryForInt(FormDataQuery.SELECT_COUNT_QRY, wherestr);  
    }
    
    @Override
    public long countData(int eventId, String code) {
        String wherestr = " WHERE code='" + code + "' AND event_id=" + eventId;
        return (genericQryForInt(FormDataQuery.SELECT_COUNT_QRY, wherestr));  
    }
    
    @Override
    public int lastOrder(int eventId, String code) {
         Object[] obj = new Object[] { eventId, code } ;
        int ret = (Integer)this.genericQryTemplateInteger(FormDataQuery.SELECT_ORDERLAST_QRY, obj);
        return ret;  
    }

    @Override
    public List<GenericFormData> getFormData(int eventId, String code) {
        String tablename = new String();
        if (code.equalsIgnoreCase(GenericFormType.HOTEL_CODE)) 
            tablename = "uberconsole.VW_EVENT_FORM_HOTEL";
        if (code.equalsIgnoreCase(GenericFormType.SPONSOR_CODE)) 
            tablename = "uberconsole.VW_EVENT_FORM_SPONSOR";
        if (code.equalsIgnoreCase(GenericFormType.INFO_CODE)) 
            tablename = "uberconsole.VW_EVENT_FORM_INFO"; 
        
        String query = FormDataQuery.SELECT_GENERIC_QRY + tablename;
        String wherestr = " WHERE event_id=" + eventId;       
        String sortSql = " ORDER BY ordervalue ASC";
        String finalSQL = query + wherestr + sortSql;
        // System.out.println(finalSQL);
        
        List<GenericFormData> formdataList = new ArrayList<GenericFormData>();
        formdataList = getJdbcTemplate().query(finalSQL, genericFormRowMapper);
        return(formdataList);
    }
    
    @Override
    public int search(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int search(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

  
    @Override
    public int delete(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public FormData get(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }  

    /**
     * @return the genericFormRowMapper
     */
    public GenericFormRowMapper getGenericFormRowMapper() {
        return genericFormRowMapper;
    }

    /**
     * @param genericFormRowMapper the genericFormRowMapper to set
     */
    public void setGenericFormRowMapper(GenericFormRowMapper genericFormRowMapper) {
        this.genericFormRowMapper = genericFormRowMapper;
    }

  

    
    
}
