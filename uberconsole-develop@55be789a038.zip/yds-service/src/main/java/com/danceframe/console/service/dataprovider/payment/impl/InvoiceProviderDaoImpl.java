/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.payment.impl;

import com.danceframe.console.common.model.payment.Invoice;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.dataprovider.payment.InvoiceProviderDao;
import com.danceframe.console.service.query.payment.InvoiceQuery;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author NDB
 */
public class InvoiceProviderDaoImpl  extends GenericProviderDaoImpl<Invoice> implements InvoiceProviderDao {
    @Override
    public int search(int id) {
        Object[] obj = new Object[] {id };
        int ret = (Integer)this.genericQryTemplateInteger(InvoiceQuery.SEARCH_BYID_QRY, obj);
        return ret;
    }

    @Override
    public int search(String email) {
        Object[] obj = new Object[] {email };
        int ret = (Integer)this.genericQryTemplateInteger(InvoiceQuery.SEARCH_BYUSERPUSHID_QRY, obj);
        return ret;
    }

    @Override
    public int insert(Invoice oneInvoice) {
        Object[] obj = new Object[] {
            oneInvoice.getUserPushId(),
            oneInvoice.getEventPushId(),
            oneInvoice.getBillingName(),
            oneInvoice.getBillingAddress(),
            oneInvoice.getEventTitle(),
            oneInvoice.getTotalAmount(),
            oneInvoice.getRecievedAmount(),
            oneInvoice.getCreatedTimestamp(),
            oneInvoice.getModifiedTimestamp(),
            oneInvoice.getRtdbEtransferPaymentJson()
            };
         int ret = (Integer)this.genericQryTemplateInteger(InvoiceQuery.INSERT_QRY, obj);
        return ret;
    }

    @Override
    public int update(Invoice oneInvoice) {
        Object[] obj = new Object[] {
            oneInvoice.getId(),
            oneInvoice.getUserPushId(),
            oneInvoice.getEventPushId(),
            oneInvoice.getBillingName(),
            oneInvoice.getBillingAddress(),
            oneInvoice.getEventTitle(),
            oneInvoice.getTotalAmount(),
            oneInvoice.getRecievedAmount(),
            oneInvoice.getCreatedTimestamp(),
            oneInvoice.getModifiedTimestamp(),
            oneInvoice.getRtdbEtransferPaymentJson()
            };
        int ret = (Integer)this.genericQryTemplateInteger(InvoiceQuery.UPDATE_QRY, obj);
        return ret;    }

    @Override
    public int delete(int id) {
        Object[] obj = new Object[] { id };
        int ret = (Integer)this.genericQryTemplateInteger(InvoiceQuery.DELETE_QRY, obj);
        return ret;
    }
    
    

    @Override
    public int delete(String name) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Invoice get(int id) {
        Object[] obj = new Object[] { id };
        String sqlWhere = " WHERE invoice_id = ?"  ;
        String finalSQL = InvoiceQuery.SELECT_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj); 
    }

    @Override
    public Invoice get(String user_push_id) {
        Object[] obj = new Object[] { user_push_id };
        String sqlWhere = " WHERE UPPER(user_push_id) = UPPER(?)"  ;
        String finalSQL = InvoiceQuery.SELECT_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj); 
    }

    @Override
    public List<Invoice> getAll(String wherestr) {
        List<Invoice> peopleList = new ArrayList<Invoice>();
        peopleList = genericQryAllTemplateRowMapper(InvoiceQuery.SELECT_QRY, wherestr); 
        return(peopleList);
    }

    @Override
    public List<Invoice> getAllWithPaging(String wherestr, int pagesize, int first) {
        List<Invoice> peopleList = new ArrayList<Invoice>();
        peopleList = genericQryAllTemplateRowMapperWithPaging(InvoiceQuery.SELECT_QRY, wherestr,  pagesize,  first);
        return(peopleList);
    }

    @Override
    public long getAllCount(String wherestr) {
         return genericQryForInt(InvoiceQuery.SELECT_COUNT_QRY, wherestr);  
    }
}
