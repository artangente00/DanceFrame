/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.constant;

/**
 *
 * @author lmorallos
 */
public final class EventStatus {
    
    public static final int PREREGISTER = 1;
    
    public static final int REGISTERING = 2;
    
    public static final int REGCLOSED   = 3;
    
    public static final int INPROGRESS  = 4;
    
    public static final int CLOSED      = 5;
    
    
}
