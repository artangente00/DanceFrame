/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.registration;

import com.danceframe.console.common.model.registration.RegPerson;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class RegPersonRowMapper implements RowMapper<RegPerson> {

    @Override
    public RegPerson mapRow(ResultSet rs, int i) throws SQLException {
        final RegPerson person = new RegPerson();
        person.setId(rs.getInt("regperson_id"));
        person.setLastname(rs.getString("lastname"));
        person.setFirstname(rs.getString("firstname"));
        person.setType(rs.getString("person_type"));
        person.setGender(rs.getString("gender"));
        person.setEventId(rs.getInt("event_id"));
        person.setEuid(rs.getString("euid"));
        person.setStudioId(rs.getInt("regstudio_id"));
        person.setSuid(rs.getString("suid"));
        person.setPuid(rs.getString("puid"));
        person.setUserId(rs.getInt("reguser_id"));
        person.setBuid(rs.getString("buid"));
        person.setCreationDate(rs.getTimestamp("create_date"));
        person.setLastModified(rs.getTimestamp("last_modified"));
        return person;
    }
    
}
