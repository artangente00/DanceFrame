/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.people;

import com.danceframe.console.common.model.people.People;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author nbonita
 */
public class PeopleRowMapper implements RowMapper<People> {

    @Override
    public People mapRow(final ResultSet rs, final int column) throws SQLException {
        final People onePeople = new People();
        onePeople.setId(rs.getInt("people_id"));
        onePeople.setFirstName(rs.getString("firstname"));
        onePeople.setLastName(rs.getString("lastname"));
        onePeople.setStudioName(rs.getString("studioname"));
        onePeople.seteMail(rs.getString("email"));
        onePeople.setGender(rs.getString("gender"));
        onePeople.setBirthday(rs.getString("birthday"));
        onePeople.setCategory(rs.getString("category"));
        onePeople.setInvoiceAddress(rs.getString("invoiceaddress"));
        onePeople.setFirebaseAuthenticationID(rs.getString("firebaseauthenticationid"));
        onePeople.setLoginProvider(rs.getString("loginprovider"));
        onePeople.setDateCreated(rs.getString("datecreated"));
        onePeople.setDateSignedIn(rs.getString("datesignedIn"));
        onePeople.setFacebookUserUID(rs.getString("facebookuseruid"));
        
        return onePeople;
    }
    
}
