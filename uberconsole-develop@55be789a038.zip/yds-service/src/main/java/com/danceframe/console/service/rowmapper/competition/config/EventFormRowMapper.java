/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.competition.config;

import com.danceframe.console.common.model.competition.form.EventForm;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class EventFormRowMapper implements RowMapper<EventForm>{ 

    @Override
    public EventForm mapRow(ResultSet rs, int columns) throws SQLException {
        final EventForm eventform = new EventForm();
        eventform.setId(rs.getInt("eventform_id"));
        eventform.setEventId(rs.getInt("event_id"));
        eventform.setFormId(rs.getInt("form_id"));
        eventform.setFormType(rs.getInt("formtype"));
        eventform.setHeaderType(rs.getInt("headertype"));
        eventform.setEntryType(rs.getInt("entrytype"));
        eventform.setEventName(rs.getString("event_name"));
        eventform.setFormName(rs.getString("form_name"));
        eventform.setFormTypeName(rs.getString("formtype_name"));
        eventform.setHeaderTypeName(rs.getString("headertype_name"));
        eventform.setEntryTypeName(rs.getString("entrytype_name"));
        return eventform;  
    }    
}
