/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.competition.impl;

import com.danceframe.console.common.model.competition.Venue;
import com.danceframe.console.service.dataprovider.competition.VenueProviderDao;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.query.competition.VenueQuery;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public class VenueProviderDaoImpl extends GenericProviderDaoImpl<Venue> implements VenueProviderDao {

    @Override
    public int search(int id) {
        Object[] obj = new Object[] {id };
        int ret = (Integer)this.genericQryTemplateInteger(VenueQuery.SEARCHBYID_QRY, obj);
        return ret;
    }

    @Override
    public int search(String name) {
        Object[] obj = new Object[] {name };
        int ret = (Integer)this.genericQryTemplateInteger(VenueQuery.SEARCHBYNAME_QRY, obj);
        return ret;
    }
   
                
    @Override
    public int insert(Venue venue) {
         Object[] obj = new Object[] {
            venue.getEventid(),
            venue.getName(),
            venue.getAddress(),
            venue.getAddress2(),
            venue.getCity(),
            venue.getProvince(),           
            venue.getCountry(),
            venue.getZipcode(),
            venue.getPhone(),
            venue.getReservePhone(),
            venue.getFax(),
            venue.getWebsite(),
            venue.getLongtitude(),
            venue.getLatitude()
         };
        int ret = (Integer)this.genericQryTemplateInteger(VenueQuery.INSERT_QRY, obj);
        return ret;
    }

    @Override
    public int update(Venue venue) {
         Object[] obj = new Object[] {
            venue.getEventid(),
            venue.getName(),
            venue.getAddress(),
            venue.getAddress2(),
            venue.getCity(),
            venue.getProvince(),           
            venue.getCountry(),
            venue.getZipcode(),
            venue.getPhone(),  
            venue.getReservePhone(),
            venue.getFax(),
            venue.getWebsite(),
            venue.getLongtitude(),
            venue.getLatitude()
         };
        int ret = (Integer)this.genericQryTemplateInteger(VenueQuery.UPDATEBYEVENTID_QRY, obj);
        return ret;
    }

    @Override
    public int delete(int id) {
        Object[] obj = new Object[] {id };
        int ret = (Integer)this.genericQryTemplateInteger(VenueQuery.DELETEBYID_QRY, obj);
        return ret;
    }

    @Override
    public int delete(String name) {
         throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Venue get(int id) {
        Object[] obj = new Object[] { id };
        String sqlWhere = " WHERE venue_id = ?"  ;
        String finalSQL =  VenueQuery.SELECT_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);    
    }

    @Override
    public Venue get(String name) {
       Object[] obj = new Object[] { name };
        String sqlWhere = " WHERE name = ?"  ;
        String finalSQL =  VenueQuery.SELECT_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);    
    }
    
     @Override
    public List<Venue> getAll(String wherestr) { 
        List<Venue> venueList = new ArrayList<Venue>();
        venueList = genericQryAllTemplateRowMapper(VenueQuery.SELECT_QRY, wherestr);
        return(venueList);
    }

    @Override
    public List<Venue> getAllWithPaging(String wherestr, int pagesize, int first) {
        List<Venue> venueList = new ArrayList<Venue>();
        venueList = genericQryAllTemplateRowMapperWithPaging(VenueQuery.SELECT_QRY, 
                wherestr,  pagesize,  first);
        return(venueList);
    }  

    @Override
    public Venue getByEventId(int id) {
        Object[] obj = new Object[] { id };
        String sqlWhere = " WHERE event_id=?";
        String finalSQL =  VenueQuery.SELECT_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);  
    }

    @Override
    public long getAllCount(String wherestr) {
        return genericQryForInt(VenueQuery.SELECT_COUNT_QRY, wherestr);      }
       
    
}
