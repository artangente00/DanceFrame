/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query.systemconfig;

/**
 *
 * @author lmorallos
 */
public final class SystemConfigQuery {
    
    public static final String TBL_NAME = "tbl_systemconfig";
    
    public static final String ID_VARIABLE = "systemconfig_id";
    
    public static final String INSERT_QRY = "SELECT uberconsole.FN_SYSTEMCONFIG_INSERT( ?, ?, ?, ?, ?, ?)";
    
    public static final String UPDATE_QRY = "SELECT uberconsole.FN_SYSTEMCONFIG_UPDATE( ?, ?, ?, ?, ?, ?, ?)";
    
    public static final String DELETE_QRY = "SELECT uberconsole.FN_SYSTEMCONFIG_DELETE( ? )";
    
    public static final String SEARCH_BYSYSTEMCONFIGID_QRY = "SELECT uberconsole.FN_SYSTEMCONFIG_BYID( ? )";
    
    public static final String SEARCH_BYSYSTEMCONFIGNAME_QRY = "SELECT uberconsole.FN_SYSTEMCONFIG_BYSYSTEMCONFIGNAME( ? )";
    
    public static final String USER_SETDISABLE_QRY = "SELECT uberconsole.FN_USER_SETDISABLE(?, ?, ?)";
    
    public static final String SELECT_QRY = "SELECT systemconfig_id, systemconfig_name, systemconfig_value, systemconfig_type, " +
                                                " systemconfig_category, systemconfig_pushid, systemconfig_enabled " +
                                                "FROM uberconsole.VW_SYSTEMCONFIGMANAGEMENT";
    
    public static final String SELECT_COUNT_QRY = "SELECT count(systemconfig_id) FROM uberconsole.VW_SYSTEMCONFIGMANAGEMENT";
    
}








