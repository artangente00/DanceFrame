/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.competition;

import com.danceframe.console.common.model.competition.Venue;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class VenueRowMapper implements RowMapper<Venue> {
        
    @Override
    public Venue mapRow(final ResultSet rs, final int column) throws SQLException {
        final Venue venue = new Venue();        
        venue.setId(rs.getInt("venue_id"));        
        venue.setName(rs.getString("name"));
        venue.setAddress(rs.getString("address"));
        venue.setAddress2(rs.getString("address2"));
        venue.setCity(rs.getString("city"));
        venue.setProvince(rs.getString("province"));
        venue.setCountry(rs.getString("country"));
        venue.setZipcode(rs.getString("zipcode"));
        venue.setPhone(rs.getString("phone"));
        venue.setReservePhone(rs.getString("resvphone"));
        venue.setFax(rs.getString("fax"));	
        venue.setWebsite(rs.getString("website"));	
        venue.setLatitude(rs.getString("longtitude"));
        venue.setLongtitude(rs.getString("latitude"));
        venue.setEventid(rs.getInt("event_id"));
        return venue;
    }
    
}
