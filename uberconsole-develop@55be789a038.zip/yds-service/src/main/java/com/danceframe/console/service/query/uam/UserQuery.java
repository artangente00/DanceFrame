/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query.uam;

/**
 *
 * @author lmorallos
 */
public final class UserQuery {
    
    public static final String TBL_NAME = "tbl_user";
    
    public static final String ID_VARIABLE = "user_id";
    
    public static final String INSERT_QRY = "SELECT uberconsole.FN_USER_INSERT( ?, ?, ?, ?, ?)";
    
    public static final String UPDATE_QRY = "SELECT uberconsole.FN_USER_UPDATE( ?, ?, ?, ?, ?, ? )";
    
    public static final String DELETE_QRY = "SELECT uberconsole.FN_USER_DELETE( ?, ? )";
    
    public static final String SEARCH_BYUSERID_QRY = "SELECT uberconsole.FN_USER_BYID( ? )";
    
    public static final String SEARCH_BYUSERNAME_QRY = "SELECT uberconsole.FN_USER_BYUSERNAME( ? )";
    
    public static final String USER_SETDISABLE_QRY = "SELECT uberconsole.FN_USER_SETDISABLE(?, ?, ?)";
    
    public static final String SELECT_QRY = "SELECT user_id, username, firstname, lastname," +
                                                "active, datecreated, lastupdated " +
                                                "FROM uberconsole.VW_USERMANAGEMENT";
    
    public static final String SELECT_QRY_OLD = "SELECT user_id, username, firstname, lastname," +
                                                "active, datecreated, lastupdated " +
                                                "FROM uberconsole.tbl_user";
    
    public static final String SELECT_COUNT_QRY = "SELECT count(user_id) FROM uberconsole.VW_USERMANAGEMENT";
    
}








