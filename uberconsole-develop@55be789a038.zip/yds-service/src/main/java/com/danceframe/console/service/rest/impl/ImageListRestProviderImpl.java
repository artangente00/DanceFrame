/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rest.impl;

import com.danceframe.console.common.model.firebase.competition.ImageBlob;
import com.danceframe.console.common.model.firebase.competition.ImageDelta;
import com.danceframe.console.service.rest.ImageListRestProvider;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author lmorallos
 */
public class ImageListRestProviderImpl extends GenericRestProviderImpl<ImageDelta> implements ImageListRestProvider {

    private String uberSyncURL = "http://localhost:8080/uberSync/EventImages?op=list";
    
    @Override
    public List<ImageBlob> getDeltaList() {
        List<ImageBlob> retList = new ArrayList<>();
        ImageDelta imgDelta = this.get(uberSyncURL);
        
        if (imgDelta.getImageList() != null) {
            if (imgDelta.getImageList().size() > 0) {
               retList = imgDelta.getImageList();
            }
        }
        return retList;         
    }
    
   
}
