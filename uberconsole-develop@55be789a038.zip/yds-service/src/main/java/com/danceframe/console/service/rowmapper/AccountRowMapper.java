/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper;

import com.danceframe.console.common.model.registry.Account;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class AccountRowMapper implements RowMapper<Account>{

    @Override
    public Account mapRow(final ResultSet rs, final int column) throws SQLException {
        final Account account = new Account();
        // account.setId(rs.getInt("account_id"));
        account.setUserName(rs.getString("ousername"));
        account.setFirstName(rs.getString("ofname"));
        account.setLastName(rs.getString("olname"));
        account.setMidName(rs.getString("omname"));
        account.setEmail(rs.getString("oemail"));
        account.setAddress(rs.getString("oaddress"));
        account.setCity(rs.getString("ocity"));
        account.setProvince(rs.getString("oprovince"));
        account.setState(rs.getString("ostate"));
        account.setCountry(rs.getString("ocountry"));
        account.setTelePhone(rs.getString("otelephone"));
        account.setMobilePhone(rs.getString("omobile"));
        account.setAccType(rs.getInt("oacctype_id"));
        account.setAccDescription(rs.getString("oacctype_desc"));
        return account;
    }
    
}
