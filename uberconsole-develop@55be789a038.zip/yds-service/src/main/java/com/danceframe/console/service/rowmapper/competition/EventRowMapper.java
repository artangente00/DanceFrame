/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.competition;

import com.danceframe.console.common.model.competition.Event;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class EventRowMapper implements RowMapper<Event> {

    @Override
    public Event mapRow(final ResultSet rs, final int column) throws SQLException {
        final Event event = new Event();
        event.setCompetitionName(rs.getString("competition_name"));
        event.setName(rs.getString("event_name"));
        event.setId(rs.getInt("event_id"));
	event.setDateStart(rs.getDate("date_start"));
	event.setDateStop(rs.getDate("date_stop"));
	event.setDeadline(rs.getTimestamp("deadline"));
        event.setEventyear(rs.getInt("event_year"));
	event.setWebsite(rs.getString("website"));
        event.setStatus(rs.getInt("status"));
        event.setPubstatus(rs.getInt("pubstatus"));
	event.setCompetitionId(rs.getInt("competition_id"));
        event.setStatusname(rs.getString("status_name"));
        event.setImageid(rs.getInt("image_id"));
        event.setImgFilename(rs.getString("filename"));
        event.setMimeType(rs.getString("mimetype"));   
        event.setPublishedStatus(rs.getString("publish_status"));
        event.setTimeCommit(rs.getLong("timecommit"));
        event.setLastupdate(rs.getTimestamp("lastupdate"));
        event.setUseManual(rs.getBoolean("usemanual"));
        event.setUberRegister(rs.getBoolean("uregister"));
        event.setPushId(rs.getString("push_id"));
        event.setLastpublish(rs.getTimestamp("lastpublish"));
        event.setShortLink(rs.getString("shortlink"));
        event.setTestEvent(rs.getBoolean("testevent"));
        event.setWebsiteEnabled(rs.getBoolean("website_enabled"));
        event.setHideEvent(rs.getBoolean("hide_event"));
        event.setPaymentMethods(rs.getString("payment_methods"));
        event.setUid(rs.getString("uid"));
        return event;
    }
    
}
