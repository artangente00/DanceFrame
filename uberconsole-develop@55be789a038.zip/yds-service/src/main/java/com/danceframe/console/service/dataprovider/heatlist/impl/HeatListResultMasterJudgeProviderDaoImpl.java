/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.heatlist.impl;

import com.danceframe.console.common.model.heatlist.result.MasterJudge;
import com.danceframe.console.service.dataprovider.heatlist.HeatListResultMasterJudgeProviderDao;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.query.heatlist.HeatListResultQuery;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public class HeatListResultMasterJudgeProviderDaoImpl extends GenericProviderDaoImpl<MasterJudge> implements  HeatListResultMasterJudgeProviderDao {

    @Override
    public int search(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int search(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int insert(MasterJudge t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int update(MasterJudge judge) {
        Object[] obj = new Object[] {
            judge.getId(),
            judge.getFirstname(),
            judge.getLastname()
        };
        int ret = (Integer)this.genericQryTemplateInteger(HeatListResultQuery.SELECT_MASTERJUDGE_EDIT, obj);
        return ret;
    }

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public MasterJudge get(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public MasterJudge get(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<MasterJudge> getAll(String wherestr) {
        List<MasterJudge> mjudgeList = new ArrayList<MasterJudge>();
        mjudgeList = genericQryAllTemplateRowMapper(HeatListResultQuery.SELECT_MASTERJUDGE, wherestr);
        return(mjudgeList);
    }

    @Override
    public List<MasterJudge> getAllWithPaging(String wherestr, int pagesize, int first) {
        List<MasterJudge> mjudgeList = new ArrayList<MasterJudge>();
        mjudgeList = genericQryAllTemplateRowMapperWithPaging(HeatListResultQuery.SELECT_MASTERJUDGE, wherestr,  pagesize,  first);
        return(mjudgeList);
    }

    @Override
    public long getAllCount(String wherestr) {
        return genericQryForInt(HeatListResultQuery.SELECT_MASTERJUDGE_COUNT, wherestr);
    }

    @Override
    public int unifiedMasterJudge(int newid, int oldid) {
         int ret = 0;
         Object[] obj = new Object[] {
            newid, oldid
        };
        try {
         ret = (Integer)this.genericQryTemplateInteger(HeatListResultQuery.SELECT_MASTERJUDGE_UNIFIED, obj);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return ret;
    }
    
}
