/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.competition;

import com.danceframe.console.common.model.competition.Hotel;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class HotelRowMapper implements RowMapper<Hotel> {

    @Override
    public Hotel mapRow(ResultSet rs, int i) throws SQLException {
        Hotel hotel = new Hotel();
        hotel.setId(rs.getInt("information_id"));
        hotel.setUrl(rs.getString("url"));
        hotel.setDescription(rs.getString("description"));
        hotel.setOrderValue(rs.getInt("ordervalue"));
        hotel.setImageId(rs.getInt("image_id"));
        hotel.setEventId(rs.getInt("event_id"));
        return hotel;  
    }
    
}
