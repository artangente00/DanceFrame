/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.competition.config;

import com.danceframe.console.common.model.competition.form.EventFormHContent;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class EventFormHContentRowMapper implements RowMapper<EventFormHContent> {

    @Override
    public EventFormHContent mapRow(ResultSet rs, int column) throws SQLException {
        EventFormHContent hcontent = new EventFormHContent();
        hcontent.setId(rs.getInt("hcontent_id"));
        hcontent.setEventFormId(rs.getInt("eventform_id"));
        hcontent.setHorizHeader(rs.getString("horizheader"));
        return hcontent;
    }
    
}
