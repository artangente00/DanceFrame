/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.impl;

import com.danceframe.console.common.model.registry.AccountType;
import com.danceframe.console.service.dataprovider.AccountTypeProviderDao;
import com.danceframe.console.service.query.AccountTypeQuery;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class AccountTypeProviderDaoImpl extends BaseJdbcDaoImpl implements AccountTypeProviderDao {

    private static final Logger logger = LogManager.getLogger(AccountTypeProviderDaoImpl.class);
    
    private RowMapper<AccountType> rowMapper;
    
    @Override
    public int insertAccountType(String description) {
        int iret = -1;
        try {
            iret = getJdbcTemplate().queryForObject(AccountTypeQuery.INSERT_QRY, 
                    new Object[] {description}, Integer.class);
        } catch (EmptyResultDataAccessException ex) {
            logger.warn("accountype:insert:empty" + ex.getMessage());
        } catch (Exception ex) {  
            logger.warn("accountype:insert:error-" + ex.getMessage());     
        }
        
        return iret;
    }

    @Override
    public int updateAccountType(int id, String description) {
          int iret = -1;
        try {
            iret = getJdbcTemplate().queryForObject(AccountTypeQuery.UPDATE_QRY, 
                    new Object[] {id, description}, Integer.class);
        } catch (EmptyResultDataAccessException ex) {
            logger.warn("accountype:update:empty" + ex.getMessage());
        } catch (Exception ex) {  
            logger.warn("accountype:update:error-" + ex.getMessage());     
        }
        
        return iret;
    }

    @Override
    public int updateAccountTypeByDesc(String description, String newdescription) {
          int iret = -1;
        try {
            iret = getJdbcTemplate().queryForObject(AccountTypeQuery.UPDATE_BYDESC_QRY, 
                    new Object[] {description, newdescription }, Integer.class);
        } catch (EmptyResultDataAccessException ex) {
            logger.warn("accountype:updatebydesc:empty" + ex.getMessage());
        } catch (Exception ex) {  
            logger.warn("accountype:updatebydesc:error-" + ex.getMessage());          
        }
        
        return iret;
    }

    @Override
    public int deleteAccountType(String description) {
          int iret = -1;
        try {
            iret = getJdbcTemplate().queryForObject(AccountTypeQuery.DELETE_QRY, 
                    new Object[] {description}, Integer.class);
        } catch (EmptyResultDataAccessException ex) {
             logger.warn("accountype:delete:empty" + ex.getMessage());
        } catch (Exception ex) {  
            logger.warn("accountype:delete:error-" + ex.getMessage());        
        }
        return iret;
    }

    @Override
    public AccountType getAccountTypeInfo(String description) {
        AccountType accttyperet = null;
        
        try {
            accttyperet = (AccountType)getJdbcTemplate().queryForObject(AccountTypeQuery.GET_ACCOUNTTYPE_QRY, 
                    new Object[] {description}, rowMapper);
        } catch (EmptyResultDataAccessException ex) {
             logger.warn("accountype:delete:empty" + ex.getMessage());
        } catch (Exception ex) {  
            logger.warn("accountype:delete:error-" + ex.getMessage());        
        }
        return accttyperet;
        
    }
    
    @Override
    public List<AccountType> getAllAccounType() {
        List<AccountType> acctypeList = new ArrayList<AccountType>();
        try {
           
            acctypeList = getJdbcTemplate().query(AccountTypeQuery.SELECT_QRY, rowMapper);
        } catch (EmptyResultDataAccessException ex) {
            logger.warn("accountype:getallaccounttype:empty" + ex.getMessage());
            
        } catch (Exception ex) {  
            ex.printStackTrace();
            logger.warn("accountype:getallaccounttype:error-" + ex.getMessage());     
        }
        return acctypeList;
    }

    /**
     * @return the rowMapper
     */
    public RowMapper<AccountType> getRowMapper() {
        return rowMapper;
    }

    /**
     * @param rowMapper the rowMapper to set
     */
    public void setRowMapper(RowMapper<AccountType> rowMapper) {
        this.rowMapper = rowMapper;
    }

    

   
}
