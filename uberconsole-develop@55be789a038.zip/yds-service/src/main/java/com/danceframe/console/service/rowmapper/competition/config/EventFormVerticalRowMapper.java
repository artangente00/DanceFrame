/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.competition.config;

import com.danceframe.console.common.model.competition.form.EventFormVertical;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class EventFormVerticalRowMapper implements RowMapper<EventFormVertical> {

    @Override
    public EventFormVertical mapRow(ResultSet rs, int column) throws SQLException {
        EventFormVertical eventvertical = new EventFormVertical();
        eventvertical.setId(rs.getInt("eventvertical_id"));        
        eventvertical.setEventformId(rs.getInt("eventform_id"));
        eventvertical.setFieldId(rs.getInt("eventfield_id"));
        eventvertical.setCode(rs.getString("code"));
        eventvertical.setDescription(rs.getString("description"));
        eventvertical.setAllowall(rs.getBoolean("allowall"));
        return eventvertical;
    }
}
