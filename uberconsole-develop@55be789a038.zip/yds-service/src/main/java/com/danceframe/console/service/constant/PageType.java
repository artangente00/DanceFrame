/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.constant;

/**
 *
 * @author lmorallos
 */
public final class PageType {
    
    public static final  int NEW     = 1;
    
    public static final int EDIT     = 2;
    
    public static final int DELETE   = 3;
    
    public static final int SEARCH   = 4;
    
    public static final int VIEW     = 5;
}
