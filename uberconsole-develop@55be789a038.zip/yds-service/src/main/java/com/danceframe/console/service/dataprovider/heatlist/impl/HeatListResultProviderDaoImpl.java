/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.heatlist.impl;

import com.danceframe.console.common.model.heatlist.result.HeatListResultPersonKey;
import com.danceframe.console.common.model.heatlist.result.HeatResultCompetitor;
import com.danceframe.console.common.model.heatlist.result.HeatResultHeat;
import com.danceframe.console.common.model.heatlist.result.HeatResultJudge;
import com.danceframe.console.common.model.heatlist.result.HeatResultMark;
import com.danceframe.console.common.model.heatlist.result.HeatResultPerson;
import com.danceframe.console.common.model.heatlist.result.HeatResultProgram;
import com.danceframe.console.common.model.heatlist.result.HeatResultResult;
import com.danceframe.console.common.model.heatlist.result.HeatResultStudio;
import com.danceframe.console.common.model.heatlist.result.HeatResultSubHeat;
import com.danceframe.console.common.model.heatlist.result.HeatResultSubHeats;
import com.danceframe.console.common.model.heatlist.result.HeatlistResultXML;
import com.danceframe.console.common.util.Utility;
import com.danceframe.console.service.dataprovider.heatlist.HeatListResultProviderDao;
import com.danceframe.console.service.dataprovider.impl.BaseJdbcDaoImpl;
import com.danceframe.console.service.query.heatlist.HeatListResultQuery;
import com.danceframe.console.service.rowmapper.heatlist.result.HeatResultCompetitorRowMapper;
import com.danceframe.console.service.rowmapper.heatlist.result.HeatResultHeatRowMapper;
import com.danceframe.console.service.rowmapper.heatlist.result.HeatResultJudgeRowMapper;
import com.danceframe.console.service.rowmapper.heatlist.result.HeatResultMarkRowMapper;
import com.danceframe.console.service.rowmapper.heatlist.result.HeatResultPersonKeyRowMapper;
import com.danceframe.console.service.rowmapper.heatlist.result.HeatResultPersonRowMapper;
import com.danceframe.console.service.rowmapper.heatlist.result.HeatResultResultRowMapper;
import com.danceframe.console.service.rowmapper.heatlist.result.HeatResultStudioRowMapper;
import com.danceframe.console.service.rowmapper.heatlist.result.HeatResultSubHeatRowMapper;
import com.danceframe.console.service.rowmapper.heatlist.result.HeatResultSubHeatsRowMapper;
import com.danceframe.console.service.rowmapper.heatlist.result.HeatResultXMLResultRowMapper;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class HeatListResultProviderDaoImpl extends BaseJdbcDaoImpl implements HeatListResultProviderDao {

    private static final Logger logger = LogManager.getLogger(HeatListResultProviderDaoImpl.class);
    
    private HeatResultStudioRowMapper heatResultStudioRowMapper;
    private HeatResultJudgeRowMapper heatResultJudgeRowMapper;
    private HeatResultCompetitorRowMapper heatResultCompetitorRowMapper;
    private HeatResultPersonKeyRowMapper heatResultPersonKeyRowMapper;
    private HeatResultPersonRowMapper heatResultPersonRowMapper; 
    private HeatResultHeatRowMapper heatResultHeatRowMapper;   
    private HeatResultSubHeatRowMapper heatResultSubHeatRowMapper;
    private HeatResultSubHeatsRowMapper heatResultSubHeatsRowMapper;
    private HeatResultResultRowMapper heatResultResultRowMapper;
    private HeatResultMarkRowMapper heatResultMarkRowMapper;
    private HeatResultXMLResultRowMapper heatResultXMLResultRowMapper;

    @Override
    public int clearByEventId(int eventId) {
        Object[] obj = new Object[] {  eventId  };
        logger.info(HeatListResultQuery.EVENT_CLEAR_QRY);
        int iret = (Integer)getJdbcTemplate().queryForObject(HeatListResultQuery.EVENT_CLEAR_QRY, 
                   obj, Integer.class);
        return iret;
    }

    @Override
    public int insertProgram(HeatResultProgram program) {
        boolean istudio	= (program.getStudios()!=null)?true:false;
	boolean ijudge	= (program.getJudges()!=null)?true:false;
	boolean iperson = (program.getPersons()!=null)?true:false;
        boolean icompetitor = (program.getCompetitors()!=null)?true:false;
	boolean iheat	= (program.getHeats()!=null)?true:false;
        
        Object[] obj = new Object[] {  
             istudio, ijudge , iperson, icompetitor, iheat,
             program.getEventId(),
             program.getXmlId()
         };
        logger.info(HeatListResultQuery.PROGRAM_INSERT_QRY);
        int iret = (Integer)getJdbcTemplate().queryForObject(HeatListResultQuery.PROGRAM_INSERT_QRY, 
                   obj, Integer.class);
        return iret;
    }
    
    @Override
    public int insertStudio(HeatResultStudio studio) {
         Object[] obj = new Object[] {  
             studio.getStudioKey(),
             studio.getName(),
             studio.getIndependentInvoice(),
             studio.getEventId(),
             studio.getXmlId()
         };
        //logger.info(HeatListResultQuery.STUDIO_INSERT_QRY);
        int iret = (Integer)getJdbcTemplate().queryForObject(HeatListResultQuery.STUDIO_INSERT_QRY, 
                   obj, Integer.class);
        return iret;
    }

    @Override
    public int insertJudge(HeatResultJudge judge) {
         Object[] obj = new Object[] {  
             judge.getJudgeKey(),
             Utility.null2Str(judge.getFirstName()),
             Utility.null2Str(judge.getLastName()),
             judge.getJudgeNumber(),
             judge.getEventId(),
             judge.getXmlId()
         };
        //logger.info(HeatListResultQuery.JUDGE_INSERT_QRY);
        int iret = (Integer)getJdbcTemplate().queryForObject(HeatListResultQuery.JUDGE_INSERT_QRY, 
                   obj, Integer.class);
        return iret;
    }
    
    @Override
    public int insertPerson(HeatResultPerson person) {
         Object[] obj = new Object[] {  
             person.getPersonKey(),
             Utility.null2Str(person.getFirstName()),
             Utility.null2Str(person.getLastName()),
             person.getGender(),
             person.getPersonType(),
             person.getStudioKey(),
             person.getCompetitorNumber(),
             person.getEventId(),
             person.getXmlId()
         };
        //logger.info(HeatListResultQuery.PERSON_INSERT_QRY);
        int iret = (Integer)getJdbcTemplate().queryForObject(HeatListResultQuery.PERSON_INSERT_QRY, 
                   obj, Integer.class);
        return iret;
    }

    
    @Override
    public int insertCompetitor(HeatResultCompetitor competitor) {
        Object[] obj = new Object[] {  
                competitor.getCompetitorKey(),
                competitor.getCompetitorType(),
                competitor.getNameOverride(),
                competitor.getPersonKeys().get(0).getPersonKey(),
                (competitor.getPersonKeys().size() == 2)?competitor.getPersonKeys().get(1).getPersonKey():null,
                competitor.getEventId(),
                competitor.getXmlId()
             };
        int iret = (Integer)getJdbcTemplate().queryForObject(HeatListResultQuery.COMPETITOR_INSERT_QRY, 
                   obj, Integer.class);
        return iret;
    }
    
    @Override
    public int insertPersonKey(HeatListResultPersonKey personkey) {
          Object[] obj = new Object[] {  
            personkey.getPersonKey(),
            personkey.getCompetitorId(),
            personkey.getEventId(),
            personkey.getXmlId()
             };
        int iret = (Integer)getJdbcTemplate().queryForObject(HeatListResultQuery.PERSONKEY_INSERT_QRY, 
                   obj, Integer.class);
        return iret;
    }

    
    @Override
    public int insertHeat(HeatResultHeat heat) {
        Object[] obj = new Object[] {  
            heat.getName(),
            heat.getSession(),
            heat.getTime(),
            heat.getDate(),
            heat.getDesc(),
            heat.getType(),
            heat.getPart(),
            heat.getCategory(),
            heat.getEventId(),
            heat.getXmlId()
         };
        int iret = (Integer)getJdbcTemplate().queryForObject(HeatListResultQuery.HEATS_INSERT_QRY, 
                   obj, Integer.class);
        return iret;
    }

     @Override
    public int insertSubHeats(HeatResultSubHeats subheats) {
        Object[] obj = new Object[] {  
             subheats.getDanceType(),
             subheats.getLevel(),             
             subheats.getAge(),
             subheats.getType(),
             subheats.getOrder(),
             subheats.getHeatId(),
             subheats.getEventId()
         };
        int iret = (Integer)getJdbcTemplate().queryForObject(HeatListResultQuery.SUBHEATS_INSERT_QRY, 
                   obj, Integer.class);
        return iret;
    }
    
    @Override
    public int insertSubHeat(HeatResultSubHeat subheat) {
        Object[] obj = new Object[] {  
             subheat.getId(),
             subheat.getDance(),
             subheat.getOrder(),
             subheat.getScoring(),
             subheat.getSubheatsId(),
             subheat.getEventId()
         };
        int iret = (Integer)getJdbcTemplate().queryForObject(HeatListResultQuery.SUBHEAT_INSERT_QRY, 
                   obj, Integer.class);
        return iret;
    }
    
    @Override
    public int insertResult(HeatResultResult result) {
        Object[] obj = new Object[] {  
            result.getJudgingPanel(),
            result.getScoreHeaders(),
            result.getSubHeatId(),
            result.getEventId()
         };
        int iret = (Integer)getJdbcTemplate().queryForObject(HeatListResultQuery.RESULT_INSERT_QRY, 
                   obj, Integer.class);
        return iret;
    }

    
    @Override
    public int insertMark(HeatResultMark mark) {
          Object[] obj = new Object[] {  
            mark.getKey(),
            mark.getValue(),
            mark.getStudioName(),
            mark.getResultId(),
            mark.getSubHeatId(),
            mark.getEventId()
         };
        int iret = (Integer)getJdbcTemplate().queryForObject(HeatListResultQuery.MARKS_INSERT_QRY, 
                   obj, Integer.class);
        return iret;
    }

    @Override
    public List<HeatResultStudio> getStudios(int eventId) {
        Object[] obj = new Object[] {eventId };
        String sql = HeatListResultQuery.SELECT_STUDIO_QRY + " WHERE event_id=?";
        logger.info(sql);
        return (List<HeatResultStudio>)getJdbcTemplate().query(sql, obj, heatResultStudioRowMapper);
    }

    @Override
    public List<HeatResultJudge> getJudges(int eventId) {
        Object[] obj = new Object[] {eventId };
        String sql = HeatListResultQuery.SELECT_JUDGE_QRY + " WHERE event_id=?";
        logger.info(sql);
        return (List<HeatResultJudge>)getJdbcTemplate().query(sql, obj, heatResultJudgeRowMapper);
    }

    @Override
    public List<HeatResultPerson> getPersons(int eventId) {
         Object[] obj = new Object[] {eventId };
        String sql = HeatListResultQuery.SELECT_PERSON_QRY + " WHERE event_id=?";
        logger.info(sql);
        return (List<HeatResultPerson>)getJdbcTemplate().query(sql, obj, heatResultPersonRowMapper);
    }

    @Override
    public List<HeatResultCompetitor> getCompetitor(int eventId) {
         Object[] obj = new Object[] {eventId };
        String sql = HeatListResultQuery.SELECT_COMPETITOR_QRY + " WHERE event_id=?";
        logger.info(sql);
        return (List<HeatResultCompetitor>)getJdbcTemplate().query(sql, obj, heatResultCompetitorRowMapper);
    }
    
        @Override
    public List<HeatListResultPersonKey> getPersonKeys(int eventId, int competitorId) {
         Object[] obj = new Object[] {eventId, competitorId};
        String sql = HeatListResultQuery.SELECT_PERSONKEY_QRY + " WHERE event_id=? AND competitor_id=?";
        logger.info(sql);
        return (List<HeatListResultPersonKey>)getJdbcTemplate().query(sql, obj, heatResultPersonKeyRowMapper);
    }


  
    @Override
    public List<HeatResultHeat> getHeats(int eventId) {
         Object[] obj = new Object[] {eventId };
        String sql = HeatListResultQuery.SELECT_HEAT_QRY + " WHERE event_id=?";
        logger.info(sql);
        return (List<HeatResultHeat>)getJdbcTemplate().query(sql, obj, heatResultHeatRowMapper);
    }

    @Override
    public List<HeatResultSubHeats> getSubHeats(int eventId, int heatId) {
        Object[] obj = new Object[] {eventId , heatId};
        String sql = HeatListResultQuery.SELECT_SUBHEATS_QRY + " WHERE event_id=? and heat_id=?";
        logger.info(sql);
        return (List<HeatResultSubHeats>)getJdbcTemplate().query(sql, obj, heatResultSubHeatsRowMapper);
    }

     @Override
    public List<HeatResultSubHeat> getSubHeat(int eventId, int subheatsId) {
        Object[] obj = new Object[] {eventId , subheatsId};
        String sql = HeatListResultQuery.SELECT_SUBHEAT_QRY + " WHERE event_id=? and suheats_id=?";
        logger.info(sql);
        return (List<HeatResultSubHeat>)getJdbcTemplate().query(sql, obj, heatResultSubHeatRowMapper);
    }

    @Override
    public List<HeatResultResult> getResult(int eventId, int subHeatId) {
        Object[] obj = new Object[] {eventId , subHeatId};
        String sql = HeatListResultQuery.SELECT_RESULT_QRY + " WHERE event_id=? and subheat_id=?";
        logger.info(sql);
        return (List<HeatResultResult>)getJdbcTemplate().query(sql, obj, heatResultResultRowMapper);
    }

    @Override
    public List<HeatResultMark> getMarks(int eventId, int subHeatId, int resultId) {
        Object[] obj = new Object[] {eventId , subHeatId, resultId };
        String sql = HeatListResultQuery.SELECT_MARK_QRY + " WHERE event_id=? and subheat_id=? and result_id=?";
        logger.info(sql);
        return (List<HeatResultMark>)getJdbcTemplate().query(sql, obj, heatResultMarkRowMapper);
    }
    
    
    @Override
    public HeatlistResultXML getHeatResultXML(int eventId) {
        HeatlistResultXML retobj = null;
        Object[] obj = new Object[] { eventId };
        String sql = HeatListResultQuery.SELECT_XMLDATA_QRY;
        logger.info(sql);
        try {
            retobj = (HeatlistResultXML)getJdbcTemplate().queryForObject(sql, obj, heatResultXMLResultRowMapper);
        } catch (EmptyResultDataAccessException ex) {
            retobj = null;
        }
        return retobj;
    }
    
    @Override
    public List<Integer> getEventIds(int masterpersonId) {
        Object[] obj = new Object[] { masterpersonId, masterpersonId };
        List<Integer> data = new ArrayList<>();
            data = getJdbcTemplate().query(HeatListResultQuery.SELECT_EVENTID_QRY, obj,
            new RowMapper<Integer>(){
                        public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
                                return rs.getInt(1);
                        }
                   });
        return data;
    }

    @Override
    public List<HeatResultJudge> getJudgesUnfied(int eventId) {
        Object[] obj = new Object[] {eventId };
        logger.info(HeatListResultQuery.SELECT_JUDGEUNFIED_QRY);
        return (List<HeatResultJudge>)getJdbcTemplate().query(HeatListResultQuery.SELECT_JUDGEUNFIED_QRY, obj, heatResultJudgeRowMapper);
    }

    @Override
    public List<HeatResultPerson> getPersons(int eventId, int masterpersonId) {
         Object[] obj = new Object[] {masterpersonId, masterpersonId, eventId };
        logger.info(HeatListResultQuery.SELECT_PERSON_VIEW_QRY);
        return (List<HeatResultPerson>)getJdbcTemplate().query(HeatListResultQuery.SELECT_PERSON_VIEW_QRY, obj, heatResultPersonRowMapper);
    }

    @Override
    public List<HeatResultCompetitor> getCompetitor(int eventId, int masterpersonId) {
         Object[] obj = new Object[] {masterpersonId, masterpersonId, eventId };
        logger.info(HeatListResultQuery.SELECT_COMPETITOR_VIEW_QRY);
        return (List<HeatResultCompetitor>)getJdbcTemplate().query(HeatListResultQuery.SELECT_COMPETITOR_VIEW_QRY, obj, heatResultCompetitorRowMapper);
    }

    @Override
    public List<HeatResultHeat> getHeat(int eventId, int masterpersonId) {
         Object[] obj = new Object[] {masterpersonId, masterpersonId, eventId };
        logger.info(HeatListResultQuery.SELECT_HEAT_VIEW_QRY);
        return (List<HeatResultHeat>)getJdbcTemplate().query(HeatListResultQuery.SELECT_HEAT_VIEW_QRY, obj, heatResultHeatRowMapper);
    }

    @Override
    public List<HeatResultSubHeats> getSubHeats(int eventId, int heatId, int masterpersonId) {
         Object[] obj = new Object[] {masterpersonId, masterpersonId, eventId , heatId};
        logger.info(HeatListResultQuery.SELECT_SUBHEATS_VIEW_QRY);
        return (List<HeatResultSubHeats>)getJdbcTemplate().query(HeatListResultQuery.SELECT_SUBHEATS_VIEW_QRY, obj, heatResultSubHeatsRowMapper);
    }
    
    @Override
    public List<HeatResultSubHeat> getSubHeat(int eventId, int subheatsId, int masterpersonId) {
         Object[] obj = new Object[] {masterpersonId, masterpersonId, eventId , subheatsId};
        logger.info(HeatListResultQuery.SELECT_SUBHEAT_VIEW_QRY);
        return (List<HeatResultSubHeat>)getJdbcTemplate().query(HeatListResultQuery.SELECT_SUBHEAT_VIEW_QRY, obj, heatResultSubHeatRowMapper);
    }

    @Override
    public HeatResultResult getResult(int eventId, int subHeatId, int masterpersonId) {
        Object[] obj = new Object[] {masterpersonId, masterpersonId, eventId, subHeatId };
        logger.info(HeatListResultQuery.SELECT_RESULT_VIEW_QRY);
        return (HeatResultResult)getJdbcTemplate().queryForObject(HeatListResultQuery.SELECT_RESULT_VIEW_QRY, obj, heatResultResultRowMapper);
    }

    @Override
    public List<HeatResultMark> getMarks(int eventId, int subHeatId, int resultId, int masterpersonId) {
        Object[] obj = new Object[] {masterpersonId, masterpersonId, eventId, subHeatId, resultId };
        logger.info(HeatListResultQuery.SELECT_MARK_VIEW_QRY);
        return (List<HeatResultMark>)getJdbcTemplate().query(HeatListResultQuery.SELECT_MARK_VIEW_QRY, obj, heatResultMarkRowMapper);
    }
    
      @Override
    public List<HeatResultSubHeats> getSubHeatsNoMP(int eventId, int heatId) {
        Object[] obj = new Object[] {eventId , heatId};
        logger.info(HeatListResultQuery.SELECT_SUBHEATS_NOMP_VIEW_QRY);
        return (List<HeatResultSubHeats>)getJdbcTemplate().query(HeatListResultQuery.SELECT_SUBHEATS_NOMP_VIEW_QRY, obj, heatResultSubHeatsRowMapper);

    }

    @Override
    public List<HeatResultSubHeat> getSubHeatNoMP(int eventId, int subheatsId) {
        Object[] obj = new Object[] {eventId , subheatsId};
        logger.info(HeatListResultQuery.SELECT_SUBHEAT_NOMP_VIEW_QRY);
        return (List<HeatResultSubHeat>)getJdbcTemplate().query(HeatListResultQuery.SELECT_SUBHEAT_NOMP_VIEW_QRY, obj, heatResultSubHeatRowMapper);

    }

    @Override
    public HeatResultResult getResultNoMP(int eventId, int subHeatId) {
        Object[] obj = new Object[] {eventId, subHeatId };
        logger.info(HeatListResultQuery.SELECT_RESULT_NOMP_VIEW_QRY);
        return (HeatResultResult)getJdbcTemplate().queryForObject(HeatListResultQuery.SELECT_RESULT_NOMP_VIEW_QRY, obj, heatResultResultRowMapper);

    }

    @Override
    public List<HeatResultMark> getMarksNoMP(int eventId, int subHeatId, int resultId) {
        Object[] obj = new Object[] {eventId, subHeatId, resultId };
        logger.info(HeatListResultQuery.SELECT_MARK_NOMP_VIEW_QRY);
        return (List<HeatResultMark>)getJdbcTemplate().query(HeatListResultQuery.SELECT_MARK_NOMP_VIEW_QRY, obj, heatResultMarkRowMapper);
    }

    
    @Override
    public List<HeatResultJudge> getJudgesUnfied(int eventId, List<String> judgeKeys) {
        StringBuffer sb = new StringBuffer();
        for (String str:judgeKeys) {
            sb.append("'" + str + "',");
        }
        if (sb.length() > 0) sb.deleteCharAt(sb.length() - 1);
        
        Object[] obj = new Object[] {eventId };
        String sql = HeatListResultQuery.SELECT_JUDGEUNFIED_LIST_QRY + " AND judge_num IN (" + sb.toString() + ")";
        logger.info(sql);
        return (List<HeatResultJudge>)getJdbcTemplate().query(sql, obj, heatResultJudgeRowMapper);
    }

    @Override
    public List<HeatResultPerson> getPersons(int eventId, List<String> competitorKeys) {
         StringBuffer sb = new StringBuffer();
        for (String str:competitorKeys) {
            sb.append("'" + str + "',");
        }
        if (sb.length() > 0) sb.deleteCharAt(sb.length() - 1);
        
        Object[] obj = new Object[] {eventId };
        String sql = String.format(HeatListResultQuery.SELECT_PERSON_COMPLIST_QRY, sb.toString());
        logger.info(sql);
        return (List<HeatResultPerson>)getJdbcTemplate().query(sql, obj, heatResultPersonRowMapper);
    }

    @Override
    public List<HeatResultCompetitor> getCompetitor(int eventId, List<String> competitorKeys) {
         StringBuffer sb = new StringBuffer();
        for (String str:competitorKeys) {
            sb.append("'" + str + "',");
        }
        if (sb.length() > 0) sb.deleteCharAt(sb.length() - 1);
        
        Object[] obj = new Object[] {eventId };
        String sql = HeatListResultQuery.SELECT_COMPETITOR_LIST_QRY + " AND competitor_key IN (" + sb.toString() + ")";
        logger.info(sql);
        return (List<HeatResultCompetitor>)getJdbcTemplate().query(sql, obj, heatResultCompetitorRowMapper);

    }
    
   @Override
    public String getPerson(int eventId, int masterpersonId) {
        Object[] obj = new Object[] {eventId, masterpersonId};
        logger.info(HeatListResultQuery.SELECT_PERSON_MASTERPERSON_QRY);
        return (String)getJdbcTemplate().queryForObject(HeatListResultQuery.SELECT_PERSON_MASTERPERSON_QRY , obj, String.class);
    }
  
  
    /**
     * @return the heatResultJudgeRowMapper
     */
    public HeatResultJudgeRowMapper getHeatResultJudgeRowMapper() {
        return heatResultJudgeRowMapper;
    }

    /**
     * @param heatResultJudgeRowMapper the heatResultJudgeRowMapper to set
     */
    public void setHeatResultJudgeRowMapper(HeatResultJudgeRowMapper heatResultJudgeRowMapper) {
        this.heatResultJudgeRowMapper = heatResultJudgeRowMapper;
    }

    /**
     * @return the heatResultResultRowMapper
     */
    public HeatResultResultRowMapper getHeatResultResultRowMapper() {
        return heatResultResultRowMapper;
    }

    /**
     * @param heatResultResultRowMapper the heatResultResultRowMapper to set
     */
    public void setHeatResultResultRowMapper(HeatResultResultRowMapper heatResultResultRowMapper) {
        this.heatResultResultRowMapper = heatResultResultRowMapper;
    }

    /**
     * @return the heatResultMarkRowMapper
     */
    public HeatResultMarkRowMapper getHeatResultMarkRowMapper() {
        return heatResultMarkRowMapper;
    }

    /**
     * @param heatResultMarkRowMapper the heatResultMarkRowMapper to set
     */
    public void setHeatResultMarkRowMapper(HeatResultMarkRowMapper heatResultMarkRowMapper) {
        this.heatResultMarkRowMapper = heatResultMarkRowMapper;
    }

    /**
     * @return the heatResultStudioRowMapper
     */
    public HeatResultStudioRowMapper getHeatResultStudioRowMapper() {
        return heatResultStudioRowMapper;
    }

    /**
     * @param heatResultStudioRowMapper the heatResultStudioRowMapper to set
     */
    public void setHeatResultStudioRowMapper(HeatResultStudioRowMapper heatResultStudioRowMapper) {
        this.heatResultStudioRowMapper = heatResultStudioRowMapper;
    }

    /**
     * @return the heatResultHeatRowMapper
     */
    public HeatResultHeatRowMapper getHeatResultHeatRowMapper() {
        return heatResultHeatRowMapper;
    }

    /**
     * @param heatResultHeatRowMapper the heatResultHeatRowMapper to set
     */
    public void setHeatResultHeatRowMapper(HeatResultHeatRowMapper heatResultHeatRowMapper) {
        this.heatResultHeatRowMapper = heatResultHeatRowMapper;
    }

    /**
     * @return the heatResultPersonRowMapper
     */
    public HeatResultPersonRowMapper getHeatResultPersonRowMapper() {
        return heatResultPersonRowMapper;
    }

    /**
     * @param heatResultPersonRowMapper the heatResultPersonRowMapper to set
     */
    public void setHeatResultPersonRowMapper(HeatResultPersonRowMapper heatResultPersonRowMapper) {
        this.heatResultPersonRowMapper = heatResultPersonRowMapper;
    }

    /**
     * @return the heatResultSubHeatRowMapper
     */
    public HeatResultSubHeatRowMapper getHeatResultSubHeatRowMapper() {
        return heatResultSubHeatRowMapper;
    }

    /**
     * @param heatResultSubHeatRowMapper the heatResultSubHeatRowMapper to set
     */
    public void setHeatResultSubHeatRowMapper(HeatResultSubHeatRowMapper heatResultSubHeatRowMapper) {
        this.heatResultSubHeatRowMapper = heatResultSubHeatRowMapper;
    }

    /**
     * @return the heatResultCompetitorRowMapper
     */
    public HeatResultCompetitorRowMapper getHeatResultCompetitorRowMapper() {
        return heatResultCompetitorRowMapper;
    }

    /**
     * @param heatResultCompetitorRowMapper the heatResultCompetitorRowMapper to set
     */
    public void setHeatResultCompetitorRowMapper(HeatResultCompetitorRowMapper heatResultCompetitorRowMapper) {
        this.heatResultCompetitorRowMapper = heatResultCompetitorRowMapper;
    }

    /**
     * @return the heatResultXMLResultRowMapper
     */
    public HeatResultXMLResultRowMapper getHeatResultXMLResultRowMapper() {
        return heatResultXMLResultRowMapper;
    }

    /**
     * @param heatResultXMLResultRowMapper the heatResultXMLResultRowMapper to set
     */
    public void setHeatResultXMLResultRowMapper(HeatResultXMLResultRowMapper heatResultXMLResultRowMapper) {
        this.heatResultXMLResultRowMapper = heatResultXMLResultRowMapper;
    }

    /**
     * @return the heatResultSubHeatsRowMapper
     */
    public HeatResultSubHeatsRowMapper getHeatResultSubHeatsRowMapper() {
        return heatResultSubHeatsRowMapper;
    }

    /**
     * @param heatResultSubHeatsRowMapper the heatResultSubHeatsRowMapper to set
     */
    public void setHeatResultSubHeatsRowMapper(HeatResultSubHeatsRowMapper heatResultSubHeatsRowMapper) {
        this.heatResultSubHeatsRowMapper = heatResultSubHeatsRowMapper;
    }

    /**
     * @return the heatResultPersonKeyRowMapper
     */
    public HeatResultPersonKeyRowMapper getHeatResultPersonKeyRowMapper() {
        return heatResultPersonKeyRowMapper;
    }

    /**
     * @param heatResultPersonKeyRowMapper the heatResultPersonKeyRowMapper to set
     */
    public void setHeatResultPersonKeyRowMapper(HeatResultPersonKeyRowMapper heatResultPersonKeyRowMapper) {
        this.heatResultPersonKeyRowMapper = heatResultPersonKeyRowMapper;
    }


}
