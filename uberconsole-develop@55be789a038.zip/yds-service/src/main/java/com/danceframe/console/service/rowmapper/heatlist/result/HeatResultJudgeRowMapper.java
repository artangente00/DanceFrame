/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.heatlist.result;

import com.danceframe.console.common.model.heatlist.result.HeatResultJudge;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class HeatResultJudgeRowMapper implements RowMapper<HeatResultJudge> {

    @Override
    public HeatResultJudge mapRow(ResultSet rs, int i) throws SQLException {
        final HeatResultJudge judge = new HeatResultJudge();
        judge.setId(rs.getInt("judge_id"));
        judge.setJudgeKey(rs.getString("judge_key"));
        judge.setFirstName(rs.getString("firstname"));
        judge.setLastName(rs.getString("lastname"));
        judge.setJudgeNumber(rs.getString("judge_num"));
        judge.setMasterjudge_id(rs.getInt("masterjudge_id"));
        judge.setEventId(rs.getInt("event_id"));
        //judge.setXmlId(rs.getInt("xml_id"));
        return judge;
    }

}
