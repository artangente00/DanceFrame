/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.heatlist.result;

import com.danceframe.console.common.model.heatlist.result.HeatListResultPersonKey;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class HeatResultPersonKeyRowMapper implements RowMapper<HeatListResultPersonKey> {

    @Override
    public HeatListResultPersonKey mapRow(ResultSet rs, int i) throws SQLException {
        final HeatListResultPersonKey personkey = new HeatListResultPersonKey();
        personkey.setId(rs.getInt("personkey_id"));
        personkey.setPersonKey(rs.getString("person_key"));
        personkey.setCompetitorId(rs.getInt("competitor_id"));
        personkey.setEventId(rs.getInt("event_id"));
        personkey.setXmlId(rs.getInt("xml_id"));
        return personkey;
    }
    
}
