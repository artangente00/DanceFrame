/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query.heatlist;

/**
 *
 * @author lmorallos
 */
public final class HeatListQuery {
    
    public final static String INSERT_HEATLIST_QRY = "SELECT uberconsole.FN_HEAT_LIST_INSERT(?, ?, ?, ?, ?, ?)";
     
    public final static String INSERT_HEATSTUDIO_QRY = "SELECT uberconsole.FN_HEAT_STUDIO_INSERT(?, ?, ?)";
     
    public final static String INSERT_HEATPERSON_QRY = "SELECT uberconsole.FN_HEAT_PERSON_INSERT(?, ?, ?, ?, ?, ?, ?)";
     
    public final static String INSERT_HEATINFO_QRY = "SELECT uberconsole.FN_HEAT_INFO_INSERT(?, ?, ?, ?)";
     
    public final static String INSERT_HEATCOMP_QRY = "SELECT uberconsole.FN_HEAT_COMP_INSERT(?, ?, ?, ?, ?, ?, ?)";
     
    public final static String INSERT_HEATENTRY_QRY = "SELECT uberconsole.FN_HEAT_ENTRY_INSERT(?, ?, ?, ?, ?, ?, ?, ?)";
     
    public final static String DELETE_HEATLIST_QRY = "SELECT uberconsole.FN_HEAT_LIST_DELETE( ? )";
    
    public final static String INSERT_HEATSESSION_QRY = "SELECT uberconsole.FN_HEAT_SESSION_INSERT(?, ?, ?, ?, ?)";
    
    public final static String UPDATE_HEATLISTFILE_QRY = "SELECT uberconsole.FN_HEATLIST_UPLOAD_FILE(?, ?)";
     
    public final static String UPDATE_HEATSTUFILE_QRY = "SELECT uberconsole.FN_HEATLIST_UPLOAD_SETUPFILE(?, ?)";
    
    
    public final static String SELECT_PERSON_QRY = 
            "SELECT person_id,personcpm_id,lastname,firstname,sex,profile_type,studio_id," + 
            "studiocpm_id,heatlist_id FROM uberconsole.tbl_heatperson WHERE heatlist_id=? ORDER BY lastname, firstname ASC";
    
    public final static String SELECT_HEATDATA_QRY = 
            "SELECT heatlist_id,person_id,personcpm_id,mainname,mainsex,partner_id," + 
            "partnercpm_id,partname,partsex,seqno,comp_id,compcpm_id,otherinfo," + 
            "heattype,dance,heatlevel,age,heat_id,heat_val,schedule,description FROM uberconsole.VW_HEATLIST_INFO " +
            "WHERE heatlist_id=? AND (personcpm_id=? OR partnercpm_id=?) ORDER BY SUBSTRING(heat_val FROM '([0-9]+)')::BIGINT ASC";

//      public final static String SELECT_HEATDATA_QRY = 
//            "SELECT heatlist_id,person_id,personcpm_id,mainname,mainsex,partner_id," + 
//            "partnercpm_id,partname,partsex,seqno,comp_id,compcpm_id,otherinfo," + 
//            "heattype,dance,heatlevel,age,heat_id,heat_val,schedule,description FROM uberconsole.VW_HEATLIST_INFO " +
//            "WHERE heatlist_id=? AND (personcpm_id=? OR partnercpm_id=?) ORDER BY partname, heat_id, schedule, description";

    public final static String COUNT_DATA_QRY = "SELECT count(heatlist_id) FROM uberconsole.VW_HEATLIST_INFO " + 
            "WHERE heatlist_id=? AND (personcpm_id=? OR partnercpm_id=?)";
    
    public final static String SELECT_HEATLIST_QRY = "SELECT heatlist_id,event_id, description,filename,comp_date, stufilename, heatasof," + 
            "event_name, event_year,date_start, date_stop, pubstatus, uid, competition_name, publish_status FROM uberconsole.VW_HEATLIST_WITH_EVENT"; 
    
    public final static String COUNT_HEATLIST_QRY = "SELECT count(heatlist_id) FROM uberconsole.VW_HEATLIST_WITH_EVENT";
    
    public final static String DELETE_HEATLIST_BYEVENTID_QRY = "SELECT uberconsole.FN_HEAT_LIST_DELETE_BYEVENTID(?)";
    
    public final static String SELECT_HEATLIST_CHECK_BYEVENTID_QRY = "SELECT uberconsole.FN_HEAT_LIST_CHECK_BYEVENTID(?)";
    
    public final static String SELECT_HEATSESSION_QRY = "SELECT session_id,session_cnt,session_day,session_date, "
             + "session_time, heatlist_id FROM uberconsole.tbl_heatsession WHERE heatlist_id = ? ORDER BY session_cnt";
     
    
}
