/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper;

import com.danceframe.console.common.model.basic.Image;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class ImageRowMapper implements RowMapper<Image>{


    @Override
    public Image mapRow(ResultSet rs, int column) throws SQLException {
        final Image image = new Image();
        image.setImageId(rs.getInt("image_id"));
        image.setFilname(rs.getString("filename"));
        image.setMimeType(rs.getString("mimetype"));
        image.setCode(rs.getString("code"));
        image.setCodeId(rs.getInt("code_id"));
        image.setImage(rs.getBytes("image"));
        return image;
    }
    
}
