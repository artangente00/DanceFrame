/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.competition.impl;

import com.danceframe.console.common.model.competition.DisplayDefault;
import com.danceframe.console.service.dataprovider.competition.DisplayDefaultProviderDao;
import com.danceframe.console.service.dataprovider.impl.BaseJdbcDaoImpl;
import com.danceframe.console.service.query.competition.DisplayDefaultQuery;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class DisplayDefaultProviderDaoImpl extends BaseJdbcDaoImpl implements DisplayDefaultProviderDao {

    private RowMapper<DisplayDefault> rowMapper;
    
    @Override
    public int insert(DisplayDefault disp) {
        Object[] obj = new Object[] {
             disp.getEventId(),
             disp.isEventDisplay(),
             disp.isVenueDisplay(), 
             disp.isContactDisplay(), 
             disp.isOrganizerDisplay(), 
             disp.isScheduleDisplay(), 
             disp.isHotelDisplay(), 
             disp.isSponsorDisplay(),
             disp.isInformationDisplay(),
             disp.isFinanceDisplay()
         };
         return(getJdbcTemplate().queryForObject(DisplayDefaultQuery.INSERT_DISPLAYDEFAULT_QRY, obj, Integer.class));   
    }

    @Override
    public int update(DisplayDefault disp) {
        Object[] obj = new Object[] {
             disp.getEventId(),
             disp.isEventDisplay(),
             disp.isVenueDisplay(), 
             disp.isContactDisplay(), 
             disp.isOrganizerDisplay(), 
             disp.isScheduleDisplay(), 
             disp.isHotelDisplay(), 
             disp.isSponsorDisplay(),
             disp.isInformationDisplay(),
             disp.isFinanceDisplay()
         };
         return(getJdbcTemplate().queryForObject(DisplayDefaultQuery.UPDATE_DISPLAYDEFAULT_QRY, obj, Integer.class));   
    }

    @Override
    public DisplayDefault get(int eventId) {
        Object[] obj = new Object[] { eventId };
        String sqlWhere = " WHERE event_id=?"  ;
        String finalSQL =  DisplayDefaultQuery.SELECT_DISPLAYDEFAULT_QRY + sqlWhere;
        return((DisplayDefault)getJdbcTemplate().queryForObject(finalSQL, obj, rowMapper));     
    }

    /**
     * @return the rowMapper
     */
    public RowMapper<DisplayDefault> getRowMapper() {
        return rowMapper;
    }

    /**
     * @param rowMapper the rowMapper to set
     */
    public void setRowMapper(RowMapper<DisplayDefault> rowMapper) {
        this.rowMapper = rowMapper;
    }
    
}
