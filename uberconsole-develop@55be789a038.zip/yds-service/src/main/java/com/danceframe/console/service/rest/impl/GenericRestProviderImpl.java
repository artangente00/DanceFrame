/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rest.impl;

import com.danceframe.console.service.rest.GenericRestProvider;
import java.lang.reflect.ParameterizedType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.client.RestTemplate;

/**
 *
 * @author lmorallos
 */
public abstract class GenericRestProviderImpl<T> implements GenericRestProvider<T> {

    private static final Logger logger = LogManager.getLogger(GenericRestProvider.class);
     
    private RestTemplate restTemplate;
    
    private Class<T> clazz;
    
    @Override
    public T get(String URL) {
        restTemplate = new RestTemplate();
//        clazz = (Class<T>)((ParameterizedType)getClass().getGenericSuperclass()).getActualTypeArguments()[0];
        logger.info("Connecing to:" + URL);
        T ret = (T)restTemplate.getForObject(URL, getClazz());
        return ret;
    }

    /**
     * @return the restTemplate
     */
    public RestTemplate getRestTemplate() {
        return restTemplate;
    }

    /**
     * @param restTemplate the restTemplate to set
     */
    public void setRestTemplate(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    /**
     * @return the clazz
     */
    public Class<T> getClazz() {
        Class<T> type = null;
        Class<?> iter = getClass();
        while (iter.getSuperclass() != null) {
          Class<?> next = iter.getSuperclass();
          if (next != null && next.isAssignableFrom(GenericRestProviderImpl.class)) {
            type =
                (Class<T>)
                    ((ParameterizedType) iter.getGenericSuperclass()).getActualTypeArguments()[0];
            break;
          }
          iter = next;
        }
        if (type == null) {
          throw new ClassCastException("Cannot determine type of T");
        }
        return type;
    }

    /**
     * @param clazz the clazz to set
     */
    public void setClazz(Class<T> clazz) {
        this.clazz = clazz;
    }

    
}
