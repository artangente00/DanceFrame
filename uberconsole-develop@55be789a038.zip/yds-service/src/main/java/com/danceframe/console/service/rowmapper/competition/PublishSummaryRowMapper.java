/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.competition;

import com.danceframe.console.common.model.competition.PublishSummary;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class PublishSummaryRowMapper implements RowMapper<PublishSummary>{

    @Override
    public PublishSummary mapRow(ResultSet rs, int column) throws SQLException {
        final PublishSummary publishSummary = new PublishSummary();
        publishSummary.setItems(rs.getInt("items"));
        publishSummary.setPubpending(rs.getInt("pubpending"));
        publishSummary.setPubcommit(rs.getInt("pubcommit"));
        publishSummary.setUnpubpending(rs.getInt("unpubpending"));
        publishSummary.setUnpubcommit(rs.getInt("unpubcommit"));
        publishSummary.setRepubpending(rs.getInt("repubpending"));
        publishSummary.setRepubcommit(rs.getInt("repubcommit"));
        publishSummary.setAllpending(rs.getInt("allpending"));
        publishSummary.setAllcommit(rs.getInt("allcommit"));
        return publishSummary;
    }
    
}
