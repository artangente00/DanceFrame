/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.file.critique.impl;


import com.danceframe.console.service.constant.HeatListTag;
import com.danceframe.console.common.model.critique.xml.HeatListResultPersonKey;
import com.danceframe.console.common.model.critique.xml.HeatResultCouple;
import com.danceframe.console.common.model.critique.xml.HeatResultCoupleEntry;
import com.danceframe.console.common.model.critique.xml.HeatResultHeat;
import com.danceframe.console.common.model.critique.xml.HeatResultPerson;
import com.danceframe.console.common.model.critique.xml.HeatResultProgram;
import com.danceframe.console.common.model.critique.xml.HeatResultSoloEntry;
import com.danceframe.console.common.model.critique.xml.HeatResultStudio;
import com.danceframe.console.common.model.critique.xml.HeatResultSubHeat;
import com.danceframe.console.common.comparator.critique.CoupleResultComparator;
import com.danceframe.console.common.comparator.critique.PersonResultComparator;
import com.danceframe.console.common.comparator.critique.StudioResultComparator;
import com.danceframe.console.common.util.Utility;
import com.danceframe.console.service.file.critique.HeatListReader;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.simpleframework.xml.Serializer;
import org.simpleframework.xml.core.Persister;


/**
 *
 * @author lmorallos
 */
public class HeatListTxtReaderImpl implements HeatListReader{

    private static final Logger logger = LogManager.getLogger(HeatListTxtReaderImpl.class);
    private static final String TYPE_NO = "1";
    private List<String> files;
    private HeatResultProgram program;
    private boolean quite;
    private boolean nostat;
    private boolean islog;
    private boolean iserrlog;
    private boolean isdebug;
    private String errfile;
    private String logfile;
    
     @Override
     public int fileToXML(String filename, String xmlfilename, boolean console ) throws FileNotFoundException, IOException {
        File heatfile = new File(filename);
        int errcnt = 0;
        if (heatfile.exists()) {
           errcnt =  buildDataStructure(filename,  console);
           try {
                File xmlfile = new File(xmlfilename);
                Serializer serializer = new Persister();
                serializer.write(program, xmlfile);
                if (xmlfile.exists())
                    logger.info("Generated:" + xmlfilename);
           } catch (Exception ex) {
                logger.info("ERROR:Writing xml.");
           }
        }
        return errcnt;
    }
     
    
    
    private int buildDataStructure(String filename, boolean console) throws IOException {
        int errcnt = 0;
        program = new HeatResultProgram();
        File heatfile = new File(filename);

        FileReader heatfr = new FileReader(heatfile);
        BufferedReader heatbr = new BufferedReader(heatfr);
        String strline = new String();
        String compid = new String();
        String strTag = new String();
        int heatinfoId = 0;
        boolean istudio = false;
        boolean iperson = false;
        boolean iprogram = false;
        boolean icomp = false;
        boolean iheat = false;
        boolean skip = false;
        long studiocnt = 0;
        long personcnt = 0;
        long infocnt = 0;
        long compcnt = 0;
        long entcnt = 0;

        List<HeatResultStudio> studios = null;
        List<HeatResultPerson> persons = null;
        List<HeatResultHeat> heats = null;
        List<HeatResultSubHeat> subheats = null;
        List<HeatResultSoloEntry> solos = null;
        List<HeatResultCouple> couples = null;
        List<HeatResultCouple> ocouples = null;
        
        HeatResultHeat heat = new HeatResultHeat(); 
        HeatResultSubHeat subheat = new HeatResultSubHeat();
        int compNumber = 1;
        while ((strline = heatbr.readLine()) != null) {
            if (strline.equals(HeatListTag.STUDIO_START_TAG)) {
                studios = new ArrayList<HeatResultStudio>();
                strTag = strline;
                istudio = true;
                skip = true;
            }
            if (strline.equals(HeatListTag.STUDIO_END_TAG)) {
                studios = reconstructStudios(studios);
                Collections.sort(studios, new StudioResultComparator());
                if (!nostat)
                    logger.info("HEATLIST - No of studio(s):" + studiocnt);
                istudio = false;
            }
            if (strline.equals(HeatListTag.PERSON_START_TAG)) {
                persons = new ArrayList<HeatResultPerson>();
                strTag = strline;
                iperson = true;
                skip = true;
            }
            if (strline.equals(HeatListTag.PERSON_END_TAG)) {
                Collections.sort(persons, new PersonResultComparator());
                // formulate couplekey
                for (HeatResultPerson person:persons) {
                    if ( person.getGender().equalsIgnoreCase("M")) {
                        person.setCompetitorNumber(Integer.toString(compNumber));
                        compNumber++;
                    }
                }
                if (!nostat)
                   logger.info("HEATLIST - No of person(s):" + personcnt);
                iperson = false;
            }
            if (strline.equals(HeatListTag.PROGRAM_START_TAG)) {
                heats = new ArrayList<HeatResultHeat>();          
                couples = new ArrayList<HeatResultCouple>();
                
                iprogram = true;
                skip = true;
            }
            if (strline.equals(HeatListTag.PROGRAM_END_TAG)) {
                // sort and organize couple keys
                Collections.sort(couples, new CoupleResultComparator());
                String coupleKey = new String();
                String coupleKeyFinal = new String();
                int ictr = 1;
                for (int i=0;i < couples.size(); i++) {
                    HeatResultCouple couple = couples.get(i);
                    if (!coupleKey.equalsIgnoreCase(couple.getCoupleKey())) {
                       if (i > 0) ictr = 1;
                    } else {
                        ictr++;
                    }
                    coupleKey = couple.getCoupleKey();
                    coupleKeyFinal = coupleKey +  "-" + Utility.padLeft(Integer.toString(ictr),2);
                    couples.get(i).setCoupleKey(coupleKeyFinal);
                }
                int j = 0;
                // edit entries base from couple List
                for (HeatResultHeat mheat:heats) {
                    int sx = 0;
                    for (HeatResultSubHeat sheat:mheat.getSubHeats()) {
                        if (sheat.getCoupleList() != null) {
                            if (sheat.getCoupleList().size() > 0) {
                                List<HeatResultCoupleEntry> entries = new ArrayList<HeatResultCoupleEntry>();  
                                for (HeatResultCouple icouple:sheat.getCoupleList()) {
                                    String cpkey = getCoupleKey(couples,  icouple);
                                    entries.add(new HeatResultCoupleEntry(cpkey));
                                }
                                if (entries.size() > 0) 
                                    heats.get(j).getSubHeats().get(sx).setCoupleEntries((ArrayList)entries);
                            }
                        }
                        sx++;
                    } 
                    j++;
                }              
//                for (HeatResultHeat mheat:heats) {
//                    for (HeatResultSubHeat sheat:mheat.getSubHeats()) {
//                        System.out.println(sheat);
//                    }
//                }
                program = new HeatResultProgram();
                program.setStudios((ArrayList)studios);
                program.setPersons((ArrayList)persons);
                program.setCouples((ArrayList)couples);
                program.setHeats((ArrayList)heats);
                if (!nostat) {
                    logger.info("HEATLIST - No of  heat:" + infocnt);
                    logger.info("HEATLIST - No of compeition:" + compcnt);
                    logger.info("HEATLIST - No of entry:" + entcnt);
                }                 
                iprogram = false;
            }
            if (istudio) {
                if (skip) {
                    skip = false;
                } else {
                    try {
                        List<String> strList = Utility.str2List(strline,'|');
                        HeatResultStudio studio = new HeatResultStudio(strList.get(0), strList.get(1), "");
                        studios.add(studio);
                        studiocnt++;
                    } catch (Exception ex) {
                        String errString = ex.getMessage() + " tag:"+ strTag + " data:" + strline;
                        logger.info(errString);
                        errcnt++;
                    }
                }
            }
            if (iperson) {
                if (skip) {
                    skip = false;
                } else {
                    try {
                        List<String> strList = Utility.str2List(strline,'|');
                        HeatResultPerson person = 
                            new HeatResultPerson(strList.get(0),strList.get(2), strList.get(1), 
                                 strList.get(3) , strList.get(4), strList.get(5), "", "", "");
                        persons.add(person);
                        personcnt++;
                    } catch (Exception ex) {
                        String errString = ex.getMessage() + " data:" + strline;
                        logger.info(errString);
                        errcnt++;
                    }
                }
            }
           
            if (iprogram) {
                if (skip) {
                    skip = false;
                } else {                        
                    List<String> strList = Utility.str2List(strline,'|');
                    String tmptag = strList.get(0);
                    if (tmptag.equals(HeatListTag.HEAT_START_TAG)) {
                        subheats = new ArrayList<>();
                        iheat = true;
                    }
                    if (tmptag.equals(HeatListTag.HEAT_END_TAG)) {                 
                        int i = heats.size() - 1;
                        heats.get(i).setSubHeats((ArrayList)subheats);
                        iheat = false;
                    }
                    if (tmptag.equals(HeatListTag.COMP_START_TAG)) {
                        solos = new ArrayList<HeatResultSoloEntry>();
                        ocouples = new ArrayList<HeatResultCouple>();
                        icomp = true;
                    }
                    if (tmptag.equals(HeatListTag.COMP_END_TAG)) {
                        if (solos.size() > 0) {
                            subheat.setSoloEntries((ArrayList)solos);
                        } else {
                            subheat.setSoloEntries(null);
                        }
                       subheat.setCoupleList(ocouples);
                       subheats.add(subheat);
                       icomp = false;
                    }
                    if (iheat && !icomp) {
                        if (!tmptag.equals(HeatListTag.COMP_END_TAG)) {
                            try {
                                String tmpdata = strList.get(1);
                                int smarker = tmpdata.indexOf("[");
                                if (smarker > -1) {
                                    String heatval = tmpdata.substring(0, smarker).trim();
                                    int slen =  tmpdata.length();
                                    int hmarker = tmpdata.indexOf("]");
                                    String sched = tmpdata.substring(smarker+1, hmarker).trim();
                                    String desc = tmpdata.substring(hmarker+1, slen).trim();

                                    String[] schedvar = sched.split("@");
                                    heat = new 
                                            HeatResultHeat(heatval, schedvar[0], schedvar[1] , "", desc);
                                    
                                    String type = Utility.getHeatType(desc);
                                    heat.setType(type);
                                    heats.add(heat);
                                    infocnt++;
                                }
                            } catch (Exception ex) {
                                String errString = ex.getMessage() + " tag:" + tmptag + "  data:" + strline;
                                logger.info(errString);
                                errcnt++;
                                }
                            }
                        }
                        if (iheat && icomp)  {
                            if (tmptag.equals(HeatListTag.COMP_START_TAG)) { 
                                try {                                 
                                    subheat = 
                                            new HeatResultSubHeat(strList.get(1), strList.get(2), strList.get(3),
                                            strList.get(4), strList.get(5));
                                    compid = strList.get(1);
                                    compcnt++;
                                } catch (Exception ex) {
                                    String errString = ex.getMessage() + " tag:" + tmptag + "  data:" + strline;
                                    logger.info(errString);
                                    errcnt++;
                                }
                            } else {
                                try {
                                    // populate entries ... check if its solo (NO_FEMALE) 
                                    String personId = strList.get(2);
                                    String partnerId = strList.get(3);
                                    if (partnerId.equalsIgnoreCase("NO_FEMALE")) {
                                       if (hasPersonKey(persons,personId)) {
                                           HeatResultSoloEntry solo = new HeatResultSoloEntry();
                                           solo.setPersonKey(personId);
                                           solos.add(solo);
                                       }
                                    } else {
                                        if ((hasPersonKey(persons,personId))
                                                && (hasPersonKey(persons,partnerId))) {
                                            // add to couple
                                            HeatResultPerson person = getPerson(persons,personId);
                                            String competiorNum = person.getCompetitorNumber();
                                            HeatResultCouple couple = new HeatResultCouple();
                                            List<HeatListResultPersonKey> personKeys  = new ArrayList<HeatListResultPersonKey>();

                                            personKeys.add( new HeatListResultPersonKey(personId));
                                            personKeys.add( new HeatListResultPersonKey(partnerId));
                                            couple.setCoupleKey(competiorNum);
                                            couple.setPersonKeys((ArrayList)personKeys);
                                            couples = insertCouple(couples,  couple);
                                            ocouples.add(couple);
                                        }
                                    }
                                    entcnt++;
                                } catch (Exception ex) {
                                    String errString = ex.getMessage() + " tag:" + tmptag + "  data:" + strline;
                                    logger.info(errString);
                                    errcnt++;
                                }
                            }
                        }
                    }
            }
        }
        heatbr.close();
        if (errcnt > 0) {               
            logger.info("HEATLIST - error found:" + errcnt + " check error file:");
        }
        return errcnt;
    }
    
    private String getCoupleKey(List<HeatResultCouple> couples, HeatResultCouple icouple) {
       String retstr = null;
       if (couples.size() > 0) {
            String iperson = icouple.getPersonKeys().get(0).getPersonKey();
            String ipartner = icouple.getPersonKeys().get(1).getPersonKey();
            for (HeatResultCouple couple:couples) {
                String person = couple.getPersonKeys().get(0).getPersonKey();
                String partner = couple.getPersonKeys().get(1).getPersonKey();
                if ((person.equalsIgnoreCase(iperson)) && 
                        (partner.equalsIgnoreCase(ipartner))) {
                    retstr = couple.getCoupleKey();
                    break;
                }  
            }
        }
        return retstr;
    }
    
    private boolean hasPersonKey(List<HeatResultPerson> persons, String pk) {
        boolean retbool = false;
        if (persons != null) {
            for (HeatResultPerson person:persons) { 
                if (person.getPersonKey().equalsIgnoreCase(pk)) {
                    retbool = true;
                    break;
                }
            }
        }
        return retbool;
    }
    
    private HeatResultPerson getPerson(List<HeatResultPerson> persons, String pk) {
        HeatResultPerson retperson = null;
        if (persons != null) {
            for (HeatResultPerson person:persons) { 
                if (person.getPersonKey().equalsIgnoreCase(pk)) {
                    retperson = person;
                    break;
                }
            }
        }
        return retperson;
    }

    private List<HeatResultCouple> insertCouple(List<HeatResultCouple> couples, HeatResultCouple icouple) {
        boolean coupleadd = true;
        if (couples.size() > 0) {
            String iperson = icouple.getPersonKeys().get(0).getPersonKey();
            String ipartner = icouple.getPersonKeys().get(1).getPersonKey();
            for (HeatResultCouple couple:couples) {
                String person = couple.getPersonKeys().get(0).getPersonKey();
                String partner = couple.getPersonKeys().get(1).getPersonKey();
                if ((person.equalsIgnoreCase(iperson)) && 
                        (partner.equalsIgnoreCase(ipartner))) {
                    coupleadd = false;
                    break;
                }  
            }
        }
        if (coupleadd) couples.add(icouple);
        return couples;
    }
    
    private List<HeatResultStudio> reconstructStudios(List<HeatResultStudio> studioList) {
        List<HeatResultStudio> retstudios = new ArrayList<>();
        int i = 0;
        for (i=0; i < studioList.size(); i++ ) {
            HeatResultStudio ostudio = studioList.get(i);// indexof
            String sname = ostudio.getName();
            int idx = sname.indexOf("<");
            if (idx > -1) {
                String[] strdata = sname.split("<");
                String dispname = strdata[0].trim();
                String invname =  strdata[1].replace(">", "").trim();
                ostudio.setName(dispname);
                ostudio.setIndependentInvoice(invname);
            } 
            retstudios.add(ostudio); 
        }
        return retstudios;
    }
    
    @Override
    public void setConfigFile(String configFile) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * @return the program
     */
    public HeatResultProgram getProgram() {
        return program;
    }

    /**
     * @param program the program to set
     */
    public void setProgram(HeatResultProgram program) {
        this.program = program;
    }

    @Override
    public void setFileList(List<String> filelist) {
        files = filelist;
        if (!files.get(1).isEmpty()) {
            islog = true;
            logfile = files.get(1);
        }
        if (!files.get(2).isEmpty()) {
            iserrlog = true;
            errfile = files.get(2);
        }
    }

    @Override
    public void setQuite(boolean quite) {
        this.quite = quite;
    }

    @Override
    public void setNoStatistics(boolean nostat) {
        this.nostat = nostat;
    }

    @Override
    public void setDebug(boolean debug) {
        this.isdebug = debug;
    }

   
}
