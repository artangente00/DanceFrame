/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.heatlist;

import com.danceframe.console.common.model.heatlist.result.HeatListResultPersonKey;
import com.danceframe.console.common.model.heatlist.result.HeatResultCompetitor;
import com.danceframe.console.common.model.heatlist.result.HeatResultHeat;
import com.danceframe.console.common.model.heatlist.result.HeatResultJudge;
import com.danceframe.console.common.model.heatlist.result.HeatResultMark;
import com.danceframe.console.common.model.heatlist.result.HeatResultPerson;
import com.danceframe.console.common.model.heatlist.result.HeatResultProgram;
import com.danceframe.console.common.model.heatlist.result.HeatResultResult;
import com.danceframe.console.common.model.heatlist.result.HeatResultStudio;
import com.danceframe.console.common.model.heatlist.result.HeatResultSubHeat;
import com.danceframe.console.common.model.heatlist.result.HeatResultSubHeats;
import com.danceframe.console.common.model.heatlist.result.HeatlistResultXML;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public interface HeatListResultProviderDao {
    
    int clearByEventId(int eventId);
    
    int insertProgram(HeatResultProgram program);
    
    int insertStudio(HeatResultStudio studio);
    
    int insertPerson(HeatResultPerson person);
    
    int insertJudge(HeatResultJudge judge);
    
    int insertCompetitor(HeatResultCompetitor competitor);
    
    int insertPersonKey(HeatListResultPersonKey personkey);
    
    int insertHeat(HeatResultHeat heat);
    
    int insertSubHeats(HeatResultSubHeats subheats);
    
    int insertSubHeat(HeatResultSubHeat subheat);
    
    int insertResult(HeatResultResult result);
    
    int insertMark(HeatResultMark mark);
    
    List<HeatResultStudio> getStudios(int eventId);
    
    List<HeatResultJudge> getJudges(int eventId);
     
    List<HeatResultPerson> getPersons(int eventId);
      
    List<HeatResultCompetitor> getCompetitor(int eventId);
    
    List<HeatListResultPersonKey> getPersonKeys(int eventId, int competitorId);
            
    List<HeatResultHeat> getHeats(int eventId);
    
    List<HeatResultSubHeats> getSubHeats(int eventId, int heatId);
    
    List<HeatResultSubHeat> getSubHeat(int eventId, int subheatsId);
    
    List<HeatResultResult> getResult(int eventId, int subHeatId);
    
    List<HeatResultMark> getMarks(int eventId, int subHeatId, int resultId);
    
    HeatlistResultXML getHeatResultXML(int eventid);
    
    List<Integer> getEventIds(int masterpersonId);
            
    List<HeatResultJudge> getJudgesUnfied(int eventId);
     
    List<HeatResultPerson> getPersons(int eventId, int masterpersonId);
      
    List<HeatResultCompetitor> getCompetitor(int eventId, int masterpersonId);
            
    List<HeatResultHeat> getHeat(int eventId,int masterpersonId);
    
    List<HeatResultSubHeats> getSubHeats(int eventId, int heatId, int masterpersonId);
    
    List<HeatResultSubHeat> getSubHeat(int eventId, int subheatsId, int masterpersonId);
    
    HeatResultResult getResult(int eventId, int subHeatId, int masterpersonId);
    
    List<HeatResultMark> getMarks(int eventId, int subHeatId, int resultId, int masterpersonId);

    List<HeatResultSubHeats> getSubHeatsNoMP(int eventId, int heatId);
    
    List<HeatResultSubHeat> getSubHeatNoMP(int eventId, int subheatsId);
    
    HeatResultResult getResultNoMP(int eventId, int subHeatId);
    
    List<HeatResultMark> getMarksNoMP(int eventId, int subHeatId, int resultId);
    
    List<HeatResultJudge> getJudgesUnfied(int eventId, List<String> judgeKeys);
    
    List<HeatResultPerson> getPersons(int eventId, List<String> competitorKeys); 
   
    List<HeatResultCompetitor> getCompetitor(int eventId, List<String> competitorKeys);
    
    String getPerson(int eventId,int masterpersonId);
    
}
