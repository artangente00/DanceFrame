/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.firebase.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.danceframe.console.common.model.competition.Contact;
import com.danceframe.console.common.model.competition.DisplayDefault;
import com.danceframe.console.common.model.competition.Enablement;
import com.danceframe.console.common.model.competition.Event;
import com.danceframe.console.common.model.competition.Finance;
import com.danceframe.console.common.model.competition.Organizer;
import com.danceframe.console.common.model.competition.Schedule;
import com.danceframe.console.common.model.competition.ScheduleData;
import com.danceframe.console.common.model.competition.Venue;
import com.danceframe.console.common.model.firebase.competition.EventInfo;
import com.danceframe.console.common.model.firebase.competition.GenericFormData;
import com.danceframe.console.common.model.firebase.competition.SchedData;
import com.danceframe.console.common.model.firebase.competition.ScheduleInfo;
import com.danceframe.console.common.model.firebase.competition.TimeData;
import com.danceframe.console.common.util.Utility;
import com.danceframe.console.service.constant.GenericFormType;
import com.danceframe.console.service.constant.PublishStatus;
import com.danceframe.console.service.dataprovider.competition.ContactProviderDao;
import com.danceframe.console.service.dataprovider.competition.DisplayDefaultProviderDao;
import com.danceframe.console.service.dataprovider.competition.EnablementProviderDao;
import com.danceframe.console.service.dataprovider.competition.EventProviderDao;
import com.danceframe.console.service.dataprovider.competition.FinanceProviderDao;
import com.danceframe.console.service.dataprovider.competition.GenericFormProviderDao;
import com.danceframe.console.service.dataprovider.competition.OrganizerProviderDao;
import com.danceframe.console.service.dataprovider.competition.ScheduleDataProviderDao;
import com.danceframe.console.service.dataprovider.competition.ScheduleProviderDao;
import com.danceframe.console.service.dataprovider.competition.VenueProviderDao;
import com.danceframe.console.service.dataprovider.competition.config.EventFormXMLProviderDao;
import java.util.Map;
import com.danceframe.console.service.firebase.EventFirebaseService;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.springframework.dao.EmptyResultDataAccessException;

/**
 *
 * @author lmorallos
 */
public class EventFirebaseServiceImpl implements EventFirebaseService {

    private EventProviderDao        eventProviderDao;
    private VenueProviderDao        venueProviderDao;
    private ContactProviderDao      contactProviderDao;
    private OrganizerProviderDao    organizerProviderDao;
    private EventFormXMLProviderDao eventFormXMLProviderDao;
    private ScheduleProviderDao     scheduleProviderDao;
    private ScheduleDataProviderDao scheduleDataProviderDao;
    private EnablementProviderDao   enablementProviderDao;
    private GenericFormProviderDao  genericFormProviderDao;
    private FinanceProviderDao      financeProviderDao;
    private DisplayDefaultProviderDao displayDefaultProviderDao;
    
    @Override
    public List<Map<String, Object>> getAllEventPublishInProgress() {
        return getAllEvents(PublishStatus.PUBLISH_IN_PROGRESS);
    }
    
    @Override
    public List<Map<String, Object>> getAllEventUnPublishInProgress() {
       return getAllEvents(PublishStatus.UNPUBLISH_IN_PROGRESS);
    }
    
    @Override
    public List<Map<String, Object>> getAllEventRePublishInProgress() {
       return getAllEvents(PublishStatus.REPUBLISH_IN_PROGRESS);
    }

    @Override
    public List<Map<String, Object>> getAllEventCommitInProgress() {
         return getAllEvents(PublishStatus.ALL_COMMITED);
    }
    

    @Override
    public List<Event> getAllEventPublished() {
        return getAllEventsAll(PublishStatus.PUBLISHED);
    }

    
    private  List<Map<String, Object>> getAllEvents(int pubstatus) {
        List<Map<String, Object>> listmap = new ArrayList<Map<String, Object>>();
        String condition = new String();
        if (pubstatus == PublishStatus.PUBLISH_IN_PROGRESS) 
            condition = "WHERE pubstatus=" + PublishStatus.PUBLISH_IN_PROGRESS;
        if (pubstatus == PublishStatus.UNPUBLISH_IN_PROGRESS) 
            condition = "WHERE pubstatus=" + PublishStatus.UNPUBLISH_IN_PROGRESS;
        if (pubstatus == PublishStatus.REPUBLISH_IN_PROGRESS) 
            condition = "WHERE pubstatus=" + PublishStatus.REPUBLISH_IN_PROGRESS;        
        if (pubstatus == PublishStatus.ALL_COMMITED) 
            condition = "WHERE pubstatus IN (" + PublishStatus.PUBLISH_IN_PROGRESS +
                    "," + PublishStatus.UNPUBLISH_IN_PROGRESS + 
                    "," + PublishStatus.REPUBLISH_IN_PROGRESS + 
                    ") ORDER BY pubstatus, event_id ";
        // System.out.println(condition);
        List<Event> events = eventProviderDao.getAll(condition);
        if (events.size() > 0) {
            for (Event event:events) {
                Map<String,Object> inputmap = new HashMap<String,Object>();
                if ((event.getPubstatus() == PublishStatus.PUBLISH_IN_PROGRESS ) ||
                    (event.getPubstatus() == PublishStatus.REPUBLISH_IN_PROGRESS )){
                    EventInfo evinfo = new EventInfo();
                    
                    String dispVar = new String();
                    try {
                        DisplayDefault displayDef = displayDefaultProviderDao.get(event.getId());
                        if (displayDef.isEventDisplay()) {
                            dispVar = "EVENT";
                        } else if (displayDef.isContactDisplay()) {
                            dispVar = "CONTACT";
                        } else if (displayDef.isFinanceDisplay()) {
                            dispVar = "FINANCE";
                        } else if (displayDef.isHotelDisplay()) {
                            dispVar = "HOTEL";
                        } else if (displayDef.isInformationDisplay()) {
                            dispVar = "INFORMATION";
                        } else if (displayDef.isOrganizerDisplay()) {
                            dispVar = "ORGANIZER";
                        } else if (displayDef.isScheduleDisplay()) {
                            dispVar = "SCHEDULE";
                        } else if (displayDef.isSponsorDisplay()) {
                            dispVar = "SPONSOR";
                        }else if (displayDef.isVenueDisplay()) {
                            dispVar = "VENUE";
                        } else {
                            dispVar = "NONE";
                        } 
                    } catch (EmptyResultDataAccessException ex) {
                        dispVar = "NONE";
                    }
                    event.setDefaultDisplay(dispVar);
                    evinfo.setInfo(event);
                    
                    //BeanUtils.copyProperties(event, evinfo);
                    Enablement enable = new Enablement();
                    try {
                        enable = enablementProviderDao.get(event.getId());
                    } catch (EmptyResultDataAccessException ex) {}
                    
                    if (enable.isVenueEnable()) {
                        boolean empty = false;
                        Venue venue = new Venue();
                        try {
                            venue = venueProviderDao.getByEventId(event.getId());
                        } catch (EmptyResultDataAccessException ex) { 
                            empty = true;
                        }
                        if (empty) {
                            venue.setId(0);venue.setEventid(event.getId());
                        }
                        evinfo.setVenue(venue);
                    }
                    
                    if (enable.isContactEnable()) {
                        boolean empty = false;
                        Contact contact = new Contact();
                        try {
                           contact = contactProviderDao.getByEventId(event.getId());
                        } catch (EmptyResultDataAccessException ex) {
                            empty = true;
                        }
                        if (empty) {
                            contact.setId(0);contact.setEventid(event.getId());
                        }
                        evinfo.setContact(contact);
                    }
                    
                    if (enable.isOrganizerEnable()) {
                        List<Organizer> orgList = new ArrayList<>();
                        try {
                            orgList = organizerProviderDao.getAllByEventId(event.getId());
                        } catch (EmptyResultDataAccessException ex) {  }
                        if (orgList.isEmpty()) {
                            Organizer organizer = new Organizer();
                            organizer.setEventid(event.getId());
                            organizer.setId(0);organizer.setName("");
                            orgList.add(organizer);
                        }
                        evinfo.setOrganizers(orgList);
                    } 
                    
                    if (enable.isFinanceEnable()) {
                        boolean empty = false;
                        Finance finance = new Finance();
                        try {
                            finance = financeProviderDao.getByEventId(event.getId());
                        } catch (EmptyResultDataAccessException ex) {
                           empty = false;
                        }
                        if (empty) {
                            finance.setId(0);finance.setEventId(event.getId());
                        }
                        evinfo.setFinance(finance);
                    }
                    
                    if (enable.isScheduleEnable()) {
                        boolean empty = false;
                        ScheduleInfo schedinfo = new ScheduleInfo();
                        try {
                            Schedule tmpsched = scheduleProviderDao.get(event.getId());
                            schedinfo.setId(tmpsched.getId());
                            schedinfo.setEventId(tmpsched.getEventId());
                            schedinfo.setTitle(tmpsched.getSchedName());
                            List<ScheduleData> tmplist = new ArrayList<ScheduleData>();
                            try {
                               String wherestr = " WHERE event_id=" + event.getId(); 
                               String sortSql = " ORDER BY hdrorder ASC, header_name ASC, tvalorder ASC";
                               wherestr += sortSql; 
                               tmplist = scheduleDataProviderDao.getAllData(wherestr);
                            } catch (EmptyResultDataAccessException ex) {
                            }              
                            List<SchedData> schedlist = new ArrayList<SchedData>();
                            String tmpstr = new String();
                            SchedData schedtmp = null;
                            int sctr = -1;
                            for (ScheduleData sd:tmplist) {
                                if (!tmpstr.equalsIgnoreCase(sd.getHeaderName())) {
                                    schedtmp = new SchedData();
                                    schedtmp.setHeaderName(sd.getHeaderName());
                                    schedtmp.setHdrOrder(sd.getHdrOrder());
                                    TimeData td = new TimeData();
                                    td.setTimeValue(sd.getTimeValue());
                                    td.setDescription(sd.getDescription());
                                    td.setTvalOrder(sd.getTvalOrder());
                                    schedtmp.setTimedata(new ArrayList<TimeData>());
                                    schedtmp.getTimedata().add(td);
                                    schedlist.add(schedtmp);
                                    sctr++;
                                } else {
                                    TimeData td = new TimeData();
                                    td.setTimeValue(sd.getTimeValue());
                                    td.setDescription(sd.getDescription());
                                    td.setTvalOrder(sd.getTvalOrder());
                                    schedlist.get(sctr).getTimedata().add(td);
                                }
                                tmpstr = sd.getHeaderName();
                            }
                            schedinfo.setSchedules(schedlist);                       
                        } catch (EmptyResultDataAccessException ex) { 
                            empty = true;
                        }
                        if (empty) {
                            schedinfo.setId(0);schedinfo.setEventId(event.getId());
                        }
                        evinfo.setSchedule(schedinfo); 
                    }
                    if (enable.isHotelEnable()) {
                        List<GenericFormData> genformList = new ArrayList<>();
                        try {
                            genformList = genericFormProviderDao.
                                getFormData(event.getId(), GenericFormType.HOTEL_CODE);
                        } catch (EmptyResultDataAccessException ex) { }
                        if (genformList.isEmpty()) {
                            GenericFormData gen = new GenericFormData();
                            gen.setId(0);
                            gen.setEventId(event.getId());
                            genformList.add(gen);
                        }
                        evinfo.setHotels(genformList);
                    }
                    if (enable.isSponsorEnable()) {
                        List<GenericFormData> genformList = new ArrayList<>();
                        try {
                            genformList = genericFormProviderDao.
                                getFormData(event.getId(), GenericFormType.SPONSOR_CODE);
                        } catch (EmptyResultDataAccessException ex) { }
                         if (genformList.isEmpty()) {
                            GenericFormData gen = new GenericFormData();
                            gen.setId(0);
                            gen.setEventId(event.getId());
                            genformList.add(gen);
                        }
                        evinfo.setSponsors(genformList);
                    }
                    if (enable.isInformationEnable()) {
                        List<GenericFormData> genformList = new ArrayList<>();
                        try {
                            genformList = genericFormProviderDao.
                                getFormData(event.getId(), GenericFormType.INFO_CODE);
                        } catch (EmptyResultDataAccessException ex) { }
                         if (genformList.isEmpty()) {
                            GenericFormData gen = new GenericFormData();
                            gen.setId(0);
                            gen.setEventId(event.getId());
                            genformList.add(gen);
                        }
                        evinfo.setInformations(genformList);
                    }
                    String json = Utility.object2Json(evinfo);
                    ObjectMapper mapper = new ObjectMapper();
                    try {
                        Map<String,Object> map = mapper.readValue(json, Map.class);
                        inputmap.put(event.getId() + "", map);
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                } else {
                    inputmap.put(event.getId() + "", null); 
                }               
                listmap.add(inputmap);
            }
        }
        return listmap;
    }
    
    
    private  List<Event> getAllEventsAll(int pubstatus) {
        String condition = new String();
        if (pubstatus == PublishStatus.PUBLISH_IN_PROGRESS) 
            condition = "WHERE pubstatus=" + PublishStatus.PUBLISH_IN_PROGRESS;
        if (pubstatus == PublishStatus.UNPUBLISH_IN_PROGRESS) 
            condition = "WHERE pubstatus=" + PublishStatus.UNPUBLISH_IN_PROGRESS;
        if (pubstatus == PublishStatus.REPUBLISH_IN_PROGRESS) 
            condition = "WHERE pubstatus=" + PublishStatus.REPUBLISH_IN_PROGRESS;
        
        if (pubstatus == PublishStatus.PUBLISH_PENDING) 
            condition = "WHERE pubstatus=" + PublishStatus.PUBLISH_PENDING;
        if (pubstatus == PublishStatus.UNPUBLISH_PENDING) 
            condition = "WHERE pubstatus=" + PublishStatus.UNPUBLISH_PENDING;
        if (pubstatus == PublishStatus.REPUBLISH_PENDING) 
            condition = "WHERE pubstatus=" + PublishStatus.REPUBLISH_PENDING;
        if (pubstatus == PublishStatus.PUBLISHED) 
            condition = "WHERE pubstatus=" + PublishStatus.PUBLISHED;
        if (pubstatus == PublishStatus.NOT_PUBLISHED) 
            condition = "WHERE pubstatus=" + PublishStatus.NOT_PUBLISHED;    
        
        if (pubstatus == PublishStatus.ALL_COMMITED) 
            condition = "WHERE pubstatus IN (" + PublishStatus.PUBLISH_IN_PROGRESS +
                    "," + PublishStatus.UNPUBLISH_IN_PROGRESS + 
                    "," + PublishStatus.REPUBLISH_IN_PROGRESS + 
                    ") ORDER BY pubstatus, event_id ";
        
        // System.out.println(condition);
        List<Event> events = eventProviderDao.getAll(condition);
        
        return events;
    }
    
    /**
     * @return the eventProviderDao
     */
    public EventProviderDao getEventProviderDao() {
        return eventProviderDao;
    }

    /**
     * @param eventProviderDao the eventProviderDao to set
     */
    public void setEventProviderDao(EventProviderDao eventProviderDao) {
        this.eventProviderDao = eventProviderDao;
    }

    /**
     * @return the venueProviderDao
     */
    public VenueProviderDao getVenueProviderDao() {
        return venueProviderDao;
    }

    /**
     * @param venueProviderDao the venueProviderDao to set
     */
    public void setVenueProviderDao(VenueProviderDao venueProviderDao) {
        this.venueProviderDao = venueProviderDao;
    }

    /**
     * @return the contactProviderDao
     */
    public ContactProviderDao getContactProviderDao() {
        return contactProviderDao;
    }

    /**
     * @param contactProviderDao the contactProviderDao to set
     */
    public void setContactProviderDao(ContactProviderDao contactProviderDao) {
        this.contactProviderDao = contactProviderDao;
    }

    /**
     * @return the organizerProviderDao
     */
    public OrganizerProviderDao getOrganizerProviderDao() {
        return organizerProviderDao;
    }

    /**
     * @param organizerProviderDao the organizerProviderDao to set
     */
    public void setOrganizerProviderDao(OrganizerProviderDao organizerProviderDao) {
        this.organizerProviderDao = organizerProviderDao;
    }

    /**
     * @return the eventFormXMLProviderDao
     */
    public EventFormXMLProviderDao getEventFormXMLProviderDao() {
        return eventFormXMLProviderDao;
    }

    /**
     * @param eventFormXMLProviderDao the eventFormXMLProviderDao to set
     */
    public void setEventFormXMLProviderDao(EventFormXMLProviderDao eventFormXMLProviderDao) {
        this.eventFormXMLProviderDao = eventFormXMLProviderDao;
    }

    /**
     * @return the enablementProviderDao
     */
    public EnablementProviderDao getEnablementProviderDao() {
        return enablementProviderDao;
    }

    /**
     * @param enablementProviderDao the enablementProviderDao to set
     */
    public void setEnablementProviderDao(EnablementProviderDao enablementProviderDao) {
        this.enablementProviderDao = enablementProviderDao;
    }

    /**
     * @return the scheduleProviderDao
     */
    public ScheduleProviderDao getScheduleProviderDao() {
        return scheduleProviderDao;
    }

    /**
     * @param scheduleProviderDao the scheduleProviderDao to set
     */
    public void setScheduleProviderDao(ScheduleProviderDao scheduleProviderDao) {
        this.scheduleProviderDao = scheduleProviderDao;
    }

    /**
     * @return the scheduleDataProviderDao
     */
    public ScheduleDataProviderDao getScheduleDataProviderDao() {
        return scheduleDataProviderDao;
    }

    /**
     * @param scheduleDataProviderDao the scheduleDataProviderDao to set
     */
    public void setScheduleDataProviderDao(ScheduleDataProviderDao scheduleDataProviderDao) {
        this.scheduleDataProviderDao = scheduleDataProviderDao;
    }

    /**
     * @return the genericFormProviderDao
     */
    public GenericFormProviderDao getGenericFormProviderDao() {
        return genericFormProviderDao;
    }

    /**
     * @param genericFormProviderDao the genericFormProviderDao to set
     */
    public void setGenericFormProviderDao(GenericFormProviderDao genericFormProviderDao) {
        this.genericFormProviderDao = genericFormProviderDao;
    }

    /**
     * @return the financeProviderDao
     */
    public FinanceProviderDao getFinanceProviderDao() {
        return financeProviderDao;
    }

    /**
     * @param financeProviderDao the financeProviderDao to set
     */
    public void setFinanceProviderDao(FinanceProviderDao financeProviderDao) {
        this.financeProviderDao = financeProviderDao;
    }

    /**
     * @return the displayDefaultProviderDao
     */
    public DisplayDefaultProviderDao getDisplayDefaultProviderDao() {
        return displayDefaultProviderDao;
    }

    /**
     * @param displayDefaultProviderDao the displayDefaultProviderDao to set
     */
    public void setDisplayDefaultProviderDao(DisplayDefaultProviderDao displayDefaultProviderDao) {
        this.displayDefaultProviderDao = displayDefaultProviderDao;
    }

   

}
