/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.critique;

import com.danceframe.console.common.model.critique.xml.HeatResultCouple;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class CritiqueCoupleRowMapper implements RowMapper<HeatResultCouple>{

    @Override
    public HeatResultCouple mapRow(ResultSet rs, int i) throws SQLException {
        final HeatResultCouple couple = new HeatResultCouple();
        couple.setId(rs.getInt("couple_id"));
        couple.setCoupleKey(rs.getString("couple_key"));
//        couple.setPersonKey(new ArrayList<String>());
//        couple.getPersonKey().add(rs.getString("person1_key"));
//        couple.getPersonKey().add(rs.getString("person2_key"));
        couple.setEventId(rs.getInt("event_id"));
        couple.setXmlId(rs.getInt("xml_id"));
        return couple;
    }
}
