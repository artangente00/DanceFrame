/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.heatlist.result;

import com.danceframe.console.common.model.heatlist.result.HeatListResultPersonKey;
import com.danceframe.console.common.model.heatlist.result.HeatResultCompetitor;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class HeatResultCompetitorRowMapper implements RowMapper<HeatResultCompetitor> {

    @Override
    public HeatResultCompetitor mapRow(ResultSet rs, int i) throws SQLException {
        final HeatResultCompetitor competitor = new HeatResultCompetitor();
        competitor.setId(rs.getInt("competitor_id"));
        competitor.setCompetitorKey(rs.getString("competitor_key"));
        competitor.setCompetitorType(rs.getString("competitor_type"));
        competitor.setNameOverride(rs.getString("name_override"));
        
        List<HeatListResultPersonKey> pkList = new ArrayList<>();
        String tmpstr = rs.getString("person1_key");
        if (tmpstr != null) {
            if (tmpstr.length() > 0) {
                HeatListResultPersonKey pktmp = new HeatListResultPersonKey();
                pktmp.setPersonKey(tmpstr);
                pkList.add(pktmp);
            }
        }
        tmpstr = rs.getString("person2_key");
        if (tmpstr != null) {
            if (tmpstr.length() > 0) {
                HeatListResultPersonKey pktmp = new HeatListResultPersonKey();
                pktmp.setPersonKey(tmpstr);
                pkList.add(pktmp);
            }
        }
        competitor.setPersonKeys((ArrayList)pkList);
        competitor.setEventId(rs.getInt("event_id"));
        competitor.setXmlId(rs.getInt("xml_id"));
        return competitor;
    }
    
}
