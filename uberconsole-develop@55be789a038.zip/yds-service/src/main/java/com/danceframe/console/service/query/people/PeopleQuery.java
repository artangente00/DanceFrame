/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query.people;


/**
 *
 * @author nbonita
 */
public final class PeopleQuery {
    
    public static final String TBL_NAME = "tbl_people";
    
    public static final String ID_VARIABLE = "people_id";
    
    public static final String INSERT_QRY = "SELECT uberconsole.FN_PEOPLE_INSERT( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    public static final String UPDATE_QRY = "SELECT uberconsole.FN_PEOPLE_UPDATE( ?, ?, ?, ?, ?, ?, ?, ?, ? )";
    
    public static final String DELETE_QRY = "SELECT uberconsole.FN_PEOPLE_DELETE( ? )";
    
    public static final String SEARCH_BYID_QRY = "SELECT uberconsole.FN_PEOPLE_BYID( ? )";
    
    public static final String SEARCH_BYEMAIL_QRY = "SELECT uberconsole.FN_PEOPLE_BYEMAIL( ? )";
    
    
    public static final String SELECT_QRY = "SELECT people_id, firstname, lastname, " +
                                                "studioname, email, gender, birthday, " +
                                                "category, invoiceaddress, firebaseauthenticationid, loginprovider, " +
                                                "datecreated, datesignedIn, facebookuseruid " +
                                                "FROM uberconsole.VW_PEOPLEMANAGEMENT";
    
    public static final String SELECT_QRY_OLD = "SELECT people_id, firstname, lastname, " +
                                                "studioname, email, gender, birthday, " +
                                                "category, invoiceaddress, firebaseauthenticationid, loginprovider, " +
                                                "datecreated, datesignedIn, facebookuseruid " +
                                                "FROM uberconsole.tbl_user";
    
    public static final String SELECT_COUNT_QRY = "SELECT count(people_id) FROM uberconsole.VW_PEOPLEMANAGEMENT";
    
}








