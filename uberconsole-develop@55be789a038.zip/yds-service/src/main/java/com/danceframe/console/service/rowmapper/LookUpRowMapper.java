/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper;

import com.danceframe.console.common.model.basic.LookUp;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class LookUpRowMapper implements RowMapper<LookUp> {

    @Override
    public LookUp mapRow(ResultSet rs, int column) throws SQLException {
        final LookUp lookup = new LookUp();
        lookup.setId(rs.getInt("lookup_id"));
        lookup.setCode(rs.getString("code"));
        lookup.setIndex(rs.getInt("idx"));
        lookup.setDescription(rs.getString("description"));
        return lookup;
    }
    
}
