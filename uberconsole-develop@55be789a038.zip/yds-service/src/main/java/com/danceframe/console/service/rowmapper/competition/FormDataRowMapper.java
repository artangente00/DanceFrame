/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.competition;

import com.danceframe.console.common.model.competition.FormData;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class FormDataRowMapper implements RowMapper<FormData> {

    @Override
    public FormData mapRow(ResultSet rs, int column) throws SQLException {
        FormData formdata = new FormData();
        formdata.setId(rs.getInt("code_id"));
        formdata.setCode(rs.getString("code"));
        formdata.setUrl(rs.getString("url"));
        formdata.setDescription(rs.getString("description"));
        formdata.setOrderValue(rs.getInt("ordervalue"));
        formdata.setImageId(rs.getInt("image_id"));
        formdata.setEventId(rs.getInt("event_id"));
        formdata.setFilename(rs.getString("filename"));
        formdata.setMimeType(rs.getString("mimetype"));
        formdata.setImage(rs.getBytes("image"));
        return formdata;        
    }
    
}
