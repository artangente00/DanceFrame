/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.payment;

import com.danceframe.console.common.model.invoice.InvoicePayment;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class InvoicePaymentRowMapper implements RowMapper<InvoicePayment> {

    @Override
    public InvoicePayment mapRow(ResultSet rs, int i) throws SQLException {
        InvoicePayment retinvPayment = new InvoicePayment();
        retinvPayment.setInvoicePaymentId(rs.getInt("invpayment_id"));
        retinvPayment.setFirebaseAuthId(rs.getString("firebase_auth_id"));
        retinvPayment.setFirebaseEventId(rs.getString("firebase_event_id"));
        retinvPayment.setEventId(rs.getInt("event_id"));
        retinvPayment.setPeopleId(rs.getInt("people_id"));
        retinvPayment.setInvoiceNo(rs.getString("invoice_no"));
        retinvPayment.setSeriesNo(rs.getString("series_no"));
        retinvPayment.setInvoiceAmount(rs.getDouble("invoice_amount"));
        retinvPayment.setReceivedAmount(rs.getDouble("received_amount"));
        retinvPayment.setBalance(rs.getDouble("balance"));
        retinvPayment.setSendMail(rs.getBoolean("sendmail"));
        retinvPayment.setLastPaymentDate(rs.getTimestamp("last_payment_date"));
        retinvPayment.setMailInvoiceId(rs.getInt("mailinv_id"));
        return retinvPayment;
    }
    
}
