/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.impl;

import com.danceframe.console.common.model.basic.Image;
import com.danceframe.console.service.constant.GenericFormType;
import com.danceframe.console.service.dataprovider.ImageProviderDao;
import com.danceframe.console.service.query.ImageQuery;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class ImageProviderDaoImpl extends BaseJdbcDaoImpl implements ImageProviderDao {

    private RowMapper<Image> rowMapper;
    
    @Override
    public int insertEventImageFile(int eventid, String path, String filename, String mimetype) {
        return (insertImageFile(eventid, path, filename, mimetype, ImageQuery.INSERT_EVENT_IMAGE_QRY, GenericFormType.EVENT_CODE));
    }

    @Override
    public int updateEventImageFile(int imageid, String path, String filename, String mimetype) {
        return(updateImageFile(imageid, path, filename, mimetype, ImageQuery.UPDATE_IMAGE_QRY));
    }
    
    @Override
    public int inserGenericFormImageFile(int codeid, String path, String filename, String mimetype, String code) {
        return (insertImageFile(codeid, path, filename, mimetype, ImageQuery.INSERT_TMPIMAGE_QRY, code));
    }

    @Override
    public int updateGenericFormImageFile(int codeid, String path, String filename, String mimetype, String code) {
        return(updateImageFile(codeid, path, filename, mimetype, ImageQuery.UPDATE_TMPIMAGE_QRY));
    }
    

    @Override
    public Image get(int imageid) {
        Object[] obj = new Object[] {imageid };
        return ((Image)getJdbcTemplate().queryForObject(ImageQuery.SELECT_IMAGE_QRY, obj, rowMapper));   
    }
    
    @Override
    public List<Integer> getAllImageIds(int eventId) {
        Object[] obj = new Object[] { eventId };
        List<Integer> itmpList = new ArrayList<Integer>();
        itmpList = getJdbcTemplate().queryForList(ImageQuery.SELECT_IMAGELIST_BYEVENTID, obj, Integer.class);
        return (itmpList);
    }

     /**
     * @return the rowMapper
     */
    public RowMapper<Image> getRowMapper() {
        return rowMapper;
    }

    /**
     * @param rowMapper the rowMapper to set
     */
    public void setRowMapper(RowMapper<Image> rowMapper) {
        this.rowMapper = rowMapper;
    }
    
    private int insertImageFile(int codeid, String path, String filename, String mimetype, String sqlQuery, String code) {
        int retint = 0;
        File file = new File(path, filename);
        if (!file.exists()) { 
            retint = -98;
            return retint;
        }
        try {
            InputStream instream = new FileInputStream(file);
            int imageid = getJdbcTemplate().queryForObject(ImageQuery.SELECT_IMAGEID_QRY, Integer.class);
        getJdbcTemplate().update(new PreparedStatementCreator() {        
            @Override
            public PreparedStatement createPreparedStatement(Connection conn) throws SQLException {
                PreparedStatement ps = conn.prepareStatement(sqlQuery);
                ps.setString(1, code);
                ps.setInt(2, imageid);
                ps.setInt(3, codeid);
                ps.setString(4, filename);
                ps.setString(5, mimetype);
                ps.setBinaryStream(6, instream, file.length());     
                return ps;
                } 
            }
        );
            instream.close();
            retint = imageid;
         } catch (IOException io) {
            io.printStackTrace();
            retint = -99;
         }
        return retint;
    }


    private int updateImageFile(int imageid, String path, String filename, String mimetype, String sqlQuery) {
        int retint = 0;
        File file = new File(path, filename);
        if (!file.exists()) {
            retint = -98;
            return retint;
        }
        try {
            InputStream instream = new FileInputStream(file);
        getJdbcTemplate().update(new PreparedStatementCreator() {        
            @Override
            public PreparedStatement createPreparedStatement(Connection conn) throws SQLException {
                PreparedStatement ps = conn.prepareStatement(sqlQuery);
                ps.setString(1, filename);
                ps.setString(2, mimetype);
                ps.setBinaryStream(3, instream, file.length());   
                 ps.setInt(4, imageid);
                return ps;
                } 
            }
        );
            instream.close();
            retint = 100;
         } catch (IOException io) {
            io.printStackTrace();
            retint = -99;
         }
        return retint;
    }
   
}
