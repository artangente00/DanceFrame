/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.payment.impl;

import com.danceframe.console.common.model.invoice.InvoicePaymentDetail;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.dataprovider.payment.InvoicePaymentDetailProviderDao;
import com.danceframe.console.service.query.payment.InvoicePaymentQuery;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public class InvoicePaymentDetailProviderDaoImpl extends GenericProviderDaoImpl<InvoicePaymentDetail> implements InvoicePaymentDetailProviderDao {

    @Override
    public int search(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int search(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int insert(InvoicePaymentDetail invpaydet) {
          Object[] obj = new Object[] {
            invpaydet.getInvoicePaymentId(),
            BigDecimal.valueOf(invpaydet.getInvoiceAmount()),
            BigDecimal.valueOf(invpaydet.getReceivedAmount()),
            BigDecimal.valueOf(invpaydet.getBalance()),
            invpaydet.getPayType(),
            invpaydet.getNotes()
         };
        int ret = (Integer)this.genericQryTemplateInteger(InvoicePaymentQuery.INSERT_INVPAYMENT_DETAIL, obj);
        return ret;
    }

    @Override
    public int update(InvoicePaymentDetail t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public InvoicePaymentDetail get(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public InvoicePaymentDetail get(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<InvoicePaymentDetail> getAll(String wherestr) {
        List<InvoicePaymentDetail> invDetList = new ArrayList<InvoicePaymentDetail>();
        invDetList = genericQryAllTemplateRowMapper(InvoicePaymentQuery.SELECT_INVPAYMENT_DETAIL, wherestr); 
        return(invDetList);
    }

    @Override
    public List<InvoicePaymentDetail> getAllWithPaging(String wherestr, int pagesize, int first) {
         List<InvoicePaymentDetail> invDetList = new ArrayList<InvoicePaymentDetail>();
        invDetList = genericQryAllTemplateRowMapperWithPaging(InvoicePaymentQuery.SELECT_INVPAYMENT_DETAIL, wherestr,  pagesize,  first); 
        return(invDetList);
    }

    @Override
    public long getAllCount(String wherestr) {
        return genericQryForInt(InvoicePaymentQuery.COUNT_INVPAYMENT_DETAIL, wherestr);
    }
    
}
