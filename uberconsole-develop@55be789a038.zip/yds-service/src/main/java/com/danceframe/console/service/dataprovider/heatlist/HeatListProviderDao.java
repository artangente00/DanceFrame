/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.heatlist;

import com.danceframe.console.common.model.heatlist.HeatComp;
import com.danceframe.console.common.model.heatlist.HeatEntry;
import com.danceframe.console.common.model.heatlist.HeatFullData;
import com.danceframe.console.common.model.heatlist.HeatInfo;
import com.danceframe.console.common.model.heatlist.HeatList;
import com.danceframe.console.common.model.heatlist.HeatListEvent;
import com.danceframe.console.common.model.heatlist.HeatPerson;
import com.danceframe.console.common.model.heatlist.HeatSession;
import com.danceframe.console.common.model.heatlist.HeatStudio;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public interface HeatListProviderDao {
    
    int insertHeatList(HeatList heatlist);
     
    int insertStudio(HeatStudio heatstudio);
    
    int insertPerson(HeatPerson heatperson);
    
    int insertHeatInfo(HeatInfo heatinfo);
    
    int insertCompetition(HeatComp heatcomp);
    
    int insertEntry(HeatEntry heatentry);
    
    int insertSession(HeatSession heatsession);
    
    int deleteHeatList(int heatListId);
    
    List<HeatPerson> getAllHeatPerson(int heatListId);
    
    List<HeatFullData> getHeatFullDataByPerson(String personCmdId, int heatListId);
    
    int getCountDataByPerson(String personCmdId, int heatListId);
    
    HeatListEvent getHeatListById(int heatListId);
    
    List<HeatListEvent> getAll(String wherestr);
    
    List<HeatListEvent> getAllWithPaging(String wherestr, int pagesize, int first);
    
    long getAllCount(String wherestr);
    
    HeatListEvent getHeatListByEventId(int eventId);
    
    int checkHeatListDataExist(int eventId);
    
    int deleteHeatListByEventId(int eventId);
    
    int saveHeatlistData(HeatList heatList, int type);
    
    List<HeatSession> getHeatSessions(int heatListId);
 
}
