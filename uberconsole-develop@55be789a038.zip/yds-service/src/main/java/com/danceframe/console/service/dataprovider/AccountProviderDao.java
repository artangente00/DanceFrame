/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider;

import com.danceframe.console.common.model.registry.Account;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public interface AccountProviderDao {
    
    int searchUserAccount(String username, int isactive);
    
    int searchAllUser(String username);
    
    int insertAccount(Account account);
    
    int updateAccount(Account account);
      
    int activateAccount(String username);
    
    int deactivateAccount(String username);
    
    Account getUserInformation(String username, int isactive);
    
    List<Account> getAllUserWithPaging(int pagesize, int pagenum, int isactive);
    
}
