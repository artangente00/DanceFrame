/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query.competition;

/**
 *
 * @author lmorallos
 */
public final class OrganizerQuery {
    
    public static final String INSERT_QRY = "SELECT uberconsole.FN_ORGANIZER_INSERT_WITH_EVENTID(?,?)";

    public static final String UPDATE_QRY = "SELECT uberconsole.FN_ORGANIZER_UPDATEBY_EVENTID(?,?)";

    public static final String DELETEBYID_QRY = "SELECT uberconsole.FN_ORGANIZER_DELETEBYID(?)";

    public static final String SEARCHBYID_QRY = "SELECT uberconsole.FN_ORGANIZER_SEARCHBYID(?)";

    public static final String SEARCHBYNAME_QRY = "SELECT uberconsole.FN_ORGANIZER_SEARCHBYNAME(?)";
    
    public static final String SELECT_QRY = "SELECT organizer_id, name, event_id FROM uberconsole.tbl_organizer";
    
    public static final String SELECT_COUNT_QRY = "SELECT count(organizer_id) FROM uberconsole.tbl_organizer";

}
