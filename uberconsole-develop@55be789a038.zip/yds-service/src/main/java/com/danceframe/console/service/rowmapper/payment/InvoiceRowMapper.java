/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.payment;


import com.danceframe.console.common.model.payment.Invoice;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author NDB
 */
public class InvoiceRowMapper implements RowMapper<Invoice> {
    
    @Override
    public Invoice mapRow(final ResultSet rs, final int column) throws SQLException {
        final Invoice oneInvoice = new Invoice();
        oneInvoice.setId(rs.getInt("invoice_id"));
        oneInvoice.setUserPushId(rs.getString("user_push_id"));
        oneInvoice.setEventPushId(rs.getString("event_push_id"));
        oneInvoice.setBillingName(rs.getString("billing_name"));
        oneInvoice.setBillingAddress(rs.getString("billing_address"));
        oneInvoice.setEventTitle(rs.getString("event_title"));
        oneInvoice.setTotalAmount(rs.getString("total_amount"));
        oneInvoice.setRecievedAmount(rs.getString("received_amount"));
        oneInvoice.setCreatedTimestamp(rs.getString("created_timestamp"));
        oneInvoice.setModifiedTimestamp(rs.getString("modified_timestamp"));
        oneInvoice.setRtdbEtransferPaymentJson(rs.getString("rtdb_etransfer_payment_json"));
        return oneInvoice;
    }
    
}
