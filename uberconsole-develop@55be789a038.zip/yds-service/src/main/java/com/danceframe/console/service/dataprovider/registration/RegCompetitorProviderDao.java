/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.registration;

import com.danceframe.console.common.model.registration.RegCompetitor;
import com.danceframe.console.service.dataprovider.GenericProviderDao;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public interface RegCompetitorProviderDao extends GenericProviderDao<RegCompetitor> {
    
    RegCompetitor get(int personId, String euid);
    
    RegCompetitor get(String cuid, String euid);
    
    List<RegCompetitor> getRegCompetitorsByEventUID(String euid);
    
    RegCompetitor get( String buid,  String euid, String cuid);
    
    List<RegCompetitor> getRegCompetitors(String buid, String euid);
    
}
