/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider;

import com.danceframe.console.common.model.basic.LookUp;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public interface LookUpProviderDao {
    
    List<LookUp> getLookUp(String code);
    
    List<LookUp> getEventStatus();
    
    List<LookUp> getNoYes();
    
    List<LookUp> getPublishStatus();
    
    List<LookUp> getFormTypes();
    
    List<LookUp> getFormHeaderTypes();
    
    List<LookUp> getFormEntryTypes();
    
    List<LookUp> getFormFields();
	
	List<LookUp> getCountry();
    
    
}
