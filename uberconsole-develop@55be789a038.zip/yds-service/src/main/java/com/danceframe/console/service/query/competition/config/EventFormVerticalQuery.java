/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query.competition.config;

/**
 *
 * @author lmorallos
 */
public final class EventFormVerticalQuery {
    
    public final static String INSERT_QRY = "SELECT uberconsole.FN_EVENTFORM_VERTICAL_INSERT(?, ?, ?, ?, ?)";
    
    public final static String DELETE_QRY = "SELECT uberconsole.FN_EVENTFORM_VERTICAL_DELETEBYId(?)";
        
    public final static String SELECT_QRY = "SELECT eventvertical_id, eventform_id, eventfield_id, code," + 
            "description, allowall FROM uberconsole.tbl_eventform_vertical";
    
    public final static String SELECT_COUNT_QRY = "SELECT count(eventvertical_id) FROM uberconsole.tbl_eventform_vertical";

}
