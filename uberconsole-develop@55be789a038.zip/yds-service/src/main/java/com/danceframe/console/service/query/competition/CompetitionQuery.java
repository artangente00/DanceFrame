/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query.competition;

/**
 *
 * @author lmorallos
 */
public final class CompetitionQuery {
    
    public static final String INSERT_QRY = "SELECT uberconsole.FN_COMPETITION_INSERT( ? )";

    public static final String UPDATE_BYID_QRY = "SELECT uberconsole.FN_COMPETITION_UPDATE_BYID(?,?)"; 

    public static final String DELETEBYID_QRY = "SELECT uberconsole.FN_COMPETITION_DELETEBYID( ? )";	

    public static final String DELETEBYNAME_QRY = "SELECT uberconsole.FN_COMPETITION_DELETEBYNAME( ? )";

    public static final String SEARCHBYNAME_QRY = "SELECT uberconsole.FN_COMPETITION_SEARCHBYNAME( ? )";

    public static final String SEARCHBYID_QRY = "SELECT uberconsole.FN_COMPETITION_SEARCHBYID( ? )";	
    
    public static final String SELECT_QRY = "SELECT competition_id, name FROM uberconsole.tbl_competition";

    public static final String SELECT_COUNT_QRY = "SELECT count(competition_id) FROM uberconsole.tbl_competition";

}
