/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.competition;

import com.danceframe.console.common.model.competition.Organizer;
import com.danceframe.console.service.dataprovider.GenericProviderDao;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public interface OrganizerProviderDao extends GenericProviderDao<Organizer> {
     
    List<Organizer> getAllByEventId(int id);   
}
