/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.competition.config;

import com.danceframe.console.common.model.competition.form.EventFormField;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class EventFormFieldRowMapper implements RowMapper<EventFormField> {

    @Override
    public EventFormField mapRow(ResultSet rs, int column) throws SQLException {
        EventFormField eventfield = new EventFormField();
        eventfield.setId(rs.getInt("eventfield_id"));
        eventfield.setEventformId(rs.getInt("eventform_id"));
        eventfield.setFieldName(rs.getString("field_name"));
        eventfield.setLinkTo(rs.getString("linkto"));
        return eventfield;
    }
    
}
