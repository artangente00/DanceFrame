/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.file.heatlist.impl;

import com.danceframe.console.common.model.heatlist.HeatComp;
import com.danceframe.console.common.model.heatlist.HeatEntry;
import com.danceframe.console.common.model.heatlist.HeatInfo;
import com.danceframe.console.common.model.heatlist.HeatPerson;
import com.danceframe.console.common.model.heatlist.HeatSession;
import com.danceframe.console.common.model.heatlist.HeatStudio;
import com.danceframe.console.common.util.Utility;
import com.danceframe.console.service.constant.HeatListTag;
import com.danceframe.console.service.dataprovider.heatlist.HeatListProviderDao;
import com.danceframe.console.service.file.heatlist.HeatListReader;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


/**
 *
 * @author lmorallos
 */
public class HeatListReaderImpl implements HeatListReader{
    
    private static final Logger logger = LogManager.getLogger(HeatListReader.class);
    private static final String SETUPFILE_MAKER = "stu";
    private static final String SESSION_MARKER = "SE";
            
    private HeatListProviderDao heatListProviderDao;
    
     @Override
     public boolean fileToDatabase(String filename, int hid) throws FileNotFoundException, IOException {
        boolean retbool = false;
        File heatfile = new File(filename);
        if (heatfile.exists()) {
            retbool = true;
            FileReader heatfr = new FileReader(heatfile);
            BufferedReader heatbr = new BufferedReader(heatfr);
            String strline = new String();
            String compid = new String();
            int heatinfoId = 0;
            boolean studio = false;
            boolean person = false;
            boolean program = false;
            boolean comp = false;
            boolean heat = false;
            boolean skip = false;
            long studiocnt = 0;
            long personcnt = 0;
            long infocnt = 0;
            long compcnt = 0;
            long entcnt = 0;
            while ((strline = heatbr.readLine()) != null) {
                if (strline.equals(HeatListTag.STUDIO_START_TAG)) {
                    studio = true;
                    skip = true;
                }
                if (strline.equals(HeatListTag.STUDIO_END_TAG)) {
                    logger.info("HEATLIST - No of inserted studio info:" + studiocnt);
                    studio = false;
                }
                if (strline.equals(HeatListTag.PERSON_START_TAG)) {
                    person = true;
                    skip = true;
                }
                if (strline.equals(HeatListTag.PERSON_END_TAG)) {
                    logger.info("HEATLIST - No of inserted person info:" + personcnt);
                    person = false;
                }
                if (strline.equals(HeatListTag.PROGRAM_START_TAG)) {
                    program = true;
                    skip = true;
                }
                if (strline.equals(HeatListTag.PROGRAM_END_TAG)) {
                    logger.info("HEATLIST - No of inserted heat:" + infocnt);
                    logger.info("HEATLIST - No of compeition heat:" + compcnt);
                    logger.info("HEATLIST - No of entry heat:" + entcnt);
                    program = false;
                }
                if (studio) {
                    if (skip) {
                        skip = false;
                    } else {
                        List<String> strList = Utility.str2List(strline,'|');
                        HeatStudio hstudio = new HeatStudio(strList.get(0), strList.get(1), hid);
                        heatListProviderDao.insertStudio(hstudio);
                        studiocnt++;
                       
                    }
                }
                if (person) {
                    if (skip) {
                        skip = false;
                    } else {                       
                        List<String> strList = Utility.str2List(strline,'|');
                        HeatPerson hperson = new HeatPerson( strList.get(0), strList.get(1), strList.get(2),  
                                strList.get(3),  strList.get(4), strList.get(5),  hid);
                        heatListProviderDao.insertPerson(hperson);
                        personcnt++;
                    }
                }
                if (program) {
                    if (skip) {
                        skip = false;
                    } else {                        
                        List<String> strList = Utility.str2List(strline,'|');
                        String tmptag = strList.get(0);
                        if (tmptag.equals(HeatListTag.HEAT_START_TAG)) {
                            heat = true;
                        }
                        if (tmptag.equals(HeatListTag.HEAT_END_TAG)) {
                            heat = false;
                        }
                        if (tmptag.equals(HeatListTag.COMP_START_TAG)) {
                            comp = true;
                        }
                        if (tmptag.equals(HeatListTag.COMP_END_TAG)) {
                            comp = false;
                        }
                        if (heat && !comp) {
                            if (!tmptag.equals(HeatListTag.COMP_END_TAG)) {
                                String tmpdata = strList.get(1);
                                int smarker = tmpdata.indexOf("[");
                                if (smarker > -1) {
                                    String heatval = tmpdata.substring(0, smarker).trim();
                                    int slen =  tmpdata.length();
                                    int hmarker = tmpdata.indexOf("]");
                                    String sched = tmpdata.substring(smarker+1, hmarker).trim();
                                    String desc = tmpdata.substring(hmarker+1, slen).trim();
                                    HeatInfo heatinfo = new HeatInfo(heatval, sched, desc, hid);
                                    heatinfoId = heatListProviderDao.insertHeatInfo(heatinfo);
                                    infocnt++;
                                }
                            }
                        }
                        if (heat && comp)  {
                            if (tmptag.equals(HeatListTag.COMP_START_TAG)) {                                                               
                                HeatComp heatcomp = new HeatComp(strList.get(1), strList.get(2), strList.get(3), strList.get(4),strList.get(5), heatinfoId, hid);
                                compid = strList.get(1);
                                heatListProviderDao.insertCompetition(heatcomp);
                                compcnt++;
                            } else {
                                HeatEntry heatentry = new 
                                HeatEntry(strList.get(0), strList.get(1), strList.get(2), 
                                     strList.get(3), strList.get(4), strList.get(5), compid, hid);
                                heatListProviderDao.insertEntry(heatentry);
                                entcnt++;
                                
                            }
                        }
                    }
                }
            }
            heatbr.close();
        }
        return retbool;
    }

    @Override
    public boolean setupFileToDatabase(String filename, int hid) throws FileNotFoundException, IOException {
        BufferedReader setupFile = new BufferedReader(new FileReader(filename));
        String tmpstr = new String();
        boolean retbool = true;
        int ctr = 0;
        int seq = 1;
        List<HeatSession> sessions = new ArrayList<>();
        List<String> tmpList = new ArrayList<>();
        while ((tmpstr = setupFile.readLine()) != null) {
            if (ctr == 0) { 
                if (!tmpstr.contains(";"))  {
                    retbool = false; break;
                } else {
                    tmpList = Utility.str2List(tmpstr, ';');
                    if (!tmpList.get(0).equalsIgnoreCase(SETUPFILE_MAKER)) {
                        retbool = false;
                        break;
                    }
               } 
            } else {
                tmpList = Utility.str2List(tmpstr, ';');                 
                if (tmpList.get(0).equalsIgnoreCase(SESSION_MARKER)) {
                    if (tmpList.size() >= 3) {
                        HeatSession session = new HeatSession() ;
                        session.setHeatlistId(hid);
                        session.setSessionCount(seq);
                        session.setSessionDay(tmpList.get(1));
                        List<String> tmpDate = Utility.str2List(tmpList.get(2), '.');
                        if (tmpDate.size() >= 3)
                            session.setSessionDate(tmpDate.get(0) + "." + tmpDate.get(1) + "." + tmpDate.get(2));
                        if (tmpDate.size() >= 6)
                            session.setSessionTime(tmpDate.get(3) + "." + tmpDate.get(4) + "." + tmpDate.get(5));
                        sessions.add(session);
                        seq++;  
                    }
                } else {
                    break;
                }
            }
           ctr++;
        }
        setupFile.close();
        if (sessions.size() > 0) {
            int insertcnt = 0;
            for (HeatSession session:sessions) {
                int iret = heatListProviderDao.insertSession(session);
                if (iret > 0) insertcnt++;
            }
            logger.info("HEATLIST (SETUP FILE)- No of session inserted:" + insertcnt);
        }
        return retbool;
    }

    
    /**
     * @return the heatListProviderDao
     */
    public HeatListProviderDao getHeatListProviderDao() {
        return heatListProviderDao;
    }

    /**
     * @param heatListProviderDao the heatListProviderDao to set
     */
    public void setHeatListProviderDao(HeatListProviderDao heatListProviderDao) {
        this.heatListProviderDao = heatListProviderDao;
    }

   
}
