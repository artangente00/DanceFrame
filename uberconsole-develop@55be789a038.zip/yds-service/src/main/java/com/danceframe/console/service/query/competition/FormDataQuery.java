/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query.competition;

/**
 *
 * @author lmorallos
 */
public final class FormDataQuery {
    
    public static final String EVENT_INSERT_QRY  = "SELECT uberconsole.FN_EVENT_GENERICFORM_INSERT_WITH_EVENTID(?,?,?)";
    
    public static final String EVENT_UPDATE_QRY = "SELECT uberconsole.FN_EVENT_GENERICFORM_UPDATE_BYEVENTID(?,?)";
    
    public static final String MOVE2TMP_QRY = "SELECT uberconsole.FN_EVENT_GENERICFORM_MOVETO_TMP(?,?)";
    
    public static final String INSERT_QRY = "SELECT uberconsole.FN_EVENT_GENERICFORM_LIST_INSERT(?, ?, ?, ?, ?, ?)";
    
    public static final String UPDATE_QRY = "SELECT uberconsole.FN_EVENT_GENERICFORM_LIST_UPDATE(?, ?, ?, ?, ?, ?)";
     
    public static final String DELETE_QRY = "SELECT uberconsole.FN_EVENT_GENERICFORM_LIST_DELETEBYID( ? )";
    
    public static final String CLEANTMP_QRY = "SELECT uberconsole.FN_EVENT_GENERICFORM_LIST_CLEANTMPBYID( ? )";
    
    public static final String UPDATE_IMAGEBYID_QRY = "SELECT uberconsole.FN_EVENT_GENERICFORM_IMAGEUPDATE_BYID(?,?)";
    
    public static final String SELECT_QRY = "SELECT code_id,code,url,description,ordervalue,image_id,event_id,"+ 
                "filename,mimetype,imgevent_id,image FROM uberconsole.VW_EVENT_GENERICFORM_DATA";
    
    public static final String SELECT_COUNT_QRY = "SELECT count(code_id) FROM uberconsole.VW_EVENT_GENERICFORM_DATA";
    
    public static final String SELECT_ORDERLAST_QRY = "SELECT DISTINCT ordervalue FROM uberconsole.tbl_tmpformdata WHERE event_id=? AND code=? ORDER BY ordervalue desc limit 1";
    
    public static final String SELECT_GENERIC_QRY = "SELECT code_id,url,description,ordervalue,image_id,event_id,filename,mimetype FROM ";
}
