/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.competition.config.impl;

import com.danceframe.console.common.model.competition.form.EventFormHContent;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import java.util.List;
import com.danceframe.console.service.query.competition.config.EventFormHContentQuery;
import java.util.ArrayList;
import com.danceframe.console.service.dataprovider.competition.config.EventFormHContentProviderDao;

/**
 *
 * @author lmorallos
 */
public class EventFormHContentProviderDaoImpl extends GenericProviderDaoImpl<EventFormHContent> implements EventFormHContentProviderDao {

    @Override
    public int insert(EventFormHContent hcontent) {
         Object[] obj = new Object[] {
            hcontent.getEventFormId(),
            hcontent.getHorizHeader()
            };
        int ret = (Integer)this.genericQryTemplateInteger(EventFormHContentQuery.INSERT_QRY, obj);
        return ret;
     }
    
    @Override
    public List<EventFormHContent> getAll(String wherestr) {
        List<EventFormHContent> eventhcontentList = new ArrayList<EventFormHContent>();
        eventhcontentList = genericQryAllTemplateRowMapper(EventFormHContentQuery.SELECT_QRY, wherestr); 
        return(eventhcontentList);
    }

    @Override
    public List<EventFormHContent> getAllWithPaging(String wherestr, int pagesize, int first) {
        List<EventFormHContent> eventhcontentList = new ArrayList<EventFormHContent>();
        eventhcontentList = genericQryAllTemplateRowMapperWithPaging(EventFormHContentQuery.SELECT_QRY, wherestr,  pagesize,  first);
        return(eventhcontentList);
     }

    @Override
    public long getAllCount(String wherestr) {
         return genericQryForInt(EventFormHContentQuery.SELECT_COUNT_QRY, wherestr); 
    }

    @Override
    public int delHorizContent(int eventformid, String header) {
        Object[] obj = new Object[] { eventformid, header };
        int ret = (Integer)this.genericQryTemplateInteger(EventFormHContentQuery.DELETE_QRY, obj);
        return ret;
    }
    
    @Override
    public int delete(int id) {
         Object[] obj = new Object[] { id };
        int ret = (Integer)this.genericQryTemplateInteger(EventFormHContentQuery.DELETEBYID_QRY, obj);
        return ret;
     }

    @Override
    public int delHorizContentClear(int eventformid) {
        Object[] obj = new Object[] { eventformid };
        int ret = (Integer)this.genericQryTemplateInteger(EventFormHContentQuery.DELETEALL_QRY, obj);
        return ret;
    }
    
    @Override
    public int search(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int search(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int update(EventFormHContent t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   

    @Override
    public int delete(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public EventFormHContent get(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public EventFormHContent get(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   
    
}
