/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query.competition;

/**
 *
 * @author lmorallos
 */
public final class FinanceQuery {
    
    public static final String INSERT_QRY = "SELECT uberconsole.FN_FINANCE_INSERT( ?, ?, ?)";
    
    public static final String UPDATE_QRY = "SELECT uberconsole.FN_FINANCE_UPDATE_BYID(?, ?, ?)";
    
    public static final String SELECT_QRY = "SELECT finance_id,surcharge,description,event_id FROM uberconsole.tbl_finance";
    
}
