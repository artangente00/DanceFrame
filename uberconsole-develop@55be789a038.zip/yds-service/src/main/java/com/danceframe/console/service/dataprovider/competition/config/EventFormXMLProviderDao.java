/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.competition.config;

import com.danceframe.console.common.model.competition.form.EventFormXML;

/**
 *
 * @author lmorallos
 */
public interface EventFormXMLProviderDao {
    
    int insertGenerate(int eventId, String path, String filename);
    
    int insertManual(int eventId, String path, String filename);
    
    int updateGenerate(int eventId, String path, String filename);
    
    int updateManual(int eventId, String path, String filename);
    
    int insertSTUManual(int eventId, String path, String filename);
    
    int updateSTUGenerate(int eventId, String path, String filename);
    
    EventFormXML get(int eventId);
    
    int setUseManual(int eventId, boolean usemanual);
}
