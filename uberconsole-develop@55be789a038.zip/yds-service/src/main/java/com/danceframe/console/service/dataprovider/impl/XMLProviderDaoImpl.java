/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.impl;

import com.danceframe.console.common.model.heatlist.result.HeatlistResultXML;
import com.danceframe.console.common.util.Utility;
import com.danceframe.console.service.dataprovider.XMLFileProviderDao;
import com.danceframe.console.service.query.XMLQuery;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import org.springframework.jdbc.core.PreparedStatementCreator;

/**
 *
 * @author lmorallos
 */
public class XMLProviderDaoImpl extends BaseJdbcDaoImpl implements XMLFileProviderDao {

    @Override
    public int insertXMLFileToDB(HeatlistResultXML xmlfile) {
        int retint = 0;
        try {
            InputStream instream = xmlfile.getByteAsInputStream();
            int xmlid = getJdbcTemplate().queryForObject(XMLQuery.SELECT_XMLID_QRY, Integer.class);
            String sqlQuery = XMLQuery.INSERT_XMLFILE_QRY;
            getJdbcTemplate().update(new PreparedStatementCreator() {        
                @Override
                public PreparedStatement createPreparedStatement(Connection conn) throws SQLException {
                    PreparedStatement ps = conn.prepareStatement(sqlQuery);

                    ps.setInt(1, xmlid);
                    ps.setString(2, xmlfile.getFilename());
                    ps.setTimestamp(3, Utility.sqlTimestamp(xmlfile.getUploadtime()));
                    ps.setString(4, xmlfile.getCode());
                    ps.setInt(5, xmlfile.getEventId());
                    ps.setBinaryStream(6, instream, xmlfile.size());   

                    return ps;
                    } 
                }
            );
            instream.close();
            retint = xmlid;
         } catch (IOException io) {
            io.printStackTrace();
            retint = -99;
         }
        return retint;
    }
    
}
