/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.systemconfig.impl;

import com.danceframe.console.common.model.systemconfig.SystemConfig;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.dataprovider.systemconfig.SystemConfigProviderDao;
import com.danceframe.console.service.query.systemconfig.SystemConfigQuery;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author nbonita
 */
public class SystemConfigProviderDaoImpl extends GenericProviderDaoImpl<SystemConfig> implements SystemConfigProviderDao {

    @Override
    public int search(int id) {
        Object[] obj = new Object[] {id };
        int ret = (Integer)this.genericQryTemplateInteger(SystemConfigQuery.SEARCH_BYSYSTEMCONFIGID_QRY, obj);
        return ret;
    }

    @Override
    public int search(String name) {
        Object[] obj = new Object[] {name };
        int ret = (Integer)this.genericQryTemplateInteger(SystemConfigQuery.SEARCH_BYSYSTEMCONFIGNAME_QRY, obj);
        return ret;
    }

    @Override
    public int insert(SystemConfig oneSystemConfig) {
        Object[] obj = new Object[] {
            oneSystemConfig.getName(),
            oneSystemConfig.getValue(),
            oneSystemConfig.getType(),
            oneSystemConfig.getCategory(),
            oneSystemConfig.getPushid(),
            oneSystemConfig.getEnabled()
            };
         int ret = (Integer)this.genericQryTemplateInteger(SystemConfigQuery.INSERT_QRY, obj);
        return ret;
    }

    @Override
    public int update(SystemConfig oneSystemConfig) {
        Object[] obj = new Object[] {
            oneSystemConfig.getId(),
            oneSystemConfig.getName(),
            oneSystemConfig.getValue(),
            oneSystemConfig.getType(),
            oneSystemConfig.getCategory(),
            oneSystemConfig.getPushid(),
            oneSystemConfig.getEnabled()
            };
        int ret = (Integer)this.genericQryTemplateInteger(SystemConfigQuery.UPDATE_QRY, obj);
        return ret;    }

    @Override
    public int delete(int id) {
        Object[] obj = new Object[] { id };
        int ret = (Integer)this.genericQryTemplateInteger(SystemConfigQuery.DELETE_QRY, obj);
        return ret;
    }
    
    @Override
    public int delete(String name) {
        throw new UnsupportedOperationException("Not supported yet.");
    }   

    @Override
    public SystemConfig get(int id) {
        Object[] obj = new Object[] { id };
        String sqlWhere = " WHERE systemconfig_id = ?"  ;
        String finalSQL = SystemConfigQuery.SELECT_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj); 
    }

    @Override
    public SystemConfig get(String name) {
        Object[] obj = new Object[] { name };
        String sqlWhere = " WHERE UPPER(systemconfig_name) = UPPER(?)"  ;
        String finalSQL = SystemConfigQuery.SELECT_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj); 
    }

    @Override
    public List<SystemConfig> getAll(String wherestr) {
        List<SystemConfig> systemConfigList = new ArrayList<SystemConfig>();
        systemConfigList = genericQryAllTemplateRowMapper(SystemConfigQuery.SELECT_QRY, wherestr); 
        return(systemConfigList);
    }

    @Override
    public List<SystemConfig> getAllWithPaging(String wherestr, int pagesize, int first) {
        List<SystemConfig> systemConfigList = new ArrayList<SystemConfig>();
        systemConfigList = genericQryAllTemplateRowMapperWithPaging(SystemConfigQuery.SELECT_QRY, wherestr,  pagesize,  first);
        return(systemConfigList);
    }

    @Override
    public long getAllCount(String wherestr) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public int setDisabled(boolean disabled) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
}
