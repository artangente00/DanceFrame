/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.competition.impl;

import com.danceframe.console.common.model.competition.Competition;
import com.danceframe.console.service.dataprovider.competition.CompetitionProviderDao;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.query.competition.CompetitionQuery;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public class CompetitionProviderDaoImpl extends GenericProviderDaoImpl<Competition> implements CompetitionProviderDao {

    @Override
    public int search(int id) {
        Object[] obj = new Object[] {id };
        int ret = (Integer)this.genericQryTemplateInteger(CompetitionQuery.SEARCHBYID_QRY, obj);
        return ret;
    }
    
    @Override
    public int search(String name) {
        Object[] obj = new Object[] {name };
        int ret = (Integer)this.genericQryTemplateInteger(CompetitionQuery.SEARCHBYNAME_QRY, obj);
        return ret;
    }


    @Override
    public int insert(Competition comp) {
        Object[] obj = new Object[] { comp.getName() };
        int ret = (Integer)this.genericQryTemplateInteger(CompetitionQuery.INSERT_QRY, obj);
        return ret;
    }

    @Override
    public int update(Competition comp) {
        Object[] obj = new Object[] {comp.getId(), comp.getName() };
        int ret = (Integer)this.genericQryTemplateInteger(CompetitionQuery.UPDATE_BYID_QRY, obj);
        return ret;
    }
     
    @Override
    public int delete(int id) {
        Object[] obj = new Object[] { id };
        int ret = (Integer)this.genericQryTemplateInteger(CompetitionQuery.DELETEBYID_QRY, obj);
        return ret;
    }

    @Override
    public int delete(String name) {
        Object[] obj = new Object[] { name };
        int ret = (Integer)this.genericQryTemplateInteger(CompetitionQuery.DELETEBYNAME_QRY, obj);
        return ret;
    }    

    @Override
    public Competition get(int id) {
        Object[] obj = new Object[] { id };
        String sqlWhere = " WHERE competition_id = ?"  ;
        String finalSQL =  CompetitionQuery.SELECT_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);        
    }

    @Override
    public Competition get(String name) {
        Object[] obj = new Object[] { name };
        String sqlWhere = " WHERE name = ?"  ;
        String finalSQL =  CompetitionQuery.SELECT_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);   
    }
    
    @Override
    public List<Competition> getAll(String wherestr) {  
        List<Competition> compList = new ArrayList<Competition>();
        compList = genericQryAllTemplateRowMapper(CompetitionQuery.SELECT_QRY, wherestr);
        return(compList);
    }

    @Override
    public List<Competition> getAllWithPaging(String wherestr, int pagesize, int first) { 
        List<Competition> compList = new ArrayList<Competition>();
        compList = genericQryAllTemplateRowMapperWithPaging(CompetitionQuery.SELECT_QRY, 
                wherestr,  pagesize,  first);
        return compList;
    }    

    @Override
    public long getAllCount(String wherestr) {
        return genericQryForInt(CompetitionQuery.SELECT_COUNT_QRY, wherestr);   
    }
}
