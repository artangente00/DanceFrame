/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.competition.config.impl;

import com.danceframe.console.common.model.competition.form.EventFormXML;
import com.danceframe.console.service.constant.PageType;
import com.danceframe.console.service.dataprovider.competition.config.EventFormXMLProviderDao;
import com.danceframe.console.service.dataprovider.impl.BaseJdbcDaoImpl;
import com.danceframe.console.service.query.competition.config.EventFormXMLQuery;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class EventFormXMLProviderDaoImpl extends BaseJdbcDaoImpl implements EventFormXMLProviderDao {

    private static final Logger logger = LogManager.getLogger(EventFormXMLProviderDaoImpl.class);
    private RowMapper rowMapper;
    
    @Override
    public int insertGenerate(int eventId, String path, String filename) {
        int id = getJdbcTemplate().queryForObject(EventFormXMLQuery.SELECT_XML_SEQ, Integer.class);
        return (insertData(id, eventId,  path,  filename, EventFormXMLQuery.INSERT_GENERATE_QRY, PageType.NEW));      
    }
    
     @Override
    public int insertManual(int eventId, String path, String filename) {
        int id = getJdbcTemplate().queryForObject(EventFormXMLQuery.SELECT_XML_SEQ, Integer.class);
        return (insertData(id, eventId,  path,  filename, EventFormXMLQuery.INSERT_MANUAL_QRY, PageType.NEW));   
    }
    
    @Override
    public int updateGenerate(int eventId, String path, String filename) {
        return (insertData(0, eventId,  path,  filename, EventFormXMLQuery.UPDATE_GENERATE_QRY, PageType.EDIT));      
    }
    
     @Override
    public int updateManual(int eventId, String path, String filename) {
        return (insertData(0, eventId,  path,  filename, EventFormXMLQuery.UPDATE_MANUAL_QRY, PageType.EDIT));   
    }
 
     @Override
    public int insertSTUManual(int eventId, String path, String basefilename) {
         int id = getJdbcTemplate().queryForObject(EventFormXMLQuery.SELECT_XML_SEQ, Integer.class);
         return insertSTUData( id,  eventId,  path,  basefilename, EventFormXMLQuery.INSERT_STU_MANUAL_QRY, PageType.NEW);
    }

    @Override
    public int updateSTUGenerate(int eventId, String path, String basefilename) {
        return insertSTUData( 0,  eventId,  path,  basefilename, EventFormXMLQuery.UPDATE_STU_MANUAL_QRY, PageType.EDIT);
    }

    private int insertData(int id, int eventId, String path, String filename, String query, int mode) {
        int retint = -99;
        File xmlfile = new File(path, filename + ".xml");
        File jsonfile = new File(path, filename + ".json");
        logger.info("==> (xml)basefilename:" + filename);
        if (!xmlfile.exists()) return -99;
        if (!jsonfile.exists()) return -99;
        try {
            InputStream inxmlstream = new FileInputStream(xmlfile);
            InputStream injsonstream = new FileInputStream(jsonfile);
            logger.info("==> (xml)executing query:" + query);
        getJdbcTemplate().update(new PreparedStatementCreator() {        
            @Override
            public PreparedStatement createPreparedStatement(Connection conn) throws SQLException {
                PreparedStatement ps = conn.prepareStatement(query);
                if (mode==PageType.NEW) {
                    ps.setInt(1, id);
                    ps.setInt(2, eventId);
                    ps.setBinaryStream(3, inxmlstream, xmlfile.length());   
                    ps.setBinaryStream(4, injsonstream, jsonfile.length());  
                }
                 if (mode==PageType.EDIT) {
                    ps.setInt(3, eventId);
                    ps.setBinaryStream(1, inxmlstream, xmlfile.length());   
                    ps.setBinaryStream(2, injsonstream, jsonfile.length());  
                }
                return ps;
                } 
            }
        );
            inxmlstream.close();
            injsonstream.close();
            retint = 100;
         } catch (IOException io) {
            io.printStackTrace();
         }
        return retint;
    }
    
    
    private int insertSTUData(int id, int eventId, String path, String basefilename, String query, int mode) {
        int retint = -99;
        File stufile = new File(path, basefilename + ".stu");
        File xmlallfile = new File(path, basefilename + "-all.xml");
        
        File xmlfile = new File(path, basefilename + "-ubc.xml");
        File jsonfile = new File(path, basefilename + ".json");
        logger.info("==> (xml)basefilename:" + basefilename);
        if (!xmlfile.exists()) return -99;
        if (!jsonfile.exists()) return -99;
        try {
            InputStream instustream = new FileInputStream(stufile);
            InputStream inxmlallstream = new FileInputStream(xmlallfile);
            InputStream inxmlstream = new FileInputStream(xmlfile);
            InputStream injsonstream = new FileInputStream(jsonfile);
            
            logger.info("==> (xml)executing query:" + query);
        getJdbcTemplate().update(new PreparedStatementCreator() {        
            @Override
            public PreparedStatement createPreparedStatement(Connection conn) throws SQLException {
                PreparedStatement ps = conn.prepareStatement(query);
                if (mode==PageType.NEW) {
                    ps.setInt(1, id);
                    ps.setInt(2, eventId);
                    ps.setBinaryStream(3, instustream, stufile.length());   
                    ps.setBinaryStream(4, inxmlallstream, xmlallfile.length());  
                    ps.setBinaryStream(5, inxmlstream, xmlfile.length());   
                    ps.setBinaryStream(6, injsonstream, jsonfile.length());  
                }
                 if (mode==PageType.EDIT) {
                    ps.setInt(5, eventId);
                    ps.setBinaryStream(1, instustream, stufile.length());   
                    ps.setBinaryStream(2, inxmlallstream, xmlallfile.length());  
                    ps.setBinaryStream(3, inxmlstream, xmlfile.length());   
                    ps.setBinaryStream(4, injsonstream, jsonfile.length());  
                }
                return ps;
                } 
            }
        );
            inxmlstream.close();
            injsonstream.close();
            retint = 100;
         } catch (IOException io) {
            io.printStackTrace();
         }
        return retint;
    }
    
    

    @Override
    public EventFormXML get(int eventId) {
        Object[] obj = new Object[] { eventId };
        String sqlWhere = " WHERE event_id = ?"  ;
        String finalSQL = EventFormXMLQuery.SELECT_XML_QRY + sqlWhere;
        return(EventFormXML) getJdbcTemplate().queryForObject(finalSQL, obj, rowMapper);
    }
    
    @Override
    public int setUseManual(int eventId, boolean usemanual) {
        Object[] obj = new Object[] { eventId , usemanual };
        return getJdbcTemplate().queryForObject(EventFormXMLQuery.USEMANUAL_QRY, obj, Integer.class);
    }
    
    /**
     * @return the rowMapper
     */
    public RowMapper getRowMapper() {
        return rowMapper;
    }

    /**
     * @param rowMapper the rowMapper to set
     */
    public void setRowMapper(RowMapper rowMapper) {
        this.rowMapper = rowMapper;
    }

   
    
    
}
