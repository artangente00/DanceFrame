/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.registration;

import com.danceframe.console.common.model.registration.RegStudio;
import com.danceframe.console.service.dataprovider.GenericProviderDao;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public interface RegStudioProviderDao extends GenericProviderDao<RegStudio>{
    
    RegStudio get(int studioId, String euid);
    
    RegStudio get(String suid, String euid);
    
    List<RegStudio> getStudiosByEventUID(String euid);
    
    RegStudio get(String buid, String euid, String suid);
    
    List<RegStudio> getStudiosByEvent(String buid, String euid);
    
}
