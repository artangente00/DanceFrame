/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.participant;

import com.danceframe.console.common.model.participant.Participant;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author nbonita
 */
public class ParticipantRowMapper implements RowMapper<Participant> {

    @Override
    public Participant mapRow(final ResultSet rs, final int column) throws SQLException {
        final Participant oneParticipant = new Participant();
        oneParticipant.setId(rs.getInt("participant_id"));
        oneParticipant.setParticipantPushId(rs.getString("participant_push_id"));
        oneParticipant.setUserPushId(rs.getString("user_push_id"));
        oneParticipant.setFirstName(rs.getString("first_name"));
        oneParticipant.setLastName(rs.getString("last_name"));
        oneParticipant.seteMail(rs.getString("email"));
        oneParticipant.setGender(rs.getString("gender"));
        oneParticipant.setBirthday(rs.getString("birthday"));
        oneParticipant.setCategory(rs.getString("category"));
        oneParticipant.setParticipantType(rs.getString("participant_type"));
        oneParticipant.setCoupleId(rs.getString("couple_id"));
        oneParticipant.setCoupleName(rs.getString("couple_name"));
        return oneParticipant;
    }
    
}
