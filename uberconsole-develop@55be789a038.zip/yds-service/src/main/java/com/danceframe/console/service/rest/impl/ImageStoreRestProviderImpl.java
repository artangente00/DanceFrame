/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rest.impl;

import com.danceframe.console.common.model.firebase.competition.ImageStore;
import com.danceframe.console.service.rest.ImageStoreRestProvider;

/**
 *
 * @author lmorallos
 */
public class ImageStoreRestProviderImpl extends GenericRestProviderImpl<ImageStore> implements ImageStoreRestProvider {

    private String uberSyncURL = "http://localhost:8080/uberSync/EventImages?op=add&id=";
     
    @Override
    public boolean addImageToFirebase(int imgId) {
        boolean retbool = false;
        String finURL = uberSyncURL + Integer.toString(imgId);
        
        ImageStore imgStore = this.get(finURL);
        retbool = imgStore.isResult();
        return retbool;
    }
    
}
