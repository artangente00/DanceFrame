/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.file.xml;

import com.danceframe.console.common.exception.YDSException;
import com.danceframe.console.common.model.heatlist.result.HeatResultPersonProgram;
import com.danceframe.console.common.model.heatlist.result.HeatlistResultXML;

/**
 *
 * @author lmorallos
 */
public interface HeatListResultXMLWriter {
    
     HeatResultPersonProgram composeHeatlistResult(String uid) throws YDSException;
     
     HeatResultPersonProgram composeHeatlistResult(int masterPersonId) throws YDSException;
     
     HeatlistResultXML databaseToXML(String tmpLocation, String uid) throws YDSException;
     
     HeatlistResultXML databaseToXML(String tmpLocation, int masterPersonId) throws YDSException;
    
}
