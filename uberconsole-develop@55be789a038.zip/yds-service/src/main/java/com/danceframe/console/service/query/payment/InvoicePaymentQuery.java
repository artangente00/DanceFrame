/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query.payment;

/**
 *
 * @author lmorallos
 */
public final class InvoicePaymentQuery {
    
    public static final String SELECT_INVPAYMENT = "SELECT * FROM uberconsole.tbl_invpayment";
    
    public static final String SELECT_INVPAYMENT_DETAIL = "SELECT * FROM uberconsole.tbl_invpayment_detail";
    
    public static final String INSERT_INVPAYMENT = "SELECT uberconsole.FN_INVPAYMENT_INSERT(?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    public static final String UPDATE_INVPAYMENT = "SELECT uberconsole.FN_INVPAYMENT_UPDATE(?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    public static final String INSERT_INVPAYMENT_DETAIL = "SELECT uberconsole.FN_INVPAYMENT_DETAIL_INSERT(?, ?, ?, ?, ?, ?)";
    
    public static final String COUNT_INVPAYMENT_COUNT = "SELECT count(invpayment_id) FROM uberconsole.tbl_invpayment";
    
    public static final String COUNT_INVPAYMENT_DETAIL = "SELECT count(invpaydetail_id) FROM uberconsole.tbl_invpayment_detail";
    
    public static final String UPDATE_SENDMAIL = "SELECT uberconsole.FN_INVPAYMENT_SENDMAIL(?, ?, ?)";
     
     
}
