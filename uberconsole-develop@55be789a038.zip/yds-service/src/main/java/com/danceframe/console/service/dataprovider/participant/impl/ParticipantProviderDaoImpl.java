/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.participant.impl;


import com.danceframe.console.common.model.participant.Participant;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.dataprovider.participant.ParticipantProviderDao;
import com.danceframe.console.service.query.participant.ParticipantQuery;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author nbonita
 */
public class ParticipantProviderDaoImpl extends GenericProviderDaoImpl<Participant> implements ParticipantProviderDao {

    @Override
    public int search(int id) {
        Object[] obj = new Object[] {id };
        int ret = (Integer)this.genericQryTemplateInteger(ParticipantQuery.SEARCH_BYID_QRY, obj);
        return ret;
    }

    @Override
    public int search(String participantPushId) {
        Object[] obj = new Object[] {participantPushId };
        int ret = (Integer)this.genericQryTemplateInteger(ParticipantQuery.SEARCH_BYPUSHID_QRY, obj);
        return ret;
    }

    @Override
    public int insert(Participant oneParticipant) {
        Object[] obj = new Object[] {
            oneParticipant.getParticipantPushId(),
            oneParticipant.getUserPushId(),
            oneParticipant.getFirstName(),
            oneParticipant.getLastName(),
            oneParticipant.geteMail(),
            oneParticipant.getGender(),
            oneParticipant.getBirthday(),
            oneParticipant.getCategory(),
            oneParticipant.getParticipantType(),
            oneParticipant.getCoupleId(),
            oneParticipant.getCoupleName()
            };
         int ret = (Integer)this.genericQryTemplateInteger(ParticipantQuery.INSERT_QRY, obj);
        return ret;
    }

    @Override
    public int update(Participant oneParticipant) {
        Object[] obj = new Object[] {
            oneParticipant.getId(),
            oneParticipant.getParticipantPushId(),
            oneParticipant.getUserPushId(),
            oneParticipant.getFirstName(),
            oneParticipant.getLastName(),
            oneParticipant.geteMail(),
            oneParticipant.getGender(),
            oneParticipant.getBirthday(),
            oneParticipant.getCategory(),
            oneParticipant.getParticipantType(),
            oneParticipant.getCoupleId(),
            oneParticipant.getCoupleName()
            };
        int ret = (Integer)this.genericQryTemplateInteger(ParticipantQuery.UPDATE_QRY, obj);
        return ret;    }

    @Override
    public int delete(int id) {
        Object[] obj = new Object[] { id };
        int ret = (Integer)this.genericQryTemplateInteger(ParticipantQuery.DELETE_QRY, obj);
        return ret;
    }
    
    

    @Override
    public int delete(String name) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Participant get(int id) {
        Object[] obj = new Object[] { id };
        String sqlWhere = " WHERE participant_id = ?"  ;
        String finalSQL = ParticipantQuery.SELECT_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj); 
    }

    @Override
    public Participant get(String participantPushId) {
        Object[] obj = new Object[] { participantPushId };
        String sqlWhere = " WHERE UPPER(participant_push_id) = UPPER(?)"  ;
        String finalSQL = ParticipantQuery.SELECT_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj); 
    }

    @Override
    public List<Participant> getAll(String wherestr) {
        List<Participant> participantList = new ArrayList<Participant>();
        participantList = genericQryAllTemplateRowMapper(ParticipantQuery.SELECT_QRY, wherestr); 
        return(participantList);
    }

    @Override
    public List<Participant> getAllWithPaging(String wherestr, int pagesize, int first) {
        List<Participant> participantList = new ArrayList<Participant>();
        participantList = genericQryAllTemplateRowMapperWithPaging(ParticipantQuery.SELECT_QRY, wherestr,  pagesize,  first);
        return(participantList);
    }

    @Override
    public long getAllCount(String wherestr) {
         return genericQryForInt(ParticipantQuery.SELECT_COUNT_QRY, wherestr);  
    }

   
    
}
