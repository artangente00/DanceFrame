/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.critique;

import com.danceframe.console.common.model.critique.xml.HeatResultSubHeat;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class CritiqueSubHeatRowMapper implements RowMapper<HeatResultSubHeat>{

    @Override
    public HeatResultSubHeat mapRow(ResultSet rs, int i) throws SQLException {
        final HeatResultSubHeat subheat = new HeatResultSubHeat();
        subheat.setSubheatId(rs.getInt("subheat_id"));
        subheat.setId(rs.getString("subheat_key"));
        subheat.setType(rs.getString("subheat_type"));
        subheat.setDance(rs.getString("subheat_dance"));
        subheat.setLevel(rs.getString("subheat_level"));
        subheat.setAge(rs.getString("subheat_age"));
        subheat.setHeatId(rs.getInt("heat_id"));
        return subheat;
    }
    
}
