/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query;

/**
 *
 * @author lmorallos
 */
public final class AccountTypeQuery {
    
    public static final String INSERT_QRY = "SELECT uberconsole.FN_ACCTTYPE_INSERT( ? )";
    
    public static final String UPDATE_QRY = "SELECT uberconsole.FN_ACCTTYPE_UPDATE(?, ?)";
     
    public static final String UPDATE_BYDESC_QRY = "SELECT uberconsole.FN_ACCTTYPE_UPDATE_BYDESC(? , ?)";
      
    public static final String DELETE_QRY = "SELECT uberconsole.FN_ACCTTYPE_DELETE(?)";
    
    public static final String SELECT_QRY = "SELECT acctype_id,acctype_desc FROM uberconsole.tbl_acctype";
    
    public static final String GET_ACCOUNTTYPE_QRY = "SELECT uberconsole.FN_ACCTTYPE_GETINFO(?)";
    
}
