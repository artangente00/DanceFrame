/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.competition.config;

import com.danceframe.console.common.model.competition.config.Dance;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class DanceRowMapper implements RowMapper<Dance> {

    @Override
    public Dance mapRow(ResultSet rs, int column) throws SQLException {
        final Dance dance = new Dance();
        dance.setId(rs.getInt("dance_id"));
        dance.setName(rs.getString("name"));
        dance.setCode(rs.getString("code"));
        return dance;    
    }
    
}
