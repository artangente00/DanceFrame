/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.uam;

import com.danceframe.console.common.model.uam.Syslog;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public interface SyslogProviderDao {
    
    int insert(Syslog syslog);
    
    int updateSyslogId(String tblname, int syslogid, String idvar, int id);
    
    List<Syslog> getAll(String wherestr);
    
    List<Syslog> getAllWithPaging(String wherestr, int pagesize, int pagenumber );  
    
    long getAllCount(String wherestr);
    
}
