/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider;

import java.sql.Connection;
import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;


/**
 *
 * @author lmorallos
 */
public interface BasicDao {
    
    DataSource getDBdataSource();
    
    Connection  getDBConnection();
    
    JdbcTemplate getDBJdbcTemplate();
}
