/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.uam;

import com.danceframe.console.common.model.uam.User;
import com.danceframe.console.service.dataprovider.GenericProviderDao;

/**
 *
 * @author lmorallos
 */
public interface UserProviderDao extends GenericProviderDao<User>{
   
    int setDisabled(boolean disabled);
    
    int delete(int id, int sysuid);
}
