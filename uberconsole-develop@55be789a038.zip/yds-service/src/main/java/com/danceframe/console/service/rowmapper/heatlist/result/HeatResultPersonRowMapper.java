/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.heatlist.result;

import com.danceframe.console.common.model.heatlist.result.HeatResultPerson;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class HeatResultPersonRowMapper implements RowMapper<HeatResultPerson> {

    @Override
    public HeatResultPerson mapRow(ResultSet rs, int i) throws SQLException {
        final HeatResultPerson person = new HeatResultPerson();
        person.setId(rs.getInt("person_id"));
        person.setPersonKey(rs.getString("person_key"));
        person.setFirstName(rs.getString("firstname"));
        person.setLastName(rs.getString("lastname"));
        person.setGender(rs.getString("gender"));
        person.setStudioKey(rs.getString("studio_key"));
//        person.setNickName(rs.getString("nickname"));
//        person.setNdcaUsabdaNumber(rs.getString("ndcaus_num"));
        person.setCompetitorNumber(rs.getString("competitor_num"));
        person.setMasterperson_id(rs.getInt("masterperson_id"));
        person.setEventId(rs.getInt("event_id"));
        person.setXmlId(rs.getInt("xml_id"));
        person.setUnified(rs.getBoolean("unified"));
        person.setNewMasterperson_id(rs.getInt("old_masterperson_id"));
        return person;
    }
    
}
