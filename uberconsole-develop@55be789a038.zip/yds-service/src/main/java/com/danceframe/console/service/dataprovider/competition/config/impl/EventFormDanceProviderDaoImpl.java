/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.competition.config.impl;

import com.danceframe.console.common.model.competition.form.EventFormDance;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.query.competition.config.EventFormDanceQuery;
import java.util.ArrayList;
import java.util.List;
import com.danceframe.console.service.dataprovider.competition.config.EventFormDanceProviderDao;

/**
 *
 * @author lmorallos
 */
public class EventFormDanceProviderDaoImpl extends GenericProviderDaoImpl<EventFormDance> implements EventFormDanceProviderDao {

    @Override
    public int insert(EventFormDance formdance) {
         Object[] obj = new Object[] {
            formdance.getHorizContentId(),
            formdance.getEventformId(),
            formdance.getCode(),
            formdance.getDescription()
            };
        int ret = (Integer)this.genericQryTemplateInteger(EventFormDanceQuery.INSERT_QRY, obj);
        return ret;
    }
    
    @Override
    public List<EventFormDance> getAll(String wherestr) {
        List<EventFormDance> evendanceList = new ArrayList<EventFormDance>();
        evendanceList = genericQryAllTemplateRowMapper(EventFormDanceQuery.SELECT_QRY, wherestr); 
        return(evendanceList);
     }

    @Override
    public List<EventFormDance> getAllWithPaging(String wherestr, int pagesize, int first) {
        List<EventFormDance> evendanceList = new ArrayList<EventFormDance>();
        evendanceList = genericQryAllTemplateRowMapperWithPaging(EventFormDanceQuery.SELECT_QRY, wherestr, pagesize, first); 
        return(evendanceList);
    }

    @Override
    public int deleteDance(int hcontent, int eventformid, String code) {
        Object[] obj = new Object[] { hcontent, eventformid, code };
        int ret = (Integer)this.genericQryTemplateInteger(EventFormDanceQuery.DELETE_QRY, obj);
        return ret;
    }
    
    @Override
    public int delete(int id) {
        Object[] obj = new Object[] { id };
        int ret = (Integer)this.genericQryTemplateInteger(EventFormDanceQuery.DELETEBYID_QRY, obj);
        return ret;
    }
    
    @Override
    public long getAllCount(String wherestr) {
       return genericQryForInt(EventFormDanceQuery.SELECT_COUNT_QRY, wherestr);  
    }
    
    @Override
    public int search(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int search(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int update(EventFormDance t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


    @Override
    public int delete(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public EventFormDance get(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public EventFormDance get(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
