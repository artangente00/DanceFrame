/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.file.critique.impl;

import com.danceframe.console.common.exception.YDSException;
import com.danceframe.console.common.model.critique.xml.HeatResultCouple;
import com.danceframe.console.common.model.critique.xml.HeatResultCoupleEntry;
import com.danceframe.console.common.model.critique.xml.HeatResultHeat;
import com.danceframe.console.common.model.critique.xml.HeatResultJudge;
import com.danceframe.console.common.model.critique.xml.HeatResultMark;
import com.danceframe.console.common.model.critique.xml.HeatResultPerson;
import com.danceframe.console.common.model.critique.xml.HeatResultProgram;
import com.danceframe.console.common.model.critique.xml.HeatResultResult;
import com.danceframe.console.common.model.critique.xml.HeatResultSoloEntry;
import com.danceframe.console.common.model.critique.xml.HeatResultStudio;
import com.danceframe.console.common.model.critique.xml.HeatResultSubHeat;
import com.danceframe.console.common.model.critique.xml.HeatlistResultXML;
import com.danceframe.console.service.dataprovider.critique.CritiqueProviderDao;
import com.danceframe.console.service.dataprovider.impl.BaseJdbcDaoImpl;
import com.danceframe.console.service.file.critique.CritiqueXMLReader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.simpleframework.xml.Serializer;
import org.simpleframework.xml.core.Persister;

/**
 *
 * @author lmorallos
 */
public class CritiqueXMLReaderImpl extends BaseJdbcDaoImpl implements CritiqueXMLReader {

    private static final Logger logger = LogManager.getLogger(CritiqueXMLReaderImpl.class);
    private CritiqueProviderDao critiqueProviderDao;
    
    @Override
    public HeatResultProgram xmlToProgramObject(HeatlistResultXML resultXML) throws YDSException{
        HeatResultProgram program = null;
        if (resultXML.getData().length > 0) {
            program = new HeatResultProgram();
            try {
                Serializer serializer = new Persister();
                program = serializer.read(HeatResultProgram.class,
                        resultXML.getByteAsInputStream());

                int eventId = resultXML.getEventId();
                int xmlId = resultXML.getId();
                program.setEventId(eventId);
                program.setXmlId(xmlId);
                
                if (program.getStudios() != null) {
                    for (int i = 0; i < program.getStudios().size(); i++) {
                        program.getStudios().get(i).setEventId(eventId);
                        program.getStudios().get(i).setXmlId(xmlId);
//                        System.out.println(program.getJudges().get(i).toString());
                    }
                }
                if (program.getJudges() != null) {
                    for (int i = 0; i < program.getJudges().size(); i++) {
                        program.getJudges().get(i).setEventId(eventId);
                        program.getJudges().get(i).setXmlId(xmlId);
//                        System.out.println(program.getJudges().get(i).toString());
                    }
                }
                
                if (program.getPersons() != null) {
                    for (int i = 0; i < program.getPersons().size(); i++) {
                        program.getPersons().get(i).setEventId(eventId);
                        program.getPersons().get(i).setXmlId(xmlId);
//                        System.out.println(program.getPersons().get(i).toString());
                    }
                }
                
                if (program.getCouples() != null) {
                    for (int i = 0; i < program.getCouples().size(); i++) {
                        program.getCouples().get(i).setEventId(eventId);
                        program.getCouples().get(i).setXmlId(xmlId);
//                        System.out.println(program.getCouples().get(i).toString());
                    }
                }
                if (program.getHeats() != null) {
                    for (int i = 0; i < program.getHeats().size(); i++) {
                        program.getHeats().get(i).setEventId(eventId);
                        program.getHeats().get(i).setXmlId(xmlId);
//                        System.out.println(program.getHeats().get(i).toString());
                    }
                  }
            } catch (Exception ex) {
                logger.warn(ex.getMessage());
                throw new YDSException(ex);
            }
        }
        return program;
    }

    @Override
    public boolean objectToDatabase(HeatResultProgram program) throws YDSException {
        boolean retbool = true;
        int eventId = program.getEventId();
        try {
            boolean cleared = (critiqueProviderDao.clearByEventId(eventId) < 0)?true:false;
            int i = 0;
            if (cleared) {
                critiqueProviderDao.insertProgram(program);
                if (program.getStudios() != null) {
                    i = 0;
                    for (HeatResultStudio studio:program.getStudios()) {
                        critiqueProviderDao.insertStudio(studio);
                        i++;
                    }
                    logger.info("Studios: event Id:" + eventId + " record inserted:"  + i);
                }
                if (program.getJudges() != null) {
                    i = 0;
                    for (HeatResultJudge judge:program.getJudges()) {
                        critiqueProviderDao.insertJudge(judge);
                        i++;
                    }
                    logger.info("Judges: event Id:" + eventId + " record inserted:"  + i);
                }
                if (program.getPersons() != null) {
                    i = 0;
                    for (HeatResultPerson person:program.getPersons()) {
                        critiqueProviderDao.insertPerson(person);
                        i++;
                    }
                    logger.info("Persons: event Id:" + eventId + " record inserted:"  + i);
                }
                if (program.getCouples() != null) {
                    i = 0;
                    for (HeatResultCouple couple:program.getCouples()) {
                        critiqueProviderDao.insertCouple(couple);
                        i++;
                    }
                    logger.info("Couples: event Id:" + eventId + " record inserted:"  + i);
                }
                if (program.getHeats() != null) {
                    i = 0;
                    for (HeatResultHeat heat:program.getHeats()) {
                        int heatId = critiqueProviderDao.insertHeat(heat);  
                        i++;                    
                        if (heat.getSubHeats() != null) {
                            for (HeatResultSubHeat subheat:heat.getSubHeats()) {
                                subheat.setEventId(eventId);
                                subheat.setHeatId(heatId);
                                int subHeatId = critiqueProviderDao.insertSubHeat(subheat);
                                if (subheat.getCoupleEntries() != null) {
                                    for (HeatResultCoupleEntry entry:subheat.getCoupleEntries()) {   
                                        entry.setEventId(eventId);
                                        entry.setSubHeatId(subHeatId);
                                        critiqueProviderDao.insertEntry(entry);
                                    }
                                }
                                if (subheat.getSoloEntries() != null) {
                                    for (HeatResultSoloEntry entry:subheat.getSoloEntries()) {   
                                        entry.setEventId(eventId);
                                        entry.setSubHeatId(subHeatId);
                                        critiqueProviderDao.insertSoloEntry(entry);
                                        
                                    }
                                }
                                HeatResultResult result = subheat.getResult();
                                if (result != null) {
                                   result.setSubHeatId(subHeatId);
                                   result.setEventId(eventId);
                                   int resultId = critiqueProviderDao.insertResult(result);
                                   if (result.getMarks() != null)  {
                                       for (HeatResultMark mark:result.getMarks()) {
                                           mark.setResultId(resultId);
                                           mark.setSubHeatId(subHeatId);
                                           mark.setEventId(eventId);
                                           critiqueProviderDao.insertMark(mark);
                                       }
                                   }                               
                                }

                            }
                        }              
                    }
                    logger.info("Heats: event Id:" + eventId + " record inserted:"  + i);
                 }
            }
        } catch (Exception ex) {
            retbool = false;
            logger.warn(ex.getMessage());
            throw new YDSException(ex);
        }
        return retbool;
    }

    /**
     * @return the critiqueProviderDao
     */
    public CritiqueProviderDao getCritiqueProviderDao() {
        return critiqueProviderDao;
    }

    /**
     * @param critiqueProviderDao the critiqueProviderDao to set
     */
    public void setCritiqueProviderDao(CritiqueProviderDao critiqueProviderDao) {
        this.critiqueProviderDao = critiqueProviderDao;
    }
    
}
