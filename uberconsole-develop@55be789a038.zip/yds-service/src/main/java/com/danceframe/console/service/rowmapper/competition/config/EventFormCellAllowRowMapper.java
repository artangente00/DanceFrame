/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.competition.config;

import com.danceframe.console.common.model.competition.form.EventFormCellAllow;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class EventFormCellAllowRowMapper implements RowMapper<EventFormCellAllow> {

    @Override
    public EventFormCellAllow mapRow(ResultSet rs, int column) throws SQLException {
        EventFormCellAllow eventcell = new EventFormCellAllow();
        eventcell.setId(rs.getInt("eventallow_id"));
        eventcell.setEventFormId(rs.getInt("eventform_id"));
        eventcell.setEventVertitcalId(rs.getInt("eventvertical_id"));
        eventcell.setEventDanceId(rs.getInt("eventdance_id"));
        eventcell.setVertCode(rs.getString("verticalcode"));
        eventcell.setVertDescription(rs.getString("verticaldesc"));
        eventcell.setDanceCode(rs.getString("dancecode"));
        eventcell.setDanceDescription(rs.getString("dancedesc"));
        return eventcell;
    }
    
}
