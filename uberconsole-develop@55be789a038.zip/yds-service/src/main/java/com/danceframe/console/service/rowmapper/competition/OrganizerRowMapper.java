/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.competition;

import com.danceframe.console.common.model.competition.Organizer;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class OrganizerRowMapper implements RowMapper<Organizer>{

    @Override
    public Organizer mapRow(final ResultSet rs, final int column) throws SQLException {
        final Organizer organizer = new Organizer();        
        organizer.setId(rs.getInt("organizer_id"));        
        organizer.setName(rs.getString("name"));
        organizer.setEventid(rs.getInt("event_id"));        
        return organizer;                
    }
    
}
