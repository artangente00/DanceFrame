/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.critique.impl;

import com.danceframe.console.common.model.critique.xml.HeatResultCouple;
import com.danceframe.console.common.model.critique.xml.HeatResultCoupleEntry;
import com.danceframe.console.common.model.critique.xml.HeatResultHeat;
import com.danceframe.console.common.model.critique.xml.HeatResultJudge;
import com.danceframe.console.common.model.critique.xml.HeatResultMark;
import com.danceframe.console.common.model.critique.xml.HeatResultPerson;
import com.danceframe.console.common.model.critique.xml.HeatResultProgram;
import com.danceframe.console.common.model.critique.xml.HeatResultResult;
import com.danceframe.console.common.model.critique.xml.HeatResultSoloEntry;
import com.danceframe.console.common.model.critique.xml.HeatResultStudio;
import com.danceframe.console.common.model.critique.xml.HeatResultSubHeat;
import com.danceframe.console.common.util.Utility;
import com.danceframe.console.service.dataprovider.critique.CritiqueProviderDao;
import com.danceframe.console.service.dataprovider.impl.BaseJdbcDaoImpl;
import com.danceframe.console.service.query.critique.CritiqueQuery;
import com.danceframe.console.service.rowmapper.critique.CritiqueCoupleEntryRowMapper;
import com.danceframe.console.service.rowmapper.critique.CritiqueCoupleRowMapper;
import com.danceframe.console.service.rowmapper.critique.CritiqueHeatRowMapper;
import com.danceframe.console.service.rowmapper.critique.CritiqueJudgeRowMapper;
import com.danceframe.console.service.rowmapper.critique.CritiqueMarkRowMapper;
import com.danceframe.console.service.rowmapper.critique.CritiquePersonRowMapper;
import com.danceframe.console.service.rowmapper.critique.CritiqueResultRowMapper;
import com.danceframe.console.service.rowmapper.critique.CritiqueSoloEntryRowMapper;
import com.danceframe.console.service.rowmapper.critique.CritiqueStudioRowMapper;
import com.danceframe.console.service.rowmapper.critique.CritiqueSubHeatRowMapper;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 *
 * @author lmorallos
 */
public class CritiqueProviderDaoImpl extends BaseJdbcDaoImpl implements CritiqueProviderDao {

    private static final Logger logger = LogManager.getLogger(CritiqueProviderDaoImpl.class);
    
    private CritiqueJudgeRowMapper critiqueJudgeRowMapper;
    private CritiqueResultRowMapper critiqueResultRowMapper;
    private CritiqueCoupleRowMapper critiqueCoupleRowMapper;
    private CritiqueMarkRowMapper critiqueMarkRowMapper;
    private CritiqueStudioRowMapper critiqueStudioRowMapper;
    private CritiqueHeatRowMapper critiqueHeatRowMapper;
    private CritiquePersonRowMapper critiquePersonRowMapper; 
    private CritiqueSubHeatRowMapper critiqueSubHeatRowMapper;
    private CritiqueCoupleEntryRowMapper critiqueCoupleEntryRowMapper; 
    private CritiqueSoloEntryRowMapper critiqueSoloEntryRowMapper; 

    @Override
    public int clearByEventId(int eventId) {
        Object[] obj = new Object[] {  eventId  };
        logger.info(CritiqueQuery.EVENT_CLEAR_QRY);
        int iret = (Integer)getJdbcTemplate().queryForObject(CritiqueQuery.EVENT_CLEAR_QRY, 
                   obj, Integer.class);
        return iret;
    }

    @Override
    public int insertProgram(HeatResultProgram program) {
        boolean istudio	= (program.getStudios()!=null)?true:false;
	boolean ijudge	= (program.getJudges()!=null)?true:false;
	boolean iperson = (program.getPersons()!=null)?true:false;
	boolean iheat	= (program.getHeats()!=null)?true:false;
        Object[] obj = new Object[] {  
             istudio, ijudge , iperson, iheat,
             program.getEventId(),
             program.getXmlId()
         };
        logger.info(CritiqueQuery.PROGRAM_INSERT_QRY);
        int iret = (Integer)getJdbcTemplate().queryForObject(CritiqueQuery.PROGRAM_INSERT_QRY, 
                   obj, Integer.class);
        return iret;
    }
    
    @Override
    public int insertStudio(HeatResultStudio studio) {
         Object[] obj = new Object[] {  
             studio.getStudioKey(),
             studio.getName(),
             studio.getIndependentInvoice(),
             studio.getEventId(),
             studio.getXmlId()
         };
        //logger.info(CritiqueQuery.STUDIO_INSERT_QRY);
        int iret = (Integer)getJdbcTemplate().queryForObject(CritiqueQuery.STUDIO_INSERT_QRY, 
                   obj, Integer.class);
        return iret;
    }

    @Override
    public int insertPerson(HeatResultPerson person) {
         Object[] obj = new Object[] {  
             person.getPersonKey(),
             Utility.null2Str(person.getFirstName()),
             Utility.null2Str(person.getLastName()),
             person.getGender(),
             person.getPersonType(),
             person.getStudioKey(),
             person.getNickName(),
             person.getNdcaUsabdaNumber(),
             person.getCompetitorNumber(),
             person.getEventId(),
             person.getXmlId()
         };
        //logger.info(CritiqueQuery.PERSON_INSERT_QRY);
        int iret = (Integer)getJdbcTemplate().queryForObject(CritiqueQuery.PERSON_INSERT_QRY, 
                   obj, Integer.class);
        return iret;
    }

    @Override
    public int insertJudge(HeatResultJudge judge) {
         Object[] obj = new Object[] {  
             judge.getJudgeKey(),
             Utility.null2Str(judge.getFirstName()),
             Utility.null2Str(judge.getLastName()),
             judge.getJudgeNumber(),
             judge.getEventId(),
             judge.getXmlId()
         };
        //logger.info(CritiqueQuery.JUDGE_INSERT_QRY);
        int iret = (Integer)getJdbcTemplate().queryForObject(CritiqueQuery.JUDGE_INSERT_QRY, 
                   obj, Integer.class);
        return iret;
    }

    @Override
    public int insertCouple(HeatResultCouple couple) {
         Object[] obj = new Object[] {  
             couple.getCoupleKey(),
             couple.getPersonKeys().get(0).getPersonKey(),
             couple.getPersonKeys().get(1).getPersonKey(),
             couple.getEventId(),
             couple.getXmlId()
         };
        //logger.info(CritiqueQuery.COUPLES_INSERT_QRY);
        int iret = (Integer)getJdbcTemplate().queryForObject(CritiqueQuery.COUPLES_INSERT_QRY, 
                   obj, Integer.class);
        return iret;
    }

    @Override
    public int coupleSearch(int coupleId, int eventId) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int insertHeat(HeatResultHeat heat) {
        Object[] obj = new Object[] {  
            heat.getName(),
            heat.getSession(),
            heat.getTime(),
            heat.getDate(),
            heat.getDesc(),
            heat.getType(),
            heat.getEventId(),
            heat.getXmlId()
         };
        int iret = (Integer)getJdbcTemplate().queryForObject(CritiqueQuery.HEATS_INSERT_QRY, 
                   obj, Integer.class);
        return iret;
    }

    @Override
    public int insertSubHeat(HeatResultSubHeat subheat) {
        Object[] obj = new Object[] {  
             subheat.getId(),
             subheat.getType(),
             subheat.getDance(),
             subheat.getLevel(),
             subheat.getAge(),
             subheat.getHeatId(),
             subheat.getEventId()
         };
        int iret = (Integer)getJdbcTemplate().queryForObject(CritiqueQuery.SUBHEATS_INSERT_QRY, 
                   obj, Integer.class);
        return iret;
    }

    @Override
    public int insertEntry(HeatResultCoupleEntry entry) {
        Object[] obj = new Object[] {  
             entry.getCoupleKey(),
             entry.getSubHeatId(),
             entry.getEventId()
         };
        int iret = (Integer)getJdbcTemplate().queryForObject(CritiqueQuery.ENTRIES_INSERT_QRY, 
                   obj, Integer.class);
        return iret;
    }
    
    
    @Override
    public int insertSoloEntry(HeatResultSoloEntry solo) {
         Object[] obj = new Object[] {  
            solo.getPersonKey(),
            solo.getSubHeatId(),
            solo.getEventId() 
         };
        int iret = (Integer)getJdbcTemplate().queryForObject(CritiqueQuery.SOLO_INSERT_QRY, 
                   obj, Integer.class);
        return iret;
    }

    @Override
    public int insertResult(HeatResultResult result) {
        Object[] obj = new Object[] {  
            result.getJudgingPanel(),
            result.getScoreHeaders(),
            result.getSubHeatId(),
            result.getEventId()
         };
        int iret = (Integer)getJdbcTemplate().queryForObject(CritiqueQuery.RESULT_INSERT_QRY, 
                   obj, Integer.class);
        return iret;
    }

    
    @Override
    public int insertMark(HeatResultMark mark) {
          Object[] obj = new Object[] {  
            mark.getCoupleKey(),
            mark.getCoupleValue(),
            mark.getResultId(),
            mark.getSubHeatId(),
            mark.getEventId()
         };
        int iret = (Integer)getJdbcTemplate().queryForObject(CritiqueQuery.MARKS_INSERT_QRY, 
                   obj, Integer.class);
        return iret;
    }

    @Override
    public List<HeatResultStudio> getStudios(int eventId) {
        Object[] obj = new Object[] {eventId };
        String sql = CritiqueQuery.SELECT_STUDIO_QRY + " WHERE event_id=?";
        logger.info(sql);
        return (List<HeatResultStudio>)getJdbcTemplate().query(sql, obj, critiqueStudioRowMapper);
    }

    @Override
    public List<HeatResultJudge> getJudges(int eventId) {
        Object[] obj = new Object[] {eventId };
        String sql = CritiqueQuery.SELECT_JUDGE_QRY + " WHERE event_id=?";
        logger.info(sql);
        return (List<HeatResultJudge>)getJdbcTemplate().query(sql, obj, critiqueJudgeRowMapper);
    }

    @Override
    public List<HeatResultPerson> getPersons(int eventId) {
         Object[] obj = new Object[] {eventId };
        String sql = CritiqueQuery.SELECT_PERSON_QRY + " WHERE event_id=?";
        logger.info(sql);
        return (List<HeatResultPerson>)getJdbcTemplate().query(sql, obj, critiquePersonRowMapper);
    }

    @Override
    public List<HeatResultCouple> getCouples(int eventId) {
        Object[] obj = new Object[] {eventId };
        String sql = CritiqueQuery.SELECT_COUPLE_QRY + " WHERE event_id=?";
        logger.info(sql);
        return (List<HeatResultCouple>)getJdbcTemplate().query(sql, obj, critiqueCoupleRowMapper);
    }
    
    @Override
    public List<HeatResultHeat> getHeats(int eventId) {
         Object[] obj = new Object[] {eventId };
        String sql = CritiqueQuery.SELECT_HEAT_QRY + " WHERE event_id=?";
        logger.info(sql);
        return (List<HeatResultHeat>)getJdbcTemplate().query(sql, obj, critiqueHeatRowMapper);
    }

    @Override
    public List<HeatResultSubHeat> getSubHeats(int eventId, int heatId) {
        Object[] obj = new Object[] {eventId };
        String sql = CritiqueQuery.SELECT_SUBHEAT_QRY + " WHERE event_id=? and heat_id=?";
        logger.info(sql);
        return (List<HeatResultSubHeat>)getJdbcTemplate().query(sql, obj, critiqueSubHeatRowMapper);
    }


    @Override
    public List<HeatResultCoupleEntry> getEntries(int eventId, int subHeatId) {
         Object[] obj = new Object[] {eventId };
        String sql = CritiqueQuery.SELECT_ENTRIES_QRY + " WHERE event_id=? and subheat_id=?";
        logger.info(sql);
        return (List<HeatResultCoupleEntry>)getJdbcTemplate().query(sql, obj, critiqueCoupleEntryRowMapper);
    }

    @Override
    public List<HeatResultSoloEntry> getSoloEntries(int eventId, int subHeatId) {
        Object[] obj = new Object[] {eventId };
        String sql = CritiqueQuery.SELECT_SOLO_QRY + " WHERE event_id=? and subheat_id=?";
        logger.info(sql);
        return (List<HeatResultSoloEntry>)getJdbcTemplate().query(sql, obj, critiqueSoloEntryRowMapper);
    }

    @Override
    public List<HeatResultResult> getResult(int eventId, int subHeatId) {
         Object[] obj = new Object[] {eventId };
        String sql = CritiqueQuery.SELECT_RESULT_QRY + " WHERE event_id=? and subheat_id=?";
        logger.info(sql);
        return (List<HeatResultResult>)getJdbcTemplate().query(sql, obj, critiqueResultRowMapper);
    }

    @Override
    public List<HeatResultMark> getMarks(int eventId, int subHeatId, int resultId) {
        Object[] obj = new Object[] {eventId };
        String sql = CritiqueQuery.SELECT_MARK_QRY + " WHERE event_id=? and subheat_id=? and result_id=?";
        logger.info(sql);
        return (List<HeatResultMark>)getJdbcTemplate().query(sql, obj, critiqueMarkRowMapper);
    }

    /**
     * @return the critiqueJudgeRowMapper
     */
    public CritiqueJudgeRowMapper getCritiqueJudgeRowMapper() {
        return critiqueJudgeRowMapper;
    }

    /**
     * @param critiqueJudgeRowMapper the critiqueJudgeRowMapper to set
     */
    public void setCritiqueJudgeRowMapper(CritiqueJudgeRowMapper critiqueJudgeRowMapper) {
        this.critiqueJudgeRowMapper = critiqueJudgeRowMapper;
    }

    /**
     * @return the critiqueResultRowMapper
     */
    public CritiqueResultRowMapper getCritiqueResultRowMapper() {
        return critiqueResultRowMapper;
    }

    /**
     * @param critiqueResultRowMapper the critiqueResultRowMapper to set
     */
    public void setCritiqueResultRowMapper(CritiqueResultRowMapper critiqueResultRowMapper) {
        this.critiqueResultRowMapper = critiqueResultRowMapper;
    }

    /**
     * @return the critiqueCoupleRowMapper
     */
    public CritiqueCoupleRowMapper getCritiqueCoupleRowMapper() {
        return critiqueCoupleRowMapper;
    }

    /**
     * @param critiqueCoupleRowMapper the critiqueCoupleRowMapper to set
     */
    public void setCritiqueCoupleRowMapper(CritiqueCoupleRowMapper critiqueCoupleRowMapper) {
        this.critiqueCoupleRowMapper = critiqueCoupleRowMapper;
    }

    /**
     * @return the critiqueMarkRowMapper
     */
    public CritiqueMarkRowMapper getCritiqueMarkRowMapper() {
        return critiqueMarkRowMapper;
    }

    /**
     * @param critiqueMarkRowMapper the critiqueMarkRowMapper to set
     */
    public void setCritiqueMarkRowMapper(CritiqueMarkRowMapper critiqueMarkRowMapper) {
        this.critiqueMarkRowMapper = critiqueMarkRowMapper;
    }

    /**
     * @return the critiqueStudioRowMapper
     */
    public CritiqueStudioRowMapper getCritiqueStudioRowMapper() {
        return critiqueStudioRowMapper;
    }

    /**
     * @param critiqueStudioRowMapper the critiqueStudioRowMapper to set
     */
    public void setCritiqueStudioRowMapper(CritiqueStudioRowMapper critiqueStudioRowMapper) {
        this.critiqueStudioRowMapper = critiqueStudioRowMapper;
    }

    /**
     * @return the critiqueHeatRowMapper
     */
    public CritiqueHeatRowMapper getCritiqueHeatRowMapper() {
        return critiqueHeatRowMapper;
    }

    /**
     * @param critiqueHeatRowMapper the critiqueHeatRowMapper to set
     */
    public void setCritiqueHeatRowMapper(CritiqueHeatRowMapper critiqueHeatRowMapper) {
        this.critiqueHeatRowMapper = critiqueHeatRowMapper;
    }

    /**
     * @return the critiquePersonRowMapper
     */
    public CritiquePersonRowMapper getCritiquePersonRowMapper() {
        return critiquePersonRowMapper;
    }

    /**
     * @param critiquePersonRowMapper the critiquePersonRowMapper to set
     */
    public void setCritiquePersonRowMapper(CritiquePersonRowMapper critiquePersonRowMapper) {
        this.critiquePersonRowMapper = critiquePersonRowMapper;
    }

    /**
     * @return the critiqueSubHeatRowMapper
     */
    public CritiqueSubHeatRowMapper getCritiqueSubHeatRowMapper() {
        return critiqueSubHeatRowMapper;
    }

    /**
     * @param critiqueSubHeatRowMapper the critiqueSubHeatRowMapper to set
     */
    public void setCritiqueSubHeatRowMapper(CritiqueSubHeatRowMapper critiqueSubHeatRowMapper) {
        this.critiqueSubHeatRowMapper = critiqueSubHeatRowMapper;
    }

    /**
     * @return the critiqueCoupleEntryRowMapper
     */
    public CritiqueCoupleEntryRowMapper getCritiqueCoupleEntryRowMapper() {
        return critiqueCoupleEntryRowMapper;
    }

    /**
     * @param critiqueCoupleEntryRowMapper the critiqueCoupleEntryRowMapper to set
     */
    public void setCritiqueCoupleEntryRowMapper(CritiqueCoupleEntryRowMapper critiqueCoupleEntryRowMapper) {
        this.critiqueCoupleEntryRowMapper = critiqueCoupleEntryRowMapper;
    }

    /**
     * @return the critiqueSoloEntryRowMapper
     */
    public CritiqueSoloEntryRowMapper getCritiqueSoloEntryRowMapper() {
        return critiqueSoloEntryRowMapper;
    }

    /**
     * @param critiqueSoloEntryRowMapper the critiqueSoloEntryRowMapper to set
     */
    public void setCritiqueSoloEntryRowMapper(CritiqueSoloEntryRowMapper critiqueSoloEntryRowMapper) {
        this.critiqueSoloEntryRowMapper = critiqueSoloEntryRowMapper;
    }
    
    
   
}
