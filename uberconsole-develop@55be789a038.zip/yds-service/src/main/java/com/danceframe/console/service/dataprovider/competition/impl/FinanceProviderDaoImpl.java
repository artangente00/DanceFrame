/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.competition.impl;

import com.danceframe.console.common.model.competition.Finance;
import com.danceframe.console.service.dataprovider.competition.FinanceProviderDao;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.query.competition.FinanceQuery;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public class FinanceProviderDaoImpl extends GenericProviderDaoImpl<Finance> implements FinanceProviderDao {

    @Override
    public int insert(Finance finance) {
        Object[] obj = new Object[] {
            finance.getEventId(),
            finance.getSurcharge(),
            finance.getDescription()
         };
         int ret = (Integer)this.genericQryTemplateInteger(FinanceQuery.INSERT_QRY, obj);
        return ret;
    }

    @Override
    public int update(Finance finance) {
         Object[] obj = new Object[] {
            finance.getId(),
            finance.getSurcharge(),
            finance.getDescription()
         };
         int ret = (Integer)this.genericQryTemplateInteger(FinanceQuery.UPDATE_QRY, obj);
        return ret;
    }

    @Override
    public Finance getByEventId(int eventId) {
        Object[] obj = new Object[] { eventId };
        String sqlWhere = " WHERE event_id = ?"  ;
        String finalSQL =  FinanceQuery.SELECT_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);   
    }
    
    
    @Override
    public Finance get(int eventId) {
        Object[] obj = new Object[] { eventId };
        String sqlWhere = " WHERE finance_id = ?"  ;
        String finalSQL =  FinanceQuery.SELECT_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);    
    }
    
    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
   

    @Override
    public int search(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int search(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

  
    @Override
    public Finance get(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Finance> getAll(String wherestr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Finance> getAllWithPaging(String wherestr, int pagesize, int pagenumber) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public long getAllCount(String wherestr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   
}
