/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query.competition.config;

/**
 *
 * @author lmorallos
 */
public class StyleQuery {
    
    public static final String SELECT_QRY = "SELECT style_id, name FROM uberconsole.tbl_style";
}
