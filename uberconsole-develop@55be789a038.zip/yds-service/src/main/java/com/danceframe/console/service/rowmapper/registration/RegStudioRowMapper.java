/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.registration;


import com.danceframe.console.common.model.registration.RegStudio;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class RegStudioRowMapper implements RowMapper<RegStudio>  {

    @Override
    public RegStudio mapRow(ResultSet rs, int i) throws SQLException {
        final RegStudio regstudio = new RegStudio();
        regstudio.setId(rs.getInt("regstudio_id"));
        regstudio.setName(rs.getString("studio_name"));
        regstudio.setContactLastname(rs.getString("contact_lname"));
        regstudio.setContactFirstname(rs.getString("contact_fname"));
        regstudio.setAddress1(rs.getString("address1"));
        regstudio.setAddress2(rs.getString("address2"));
        regstudio.setCity(rs.getString("city"));
        regstudio.setState(rs.getString("state"));
        regstudio.setPostal(rs.getString("postal"));
        regstudio.setCountry(rs.getString("country"));
        regstudio.setPhone(rs.getString("phone"));
        regstudio.setEmail(rs.getString("email"));
        regstudio.setEventId(rs.getInt("event_id"));
        regstudio.setEuid(rs.getString("euid"));
        regstudio.setSuid(rs.getString("suid"));
        regstudio.setUserId(rs.getInt("reguser_id"));
        regstudio.setBuid(rs.getString("buid"));
        regstudio.setCreationDate(rs.getTimestamp("create_date"));
        regstudio.setLastModified(rs.getTimestamp("last_modified"));
        return regstudio;
    }
    
}
