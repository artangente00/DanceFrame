/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.file.xml.impl;

import com.danceframe.console.common.exception.YDSException;
import com.danceframe.console.common.model.competition.Event;
import com.danceframe.console.common.model.heatlist.result.HeatListResultPersonKey;
import com.danceframe.console.common.model.heatlist.result.HeatResultCompetitor;
import com.danceframe.console.common.model.heatlist.result.HeatResultEvent;
import com.danceframe.console.common.model.heatlist.result.HeatResultHeat;
import com.danceframe.console.common.model.heatlist.result.HeatResultJudge;
import com.danceframe.console.common.model.heatlist.result.HeatResultMark;
import com.danceframe.console.common.model.heatlist.result.HeatResultPerson;
import com.danceframe.console.common.model.heatlist.result.HeatResultPersonProgram;
import com.danceframe.console.common.model.heatlist.result.HeatResultResult;
import com.danceframe.console.common.model.heatlist.result.HeatResultStudio;
import com.danceframe.console.common.model.heatlist.result.HeatResultSubHeat;
import com.danceframe.console.common.model.heatlist.result.HeatResultSubHeats;
import com.danceframe.console.common.model.heatlist.result.HeatlistResultXML;
import com.danceframe.console.common.util.Utility;
import com.danceframe.console.service.dataprovider.competition.EventProviderDao;
import com.danceframe.console.service.dataprovider.heatlist.HeatListResultMasterPersonProviderDao;
import com.danceframe.console.service.dataprovider.heatlist.HeatListResultProviderDao;
import com.danceframe.console.service.file.xml.HeatListResultXMLWriter;
import java.io.File;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.simpleframework.xml.Serializer;
import org.simpleframework.xml.core.Persister;

/**
 *
 * @author lmorallos
 */
public class HeatListResultXMLWriterImpl implements HeatListResultXMLWriter {

    private static final Logger logger = LogManager.getLogger(HeatListResultXMLWriterImpl.class);
    private static final String XMLPREFIX = "result-";
    
    private HeatListResultProviderDao heatListResultProviderDao;
    private EventProviderDao eventProviderDao;
    private HeatListResultMasterPersonProviderDao heatListResultMasterPersonProviderDao;
    
    
    
     @Override
    public HeatResultPersonProgram composeHeatlistResult(String uid) throws YDSException {
        int masterPersonId = heatListResultMasterPersonProviderDao.getMasterPersonUIDById(uid);
        List<Integer> iEvent = heatListResultProviderDao.getEventIds(masterPersonId);
        List<HeatResultEvent> events = new ArrayList<>();
        for (Integer eventId:iEvent) {
            Event eventdata = eventProviderDao.get(eventId);
            HeatResultEvent event = new HeatResultEvent();
            String euid = eventdata.getUid();
//            event.setId(eventdata.getId());
            event.setEuid(euid);
            event.setName(eventdata.getName());
            event.setDateStart(Utility.date2String(eventdata.getDateStart()));
            event.setDateStop(Utility.date2String(eventdata.getDateStop()));
            event.setYear(eventdata.getEventyear());
            String personKey = heatListResultProviderDao.getPerson(eventId, masterPersonId);
            event.setPersonKey(personKey);
                        
            List<HeatResultHeat> heats = heatListResultProviderDao.getHeat(eventId, masterPersonId);
            List<String> competitorKeys = new ArrayList<>();
            List<String> judgeKeys = new ArrayList<>();
            for (int i=0; i< heats.size();i++) {
                int heatid = heats.get(i).getId();
                heats.get(i).setEventId(0);
                List<HeatResultSubHeats> subheats = heatListResultProviderDao.getSubHeatsNoMP(eventId, heatid);
                for (int j=0; j < subheats.size(); j++) {
                    subheats.get(j).setEventId(0);
                    int subheastid = subheats.get(j).getId();
                    List<HeatResultSubHeat> subheat = heatListResultProviderDao.getSubHeatNoMP(eventId, subheastid);
                    for (int k=0;  k< subheat.size(); k++) {
                        subheat.get(k).setEventId(0);
                        int subheatid = subheat.get(k).getSubheatId();
                        HeatResultResult result = heatListResultProviderDao.getResultNoMP(eventId, subheatid);
                        int resultid = result.getId();
                        result.setEventId(0);
                        if (result.getJudgingPanel() != null) {
                            if (result.getJudgingPanel().contains("|")) {
                                List<String> judgeList = Utility.str2List(result.getJudgingPanel(),'|');
                                for (String judgeStr:judgeList) {
                                    if (judgeStr != null) {
                                        if (judgeStr.length() > 0) {
                                            if (!judgeKeys.contains(judgeStr)) {
                                                judgeKeys.add(judgeStr);
                                            }
                                        }
                                    }
                                }
                            } else {
                                judgeKeys.add(result.getJudgingPanel());
                            }
                        }
                        List<HeatResultMark> marks = heatListResultProviderDao.getMarksNoMP(eventId, subheatid, resultid);
                        for (HeatResultMark mark:marks) {
                            mark.setEventId(0);
                            if (mark.getKey().length() > 0) {
                                if (!competitorKeys.contains(mark.getKey())) {
                                    competitorKeys.add(mark.getKey());
                                }
                            }
                        }                   
                        result.setMarks((ArrayList)marks);
                        subheat.get(k).setResult(result); 
                    }
                    subheats.get(j).setSubHeat((ArrayList)subheat);
                    
                }  
                heats.get(i).setSubHeats((ArrayList)subheats);
            }
            List<HeatResultStudio> studios = heatListResultProviderDao.getStudios(eventId);
            event.setStudios((ArrayList)studios);
            List<HeatResultJudge> judges = heatListResultProviderDao.getJudgesUnfied(eventId, judgeKeys);
            event.setJudges((ArrayList)judges);            
  
            List<HeatResultCompetitor> competitors = heatListResultProviderDao.getCompetitor(eventId, competitorKeys);
            List<HeatResultPerson> persons = heatListResultProviderDao.getPersons(eventId, competitorKeys);
            
            // fill in the competitor number here
            if (competitors != null) {
                if (competitors.size() > 0) {
                    for (int i=0; i < competitors.size(); i++) {
                        List<HeatListResultPersonKey> pkeys = competitors.get(i).getPersonKeys();
                        String competitorNo = new String();
                        for (HeatListResultPersonKey pkey:pkeys) {
                            competitorNo = getCompetitorKeyFromPersons(persons, pkey.getPersonKey());
                            if (competitorNo != null) {
                                if (competitorNo.length() > 0) {
                                    competitors.get(i).setCompetitorNumber(competitorNo);
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            
            event.setCompetitors((ArrayList)competitors);
            event.setPersons((ArrayList)persons);

            event.setHeats((ArrayList)heats);
            events.add(event);
            
        }
       
        HeatResultPersonProgram program = new HeatResultPersonProgram();
        program.setPuid(uid);
        program.setEvents((ArrayList)events);
        return program;
    }

    
    @Override
    public HeatResultPersonProgram composeHeatlistResult(int masterPersonId) throws YDSException {
        String uid = heatListResultMasterPersonProviderDao.getMasterPersonUIDById(masterPersonId);
        List<Integer> iEvent = heatListResultProviderDao.getEventIds(masterPersonId);
        List<HeatResultEvent> events = new ArrayList<>();
        for (Integer eventId:iEvent) {
            Event eventdata = eventProviderDao.get(eventId);
            HeatResultEvent event = new HeatResultEvent();
            event.setId(eventdata.getId());
            event.setEuid(eventdata.getUid());
            event.setName(eventdata.getName());
            event.setDateStart(Utility.date2String(eventdata.getDateStart()));
            event.setDateStop(Utility.date2String(eventdata.getDateStop()));
            event.setYear(eventdata.getEventyear());
            String personKey = heatListResultProviderDao.getPerson(eventId, masterPersonId);
            event.setPersonKey(personKey);
                        
            List<HeatResultHeat> heats = heatListResultProviderDao.getHeat(eventId, masterPersonId);
            List<String> competitorKeys = new ArrayList<>();
            List<String> judgeKeys = new ArrayList<>();
            for (int i=0; i< heats.size();i++) {
                int heatid = heats.get(i).getId();
                List<HeatResultSubHeats> subheats = heatListResultProviderDao.getSubHeatsNoMP(eventId, heatid);
                for (int j=0; j < subheats.size(); j++) {
                    int subheastid = subheats.get(j).getId();
                    List<HeatResultSubHeat> subheat = heatListResultProviderDao.getSubHeatNoMP(eventId, subheastid);
                    for (int k=0;  k< subheat.size(); k++) {
                        int subheatid = subheat.get(k).getSubheatId();
                        HeatResultResult result = heatListResultProviderDao.getResultNoMP(eventId, subheatid);
                        int resultid = result.getId();
                        if (result.getJudgingPanel() != null) {
                            if (result.getJudgingPanel().contains("|")) {
                                List<String> judgeList = Utility.str2List(result.getJudgingPanel(),'|');
                                for (String judgeStr:judgeList) {
                                    if (judgeStr != null) {
                                        if (judgeStr.length() > 0) {
                                            if (!judgeKeys.contains(judgeStr)) {
                                                judgeKeys.add(judgeStr);
                                            }
                                        }
                                    }
                                }
                            } else {
                                judgeKeys.add(result.getJudgingPanel());
                            }
                        }
                        List<HeatResultMark> marks = heatListResultProviderDao.getMarksNoMP(eventId, subheatid, resultid);
                        for (HeatResultMark mark:marks) {
                            if (mark.getKey().length() > 0) {
                                if (!competitorKeys.contains(mark.getKey())) {
                                    competitorKeys.add(mark.getKey());
                                }
                            }
                        }                   
                        result.setMarks((ArrayList)marks);
                        subheat.get(k).setResult(result); 
                    }
                    subheats.get(j).setSubHeat((ArrayList)subheat);
                    
                }  
                heats.get(i).setSubHeats((ArrayList)subheats);
            }
            List<HeatResultStudio> studios = heatListResultProviderDao.getStudios(eventId);
            event.setStudios((ArrayList)studios);
            List<HeatResultJudge> judges = heatListResultProviderDao.getJudgesUnfied(eventId, judgeKeys);
            event.setJudges((ArrayList)judges);            
  
            List<HeatResultCompetitor> competitors = heatListResultProviderDao.getCompetitor(eventId, competitorKeys);            
            List<HeatResultPerson> persons = heatListResultProviderDao.getPersons(eventId, competitorKeys);

            // fill in the competitor number here
            if (competitors != null) {
                if (competitors.size() > 0) {
                    for (int i=0; i < competitors.size(); i++) {
                        List<HeatListResultPersonKey> pkeys = competitors.get(i).getPersonKeys();
                        String competitorNo = new String();
                        for (HeatListResultPersonKey pkey:pkeys) {
                            competitorNo = getCompetitorKeyFromPersons(persons, pkey.getPersonKey());
                            if (competitorNo != null) {
                                if (competitorNo.length() > 0) {
                                    competitors.get(i).setCompetitorNumber(competitorNo);
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            
            event.setCompetitors((ArrayList)competitors);
            event.setPersons((ArrayList)persons);
            event.setHeats((ArrayList)heats);
            events.add(event);
            
        }
       
        HeatResultPersonProgram program = new HeatResultPersonProgram();
        program.setMasterPersonId(masterPersonId);
        program.setPuid(uid);
        program.setEvents((ArrayList)events);
        return program;
    }
    
    private String getCompetitorKeyFromPersons(List<HeatResultPerson> persons, String pKey) {
        String competitor = null;
        for (HeatResultPerson person:persons) {
            if (person.getPersonKey().equalsIgnoreCase(pKey)) {
                competitor = person.getCompetitorNumber();
                if (competitor != null) {
                    if (competitor.length() == 0) competitor = null;
                }
                break;
            }
        }
        return competitor;
    }
    
    @Override
    public HeatlistResultXML databaseToXML(String tmpLocation, String uid) throws YDSException {
        HeatlistResultXML heatxml = null;
        String heatResultXMLFile = new String();
        try 
        {
           int masterPersonId = heatListResultMasterPersonProviderDao.getMasterPersonUIDById(uid);
            HeatResultPersonProgram program = composeHeatlistResult(masterPersonId);
            heatResultXMLFile = tmpLocation + Utility.generateUniqueFileName("HEATRESULT", "HRX");
            File xmlfile = new File( heatResultXMLFile);
            Serializer serializer = new Persister();
            serializer.write(program, xmlfile);
            heatxml = new HeatlistResultXML();
            heatxml.setCode("HRX");
            heatxml.setId(masterPersonId);
            heatxml.setEventId(0);
            heatxml.setFilename(XMLPREFIX  + Integer.toString(masterPersonId) + ".xml");
            File file = new File(heatResultXMLFile);
            byte[] bytes = Files.readAllBytes(file.toPath());
            heatxml.setData(bytes);
        } catch (Exception ex) {
            logger.error(ex.getMessage());
            throw new YDSException(ex);
        }   
        return heatxml;
    }



    @Override
    public HeatlistResultXML databaseToXML(String tmpLocation, int masterPersonId) throws YDSException {
        HeatlistResultXML heatxml = null;
        String heatResultXMLFile = new String();
        try 
        {
            HeatResultPersonProgram program = composeHeatlistResult(masterPersonId);
            heatResultXMLFile = tmpLocation + Utility.generateUniqueFileName("HEATRESULT", "HRX");
            File xmlfile = new File( heatResultXMLFile);
            Serializer serializer = new Persister();
            serializer.write(program, xmlfile);
            heatxml = new HeatlistResultXML();
            heatxml.setCode("HRX");
            heatxml.setId(masterPersonId);
            heatxml.setEventId(0);
            heatxml.setFilename(XMLPREFIX + Integer.toString(masterPersonId) + ".xml");
            File file = new File(heatResultXMLFile);
            byte[] bytes = Files.readAllBytes(file.toPath());
            heatxml.setData(bytes);
        } catch (Exception ex) {
            logger.error(ex.getMessage());
            throw new YDSException(ex);
        }   
        return heatxml;
    }

    /**
     * @return the heatListResultProviderDao
     */
    public HeatListResultProviderDao getHeatListResultProviderDao() {
        return heatListResultProviderDao;
    }

    /**
     * @param heatListResultProviderDao the heatListResultProviderDao to set
     */
    public void setHeatListResultProviderDao(HeatListResultProviderDao heatListResultProviderDao) {
        this.heatListResultProviderDao = heatListResultProviderDao;
    }

    /**
     * @return the eventProviderDao
     */
    public EventProviderDao getEventProviderDao() {
        return eventProviderDao;
    }

    /**
     * @param eventProviderDao the eventProviderDao to set
     */
    public void setEventProviderDao(EventProviderDao eventProviderDao) {
        this.eventProviderDao = eventProviderDao;
    }

    /**
     * @return the heatListResultMasterPersonProviderDao
     */
    public HeatListResultMasterPersonProviderDao getHeatListResultMasterPersonProviderDao() {
        return heatListResultMasterPersonProviderDao;
    }

    /**
     * @param heatListResultMasterPersonProviderDao the heatListResultMasterPersonProviderDao to set
     */
    public void setHeatListResultMasterPersonProviderDao(HeatListResultMasterPersonProviderDao heatListResultMasterPersonProviderDao) {
        this.heatListResultMasterPersonProviderDao = heatListResultMasterPersonProviderDao;
    }

   
}
