/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query.heatlist;

/**
 *
 * @author lmorallos
 */
public final class HeatListResultQuery {
    
    public final static String EVENT_CLEAR_QRY = "SELECT uberconsole.FN_HEATRESULT_EVENT_CLEAR( ? )";

    public final static String PROGRAM_INSERT_QRY = "SELECT uberconsole.FN_HEATRESULT_PROGRAM_INSERT(?, ?, ?, ?, ?, ? , ?)";
    
    public final static String STUDIO_INSERT_QRY = "SELECT uberconsole.FN_HEATRESULT_STUDIO_INSERT(?, ?, ?, ?, ? )";

    public final static String JUDGE_INSERT_QRY = "SELECT uberconsole.FN_HEATRESULT_JUDGE_INSERT( ?, ?, ?, ?, ?, ? )";

    public final static String PERSON_INSERT_QRY = "SELECT uberconsole.FN_HEATRESULT_PERSON_INSERT( ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    public final static String COMPETITOR_INSERT_QRY = "SELECT uberconsole.FN_HEATRESULT_COMPETITOR_INSERT( ?, ?, ?, ?, ?, ?, ?)";
    
    public final static String PERSONKEY_INSERT_QRY = "SELECT uberconsole.FN_HEATRESULT_PERSONKEY_INSERT( ?, ?, ?, ?)";
    
    public final static String HEATS_INSERT_QRY = "SELECT uberconsole.FN_HEATRESULT_HEAT_INSERT( ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )";

    public final static String SUBHEATS_INSERT_QRY = "SELECT uberconsole.FN_HEATRESULT_SUBHEATS_INSERT( ?, ?, ?, ?, ?, ?, ? )";
    
     public final static String SUBHEAT_INSERT_QRY = "SELECT uberconsole.FN_HEATRESULT_SUBHEAT_INSERT( ?, ?, ?, ?, ?, ?)";
    
    public final static String RESULT_INSERT_QRY = "SELECT uberconsole.FN_HEATRESULT_RESULT_INSERT( ?, ?, ?, ?)";

    public final static String MARKS_INSERT_QRY = "SELECT uberconsole.FN_HEATRESULT_MARKS_INSERT( ?, ?, ?, ?, ?, ?)";

    public final static String SELECT_STUDIO_QRY = "SELECT studio_id,studio_key,name,invoice,event_id,xml_id " + 
						"FROM uberconsole.tbl_hrstudios";

    public final static String SELECT_JUDGE_QRY = "SELECT judge_id,judge_key,firstname,lastname,judge_num," + 
						"event_id,xml_id FROM uberconsole.tbl_hrjudges";

    public final static String SELECT_PERSON_QRY = "SELECT person_id,person_key,firstname,lastname,gender," + 
						"persontype,studio_key,nickname,ndcaus_num,competitor_num,event_id," + 
						"xml_id FROM uberconsole.tbl_hrpersons";

    public final static String SELECT_COMPETITOR_QRY = "SELECT competitor_id,competitor_key,competitor_type,name_override," + 
						"person1_key,person2_key,event_id,xml_id FROM uberconsole.tbl_hrcompetitor";
    
     public final static String SELECT_PERSONKEY_QRY = "SELECT personkey_id,person_key,competitor_id," + 
						"event_id,xml_id FROM uberconsole.tbl_hrpersonkey";
    
    public final static String SELECT_HEAT_QRY = "SELECT * FROM uberconsole.tbl_hrheat";

    public final static String SELECT_SUBHEATS_QRY = "SELECT * FROM uberconsole.tbl_hrsubheats";

    public final static String SELECT_SUBHEAT_QRY = "SELECT * FROM uberconsole.tbl_hrsubheat";

    public final static String SELECT_RESULT_QRY = "SELECT result_id,judgepanel,scoreheaders,subheat_id,event_id," + 
                                                    "xml_id FROM uberconsole.tbl_hrresult";

    public final static String SELECT_MARK_QRY = "SELECT mark_id,competitor_key,competitor_value,studio_name,competitor_id,result_id,subheat_id," + 
						"event_id FROM uberconsole.tbl_hrmarks";
    
    public final static String SELECT_XMLDATA_QRY = "SELECT xml_id,filename,uploadtime,code,event_id,xmldata " + 
                                                "FROM uberconsole.tbl_xmldata WHERE event_id=? ORDER BY xml_id DESC LIMIT 1";
    

    public final static String COUPLES_SEARCH_QRY = "SELECT uberconsole.FN_HEATRESULT_COUPLES_SEARCH( ?, ? )";
    
    public final static String COUPLES_INSERT_QRY = "SELECT uberconsole.FN_HEATRESULT_COUPLES_INSERT( ?, ?, ?, ?, ? )";

    public final static String ENTRIES_INSERT_QRY = "SELECT uberconsole.FN_HEATRESULT_COUPLE_ENTRIES_INSERT( ?, ?, ? )";

    public final static String SOLO_INSERT_QRY = "SELECT uberconsole.FN_HEATRESULT_SOLO_ENTRIES_INSERT( ?, ?, ? )";

    public final static String SELECT_COUPLE_QRY = "SELECT couple_id,couple_key,person1_key,person2_key," + 
						"event_id,xml_id FROM uberconsole.tbl_hrcouples";

    
    public final static String SELECT_ENTRIES_QRY = "SELECT entry_id,couple_key,couple_id,subheat_id,event_id,xml_id" + 
                                                    " FROM uberconsole.tbl_hrcoupleentries";
    
     public final static String SELECT_SOLO_QRY = "SELECT sentry_id,person_key,subheat_id,event_id" + 
                                                    " FROM uberconsole.tbl_hrsoloentries";

    public final static String SELECT_ALLPERSON_QRY = "SELECT person_id,person_key,firstname,lastname,gender,persontype," + 
                                    "studio_key,nickname,ndcaus_num,competitor_num,event_id,xml_id,masterperson_id " +
                                    "FROM uberconsole.VW_HEATLIST_RESULT_PERSON";
    
    public final static String SELECT_ALLJUDGE_QRY = "SELECT judge_id, judge_key, firstname,lastname,judge_num," +
                                    "event_id, masterjudge_id FROM uberconsole.VW_HEATLIST_RESULT_JUDGE";
    
    public final static String SELECT_CNTDATA_BYPERSON_QRY = "SELECT count(mark_id) FROM uberconsole.VW_HEATLIST_RESULT_INFO " + 
                                    "WHERE event_id=? AND (person1_key=? OR person2_key=?)";
    
    public final static String SELECT_DATA_BYPERSON_QRY = "SELECT mark_id,couple_key,couple_value,judgepanel,scoreheaders,person1_key,person2_key," + 
                                    "subheat_type,subheat_dance,subheat_level,subheat_age,heat_id,heat_name,heat_session,heat_time,heat_date," +
                                    "heat_type,description,couple_id,result_id,subheat_id,event_id FROM uberconsole.VW_HEATLIST_RESULT_INFO";;


    public final static String SELECT_HEAT_ENTRY_QRY = "SELECT DISTINCT a.heat_id, a.subheat_id, a.event_id, a.person1_key, a.person2_key, a.couple_key, a.heat_name," + 
                    "(a.description || ' (' || a.subheat_dance || ')') as description, a.category," +
                    "b.firstname as firstname1, b.lastname as lastname1, " +
                    "c.firstname as firstname2, c.lastname as lastname2, coalesce(b.competitor_num, c.competitor_num ) as competitor_num " +
                    "FROM uberconsole.VW_HEATLIST_RESULT_INFO a LEFT JOIN uberconsole.VW_HEATLIST_RESULT_PERSON b " +
                    "ON b.person_key = a.person1_key LEFT JOIN uberconsole.VW_HEATLIST_RESULT_PERSON c " +
                    "ON c.person_key = a.person2_key ";
    
    public final static String SELECT_SCORE_ENTRY_QRY = "SELECT DISTINCT a.event_id, a.heat_id, a.subheat_id, a.person1_key, a.person2_key, a.couple_key, a.heat_name," +
                    "a.description, a.category, a.judgepanel, a.scoreheaders, a.couple_value, a.subheat_type, a.subheat_dance, a.subheat_level, a.subheat_age," +
                    "b.firstname as firstname1, b.lastname as lastname1, c.firstname as firstname2, c.lastname as lastname2," +
                    "coalesce(b.competitor_num, c.competitor_num ) as competitor_num " +
                    "FROM uberconsole.VW_HEATLIST_RESULT_INFO a LEFT JOIN uberconsole.VW_HEATLIST_RESULT_PERSON b " +
                    "ON b.person_key = a.person1_key LEFT JOIN uberconsole.VW_HEATLIST_RESULT_PERSON c " +
                    "ON c.person_key = a.person2_key ";
    
    
    public final static String SELECT_MASTERPERSON = "SELECT masterperson_id, uid, firstname, lastname FROM uberconsole.tbl_masterpersons";
    
    public final static String SELECT_MASTERPERSON_ID_BYNAME = "SELECT masterperson_id FROM uberconsole.tbl_masterpersons WHERE firstname=? AND lastname=?";
    
    public final static String SELECT_MASTERPERSON_UID_BYID = "SELECT uid FROM uberconsole.tbl_masterpersons WHERE masterperson_id=?";

    public final static String SELECT_MASTERPERSON_UID_BYNAME = "SELECT uid FROM uberconsole.tbl_masterpersons WHERE firstname=? AND lastname=?";

    public final static String SELECT_MASTERPERSON_ID_BYUID = "SELECT masterperson_id FROM uberconsole.tbl_masterpersons WHERE uid=?";
 
    public final static String SELECT_MASTERPERSON_COUNT = "SELECT count(masterperson_id) FROM uberconsole.tbl_masterpersons";
    
    public final static String SELECT_MASTERPERSON_UNIFIED = "SELECT uberconsole.FN_HEATRESULT_MASTERPERSON_UNIFIED(?, ?)";
    
    public final static String SELECT_MASTERPERSON_EDIT = "SELECT uberconsole.FN_HEATRESULT_MASTERPERSON_EDIT(?, ?, ?)";
    
    
     public final static String SELECT_MASTERJUDGE = "SELECT masterjudge_id, firstname, lastname FROM uberconsole.tbl_masterjudges";
    
    public final static String SELECT_MASTERJUDGE_COUNT = "SELECT count(masterjudge_id) FROM uberconsole.tbl_masterjudges";
    
    public final static String SELECT_MASTERJUDGE_UNIFIED = "SELECT uberconsole.FN_HEATRESULT_MASTERJUDGE_UNIFIED(?, ?)";
    
    public final static String SELECT_MASTERJUDGE_EDIT = "SELECT uberconsole.FN_HEATRESULT_MASTERJUDGE_EDIT(?, ?, ?)";
    
    public final static String SELECT_EVENTID_QRY = "SELECT DISTINCT event_id FROM uberconsole.VW_HEATRESULT_DATAWITHVWPERSON " +
                "WHERE (masterperson_id1=? OR masterperson_id2=?)";
    
    public final static String SELECT_JUDGEUNFIED_QRY = "SELECT * FROM uberconsole.VW_HEATRESULT_JUDGE WHERE event_id=?";

    public final static String SELECT_PERSON_VIEW_QRY = "SELECT * FROM uberconsole.VW_HEATRESULT_PERSON " +
                "WHERE person_key IN (SELECT DISTINCT  person_key FROM uberconsole.VW_HEATRESULT_PERSON_KEY " +
                "WHERE competitor_id IN (SELECT DISTINCT competitor_id FROM uberconsole.VW_HEATRESULT_DATAWITHVWPERSON " +
                "WHERE (masterperson_id1=? OR masterperson_id2=?) AND event_id=? ))";

    public final static String SELECT_COMPETITOR_VIEW_QRY = "SELECT * FROM uberconsole.tbl_hrcompetitor " +
                "WHERE competitor_id IN (SELECT DISTINCT competitor_id FROM uberconsole.VW_HEATRESULT_DATAWITHVWPERSON " +
                "WHERE (masterperson_id1=? OR masterperson_id2=?) AND event_id=?)";

    public final static String SELECT_HEAT_VIEW_QRY = "SELECT * FROM uberconsole.tbl_hrheat WHERE heat_id IN (" +
        "SELECT DISTINCT heat_id FROM uberconsole.tbl_hrsubheats WHERE subheats_id IN (" +
        "SELECT DISTINCT subheats_id FROM uberconsole.tbl_hrsubheat WHERE subheat_id IN (" +
        "SELECT DISTINCT subheat_id FROM uberconsole.VW_HEATRESULT_DATAWITHVWPERSON " +
        "WHERE ((masterperson_id1=? OR masterperson_id2=?) AND event_id=? ))))";

     public final static String SELECT_SUBHEATS_VIEW_QRY = "SELECT * FROM uberconsole.tbl_hrsubheats WHERE subheats_id IN (" +
        "SELECT DISTINCT subheats_id FROM uberconsole.tbl_hrsubheat WHERE subheat_id IN (" +
        "SELECT DISTINCT subheat_id FROM uberconsole.VW_HEATRESULT_DATAWITHVWPERSON " +
        "WHERE ((masterperson_id1=? OR masterperson_id2=?) AND event_id=? ))) AND heat_id=?";
     
    public final static String SELECT_SUBHEAT_VIEW_QRY = "SELECT * FROM uberconsole.tbl_hrsubheat WHERE subheat_id IN (" +
               "SELECT DISTINCT subheat_id FROM uberconsole.VW_HEATRESULT_DATAWITHVWPERSON " + 
               "WHERE (masterperson_id1=? OR masterperson_id2=?) AND event_id=?) AND subheats_id=?";

    public final static String SELECT_RESULT_VIEW_QRY = "SELECT result_id,judgepanel,scoreheaders,subheat_id,event_id " +
                "FROM uberconsole.VW_HEATRESULT_DATAWITHVWPERSON WHERE (masterperson_id1=? OR masterperson_id2=?) " +
                "AND event_id=? AND subheat_id=?";

    public final static String SELECT_MARK_VIEW_QRY = "SELECT mark_id,competitor_key,competitor_value,competitor_id,result_id,subheat_id,event_id " +
                "FROM uberconsole.VW_HEATRESULT_DATAWITHVWPERSON WHERE (masterperson_id1=? OR masterperson_id2=?)" +
                "AND event_id=? AND subheat_id=? AND result_id=?";

    
    public final static String SELECT_SUBHEATS_NOMP_VIEW_QRY = "SELECT * FROM uberconsole.tbl_hrsubheats WHERE event_id=? AND heat_id=?";
     
    public final static String SELECT_SUBHEAT_NOMP_VIEW_QRY = "SELECT * FROM uberconsole.tbl_hrsubheat WHERE event_id=? AND subheats_id=?";

    public final static String SELECT_RESULT_NOMP_VIEW_QRY = "SELECT result_id,judgepanel,scoreheaders,subheat_id,event_id " +
                "FROM uberconsole.tbl_hrresult WHERE event_id=? AND subheat_id=?";

    public final static String SELECT_MARK_NOMP_VIEW_QRY = "SELECT mark_id,competitor_key,competitor_value,competitor_id,result_id,subheat_id,event_id " +
                "FROM uberconsole.tbl_hrmarks WHERE event_id=? AND subheat_id=? AND result_id=?";


    
    public final static String SELECT_JUDGEUNFIED_LIST_QRY = "SELECT * FROM uberconsole.VW_HEATRESULT_JUDGE WHERE event_id=? ";
    
    public final static String SELECT_COMPETITOR_LIST_QRY = "SELECT * FROM uberconsole.tbl_hrcompetitor WHERE event_id=? ";
     
    public final static String SELECT_PERSON_COMPLIST_QRY = "SELECT * FROM uberconsole.VW_HEATRESULT_PERSON " +
                "WHERE person_key IN (SELECT DISTINCT  person_key FROM uberconsole.VW_HEATRESULT_PERSON_KEY " +
                "WHERE competitor_id IN (SELECT DISTINCT competitor_id FROM uberconsole.tbl_hrcompetitor WHERE event_id=? " +
                "AND competitor_key IN (%s) ))"; 
    
    public final static String SELECT_PERSON_MASTERPERSON_QRY = "SELECT DISTINCT person_key FROM uberconsole.VW_HEATRESULT_PERSON " +
                "WHERE event_id=? AND masterperson_id=?";
    
     
}
