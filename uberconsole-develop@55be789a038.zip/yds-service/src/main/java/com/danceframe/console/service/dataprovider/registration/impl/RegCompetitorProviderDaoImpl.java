/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.registration.impl;

import com.danceframe.console.common.model.registration.RegCompetitor;
import com.danceframe.console.service.dataprovider.impl.GenericProviderDaoImpl;
import com.danceframe.console.service.dataprovider.registration.RegCompetitorProviderDao;
import com.danceframe.console.service.query.RegistrationQuery;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public class RegCompetitorProviderDaoImpl extends GenericProviderDaoImpl<RegCompetitor> implements RegCompetitorProviderDao{

    @Override
    public int search(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int search(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int insert(RegCompetitor competitor) {
        Object[] obj = new Object[] { 
            competitor.getBuid(),
            competitor.getEuid(),
            competitor.getType()
           
        };
        int ret = (Integer)this.genericQryTemplateInteger(RegistrationQuery.INSERT_REGCOMPETITOR_QRY, obj);
        return ret;
    }

    @Override
    public int update(RegCompetitor t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public RegCompetitor get(int id) {
        Object[] obj = new Object[] { id };
        String sqlWhere = " WHERE regcompetitor_id = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGCOMPETITOR_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);   
    }

    @Override
    public RegCompetitor get(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RegCompetitor> getAll(String wherestr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RegCompetitor> getAllWithPaging(String wherestr, int pagesize, int pagenumber) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public long getAllCount(String wherestr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public RegCompetitor get(int personId, String euid) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public RegCompetitor get(String cuid, String euid) {
        Object[] obj = new Object[] { cuid, euid };
        String sqlWhere = " WHERE cuid = ? AND euid = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGCOMPETITOR_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);   
    }

    @Override
    public List<RegCompetitor> getRegCompetitorsByEventUID(String euid) {
        List<RegCompetitor> personList = new ArrayList<>();
        Object[] obj = new Object[] { euid };
        String sqlWhere = " WHERE euid = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGCOMPETITOR_QRY + sqlWhere;
        personList =  genericQryAllTemplateRowMapper(finalSQL, obj);
        return personList;    
    }

    @Override
    public RegCompetitor get(String buid, String euid, String cuid) {
        Object[] obj = new Object[] { buid, euid, cuid };
        String sqlWhere = " WHERE buid=? AND euid=? AND cuid=?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGCOMPETITOR_QRY + sqlWhere;
        return genericQryTemplateRowMapper(finalSQL, obj);   
    }

    @Override
    public List<RegCompetitor> getRegCompetitors(String buid, String euid) {
        List<RegCompetitor> personList = new ArrayList<>();
        Object[] obj = new Object[] { euid };
        String sqlWhere = " WHERE buid=? AND euid = ?"  ;
        String finalSQL =  RegistrationQuery.SELECT_REGCOMPETITOR_QRY + sqlWhere;
        personList =  genericQryAllTemplateRowMapper(finalSQL, obj);
        return personList;   
    }
    
}
