/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query;

/**
 *
 * @author lmorallos
 */
public final class AccountQuery {
    
    public static final String SEARCH_QRY = "SELECT uberConsole.FN_ACCOUNT_SEARCH_USER( ?,? )";
    
    public static final String SEARCH_ALL_QRY = "SELECT uberConsole.FN_ACCOUNT_SEARCH_ALLUSER( ? )";
    
    public static final String INSERT_QRY = "SELECT uberConsole.FN_ACCOUNT_INSERT( ?,?,?,?,?,?,?,?,?,?,?,?,? )";
    
    public static final String UPDATE_QRY = "SELECT uberConsole.FN_ACCOUNT_UPDATE( ?,?,?,?,?,?,?,?,?,?,?,?,? )";
    
    public static final String ACTIVATE_QRY = "SELECT uberConsole.FN_ACCOUNT_ACTIVATE( ? )";
    
    public static final String DEACTIVATE_QRY = "SELECT uberConsole.FN_ACCOUNT_DEACTIVATE( ? )";
    
    public static final String GETALLINFO_WITH_PAGING_QRY = "SELECT * FROM uberconsole.FN_ACCOUNT_GETALL_USER( ?,?,? )";
    
    public static final String GETUSERINFO_QRY = "SELECT * FROM uberConsole.FN_ACCOUNT_GETUSERINFO( ?, ? )";
    
}
