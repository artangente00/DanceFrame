/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.dataprovider.registration;

import com.danceframe.console.common.model.registration.RegUser;
import com.danceframe.console.service.dataprovider.GenericProviderDao;
import java.util.List;

/**
 *
 * @author lmorallos
 */
public interface RegUserProviderDao extends GenericProviderDao<RegUser> {  
    
    int signin(String bgoid, String buid);
    
    int updateByBuid(RegUser reguser);
      
    RegUser get(String bgoid, String buid);
    
    RegUser getByBgoId(String bgoid);
    
    List<RegUser> getAll();
}
