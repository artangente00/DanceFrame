/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.payment;

import com.danceframe.console.common.model.invoice.InvoicePaymentDetail;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class InvoicePaymentDetailRowMapper implements RowMapper<InvoicePaymentDetail> {

    @Override
    public InvoicePaymentDetail mapRow(ResultSet rs, int i) throws SQLException {
        InvoicePaymentDetail paydet = new InvoicePaymentDetail();
        paydet.setInvoicePaymnetDetailId(rs.getInt("invpaydetail_id"));
        paydet.setInvoicePaymentId(rs.getInt("invpayment_id"));
        paydet.setInvoiceAmount(rs.getDouble("invoice_amount"));
        paydet.setReceivedAmount(rs.getDouble("received_amount"));
        paydet.setBalance(rs.getDouble("balance"));
        paydet.setNotes(rs.getString("notes"));
        paydet.setPayType(rs.getInt("pay_type"));
        paydet.setPaymentDate(rs.getTimestamp("payment_date"));
        return paydet;
    }
    
}
