/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.query.competition;

/**
 *
 * @author lmorallos
 */
public final class EventQuery {
    
    public static final String INSERT_QRY = "SELECT uberconsole.FN_EVENT_INSERT_BYCOMPID( ?,?,?,?,?,?,?,?,?,?,?,?,?,?)"; 

    public static final String UPDATE_BYEVENTID_QRY = "SELECT uberconsole.FN_EVENT_UPDATE_BYEVENTID( ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    
    public static final String UPDATE_IMG_BYEVENTID_QRY = "SELECT uberconsole.FN_EVENT_IMAGEUPDATE_BYEVENTID( ?,? )";

    public static final String SETSTATUS_QRY = "SELECT uberconsole.FN_EVENT_SETSTATUS(?,?)";
    
    public static final String SETPUSHID_QRY = "SELECT uberconsole.FN_EVENT_SETPUSHID(?,?)";
    
    public static final String SETPUBSTATUS_QRY = "SELECT uberconsole.FN_EVENT_PUBSTATUS(?,?,?)";
	
    public static final String DELETE_QRY = "SELECT uberconsole.FN_EVENT_DELETE(?)";
    
    public static final String COPY_QRY = "SELECT uberconsole.FN_EVENT_COPY(?, ?)";

    public static final String SEARCH_BYEVENTANDDATE_QRY = "SELECT uberconsole.FN_EVENT_SEARCH_BYEVENTANDDATE(?,?,?)";

    public static final String SEARCH_BYCOMPIDANDDATE_QRY = "SELECT uberconsole.FN_EVENT_SEARCH_BYCOMPIDANDDATE(?,?,?)";
    
    public static final String SELECT_QRY = 
                "SELECT competition_name, event_name, event_year, event_id, date_start, date_stop, deadline,website, " + 
                    "status, competition_id, image_id, pubstatus, timecommit, lastupdate, usemanual, uregister, push_id, " + 
                    "filename, mimetype, status_name, publish_status, lastpublish, shortlink, testevent, website_enabled, " +
                    "hide_event, payment_methods, uid " +
                    "FROM uberconsole.VW_EVENT_WITHCOMPETITION";
               
    public static final String SELECT_COUNT_QRY = "SELECT COUNT(event_id) FROM uberconsole.VW_EVENT_WITHCOMPETITION";
 
    public static final String SELECT_PUBSTAT_QRY = "SELECT items, pubpending, pubcommit, unpubpending, unpubcommit, repubpending, repubcommit, allpending, allcommit " + 
                    "FROM uberconsole.FN_EVENT_GET_PUBSTATUS_REPORT()";
    
    public static final String SELECT_EVENT_SUMMARY = "SELECT futurepubcnt,futureunpubcnt,remlastyrcnt,uniqeventcnt FROM uberconsole.FN_EVENT_GET_EVENTSTATUS_REPORT()";
    
    public static final String SELECT_EVENT_YEAR_QRY = "SELECT DISTINCT event_year FROM uberconsole.VW_EVENT_WITHCOMPETITION ORDER BY event_year DESC";
    
}
