/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.danceframe.console.service.rowmapper.registration;

import com.danceframe.console.common.model.registration.RegCompetitor;
import com.danceframe.console.common.model.registration.RegCompetitorPerson;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author lmorallos
 */
public class RegCompetitorRowMapper implements RowMapper<RegCompetitor> {
    
    @Override
    public RegCompetitor mapRow(ResultSet rs, int i) throws SQLException {
        final RegCompetitor competitor = new RegCompetitor();
        competitor.setId(rs.getInt("regcompetitor_id"));
        competitor.setType(rs.getString("competitor_type"));
        competitor.setEventId(rs.getInt("event_id"));
        competitor.setEuid(rs.getString("euid"));
        competitor.setUserId(rs.getInt("reguser_id"));
        competitor.setBuid(rs.getString("buid"));
        competitor.setCuid(rs.getString("cuid"));
        competitor.setCreationDate(rs.getTimestamp("create_date"));
        competitor.setLastModified(rs.getTimestamp("last_modified"));
        competitor.setPersonList(new ArrayList<RegCompetitorPerson>());
        return competitor;
    }
    
}
