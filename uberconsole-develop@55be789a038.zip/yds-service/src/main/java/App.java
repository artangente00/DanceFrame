
import com.danceframe.console.common.exception.YDSException;
import com.danceframe.console.common.model.competition.Event;
import com.danceframe.console.common.model.heatlist.HeatSession;
import com.danceframe.console.common.model.heatlist.result.HeatResultCompetitor;
import com.danceframe.console.common.model.heatlist.result.HeatResultEvent;
import com.danceframe.console.common.model.heatlist.result.HeatResultHeat;
import com.danceframe.console.common.model.heatlist.result.HeatResultJudge;
import com.danceframe.console.common.model.heatlist.result.HeatResultMark;
import com.danceframe.console.common.model.heatlist.result.HeatResultPerson;
import com.danceframe.console.common.model.heatlist.result.HeatResultPersonProgram;
import com.danceframe.console.common.model.heatlist.result.HeatResultResult;
import com.danceframe.console.common.model.heatlist.result.HeatResultStudio;
import com.danceframe.console.common.model.heatlist.result.HeatResultSubHeat;
import com.danceframe.console.common.model.registration.RegPerson;
import com.danceframe.console.common.util.Utility;
import com.danceframe.console.service.dataprovider.competition.EventProviderDao;
import com.danceframe.console.service.dataprovider.heatlist.HeatListResultProviderDao;
import com.danceframe.console.service.file.heatlist.HeatListReader;
import com.danceframe.console.service.file.heatlist.HeatListResultWriter;
import com.danceframe.console.service.file.heatlist.HeatListWriter;
import com.danceframe.console.service.file.xml.CompManagerXMLWriter;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.simpleframework.xml.Serializer;
import org.simpleframework.xml.core.Persister;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lmorallos
 */
public class App {
    
     
     public static void main( String[] args ) throws IOException {
        ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("uaydsServiceConfig.xml");
        EventProviderDao eventProviderDao = (EventProviderDao) ctx.getBean("eventProviderDao");
        CompManagerXMLWriter compManagerXMLWriter = (CompManagerXMLWriter)ctx.getBean("compManagerXMLWriter");
        String tmpLoc = "/Users/vortex/Projects/java/ubercompmngr/cpmgr-ddl/commgr-edit/";
        String dbcFile = "DEMODATA.dbc";
        String xmlFile = "out2.xml";
        try {
            if (compManagerXMLWriter.createXMLOutput(tmpLoc, dbcFile, xmlFile, true)) {
                System.out.println("XML Created.");
            }
        } catch (YDSException ex) {
            ex.printStackTrace();
        }
       
        
        
//        String stuFile = "/Users/vortex/Projects/java/ua-yds/yds-ddl/programinfo/canam-2019-setup.txt";
//        BufferedReader setupFile = new BufferedReader(new FileReader(stuFile));
//        String tmpstr = new String();
//        boolean isValidFile = true;
//        int hid = 1;
//        int ctr = 0;
//        int seq = 1;
//        List<HeatSession> sessions = new ArrayList<>();
//        List<String> tmpList = new ArrayList<>();
//        while ((tmpstr = setupFile.readLine()) != null) {
//            if (ctr == 0) { // read marker first
//                if (!tmpstr.contains(";"))  {
//                    isValidFile = false; break;
//                } else {
//                    tmpList = Utility.str2List(tmpstr, ';');
//                    if (!tmpList.get(0).equalsIgnoreCase("stu")) {
//                        isValidFile = false;
//                        break;
//                    }
//               } 
//            } else {
//                tmpList = Utility.str2List(tmpstr, ';');                 
//                if (tmpList.get(0).equalsIgnoreCase("SE")) {
//                    System.out.println(tmpList + ":" + tmpList.size());
//                    if (tmpList.size() >= 3) {
//                        HeatSession session = new HeatSession() ;
//                        session.setHeatlistId(hid);
//                        session.setSessionCount(seq);
//                        session.setSessionDay(tmpList.get(1));
//                        List<String> tmpDate = Utility.str2List(tmpList.get(2), '.');
//                        if (tmpDate.size() >= 3)
//                            session.setSessionDate(tmpDate.get(0) + "." + tmpDate.get(1) + "." + tmpDate.get(2));
//                        if (tmpDate.size() >= 6)
//                            session.setSessionTime(tmpDate.get(3) + "." + tmpDate.get(4) + "." + tmpDate.get(5));
//                        sessions.add(session);
//                        seq++;  
//                    }
//                } else {
//                    break;
//                }
//            }
//           ctr++;
//        }
//        setupFile.close();
//        System.out.println("VALID File:" + isValidFile);
//        for (HeatSession session:sessions) {
//            System.out.println(session.toString());
//        }
        
        
        
//        EventProviderDao eventProviderDao = (EventProviderDao) ctx.getBean("eventProviderDao");
//        String euid = "a9750901-75cf-9ed4-3b9f-0438ef1ec0b7";
//        Event event = eventProviderDao.getEventByEuid(euid);
//        System.out.println(event.toString());
        
        
//        HeatListResultWriter wresult = (HeatListResultWriter) ctx.getBean("heatListResultWriter");
//        wresult.writeToFile("d:/temp/", "output.html", 61);
        
//        HeatListWriter wresult = (HeatListWriter) ctx.getBean("heatListWriter");
//        wresult.writeToFile("/Users/vortex/Projects/java/data/tmp/", "outheat.html", 1);
        
//        HeatListResultProviderDao heatListResultProviderDao = (HeatListResultProviderDao) ctx.getBean("heatListResultProviderDao");
//        int masterPersonId = 30;
//        // masterpersonid =
//        List<Integer> iEvent = heatListResultProviderDao.getEventIds(masterPersonId);
//        List<HeatResultEvent> events = new ArrayList<>();
//        for (Integer eventId:iEvent) {
//            Event eventdata = eventProviderDao.get(eventId);
//            HeatResultEvent event = new HeatResultEvent();
//            event.setId(eventdata.getId());
//            event.setName(eventdata.getName());
//            event.setDateStart(Utility.date2String(eventdata.getDateStart()));
//            event.setDateStop(Utility.date2String(eventdata.getDateStop()));
//            event.setYear(eventdata.getEventyear());
//            String personKey = heatListResultProviderDao.getPerson(eventId, masterPersonId);
//            event.setPersonKey(personKey);
//                        
//            List<HeatResultHeat> heats = heatListResultProviderDao.getHeat(eventId, masterPersonId);
//            List<String> competitorKeys = new ArrayList<>();
//            List<String> judgeKeys = new ArrayList<>();
//            for (int i=0; i< heats.size();i++) {
//                int heatid = heats.get(i).getId();
//                List<HeatResultSubHeat> subheats = heatListResultProviderDao.getSubHeat(eventId, heatid, masterPersonId);
//                for (int j=0; j < subheats.size(); j++) {
//                    int subheatid = subheats.get(j).getSubheatId();
//                    HeatResultResult result = heatListResultProviderDao.getResult(eventId, subheatid, masterPersonId);
//                    int resultid = result.getId();
//                    List<String> judgeList = Utility.str2List(result.getJudgingPanel(),'|');
//                    for (String judgeStr:judgeList) {
//                        if (judgeStr.length() > 0) {
//                            if (!judgeKeys.contains(judgeStr)) {
//                                judgeKeys.add(judgeStr);
//                            }
//                        }
//                    }
//                    List<HeatResultMark> marks = heatListResultProviderDao.getMarks(eventId, subheatid, resultid);
//                    for (HeatResultMark mark:marks) {
//                        if (mark.getKey().length() > 0) {
//                            if (!competitorKeys.contains(mark.getKey())) {
//                                competitorKeys.add(mark.getKey());
//                            }
//                        }
//                    }                   
//                    result.setMarks((ArrayList)marks);
//                    subheats.get(j).setResult(result);
//                }
//                heats.get(i).setSubHeats((ArrayList)subheats);
//            }
//            List<HeatResultStudio> studios = heatListResultProviderDao.getStudios(eventId);
//            event.setStudios((ArrayList)studios);
//            List<HeatResultJudge> judges = heatListResultProviderDao.getJudgesUnfied(eventId, judgeKeys);
//            event.setJudges((ArrayList)judges);            
//  
//            List<HeatResultCompetitor> competitors = heatListResultProviderDao.getCompetitor(eventId, competitorKeys);
//            event.setCompetitors((ArrayList)competitors);
//            
//            List<HeatResultPerson> persons = heatListResultProviderDao.getPersons(eventId, competitorKeys);
//            event.setPersons((ArrayList)persons);
//
//            event.setHeats((ArrayList)heats);
//            events.add(event);
//            
//        }
//       
//        HeatResultPersonProgram program = new HeatResultPersonProgram();
//        program.setMasterPersonId(masterPersonId);
//        program.setEvents((ArrayList)events);
//        
//        try 
//        {
//            String outputXML = "/Users/vortex/Projects/java/tmp/masterperson-sample.xml";
//            File xmlfile = new File( outputXML);
//            Serializer serializer = new Persister();
//            serializer.write(program, xmlfile);
//        } catch (Exception ex) {
//               ex.printStackTrace();
//        }   

//        SimpleDateFormat formatter = new SimpleDateFormat("MM.dd.yyyy.HH.mm.ss");  
//        RegPerson person = new RegPerson();
//        person.setLastname("Lee");
//        person.setFirstname("Jason");
//        person.setCreationDate(new Date());
//        String personcode = person.getLastname().trim() + person.getFirstname().trim() + formatter.format(person.getCreationDate());
//        System.out.println(personcode); 
//        System.out.println(Utility.sqlTimestamp(person.getCreationDate()));

    }
}
